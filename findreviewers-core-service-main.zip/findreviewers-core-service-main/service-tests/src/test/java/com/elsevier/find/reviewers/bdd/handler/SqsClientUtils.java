package com.elsevier.find.reviewers.bdd.handler;

import software.amazon.awssdk.auth.credentials.AnonymousCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.CreateQueueRequest;
import software.amazon.awssdk.services.sqs.model.GetQueueUrlRequest;
import software.amazon.awssdk.services.sqs.model.Message;
import software.amazon.awssdk.services.sqs.model.PurgeQueueRequest;
import software.amazon.awssdk.services.sqs.model.ReceiveMessageRequest;
import software.amazon.awssdk.services.sqs.model.ReceiveMessageResponse;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;

import java.net.URI;
import java.util.List;

public class SqsClientUtils {
    private static SqsClient sqsClient;

    private final String sqsEndpoint;

    public SqsClientUtils(String host, int port) {
        sqsEndpoint = String.format("http://%s:%d", host, port);
    }

    public void clearQueue(String queueName) {
        PurgeQueueRequest request =
                PurgeQueueRequest.builder()
                        .queueUrl(getQueueUrl(queueName))
                        .build();
        createClient().purgeQueue(request);
    }

    public void sendMessage(String message, String queueName) {
        SendMessageRequest request =
                SendMessageRequest.builder()
                        .queueUrl(getQueueUrl(queueName))
                        .messageBody(message)
                        .build();
        createClient().sendMessage(request);
    }

    public List<Message> getMessages(String queueName) {
        ReceiveMessageRequest request =
                ReceiveMessageRequest.builder()
                        .queueUrl(getQueueUrl(queueName))
                        .build();

        ReceiveMessageResponse response = createClient().receiveMessage(request);
        return response.messages();
    }

    private String getQueueUrl(String queueName) {
        GetQueueUrlRequest request =
                GetQueueUrlRequest.builder()
                        .queueName(queueName)
                        .build();

        return createClient().getQueueUrl(request).queueUrl();
    }

    private SqsClient createClient() {
        if (sqsClient == null) {
            sqsClient = SqsClient.builder()
                    .region(Region.US_EAST_1)
                    .endpointOverride(URI.create(sqsEndpoint))
                    .credentialsProvider(AnonymousCredentialsProvider.create())
                    .build();
            sqsClient.createQueue(CreateQueueRequest.builder().queueName("rev-rec-test-em-replica-sqs-queue").build());
        }

        return sqsClient;
    }
}
