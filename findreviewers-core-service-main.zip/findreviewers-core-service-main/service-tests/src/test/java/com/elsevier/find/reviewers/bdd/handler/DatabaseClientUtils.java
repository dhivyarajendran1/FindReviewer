package com.elsevier.find.reviewers.bdd.handler;

import org.postgresql.ds.PGSimpleDataSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import software.amazon.awssdk.core.waiters.WaiterResponse;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.AttributeDefinition;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;
import software.amazon.awssdk.services.dynamodb.model.CreateTableRequest;
import software.amazon.awssdk.services.dynamodb.model.CreateTableResponse;
import software.amazon.awssdk.services.dynamodb.model.DescribeTableRequest;
import software.amazon.awssdk.services.dynamodb.model.DescribeTableResponse;
import software.amazon.awssdk.services.dynamodb.model.KeySchemaElement;
import software.amazon.awssdk.services.dynamodb.model.KeyType;
import software.amazon.awssdk.services.dynamodb.model.ProvisionedThroughput;
import software.amazon.awssdk.services.dynamodb.model.PutItemRequest;
import software.amazon.awssdk.services.dynamodb.model.ScalarAttributeType;
import software.amazon.awssdk.services.dynamodb.waiters.DynamoDbWaiter;

import java.net.URI;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class DatabaseClientUtils {

    private final NamedParameterJdbcTemplate coreJdbcTemplate;

    private final NamedParameterJdbcTemplate emJdbcTemplate;

    private final NamedParameterJdbcTemplate emReplicaJdbcTemplate;

    private final DynamoDbClient dynamoDbClient;

    public DatabaseClientUtils(String host, int postreSqlPort, int dynamoDbPort) {
        PGSimpleDataSource coreDataSource = new PGSimpleDataSource();
        coreDataSource.setURL(String.format("jdbc:postgresql://%s:%s/postgres?currentSchema=find_reviewers", host, postreSqlPort));
        coreDataSource.setUser("postgres");
        coreDataSource.setPassword("mysecretpassword");
        coreJdbcTemplate = new NamedParameterJdbcTemplate(coreDataSource);

        PGSimpleDataSource emDataSource = new PGSimpleDataSource();
        emDataSource.setURL(String.format("jdbc:postgresql://%s:%s/postgres?currentSchema=rr_ursdb", host, postreSqlPort));
        emDataSource.setUser("postgres");
        emDataSource.setPassword("mysecretpassword");
        emJdbcTemplate = new NamedParameterJdbcTemplate(emDataSource);

        PGSimpleDataSource emReplicaDataSource = new PGSimpleDataSource();
        emReplicaDataSource.setURL(String.format("jdbc:postgresql://%s:%s/postgres?currentSchema=fr_ursdb", host, postreSqlPort));
        emReplicaDataSource.setUser("postgres");
        emReplicaDataSource.setPassword("mysecretpassword");
        emReplicaJdbcTemplate = new NamedParameterJdbcTemplate(emReplicaDataSource);

        dynamoDbClient = DynamoDbClient.builder().region(Region.US_EAST_1)
                .endpointOverride(URI.create(String.format("http://%s:%d", host, dynamoDbPort))).build();
        createManuscriptAuditTable();
    }

    private void createManuscriptAuditTable() {
        String tableName = "rev-rec-test-manuscript-audit";
        DynamoDbWaiter dbWaiter = dynamoDbClient.waiter();
        CreateTableRequest request = CreateTableRequest.builder()
                .attributeDefinitions(AttributeDefinition.builder()
                                .attributeName("JournalAcronym")
                                .attributeType(ScalarAttributeType.S)
                                .build(),
                        AttributeDefinition.builder()
                                .attributeName("SortKey")
                                .attributeType(ScalarAttributeType.S)
                                .build())
                .keySchema(KeySchemaElement.builder()
                                .attributeName("JournalAcronym")
                                .keyType(KeyType.HASH)
                                .build(),
                        KeySchemaElement.builder()
                                .attributeName("SortKey")
                                .keyType(KeyType.RANGE)
                                .build())
                .provisionedThroughput(ProvisionedThroughput.builder()
                        .readCapacityUnits(10L)
                        .writeCapacityUnits(10L)
                        .build())
                .tableName(tableName)
                .build();

        try {
            CreateTableResponse response = dynamoDbClient.createTable(request);
            DescribeTableRequest tableRequest = DescribeTableRequest.builder()
                    .tableName(tableName)
                    .build();

            // Wait until the Amazon DynamoDB table is created
            WaiterResponse<DescribeTableResponse> waiterResponse = dbWaiter.waitUntilTableExists(tableRequest);
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    public void addAuditEntry() {
        PutItemRequest request = PutItemRequest.builder().tableName("rev-rec-test-manuscript-audit").item(Map.of(
                "JournalAcronym", AttributeValue.fromS("EM_ARC"),
                "SortKey", AttributeValue.fromS("456#123456789"),
                "EventTime", AttributeValue.fromN("123456789"),
                "Forced", AttributeValue.fromBool(false),
                "AdditionalInfo", AttributeValue.fromM(Map.of(
                        "Message", AttributeValue.fromS("Missing values abstract for Manuscript"),
                        "MissingAttributes", AttributeValue.fromL(List.of(AttributeValue.fromS("abstract")))
                ))
        )).build();

        dynamoDbClient.putItem(request);
    }

    public void createJournal() {
        coreJdbcTemplate.update("insert into rh_em_journal (id, em_journal_acronym, journal_acronym, classifications, em_internal_journal_id, issn_l) " +
                        "values (4, 'EM_ARC', 'ARC', '{\"classifications\": [{\"code\": \"10\", \"description\": \"CONTENT AREAS\"}, {\"code\": \"10.010\", \"parentCode\": \"10\", \"description\": \"360/multirater feedback\"}, {\"code\": \"10.020\", \"parentCode\": \"10\", \"description\": \"action learning\"}, {\"code\": \"10.030\", \"parentCode\": \"10\", \"description\": \"adult learning & development\"}, {\"code\": \"10.040\", \"parentCode\": \"10\", \"description\": \"assessment\"}, {\"code\": \"10.050\", \"parentCode\": \"10\", \"description\": \"behavioral change\"}, {\"code\": \"10.060\", \"parentCode\": \"10\", \"description\": \"boards/governance\"}, {\"code\": \"10.070\", \"parentCode\": \"10\", \"description\": \"bullying\"}, {\"code\": \"10.080\", \"parentCode\": \"10\", \"description\": \"career transition\"}, {\"code\": \"10.090\", \"parentCode\": \"10\", \"description\": \"change management\"}, {\"code\": \"10.100\", \"parentCode\": \"10\", \"description\": \"character\"}, {\"code\": \"10.110\", \"parentCode\": \"10\", \"description\": \"coaching\"}, {\"code\": \"10.120\", \"parentCode\": \"10\", \"description\": \"cognitive-behavioral therapy\"}, {\"code\": \"10.130\", \"parentCode\": \"10\", \"description\": \"community psychology\"}, {\"code\": \"10.140\", \"parentCode\": \"10\", \"description\": \"competencies\"}, {\"code\": \"10.150\", \"parentCode\": \"10\", \"description\": \"conflict resolution\"}, {\"code\": \"10.160\", \"parentCode\": \"10\", \"description\": \"consulting process\"}, {\"code\": \"10.170\", \"parentCode\": \"10\", \"description\": \"cross-cultural issues\"}, {\"code\": \"10.180\", \"parentCode\": \"10\", \"description\": \"decision-making\"}, {\"code\": \"10.190\", \"parentCode\": \"10\", \"description\": \"destructive leadership\"}, {\"code\": \"10.200\", \"parentCode\": \"10\", \"description\": \"diversity\"}, {\"code\": \"10.210\", \"parentCode\": \"10\", \"description\": \"employee attitudes\"}, {\"code\": \"10.220\", \"parentCode\": \"10\", \"description\": \"employee involvement\"}, {\"code\": \"10.230\", \"parentCode\": \"10\", \"description\": \"employee selection\"}, {\"code\": \"10.240\", \"parentCode\": \"10\", \"description\": \"engagement\"}, {\"code\": \"10.250\", \"parentCode\": \"10\", \"description\": \"ethics\"}, {\"code\": \"10.260\", \"parentCode\": \"10\", \"description\": \"executive education\"}, {\"code\": \"10.270\", \"parentCode\": \"10\", \"description\": \"executive selection\"}, {\"code\": \"10.280\", \"parentCode\": \"10\", \"description\": \"feedback\"}, {\"code\": \"10.290\", \"parentCode\": \"10\", \"description\": \"generational differences\"}, {\"code\": \"10.300\", \"parentCode\": \"10\", \"description\": \"globalization\"}, {\"code\": \"10.310\", \"parentCode\": \"10\", \"description\": \"group dynamics\"}, {\"code\": \"10.320\", \"parentCode\": \"10\", \"description\": \"health psychology\"}, {\"code\": \"10.330\", \"parentCode\": \"10\", \"description\": \"high potentials\"}, {\"code\": \"10.340\", \"parentCode\": \"10\", \"description\": \"human resource management\"}, {\"code\": \"10.350\", \"parentCode\": \"10\", \"description\": \"individual assessment\"}, {\"code\": \"10.360\", \"parentCode\": \"10\", \"description\": \"innovation\"}, {\"code\": \"10.370\", \"parentCode\": \"10\", \"description\": \"international consulting\"}, {\"code\": \"10.380\", \"parentCode\": \"10\", \"description\": \"job performance\"}, {\"code\": \"10.390\", \"parentCode\": \"10\", \"description\": \"job satisfaction\"}, {\"code\": \"10.400\", \"parentCode\": \"10\", \"description\": \"leadership\"}, {\"code\": \"10.410\", \"parentCode\": \"10\", \"description\": \"leadership development\"}, {\"code\": \"10.420\", \"parentCode\": \"10\", \"description\": \"legal issues/litigation\"}, {\"code\": \"10.430\", \"parentCode\": \"10\", \"description\": \"management\"}, {\"code\": \"10.440\", \"parentCode\": \"10\", \"description\": \"motivation\"}, {\"code\": \"10.450\", \"parentCode\": \"10\", \"description\": \"multicultural issues\"}, {\"code\": \"10.460\", \"parentCode\": \"10\", \"description\": \"on-boarding/assimilation\"}, {\"code\": \"10.470\", \"parentCode\": \"10\", \"description\": \"organization development\"}, {\"code\": \"10.480\", \"parentCode\": \"10\", \"description\": \"organizational behavior\"}, {\"code\": \"10.490\", \"parentCode\": \"10\", \"description\": \"organizational change\"}, {\"code\": \"10.500\", \"parentCode\": \"10\", \"description\": \"organizational consultation\"}, {\"code\": \"10.510\", \"parentCode\": \"10\", \"description\": \"organizational culture\"}, {\"code\": \"10.520\", \"parentCode\": \"10\", \"description\": \"organizational development\"}, {\"code\": \"10.530\", \"parentCode\": \"10\", \"description\": \"organizational diagnosis\"}, {\"code\": \"10.540\", \"parentCode\": \"10\", \"description\": \"organizational performance\"}, {\"code\": \"10.550\", \"parentCode\": \"10\", \"description\": \"performance management\"}, {\"code\": \"10.560\", \"parentCode\": \"10\", \"description\": \"personality\"}, {\"code\": \"10.570\", \"parentCode\": \"10\", \"description\": \"positive psychology\"}, {\"code\": \"10.580\", \"parentCode\": \"10\", \"description\": \"process consultation\"}, {\"code\": \"10.590\", \"parentCode\": \"10\", \"description\": \"professional practice guidelines\"}, {\"code\": \"10.600\", \"parentCode\": \"10\", \"description\": \"professional training & education\"}, {\"code\": \"10.610\", \"parentCode\": \"10\", \"description\": \"psychodynamics\"}, {\"code\": \"10.620\", \"parentCode\": \"10\", \"description\": \"relocation/expatriation\"}, {\"code\": \"10.630\", \"parentCode\": \"10\", \"description\": \"strategy\"}, {\"code\": \"10.640\", \"parentCode\": \"10\", \"description\": \"stress\"}, {\"code\": \"10.650\", \"parentCode\": \"10\", \"description\": \"succession/succession planning\"}, {\"code\": \"10.660\", \"parentCode\": \"10\", \"description\": \"systems theory\"}, {\"code\": \"10.670\", \"parentCode\": \"10\", \"description\": \"talent management\"}, {\"code\": \"10.680\", \"parentCode\": \"10\", \"description\": \"teams\"}, {\"code\": \"10.690\", \"parentCode\": \"10\", \"description\": \"telehealth\"}, {\"code\": \"10.700\", \"parentCode\": \"10\", \"description\": \"test construction\"}, {\"code\": \"10.710\", \"parentCode\": \"10\", \"description\": \"training\"}, {\"code\": \"20\", \"description\": \"RESEARCH METHODS\"}, {\"code\": \"20.010\", \"parentCode\": \"20\", \"description\": \"Basic statistics\"}, {\"code\": \"20.020\", \"parentCode\": \"20\", \"description\": \"Advanced statistics\"}, {\"code\": \"20.030\", \"parentCode\": \"20\", \"description\": \"Experimental design\"}, {\"code\": \"20.040\", \"parentCode\": \"20\", \"description\": \"Case study methods\"}, {\"code\": \"30.050\", \"parentCode\": \"30\", \"description\": \"Content analysis\"}, {\"code\": \"30\", \"description\": \"Medicine\"}]}', 111, '1111-2222')",
                Collections.emptyMap());

        coreJdbcTemplate.update("insert into eph_journal (acronym, title, issn_l, status) " +
                "values ('ARC', 'Journal Title', '1111-2222', 1)", Collections.emptyMap());

        emJdbcTemplate.update("insert into \"JOURNAL_INFO\" (\"UDB_ID\",\"JOURNAL_ID\",\"JOURNAL\",\"FULLTITLE\",\"JOURNAL__upper\", pts_code) values " +
                "(1,123,'EM_ARC','My Test Journal','EM_ARC','ARC')", Collections.emptyMap());

        emReplicaJdbcTemplate.update("insert into journal_info (udb_id, id, journal_id, journal, fulltitle, journal__upper, pts_code) values " +
                "(1, 1, 123, 'EM_ARC', 'My Test Journal', 'EM_ARC', 'ARC')", Collections.emptyMap());
    }

    public void createReviewVolunteer() {
        coreJdbcTemplate.update("insert into rh_review_volunteer (web_user_id, email, display_name, given_name, family_name, journal_acronym, " +
                        "volunteer_date, reason, message, classifications,scopus_ids) " +
                        "values (33,'fred@bedrock.com', 'Fred Flintstone', 'Fred', 'Flintstone', 'ARC', 1222223, 'ExpertOrInterest', " +
                        "'Please let me review', '{\"classifications\": [{\"code\": \"4\", \"description\": \"Chemistry of deposition and growth\"}, " +
                        "{\"code\": \"10\", \"description\": \"Growth\"}]}'::jsonb,'{\"scopus\": [\"57214008172\", \"23991127100\"]}')",
                Collections.emptyMap());
    }

    public void createEditorLogin() {
        coreJdbcTemplate.update("insert into rh_editor (editor_id, editor_journal_id, journal_acronym, classification, email) " +
                "values (1111, 2222, 'ARC', 'highestRanking', 'fred@bedrock.com')", Collections.emptyMap());
    }

    public void createCAL() {
        coreJdbcTemplate.update("insert into eph_content_lead (journal_acronym, email) values ('ARC', 'fred@bedrock.com')",
                Collections.emptyMap());
    }

    public void createEditor() {
        coreJdbcTemplate.update("insert into rh_editor (editor_id, editor_journal_id, journal_acronym, classification, email, scopus_ids) " +
                        "values (44, 55, 'ARC', 'editorialBoardMember', 'barney@bedrock.com','{\"scopus\": [\"57214008172\", \"23991127100\"]}')",
                Collections.emptyMap());
    }

    public void createCrowdsourcedReview() {
        coreJdbcTemplate.update("insert into rh_crowdsourced_manuscript_review (id, journal_acronym, document_id, scopus_ids, email, volunteer_date) " +
                "values (66, 'ARC', 333,'{\"scopus\": [\"111222333\"]}', 'betty@bedrock.com', 123456789)", Collections.emptyMap());
    }

    public void createManuscript() {
        emJdbcTemplate.update("insert into \"DOCUMENT\" (\"UDB_ID\",\"JOURNAL_ID\",\"DTITLE\",\"PUBDNUMBER\",\"DOCUMENTID\",\"REVISION\") " +
                "values (2,123,'Manuscript Title','PubNumber',333, 0)", Collections.emptyMap());

        emJdbcTemplate.update("insert into \"KEYWDATA\" (\"UDB_ID\",\"JOURNAL_ID\",\"DOCUMENTID\",\"KEYWORDID\") " +
                "values (3,123,333, 444)", Collections.emptyMap());

        emJdbcTemplate.update("insert into \"KEYWORD\" (\"UDB_ID\",\"JOURNAL_ID\",\"KEYWORDID\",\"WORD\") " +
                "values (4,123,444, 'My Keyword')", Collections.emptyMap());

        emReplicaJdbcTemplate.update("insert into document (udb_id, journal_id, dtitle, pubdnumber, documentid, revision) " +
                "values (2, 123, 'Manuscript Title', 'PubNumber', 333, 0)", Collections.emptyMap());

        emReplicaJdbcTemplate.update("insert into keywdata (udb_id, keywdataid, journal_id, documentid, keywordid) " +
                "values (3, 3, 123, 333, 444)", Collections.emptyMap());

        emReplicaJdbcTemplate.update("insert into keyword (udb_id, journal_id, keywordid, word) " +
                "values (4,123,444, 'My Keyword')", Collections.emptyMap());
    }

    public void createManuscriptReviewer() {
        emJdbcTemplate.update("insert into \"ROLEREVU\" (\"UDB_ID\",\"JOURNAL_ID\",\"DOCUMENTID\",\"REVISION\",\"PEOPLEID\",\"WORKINPROGRESS\") values " +
                "(3,123,333,0, 666, true)", Collections.emptyMap());

        emJdbcTemplate.update("insert into \"PEOPLE\" (\"UDB_ID\",\"JOURNAL_ID\",\"PEOPLEID\",\"FIRSTNAME\",\"LASTNAME\") " +
                "values (4,123,666,'Fred','Flintstone')", Collections.emptyMap());

        emJdbcTemplate.update("insert into \"ADDRESS_EMAIL\" (\"UDB_ID\",\"JOURNAL_ID\",\"PeopleID\",\"Email\",\"Email__lower\") " +
                "values (5,123,666,'fred@bedrock.com','fred@bedrock.com')", Collections.emptyMap());

        emReplicaJdbcTemplate.update("insert into rolerevu (udb_id, roleid, journal_id, documentid, revision, peopleid, workinprogress) values " +
                "(3, 3, 123, 333, 0, 666, true)", Collections.emptyMap());

        emReplicaJdbcTemplate.update("insert into people (udb_id, journal_id, peopleid, firstname, lastname) " +
                "values (4, 123, 666, 'Fred', 'Flintstone')", Collections.emptyMap());

        emReplicaJdbcTemplate.update("insert into address_email (udb_id, id, journal_id, peopleid, email, email__lower) " +
                "values (5, 5, 123, 666, 'fred@bedrock.com', 'fred@bedrock.com')", Collections.emptyMap());
    }
}
