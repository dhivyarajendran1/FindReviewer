package com.elsevier.find.reviewers.bdd.steps;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.elsevier.find.reviewers.bdd.handler.FindReviewersHandler;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.RestAssured;
import software.amazon.awssdk.services.sqs.model.Message;

import java.util.Base64;
import java.util.List;

import static io.restassured.RestAssured.given;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.nullValue;

public class FindReviewersSteps {
    private final FindReviewersHandler handler = FindReviewersHandler.getInstance();

    @Before
    public void setup() {
        RestAssured.baseURI = handler.getCoreServiceBaseUri();
        RestAssured.port = 443;
    }

    @Given("^a find reviewers service$")
    public void aFindReviewersService() {
        handler.waitForFindReviewersService();
    }

    @Then("^service availability can be determined$")
    public void serviceAvailabilityCanBeDetermined() {
        handler.validateServiceSuccessResponse();
    }

    @Then("^ID Plus Find Reviewers Authentication works$")
    public void idPlusFindReviewersAuthentication() {
        handler.getDatabaseClientUtils().createJournal();
        handler.getDatabaseClientUtils().createEditorLogin();
        String jwtToken = JWT.create().withIssuer("Elsevier")
                .withClaim("email", "fred@bedrock.com")
                .withClaim("email_verified", true)
                .withSubject("1234")
                .sign(Algorithm.HMAC384("secret"));

        given().header("x-amzn-oidc-data", jwtToken)
                .header("X-Scope", "FR-IDP-ACR")
                .contentType("application/json")
                .body("{\"emJournalAcronym\": \"EM_ARC\"}")
                .post("/authenticate")
                .then()
                .statusCode(200);
    }

    @And("^ID Plus Find Editors Authentication works$")
    public void idPlusFindEditorsAuthentication() {
        handler.getDatabaseClientUtils().createCAL();
        String jwtToken = JWT.create().withIssuer("Elsevier")
                .withClaim("email", "fred@bedrock.com")
                .withClaim("email_verified", true)
                .withSubject("1234")
                .sign(Algorithm.HMAC384("secret"));

        given().header("x-amzn-oidc-data", jwtToken)
                .header("X-Scope", "FE-IDP")
                .contentType("application/json")
                .body("{\"emJournalAcronym\": \"EM_ARC\"}")
                .post("/authenticate")
                .then()
                .statusCode(200);

        given().header("x-amzn-oidc-data", jwtToken)
                .header("X-Scope", "FE-IDP")
                .contentType("application/json")
                .body("{}")
                .post("/authenticate")
                .then()
                .statusCode(200);

        // Additional access provided by Reviewer Hub API call
        jwtToken = JWT.create().withIssuer("Elsevier")
                .withClaim("email", "wilma@bedrock.com")
                .withClaim("email_verified", true)
                .withSubject("1234")
                .sign(Algorithm.HMAC384("secret"));

        given().header("x-amzn-oidc-data", jwtToken)
                .header("X-Scope", "FE-IDP")
                .contentType("application/json")
                .body("{\"emJournalAcronym\": \"EM_ARC\"}")
                .post("/authenticate")
                .then()
                .statusCode(200);
    }

    @Then("^initialisation is empty$")
    public void noInitialisation() {
        given().cookie("FR-EM-ACR", getCookieValue())
                .header("X-Scope", "FR-EM-ACR")
                .queryParam("emJournalAcronym", "TEST_ACR")
                .queryParam("documentId", 123)
                .get("/initialisation").then().statusCode(200);

        // No document Id
        given().cookie("FE-IDP", getCookieValue())
                .header("X-Scope", "FE-IDP")
                .queryParam("emJournalAcronym", "TEST_ACR")
                .get("/initialisation").then().statusCode(400);

        // No Journal Acronym
        given().cookie("FE-IDP", getCookieValue())
                .header("X-Scope", "FE-IDP")
                .get("/initialisation").then().statusCode(400);
    }

    @Then("^manuscript is empty$")
    public void noManuscript() {
        given().cookie("FR-EM-ACR", getCookieValue())
                .header("X-Scope", "FR-EM-ACR")
                .queryParam("emJournalAcronym", "TEST_ACR")
                .queryParam("documentId", 123)
                .get("/manuscripts").then().statusCode(200);
    }

    @Then("^initialisation is populated$")
    public void populatedInitialisation() {
        handler.getDatabaseClientUtils().createManuscript();

        given().cookie("FR-EM-ACR", getCookieValue())
                .header("X-Scope", "FR-EM-ACR")
                .queryParam("emJournalAcronym", "EM_ARC")
                .queryParam("documentId", 333)
                .get("/initialisation").then().statusCode(200)
                .body("permittedFeatures.size()", equalTo(10))
                .body("permittedFeatures[0]", equalTo("addedReviewers"))
                .body("permittedFeatures[1]", equalTo("authorSearch"))
                .body("permittedFeatures[2]", equalTo("keywordSearch"))
                .body("permittedFeatures[3]", equalTo("sessionPreferences"))
                .body("permittedFeatures[4]", equalTo("recommendations"))
                .body("permittedFeatures[5]", equalTo("volunteers"))
                .body("permittedFeatures[6]", equalTo("manuscriptDetails"))
                .body("permittedFeatures[7]", equalTo("reviewerHistory"))
                .body("permittedFeatures[8]", equalTo("reviewerLimits"))
                .body("permittedFeatures[9]", equalTo("journalReviewers"))
                .body("journalIssnl", equalTo("1111-2222"))
                .body("journalClassifications.size()", equalTo(3))
                .body("keywords[0]", equalTo("My Keyword"))
                .body("reviewers", nullValue())
                .body("editorialBoardMembers", nullValue());
    }

    @Then("^manuscript is populated$")
    public void populatedManuscript() {
        given().cookie("FR-EM-ACR", getCookieValue())
                .header("X-Scope", "FR-EM-ACR")
                .queryParam("emJournalAcronym", "EM_ARC")
                .queryParam("documentId", 333)
                .get("/manuscripts").then().statusCode(200)
                .body("manuscriptNumber", equalTo("PubNumber"))
                .body("title", equalTo("Manuscript Title"));
    }

    @Then("^non URSDB manuscript is populated$")
    public void populatedNonUrsdbManuscript() {
        given().cookie("FR-EM-ACR", getNonURSDBCookieValue())
                .header("X-Scope", "FR-EM-ACR")
                .queryParam("emJournalAcronym", "CELL")
                .queryParam("documentId", 333)
                .get("/initialisation").then().statusCode(200)
                .body("permittedFeatures.size()", equalTo(7))
                .body("permittedFeatures[0]", equalTo("addedReviewers"))
                .body("permittedFeatures[1]", equalTo("authorSearch"))
                .body("permittedFeatures[2]", equalTo("keywordSearch"))
                .body("permittedFeatures[3]", equalTo("sessionPreferences"))
                .body("permittedFeatures[4]", equalTo("manuscriptDetails"))
                .body("permittedFeatures[5]", equalTo("reviewerHistory"))
                .body("permittedFeatures[6]", equalTo("reviewerLimits"))
                .body("journalIssnl", equalTo("0092-8674"));
    }

    @Then("^non Elsevier manuscript is populated$")
    public void populatedNonElsevierManuscript() {
        given().cookie("FR-EM-ACR", getNonURSDBCookieValue())
                .header("X-Scope", "FR-EM-ACR")
                .queryParam("emJournalAcronym", "NON-ELSEVIER")
                .queryParam("documentId", 333)
                .get("/initialisation").then().statusCode(200)
                .body("permittedFeatures.size()", equalTo(5))
                .body("permittedFeatures[0]", equalTo("addedReviewers"))
                .body("permittedFeatures[1]", equalTo("authorSearch"))
                .body("permittedFeatures[2]", equalTo("keywordSearch"))
                .body("permittedFeatures[3]", equalTo("sessionPreferences"))
                .body("permittedFeatures[4]", equalTo("manuscriptDetails"));
    }

    @Then("^manuscript is populated with reviewers$")
    public void reviewersManuscript() {
        handler.getDatabaseClientUtils().createManuscriptReviewer();

        given().cookie("FR-EM-ACR", getCookieValue())
                .header("X-Scope", "FR-EM-ACR")
                .queryParam("emJournalAcronym", "EM_arc")
                .queryParam("documentId", 333)
                .get("/initialisation").then().statusCode(200)
                .body("journalIssnl", equalTo("1111-2222"))
                .body("journalClassifications.size()", equalTo(3))
                .body("reviewers.size()", equalTo(1))
                .body("reviewers[0].firstName", equalTo("Fred"))
                .body("reviewers[0].lastName", equalTo("Flintstone"))
                .body("reviewers[0].emails[0]", equalTo("fred@bedrock.com"))
                .body("reviewers[0].status", equalTo("InProgress"))
                .body("editorialBoardMembers", nullValue());
    }

    @Then("^manuscript is populated with editors and crowdsourced reviewers$")
    public void editorsAndCrowdsourcedManuscript() {
        handler.getDatabaseClientUtils().createEditor();
        handler.getDatabaseClientUtils().createCrowdsourcedReview();

        given().cookie("FR-EM-ACR", getCookieValue())
                .header("X-Scope", "FR-EM-ACR")
                .queryParam("emJournalAcronym", "EM_arc")
                .queryParam("documentId", 333)
                .get("/initialisation").then().statusCode(200)
                .body("journalIssnl", equalTo("1111-2222"))
                .body("journalClassifications.size()", equalTo(3))
                .body("crowdsourcedReviewers.size()", equalTo(1))
                .body("crowdsourcedReviewers[0].email", equalTo("betty@bedrock.com"))
                .body("crowdsourcedReviewers[0].scopusIds.size()", equalTo(1))
                .body("crowdsourcedReviewers[0].scopusIds[0]", equalTo("111222333"));
    }

    @Then("^listing volunteers for \"([^\"]*)\" returns an empty list$")
    public void emptyVolunteers(String status) {
        given().cookie("FR-EM-ACR", getCookieValue())
                .header("X-Scope", "FR-EM-ACR")
                .queryParam("emJournalAcronym", "TEST_ACR")
                .queryParam("statusFilter", status)
                .get("/volunteers").then().statusCode(200)
                .body("volunteers.size()", equalTo(0));
    }

    @Then("^list single volunteer$")
    public void singleVolunteer() {
        handler.getDatabaseClientUtils().createReviewVolunteer();

        given().cookie("FR-EM-ACR", getCookieValue())
                .header("X-Scope", "FR-EM-ACR")
                .queryParam("emJournalAcronym", "EM_ARC")
                .queryParam("limit", 1)
                .get("/volunteers").then().statusCode(200)
                .body("volunteers.size()", equalTo(1))
                .body("volunteers[0].displayName", equalTo("Fred Flintstone"))
                .body("volunteers[0].classificationCodes.size()", equalTo(2));
    }

    @Then("^list volunteer filtered by classification$")
    public void filteredClassificationsVolunteer() {
        given().cookie("FR-EM-ACR", getCookieValue())
                .header("X-Scope", "FR-EM-ACR")
                .queryParam("emJournalAcronym", "EM_arc")
                .queryParam("classificationCodes", "10")
                .queryParam("limit", 1)
                .get("/volunteers").then().statusCode(200)
                .body("volunteers.size()", equalTo(1))
                .body("volunteers[0].displayName", equalTo("Fred Flintstone"))
                .body("volunteers[0].classificationCodes.size()", equalTo(2));
    }

    @Then("^scopus search returns valid results$")
    public void scopusSearch() {
        given().cookie("FR-EM-ACR", getCookieValue())
                .header("X-Scope", "FR-EM-ACR")
                .queryParam("emJournalAcronym", "TEST_ACR")
                .queryParam("keywords", "TestSearch")
                .get("/scopus").then().statusCode(200)
                .body("authors.size()", equalTo(1))
                .body("authors[0].emails[0]", equalTo("fred@bedrock.com"))
                .body("authors[0].displayName", equalTo("Fred Flintstone"))
                .body("authors[0].hindex", equalTo(24));
    }

    @Then("^scopus id lookup can be called$")
    public void scopusLookup() {
        given().cookie("FR-EM-ACR", getCookieValue())
                .header("X-Scope", "FR-EM-ACR")
                .queryParam("emJournalAcronym", "ACR")
                .get("/scopus/12345").then().statusCode(404);

        // No Journal Acronym
        given().cookie("FE-IDP", getCookieValue())
                .header("X-Scope", "FE-IDP")
                .get("/scopus/12345").then().statusCode(404);
    }

    @Then("^recommendations returns not found$")
    public void recommendationsNotFound() {
        handler.getSqsClientUtils().clearQueue("rev-rec-test-em-replica-sqs-queue");

        given().cookie("FR-EM-ACR", getCookieValue())
                .header("X-Scope", "FR-EM-ACR")
                .queryParam("emJournalAcronym", "EM_ARC")
                .queryParam("documentId", "456")
                .get("/recommendations/MAN_123").then().statusCode(404);

        List<Message> messages = handler.getSqsClientUtils().getMessages("rev-rec-test-em-replica-sqs-queue");
        assertThat(messages.size(), equalTo(1));

        assertThat(messages.get(0).body(), equalTo("""
                {"operation": "UPDATE", "force": true, "journal_id": 123, "document_id": 456 }
                """));

// This is the format for the original URSDB - can clean up later, left here so tests can be switched between them
//        assertThat(messages.get(0).body(), equalTo("""
//                {"operation": "UPSERT", "force": true, "manuscripts": [{"journalId": 123, "journalAcronym": "EM_ARC", "documentId": 456 }]}
//                """));
    }

    @Then("^recommendations returns not found due to missing data$")
    public void recommendationsNotFoundDueToMissingData() {
        handler.getSqsClientUtils().clearQueue("rev-rec-test-em-replica-sqs-queue");
        handler.getDatabaseClientUtils().addAuditEntry();

        given().cookie("FR-EM-ACR", getCookieValue())
                .header("X-Scope", "FR-EM-ACR")
                .queryParam("emJournalAcronym", "EM_ARC")
                .queryParam("documentId", "456")
                .get("/recommendations/MAN_123").then()
                .statusCode(404)
                .body("missingManuscriptData.size()", equalTo(1))
                .body("missingManuscriptData[0]", equalTo("Abstract"));

        List<Message> messages = handler.getSqsClientUtils().getMessages("rev-rec-test-em-replica-sqs-queue");
        assertThat(messages.size(), equalTo(1));

        assertThat(messages.get(0).body(), equalTo("""
                {"operation": "UPDATE", "force": true, "journal_id": 123, "document_id": 456 }
                """));

// This is the format for the original URSDB - can clean up later, left here so tests can be switched between them
//        assertThat(messages.get(0).body(), equalTo("""
//                {"operation": "UPSERT", "force": true, "manuscripts": [{"journalId": 123, "journalAcronym": "EM_ARC", "documentId": 456 }]}
//                """));
    }

    @Then("^editors is empty$")
    public void noEditors() {
        given().cookie("FR-EM-ACR", getCookieValue())
                .header("X-Scope", "FR-EM-ACR")
                .queryParam("emJournalAcronym", "TEST_ACR")
                .get("/editors").then().statusCode(200);
    }

    @Then("^editors for non ursdb$")
    public void nonUrsdbEditors() {
        given().cookie("FR-EM-CELL", getCookieValue())
                .header("X-Scope", "FR-EM-CELL")
                .queryParam("emJournalAcronym", "CELL")
                .get("/editors").then().statusCode(200);
    }

    @Then("^author search returns valid results$")
    public void authorSearch() {
        given().cookie("FR-EM-ACR", getCookieValue())
                .header("X-Scope", "FR-EM-ACR")
                .queryParam("emJournalAcronym", "TEST_ACR")
                .queryParam("firstName", "Fred")
                .get("/authors").then().statusCode(200)
                .body("authors.size()", equalTo(1))
                .body("authors[0].emails[0]", equalTo("fred@bedrock.com"))
                .body("authors[0].displayName", equalTo("Fred Flintstone"))
                .body("authors[0].hindex", equalTo(20));

        // No Journal Acronym
        given().cookie("FE-IDP", getCookieValue())
                .header("X-Scope", "FE-IDP")
                .queryParam("firstName", "Fred")
                .get("/authors").then().statusCode(200)
                .body("authors.size()", equalTo(1))
                .body("authors[0].emails[0]", equalTo("fred@bedrock.com"))
                .body("authors[0].displayName", equalTo("Fred Flintstone"))
                .body("authors[0].hindex", equalTo(20));
    }

    @Then("^a crowdsourced reviewer can be rejected$")
    public void rejectCrowdsourceReviewer() {
        given().cookie("FR-EM-ACR", getCookieValue())
                .header("X-Scope", "FR-EM-ACR")
                .queryParam("emJournalAcronym", "EM_ARC")
                .queryParam("documentId", 333)
                .queryParam("emails", "betty@bedrock.com")
                .delete("/reviewers").then().statusCode(200);
    }

    @Then("^candidate details is empty$")
    public void noCandidateDetails() {
        given().cookie("FR-EM-ACR", getCookieValue())
                .header("X-Scope", "FR-EM-ACR")
                .queryParam("emJournalAcronym", "TEST_ACR")
                .queryParam("emails", "betty@bedrock.com")
                .get("/candidates").then().statusCode(200);
    }

    @Then("^journal reviewers is empty$")
    public void noJournalReviewers() {
        given().cookie("FR-EM-ACR", getCookieValue())
                .header("X-Scope", "FR-EM-ACR")
                .queryParam("emJournalAcronym", "TEST_ACR")
                .queryParam("keywords", "keyword")
                .queryParam("limit", "200")
                .get("/journalReviewers").then().statusCode(200);
    }

    @Then("^referenced authors is empty$")
    public void noReferencedAuthors() {
        given().cookie("FR-EM-ACR", getCookieValue())
                .header("X-Scope", "FR-EM-ACR")
                .queryParam("emJournalAcronym", "TEST_ACR")
                .queryParam("documentId", 123L)
                .get("/referencedAuthors").then().statusCode(200);
    }

    @Then("^conflict of interest is returned$")
    public void conflictOfInterest() {
        given().cookie("FR-EM-ACR", getCookieValue())
                .header("X-Scope", "FR-EM-ACR")
                .queryParam("authorScopusIds", "6543")
                .queryParam("reviewerScopusIds", "1234")
                .get("/conflictOfInterest").then().statusCode(200)
                .body("reviewers[0].scopusId", equalTo("1234"))
                .body("reviewers[0].indicators[0]", equalTo("SameInstitution"));
    }

    @Then("^journals are returned$")
    public void journals() {
        given().cookie("FR-EM-ACR", getCookieValue())
                .header("X-Scope", "FR-EM-ACR")
                .get("/journals").then().statusCode(200)
                .body("journals[0].emJournalAcronym", equalTo("EM_ARC"))
                .body("journals[0].title", equalTo("Journal Title"));
    }

    private String getCookieValue() {
        return Base64.getEncoder().encodeToString("{\"c\": \"s\", \"b\": \"b\", \"j\": \"ACR\", \"r\": false, \"u\": true}".getBytes());
    }

    private String getNonURSDBCookieValue() {
        return Base64.getEncoder().encodeToString("{\"c\": \"s\", \"b\": \"b\", \"j\": \"ACR\", \"r\": false, \"u\": false}".getBytes());
    }
}
