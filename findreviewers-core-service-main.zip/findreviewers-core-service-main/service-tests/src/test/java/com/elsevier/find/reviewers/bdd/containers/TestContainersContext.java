package com.elsevier.find.reviewers.bdd.containers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.containers.Network;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.containers.localstack.LocalStackContainer;
import org.testcontainers.images.builder.ImageFromDockerfile;
import org.testcontainers.lifecycle.Startables;
import org.testcontainers.utility.DockerImageName;
import org.testcontainers.utility.MountableFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import static java.nio.file.Files.walk;
import static java.util.Objects.requireNonNull;

public class TestContainersContext {
    private static final Logger logger = LoggerFactory.getLogger(TestContainersContext.class);

    private static final int INTERNAL_DEBUGGER_PORT = 8181;

    private static final Network serviceTestsNetwork = Network.newNetwork();

    private static final Path coreServiceDockerfile = Paths.get(
            System.getProperty("service_build_context",
                    locateServiceDockerfile("findreviewers-service", "Dockerfile"))
    );

    private static final PostgreSQLContainer<?> postgreSQLContainer = new PostgreSQLContainer<>("postgres:15-alpine")
            .withNetworkAliases("find-reviewers-db")
            .withInitScript("./META-INF/find-reviewers-all-schema.sql")
            .withDatabaseName("postgres")
            .withUsername("postgres")
            .withPassword("mysecretpassword")
            .withNetwork(serviceTestsNetwork);

    private static final LocalStackContainer awsContainer = new LocalStackContainer(DockerImageName.parse("localstack/localstack:latest"))
            .withServices(LocalStackContainer.Service.DYNAMODB, LocalStackContainer.Service.SQS)
            .withNetworkAliases("localstack")
            .withNetwork(serviceTestsNetwork);

    private static final GenericContainer<?> personFinderContainer = new GenericContainer<>("wiremock/wiremock:main-alpine")
            .withNetworkAliases("externalapis")
            .withCopyFileToContainer(MountableFile.forHostPath("./externalapis/"), "/home/wiremock/")
            .withExposedPorts(8080)
            .withNetwork(serviceTestsNetwork);

    private static final GenericContainer<?> coreServiceContainer = createCoreServiceContainer()
            .withNetworkAliases("core-service")
            .withExposedPorts(8999, INTERNAL_DEBUGGER_PORT)
            .withEnv("SPRING_PROFILES_ACTIVE", "servicetests")
            .withEnv("NEW_RELIC_AGENT_ENABLED", "false")
            .withEnv("AWS_ACCESS_KEY_ID", "x")
            .withEnv("AWS_SECRET_ACCESS_KEY", "x")
            .withEnv("rev.rec.aws.sqs.endpoint.override", "http://localstack:4566")
            .withEnv("rev.rec.aws.dynamodb.endpoint.override", "http://localstack:4566")
            .withEnv("findreviewers.cloud.ursdb", "true")
            .withEnv("JAVA_TOOL_OPTIONS",
                    String.format("-agentlib:jdwp=transport=dt_socket,address=*:%s,server=y,suspend=n",
                            INTERNAL_DEBUGGER_PORT)
            )
            .withNetwork(serviceTestsNetwork)
            .dependsOn(postgreSQLContainer, awsContainer, personFinderContainer);

    private static GenericContainer<?> createCoreServiceContainer() {
        String imageName = System.getenv("DOCKER_IMAGE");

        logger.info("DOCKER_IMAGE env variable: {}", imageName);

        return imageName == null || imageName.length() == 0 || !imageName.contains("find-reviewers-service") ?
                // Build container from the local docker file
                new GenericContainer<>(
                        new ImageFromDockerfile()
                                .withDockerfile(coreServiceDockerfile)
                ) :
                // Use the image specified in environment variables
                new GenericContainer<>(imageName);
    }

    public static List<GenericContainer<?>> startContainers() {
        Startables.deepStart(Stream.of(postgreSQLContainer, awsContainer, personFinderContainer, coreServiceContainer)).join();
        /*
           Exposed debugger port will be random, so you will need to determine what it is before connecting to the service via the remote debugger
         */
        logger.info("Service debugger port is: {}", coreServiceContainer.getMappedPort(INTERNAL_DEBUGGER_PORT));

        return Arrays.asList(postgreSQLContainer, awsContainer, personFinderContainer, coreServiceContainer);
    }

    /*
      Here we account for differences in default working directory for different OS combinations in IDEs
      We first try to locate the Dockerfile in the `user.dir`
      - https://softwareengineering.stackexchange.com/questions/302988/trying-to-understand-on-what-user-dir-property-actually-means
      If it isn't found there, we go one directory up and walk the child directories to find the Dockerfile we require
    */
    private static String locateServiceDockerfile(String... dockerFilePath) {
        Path locatedDockerFilePath = null;
        String userDir = System.getProperty("user.dir");
        Path dockerFilePathInCurrentDirectory = Paths.get(userDir, dockerFilePath);
        if (Files.exists(dockerFilePathInCurrentDirectory)) {
            logger.info("Found Dockerfile in current path");
            return dockerFilePathInCurrentDirectory.toAbsolutePath().toString();
        }
        try (Stream<Path> paths = walk(Paths.get(userDir).getParent())) {
            locatedDockerFilePath = paths
                    .filter(path -> path.endsWith(Paths.get("", dockerFilePath)))
                    .findFirst().orElse(null);
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (locatedDockerFilePath != null) {
            logger.info("Found Dockerfile in parent path");
        } else {
            logger.warn("Could not locate Dockerfile, test will most likely fail to run");
        }
        return requireNonNull(locatedDockerFilePath).toAbsolutePath().toString();
    }
}
