package com.elsevier.find.reviewers.bdd.handler;

import com.elsevier.find.reviewers.bdd.containers.TestContainersContext;
import org.testcontainers.containers.GenericContainer;

import java.util.List;
import java.util.Objects;

import static io.restassured.RestAssured.get;

public class FindReviewersHandler {
    private static final String LOCALHOST = "localhost";
    private static final int POSTGRES_PORT = 5432;
    private static final int SQS_PORT = 4566;
    private static final int DYNAMODB_PORT = 4566;
    private static final int CORE_SERVICE_PORT = 8999;

    private static final FindReviewersHandler findReviewersHandler = new FindReviewersHandler();

    private final DatabaseClientUtils databaseClientUtils;
    private final SqsClientUtils sqsClientUtils;
    private final int coreServiceMappedPort;

    public static FindReviewersHandler getInstance() {
        return findReviewersHandler;
    }

    private FindReviewersHandler() {
        List<GenericContainer<?>> containers = TestContainersContext.startContainers();
        databaseClientUtils = configuredDatabaseClientUtils(containers);
        sqsClientUtils = configuredSqsClientUtils(containers);
        coreServiceMappedPort = getCoreServiceMappedPortFromContainer(containers);
    }

    public String getCoreServiceBaseUri() {
        return String.format("http://%s:%d", LOCALHOST, coreServiceMappedPort);
    }

    public DatabaseClientUtils getDatabaseClientUtils() {
        return databaseClientUtils;
    }

    public SqsClientUtils getSqsClientUtils() {
        return sqsClientUtils;
    }

    public void waitForFindReviewersService() {

        int count = 0;
        while (count < 100) {
            try {
                if (get("/ping").getStatusCode() == 200) {
                    System.out.println("FindReviewers service is ready");
                    return;
                }
            } catch (Exception e) {
                System.out.println("Waiting for FindReviewers service, exception: " + e.getMessage());
            }

            count++;

            try {
                System.out.println("Waiting for FindReviewers service, iteration: " + count);
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                System.out.println("Exception caught waiting for FindReviewers");
                throw new RuntimeException("Exception caught waiting for FindReviewers");
            }
        }

        throw new RuntimeException("Find Reviewers service is not available");
    }

    public void validateServiceSuccessResponse() {
        get("/ping").then().statusCode(200);
    }

    private static int getCoreServiceMappedPortFromContainer(List<GenericContainer<?>> containers) {
        GenericContainer<?> coreServiceContainer = containers.stream().filter(container ->
                        container.getNetworkAliases()
                                .stream().anyMatch(match -> match.equals("core-service")))
                .findFirst().orElse(null);

        return Objects.requireNonNull(coreServiceContainer).getMappedPort(CORE_SERVICE_PORT);
    }

    private static DatabaseClientUtils configuredDatabaseClientUtils(List<GenericContainer<?>> containers) {
        GenericContainer<?> postgresqlContainer = containers.stream().filter(container ->
                        container.getNetworkAliases()
                                .stream().anyMatch(match -> match.equals("find-reviewers-db")))
                .findFirst().orElse(null);

        GenericContainer<?> dynamoDbContainer = containers.stream().filter(container ->
                        container.getNetworkAliases()
                                .stream().anyMatch(match -> match.equals("localstack")))
                .findFirst().orElse(null);

        return new DatabaseClientUtils(LOCALHOST,
                Objects.requireNonNull(postgresqlContainer).getMappedPort(POSTGRES_PORT),
                Objects.requireNonNull(dynamoDbContainer).getMappedPort(DYNAMODB_PORT));
    }

    private static SqsClientUtils configuredSqsClientUtils(List<GenericContainer<?>> containers) {
        GenericContainer<?> sqsContainer = containers.stream().filter(container ->
                        container.getNetworkAliases()
                                .stream().anyMatch(match -> match.equals("localstack")))
                .findFirst().orElse(null);

        return new SqsClientUtils(
                LOCALHOST,
                Objects.requireNonNull(sqsContainer).getMappedPort(SQS_PORT)
        );
    }
}
