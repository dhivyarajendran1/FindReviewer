package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.dao.impl.AdditionalInfoDaoImpl.AdditionalInfoResultsExtractor;
import com.elsevier.find.reviewers.dao.impl.CandidateInfoDaoImpl.ReviewStatisticsResultsExtractor;
import com.elsevier.find.reviewers.enums.ProductType;
import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.generated.model.EditorsResponse;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.generated.model.Indicators;
import com.elsevier.find.reviewers.generated.model.KeywordSearchLogic;
import com.elsevier.find.reviewers.testutils.JdbcMockAnswer;
import com.elsevier.find.reviewers.testutils.TestBase;
import com.elsevier.find.reviewers.utils.CookieManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.data.jdbc.JdbcRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.sql.SQLException;
import java.time.Year;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, JdbcRepositoriesAutoConfiguration.class})
public class Editors_getEditorsTest extends TestBase {
    // Wire to the service that we want to test
    @Autowired
    private EditorsService editorsService;

    @MockBean(name = "personfinder")
    private WebClient personFinderWebClient;

    @MockBean(name = "scopussharedsearch")
    private WebClient sharedSearchWebClient;

    @Captor
    private ArgumentCaptor<String> requestCaptor;

    @BeforeEach
    void setup() {
        SessionContext.initialize(new CookieManager.SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", true, true));
    }

    @Test
    void testNoEditors() {
        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(RowMapper.class))).thenAnswer(mockAnswer);

        ResponseEntity<EditorsResponse> response = editorsService.getEditors("ACR", null, null, null, null, null);

        assertEquals("ACR", mockAnswer.getParameter("emJournalAcronym", String.class));
        assertEquals("editorialBoardMember", mockAnswer.getParameter("classification", String.class));
        assertFalse(mockAnswer.hasParameter("offset"));
        assertFalse(mockAnswer.hasParameter("limit"));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertEquals(false, response.getBody().isMore());
        assertEquals(0, response.getBody().getEditors().size());
    }

    @Test
    void testDatabaseException() {
        SessionContext.initialize(new CookieManager.SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", true, true));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(RowMapper.class))).thenThrow(new DataAccessException("Test Exception") {
        });

        assertThrows(DataAccessException.class, () -> editorsService.getEditors("ACR", null, null, null, null, null));
    }

    @Test
    void testInvalidInput() {
        assertThrows(InternalException.class, () -> editorsService.getEditors(null, null, null, null, null, null));
        assertThrows(InternalException.class, () -> editorsService.getEditors("", null, null, null, null, null));
        assertThrows(InternalException.class, () -> editorsService.getEditors(" ", null, null, null, null, null));
    }

    @Test
    void testNonElsevierJournal() {
        SessionContext.initialize(new CookieManager.SessionData(ProductType.FindReviewers, "code", "bearer", "NOT-CELL", true, false));

        ResponseEntity<EditorsResponse> response = editorsService.getEditors("NOT-CELL", null, null, null, null, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNull(response.getBody().getEditors(), "Body not valid");

        SessionContext.initialize(new CookieManager.SessionData(ProductType.FindReviewers, "code", "bearer", null, true, false));
        assertFalse(SessionContext.isElsevierJournal());
    }

    @Test
    void testAllDataEditor() throws SQLException {
        JdbcMockAnswer mockAnswer1 = new JdbcMockAnswer();
        mockAnswer1.addResultMapping(Map.ofEntries(
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("first_name", "Fred"),
                Map.entry("last_name", "Flintstone"),
                Map.entry("scopus_ids", "[\"111111\",\"222222\"]"),
                Map.entry("start_date", 123456789L),
                Map.entry("accreditation", "PhD"),
                Map.entry("job_title", "Miner"),
                Map.entry("personal_website", "http://www.bedrock.com/"),
                Map.entry("fields_of_interest", "[\"Rocks\",\"Gravel\"]")));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(RowMapper.class))).thenAnswer(mockAnswer1);

        JdbcMockAnswer mockAnswer2 = new JdbcMockAnswer();
        mockAnswer2.addResultMapping(Map.ofEntries(
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("volunteer", false),
                Map.entry("unavailability", "[{\"start\": 12345,\"stop\": 98765}]"),
                Map.entry("concurrent_review_limit", 100),
                Map.entry("this_recently_accepted_author", true),
                Map.entry("other_recently_accepted_author", false),
                Map.entry("is_ebm", false),
                Map.entry("editorial_history_count", 1)));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(AdditionalInfoResultsExtractor.class))).thenAnswer(mockAnswer2);

        JdbcMockAnswer mockEmAnswer = new JdbcMockAnswer();
        mockEmAnswer.addResultMapping(Map.ofEntries(
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("journal_acronym", "ACR"),
                Map.entry("rstop", 1589809511783L),
                Map.entry("work_in_progress", false),
                Map.entry("declined", false),
                Map.entry("terminated", false),
                Map.entry("completed", false),
                Map.entry("uninvited", false),
                Map.entry("assigned_not_invited", false)));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(ReviewStatisticsResultsExtractor.class))).thenAnswer(mockEmAnswer);

        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(personFinderWebClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("[]"));

        final WebClient.RequestBodyUriSpec bodyUriSpecMock2 = Mockito.mock(WebClient.RequestBodyUriSpec.class);
        final WebClient.RequestBodySpec bodySpecMock2 = Mockito.mock(WebClient.RequestBodySpec.class);
        final WebClient.RequestHeadersSpec headersSpecMock2 = Mockito.mock(WebClient.RequestHeadersSpec.class);
        final WebClient.ResponseSpec responseSpecMock2 = Mockito.mock(WebClient.ResponseSpec.class);
        Mockito.when(sharedSearchWebClient.post()).thenReturn(bodyUriSpecMock2);
        Mockito.when(bodyUriSpecMock2.uri(Mockito.anyString())).thenReturn(bodySpecMock2);
        Mockito.when(bodySpecMock2.header(Mockito.anyString(), Mockito.anyString())).thenReturn(bodySpecMock2);
        Mockito.when(bodySpecMock2.accept(Mockito.notNull())).thenReturn(bodySpecMock2);
        Mockito.when(bodySpecMock2.contentType(Mockito.notNull())).thenReturn(bodySpecMock2);
        Mockito.when(bodySpecMock2.bodyValue(Mockito.contains(Integer.toString(Year.now().minusYears(4).getValue()))))
                .thenReturn(headersSpecMock2);
        Mockito.when(headersSpecMock2.retrieve()).thenReturn(responseSpecMock2);
        Mockito.when(responseSpecMock2.bodyToMono(String.class))
                .thenReturn(Mono.just("{\"totalResultsCount\": 3, \"hits\": [{\"eid\": \"1\", \"authors\": [{\"authid\": \"111111\"},{\"authid\": \"1234567\"}]}, {\"eid\": \"2\", \"authors\": [{\"authid\": \"111111\"}]}, {\"eid\": \"3\", \"authors\": [{\"authid\": \"111111\"}]}]}"));

        ResponseEntity<EditorsResponse> response = editorsService.getEditors("ACR", null, "-stone -ve mid-year (rocks) A*", KeywordSearchLogic.OR, null, 1);

        assertEquals("ACR", mockAnswer1.getParameter("emJournalAcronym", String.class));
        assertEquals("editorialBoardMember", mockAnswer1.getParameter("classification", String.class));
        assertEquals(1, mockAnswer1.getParameter("limit", Integer.class));

        Mockito.verify(bodySpecMock2, Mockito.times(1)).bodyValue(requestCaptor.capture());
        assertFalse(requestCaptor.getValue().contains("(rocks"), "Incorrect left bracket removal");
        assertFalse(requestCaptor.getValue().contains("rocks)"), "Incorrect right bracket removal");
        assertTrue(requestCaptor.getValue().contains("(stone ve mid-year  rocks"), "Incorrect search term");

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertEquals(true, response.getBody().isMore());
        assertEquals(1, response.getBody().getEditors().size());
        assertEquals("fred@bedrock.com", response.getBody().getEditors().get(0).getEmails().get(0));
        assertEquals("Fred Flintstone", response.getBody().getEditors().get(0).getDisplayName());
        assertEquals("Fred", response.getBody().getEditors().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getEditors().get(0).getLastName());
        assertEquals(3, response.getBody().getEditors().get(0).getKeywordMatchCount());
        assertEquals(2, response.getBody().getEditors().get(0).getScopusIds().size());
        assertEquals("111111", response.getBody().getEditors().get(0).getScopusIds().get(0));
        assertEquals("222222", response.getBody().getEditors().get(0).getScopusIds().get(1));
        assertEquals(123456789, response.getBody().getEditors().get(0).getStartDate());
        assertEquals("PhD", response.getBody().getEditors().get(0).getAccreditation());
        assertEquals("Miner", response.getBody().getEditors().get(0).getJobTitle());
        assertEquals("http://www.bedrock.com/", response.getBody().getEditors().get(0).getPersonalWebsite());
        assertEquals(2, response.getBody().getEditors().get(0).getFieldsOfInterest().size());
        assertEquals("Rocks", response.getBody().getEditors().get(0).getFieldsOfInterest().get(0));
        assertEquals("Gravel", response.getBody().getEditors().get(0).getFieldsOfInterest().get(1));
        assertEquals(1, response.getBody().getEditors().get(0).getIndicators().size());
        assertEquals(Indicators.RECENTLYACCEPTEDAUTHORTHISJOURNAL, response.getBody().getEditors().get(0).getIndicators().get(0));

        assertEquals(1, response.getBody().getEditors().get(0).getEditorialHistoryCount());

        assertEquals(1, response.getBody().getEditors().get(0).getReviewStatistics().size());
        assertEquals("ACR", response.getBody().getEditors().get(0).getReviewStatistics().get(0).getEmJournalAcronym());
        assertEquals(1, response.getBody().getEditors().get(0).getReviewStatistics().get(0).getInvitationCount());
        assertEquals(0, response.getBody().getEditors().get(0).getReviewStatistics().get(0).getWorkInProgressCount());
        assertEquals(0, response.getBody().getEditors().get(0).getReviewStatistics().get(0).getCompletedCount());
        assertNull(response.getBody().getEditors().get(0).getReviewStatistics().get(0).getMostRecentCompleted());

        assertEquals(0, getAnalyticsCounterValue("custom.preferences.reviewer", "availability"));
        assertEquals(0, getAnalyticsCounterValue("custom.preferences.reviewer", "concurrent.limit"));
    }

    @Test
    void testInvalidColumnValues() throws SQLException {
        Map<String, Object> resultMapping1 = Map.ofEntries(
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("first_name", "Fred"),
                Map.entry("scopus_ids", "[1 2 3]"),
                Map.entry("fields_of_interest", "[1 2 3]"));

        Map<String, Object> resultMapping2 = Map.ofEntries(
                Map.entry("email", "barney@bedrock.com"),
                Map.entry("scopus_ids", ""),
                Map.entry("fields_of_interest", ""));

        Map<String, Object> resultMapping3 = Map.ofEntries(
                Map.entry("email", "wilma@bedrock.com"),
                Map.entry("scopus_ids", "-null-"),
                Map.entry("fields_of_interest", "-null-"));

        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(resultMapping1);
        mockAnswer.addResultMapping(resultMapping2);
        mockAnswer.addResultMapping(resultMapping3);

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(RowMapper.class))).thenAnswer(mockAnswer);

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(AdditionalInfoResultsExtractor.class))).thenAnswer(new JdbcMockAnswer());

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(ReviewStatisticsResultsExtractor.class))).thenAnswer(new JdbcMockAnswer());

        ResponseEntity<EditorsResponse> response = editorsService.getEditors("ACR", null, null, null, 10, 100);

        assertEquals("ACR", mockAnswer.getParameter("emJournalAcronym", String.class));
        assertEquals(10, mockAnswer.getParameter("offset", Integer.class));
        assertEquals(100, mockAnswer.getParameter("limit", Integer.class));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertEquals(3, response.getBody().getEditors().size());
        assertEquals("fred@bedrock.com", response.getBody().getEditors().get(0).getEmails().get(0));
        assertEquals("Fred", response.getBody().getEditors().get(0).getDisplayName());
        assertEquals("Fred", response.getBody().getEditors().get(0).getFirstName());
        assertNull(response.getBody().getEditors().get(0).getLastName());
        assertNull(response.getBody().getEditors().get(0).getIndicators());
        assertNull(response.getBody().getEditors().get(0).getScopusIds());
        assertNull(response.getBody().getEditors().get(0).getFieldsOfInterest());
        assertNull(response.getBody().getEditors().get(0).getEditorialHistoryCount());
        assertNull(response.getBody().getEditors().get(0).getReviewStatistics());

        assertEquals("barney@bedrock.com", response.getBody().getEditors().get(1).getEmails().get(0));
        assertNull(response.getBody().getEditors().get(1).getIndicators());
        assertNull(response.getBody().getEditors().get(1).getScopusIds());
        assertNull(response.getBody().getEditors().get(1).getFieldsOfInterest());
        assertNull(response.getBody().getEditors().get(1).getEditorialHistoryCount());
        assertNull(response.getBody().getEditors().get(1).getReviewStatistics());

        assertEquals("wilma@bedrock.com", response.getBody().getEditors().get(2).getEmails().get(0));
        assertNull(response.getBody().getEditors().get(2).getIndicators());
        assertNull(response.getBody().getEditors().get(2).getScopusIds());
        assertNull(response.getBody().getEditors().get(2).getFieldsOfInterest());
        assertNull(response.getBody().getEditors().get(2).getEditorialHistoryCount());
        assertNull(response.getBody().getEditors().get(2).getReviewStatistics());
    }

    @Test
    void testExtraScopusData() throws SQLException {
        final String author = "{\"authid\":\"000000800\",\"afdispname\":\"Bedrock Uni\",\"afdispcity\":\"Red Rock\"," +
                "\"afdispctry\":\"Bedrock\",\"count\":182,\"h_index\":\"24\", \"num_cited_by\":\"76\"}";

        Map<String, Object> resultMapping1 = Map.ofEntries(
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("first_name", "Fred"),
                Map.entry("last_name", "Flintstone"),
                Map.entry("scopus_ids", "[\"000000800\"]"));

        Map<String, Object> resultMapping2 = Map.ofEntries(
                Map.entry("email", "wilma@bedrock.com"),
                Map.entry("first_name", "Wilma"),
                Map.entry("last_name", "Flintstone"),
                Map.entry("scopus_ids", "-null-"));

        Map<String, Object> resultMapping3 = Map.ofEntries(
                Map.entry("email", "barney@bedrock.com"),
                Map.entry("first_name", "Barney"),
                Map.entry("last_name", "Rubble"),
                Map.entry("scopus_ids", "[\"000000000\"]"));

        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(resultMapping1);
        mockAnswer.addResultMapping(resultMapping2);
        mockAnswer.addResultMapping(resultMapping3);

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(RowMapper.class))).thenAnswer(mockAnswer);

        JdbcMockAnswer mockAnswer2 = new JdbcMockAnswer();
        mockAnswer2.addResultMapping(
                Map.ofEntries(Map.entry("email", "fred@bedrock.com"),
                        Map.entry("unavailability", "[{\"start\": 12345,\"stop\": 98765}]")),
                Map.ofEntries(Map.entry("email", "wilma@bedrock.com"),
                        Map.entry("unavailability", "[{\"start\": 12345,\"stop\": 98765}]")),
                Map.ofEntries(Map.entry("email", "barney@bedrock.com"),
                        Map.entry("unavailability", "[{\"start\": 1643720400000,\"stop\": 2644940798000}]")));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(AdditionalInfoResultsExtractor.class))).thenAnswer(mockAnswer2);

        JdbcMockAnswer mockStatsAnswer = new JdbcMockAnswer();
        mockStatsAnswer.addResultMapping(Map.ofEntries(
                        Map.entry("email", "fred@bedrock.com"),
                        Map.entry("journal_acronym", "ACR1"),
                        Map.entry("rstop", 1589809511800L),
                        Map.entry("work_in_progress", false),
                        Map.entry("declined", false),
                        Map.entry("terminated", false),
                        Map.entry("completed", true),
                        Map.entry("uninvited", false),
                        Map.entry("assigned_not_invited", false)),
                Map.ofEntries(
                        Map.entry("email", "fred@bedrock.com"),
                        Map.entry("journal_acronym", "ACR1"),
                        Map.entry("rstop", 1589809511783L),
                        Map.entry("work_in_progress", false),
                        Map.entry("declined", false),
                        Map.entry("terminated", false),
                        Map.entry("completed", true),
                        Map.entry("uninvited", false),
                        Map.entry("assigned_not_invited", false)));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(ReviewStatisticsResultsExtractor.class))).thenAnswer(mockStatsAnswer);

        final WebClient.ResponseSpec personFinderResponseSpecMock = createWebClientResponseSpecMock(personFinderWebClient);
        Mockito.when(personFinderResponseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("[" + author + "]"));

        final WebClient.ResponseSpec sharedSearchResponseSpecMock = createWebClientResponseSpecMock(sharedSearchWebClient);
        Mockito.when(sharedSearchResponseSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just("{\"totalResultsCount\": 5000, \"hits\": [{\"eid\": \"2-s2.0-85127470299\", \"authors\": null}]}"));

        ResponseEntity<EditorsResponse> response = editorsService.getEditors("ACR", null, "authors null", null, null, null);

        assertEquals("ACR", mockAnswer.getParameter("emJournalAcronym", String.class));
        assertEquals("editorialBoardMember", mockAnswer.getParameter("classification", String.class));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertEquals(false, response.getBody().isMore());
        assertEquals(2, response.getBody().getEditors().size());
        assertEquals("fred@bedrock.com", response.getBody().getEditors().get(0).getEmails().get(0));
        assertEquals("Fred Flintstone", response.getBody().getEditors().get(0).getDisplayName());
        assertEquals("Fred", response.getBody().getEditors().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getEditors().get(0).getLastName());
        assertNull(response.getBody().getEditors().get(0).getKeywordMatchCount());
        assertEquals(1, response.getBody().getEditors().get(0).getScopusIds().size());
        assertEquals("000000800", response.getBody().getEditors().get(0).getScopusIds().get(0));
        assertEquals("Bedrock Uni", response.getBody().getEditors().get(0).getAffiliationName());
        assertEquals("Red Rock", response.getBody().getEditors().get(0).getAffiliationCity());
        assertEquals("Bedrock", response.getBody().getEditors().get(0).getAffiliationCountry());
        assertEquals(182, response.getBody().getEditors().get(0).getPublicationCount());
        assertEquals(76, response.getBody().getEditors().get(0).getCitationCount());
        assertEquals(24, response.getBody().getEditors().get(0).getHindex());

        assertEquals(1, response.getBody().getEditors().get(0).getReviewStatistics().size());
        assertEquals("ACR1", response.getBody().getEditors().get(0).getReviewStatistics().get(0).getEmJournalAcronym());
        assertEquals(2, response.getBody().getEditors().get(0).getReviewStatistics().get(0).getInvitationCount());
        assertEquals(0, response.getBody().getEditors().get(0).getReviewStatistics().get(0).getWorkInProgressCount());
        assertEquals(2, response.getBody().getEditors().get(0).getReviewStatistics().get(0).getCompletedCount());
        assertEquals(1589809511800L, response.getBody().getEditors().get(0).getReviewStatistics().get(0).getMostRecentCompleted());

        assertEquals(1, getAnalyticsCounterValue("custom.preferences.reviewer", "availability"));
    }

    @Test
    void testContentMatchFailure() throws SQLException {
        Map<String, Object> resultMapping1 = Map.ofEntries(
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("first_name", "Fred"),
                Map.entry("last_name", "Flintstone"),
                Map.entry("scopus_ids", "[\"000000800\"]"));

        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(resultMapping1);
        JdbcMockAnswer mockAnswer2 = new JdbcMockAnswer();
        mockAnswer2.addResultMapping(resultMapping1);

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(RowMapper.class))).thenAnswer(mockAnswer).thenAnswer(mockAnswer2);

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(ResultSetExtractor.class))).thenAnswer(new JdbcMockAnswer());

        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(personFinderWebClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just(""));

        final WebClient.ResponseSpec sharedSearchResponseSpecMock = createWebClientResponseSpecMock(sharedSearchWebClient);
        Mockito.when(sharedSearchResponseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("invalid json"))
                .thenReturn(Mono.just("{\"totalResultsCount\": null, \"hits\": []}"));

        InternalException e = assertThrows(InternalException.class, () ->
                editorsService.getEditors("ACR", null, "\"Invalid JSON\"", null, null, null));
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getHttpStatus(), "Invalid status");
        assertEquals(ErrorResponse.IdEnum.SCOPUSSHAREDSEARCHFAILURE, e.toErrorResponse().getId(), "Invalid error Id");

        ResponseEntity<EditorsResponse> response = editorsService.getEditors("ACR", null, "Not enough results", null, null, null);
        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertEquals(false, response.getBody().isMore());
        assertEquals(1, response.getBody().getEditors().size());
        assertNull(response.getBody().getEditors().get(0).getEditorialHistoryCount());
    }

    @Test
    void testNonUrsdbEditors() throws SQLException {
        SessionContext.initialize(new CookieManager.SessionData(ProductType.FindReviewers, "code", "bearer", "CELL", true, false));

        Map<String, Object> resultMapping1 = Map.ofEntries(
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("first_name", "Fred"),
                Map.entry("last_name", "Flintstone"),
                Map.entry("scopus_ids", "[\"111111\",\"222222\"]"),
                Map.entry("start_date", 123456789L),
                Map.entry("accreditation", "PhD"),
                Map.entry("job_title", "Miner"),
                Map.entry("personal_website", "http://www.bedrock.com/"),
                Map.entry("fields_of_interest", "[\"Rocks\",\"Gravel\"]"));

        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(resultMapping1);

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(RowMapper.class))).thenAnswer(mockAnswer);

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(AdditionalInfoResultsExtractor.class))).thenAnswer(new JdbcMockAnswer());

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(ReviewStatisticsResultsExtractor.class))).thenAnswer(new JdbcMockAnswer());

        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(personFinderWebClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("[]"));

        final WebClient.ResponseSpec sharedSearchSpecMock = createWebClientResponseSpecMock(sharedSearchWebClient);
        Mockito.when(sharedSearchSpecMock.bodyToMono(String.class)).thenReturn(Mono.just(
                "{\"totalResultsCount\": 1, \"hits\": [{\"eid\": \"1\", \"authors\": [{\"authid\": \"DIFF_AUTH_ONLY\"}]}]}"));

        ResponseEntity<EditorsResponse> response = editorsService.getEditors("CELL", null, "keyword", null, null, null);

        assertEquals("CELL", mockAnswer.getParameter("journalAcronym", String.class));
        assertEquals("editorialBoardMember", mockAnswer.getParameter("classification", String.class));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertEquals(false, response.getBody().isMore());
        assertEquals(1, response.getBody().getEditors().size());
        assertEquals("fred@bedrock.com", response.getBody().getEditors().get(0).getEmails().get(0));
        assertEquals("Fred Flintstone", response.getBody().getEditors().get(0).getDisplayName());
        assertEquals("Fred", response.getBody().getEditors().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getEditors().get(0).getLastName());
        assertEquals(2, response.getBody().getEditors().get(0).getScopusIds().size());
        assertEquals("111111", response.getBody().getEditors().get(0).getScopusIds().get(0));
        assertEquals("222222", response.getBody().getEditors().get(0).getScopusIds().get(1));
        assertEquals(123456789, response.getBody().getEditors().get(0).getStartDate());
        assertEquals("PhD", response.getBody().getEditors().get(0).getAccreditation());
        assertEquals("Miner", response.getBody().getEditors().get(0).getJobTitle());
        assertEquals("http://www.bedrock.com/", response.getBody().getEditors().get(0).getPersonalWebsite());
        assertEquals(2, response.getBody().getEditors().get(0).getFieldsOfInterest().size());
        assertEquals("Rocks", response.getBody().getEditors().get(0).getFieldsOfInterest().get(0));
        assertEquals("Gravel", response.getBody().getEditors().get(0).getFieldsOfInterest().get(1));
        assertNull(response.getBody().getEditors().get(0).getKeywords());
        assertNull(response.getBody().getEditors().get(0).getSubjectAreas());
        assertNull(response.getBody().getEditors().get(0).getReviewStatistics());
    }
}
