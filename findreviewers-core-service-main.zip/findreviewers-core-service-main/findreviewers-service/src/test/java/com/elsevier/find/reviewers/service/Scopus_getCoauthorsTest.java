package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.external.ScopusGraph;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.generated.model.ScopusCoauthorResponse;
import com.elsevier.find.reviewers.testutils.TestBase;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.data.jdbc.JdbcRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

@TestPropertySource(properties = {
        "scopusgraph.client.base.url=https://localhost/api/"
})
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, JdbcRepositoriesAutoConfiguration.class})
public class Scopus_getCoauthorsTest extends TestBase {
    @Autowired
    private ScopusService scopusService;

    @MockBean(name = "scopusgraph")
    private WebClient webClient;

    @Test
    void testCoauthors() {
        String graphReturn = """
                "pageInfo": {
                    "totalCount": 97
                },
                "nodes": [
                    {
                        "ID": "1001234567",
                        "preffirst": "Fred",
                        "preflast": "Flintstone",
                        "hIndex": 34,
                        "authemail": "Fred@bedrock.com",
                        "hasAffiliation": {
                            "nodes": [
                                {
                                    "affilcity": "Bedrock",
                                    "affilctry": "Cobblestone",
                                    "prefname": "Mining Department",
                                    "prefparname": "University of Rocks"
                                }
                            ]
                        },
                        "relations": {
                            "coauthorship": {
                                "pageInfo": {
                                    "totalCount": 28
                                }
                            }
                        },
						"authorOf": {
							"pageInfo": {
								"totalCount": 14
							}
						}
                    }
                ]
                """;

        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(webClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just(String.format("{\"data\": {\"person\": {\"coauthorsDistinct\":{%s}}}}", graphReturn)));

        ResponseEntity<ScopusCoauthorResponse> response = scopusService.getCoauthors("123", null, "1234-5678");

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(97, response.getBody().getTotalCoauthors());
        assertEquals(1, response.getBody().getCoauthors().size());
        assertEquals(1, response.getBody().getCoauthors().get(0).getScopusIds().size());
        assertEquals("1001234567", response.getBody().getCoauthors().get(0).getScopusIds().get(0));
        assertEquals(1, response.getBody().getCoauthors().get(0).getEmails().size());
        assertEquals("fred@bedrock.com", response.getBody().getCoauthors().get(0).getEmails().get(0));
        assertEquals("Fred", response.getBody().getCoauthors().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getCoauthors().get(0).getLastName());
        assertEquals("Fred Flintstone", response.getBody().getCoauthors().get(0).getDisplayName());
        assertEquals(34, response.getBody().getCoauthors().get(0).getHindex());
        assertEquals(28, response.getBody().getCoauthors().get(0).getCoauthoredCount());
        assertEquals(14, response.getBody().getCoauthors().get(0).getPublishedInJournalCount());
        assertEquals("University of Rocks", response.getBody().getCoauthors().get(0).getAffiliationName());
        assertEquals("Bedrock", response.getBody().getCoauthors().get(0).getAffiliationCity());
        assertEquals("Cobblestone", response.getBody().getCoauthors().get(0).getAffiliationCountry());
    }

    @Test
    void testCoauthorsMultiple() {
        String graphReturn = """
                "nodes": [
                    {
                        "ID": "1001234567",
                        "preffirst": "Fred",
                        "preflast": "Flintstone"
                    },
                    {
                        "ID": "2001234567",
                        "preffirst": "Wilma",
                        "hIndex": 34,
                        "authemail": "wilma@bedrock.com",
                        "hasAffiliation": {},
                        "relations": {},
                        "authorOf": {}
                    },
                    {
                        "ID": "3001234567",
                        "preffirst": "Betty",
                        "authemail": "betty@bedrock.com",
                        "hasAffiliation": {
                            "nodes": []
                        },
                        "relations": {
                            "coauthorship": {}
                        },
						"authorOf": {
							"pageInfo": {}
						}
                    },
                    {
                        "ID": "4001234567",
                        "preffirst": "Barney",
                        "authemail": "barney@bedrock.com",
                        "hasAffiliation": {
                            "nodes": [
                                {
                                    "prefname": "Mining Department"
                                }
                            ]
                        },
                        "relations": {
                            "coauthorship": {
                                "pageInfo": {}
                            }
                        }
                    }
                ]
                """;

        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(webClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just(String.format("{\"data\": {\"person\": {\"coauthorsDistinct\":{%s}}}}", graphReturn)));

        ResponseEntity<ScopusCoauthorResponse> response = scopusService.getCoauthors("123", null, "1234-5678");

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(4, response.getBody().getCoauthors().size());
        assertEquals(1, response.getBody().getCoauthors().get(0).getScopusIds().size());
        assertEquals("1001234567", response.getBody().getCoauthors().get(0).getScopusIds().get(0));
        assertEquals(0, response.getBody().getCoauthors().get(0).getEmails().size());
        assertEquals("Fred", response.getBody().getCoauthors().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getCoauthors().get(0).getLastName());
        assertEquals("Fred Flintstone", response.getBody().getCoauthors().get(0).getDisplayName());
        assertNull(response.getBody().getCoauthors().get(0).getHindex());
        assertNull(response.getBody().getCoauthors().get(0).getCoauthoredCount());
        assertNull(response.getBody().getCoauthors().get(0).getPublishedInJournalCount());
        assertNull(response.getBody().getCoauthors().get(0).getAffiliationName());
        assertNull(response.getBody().getCoauthors().get(0).getAffiliationCity());
        assertNull(response.getBody().getCoauthors().get(0).getAffiliationCountry());

        assertEquals(1, response.getBody().getCoauthors().get(1).getScopusIds().size());
        assertEquals("2001234567", response.getBody().getCoauthors().get(1).getScopusIds().get(0));
        assertEquals(1, response.getBody().getCoauthors().get(1).getEmails().size());
        assertEquals("wilma@bedrock.com", response.getBody().getCoauthors().get(1).getEmails().get(0));
        assertEquals("Wilma", response.getBody().getCoauthors().get(1).getFirstName());
        assertEquals("Wilma", response.getBody().getCoauthors().get(1).getDisplayName());
        assertNull(response.getBody().getCoauthors().get(1).getLastName());
        assertEquals(34, response.getBody().getCoauthors().get(1).getHindex());
        assertNull(response.getBody().getCoauthors().get(1).getCoauthoredCount());
        assertNull(response.getBody().getCoauthors().get(1).getPublishedInJournalCount());
        assertNull(response.getBody().getCoauthors().get(1).getAffiliationName());
        assertNull(response.getBody().getCoauthors().get(1).getAffiliationCity());
        assertNull(response.getBody().getCoauthors().get(1).getAffiliationCountry());

        assertEquals(1, response.getBody().getCoauthors().get(2).getScopusIds().size());
        assertEquals("3001234567", response.getBody().getCoauthors().get(2).getScopusIds().get(0));
        assertEquals(1, response.getBody().getCoauthors().get(2).getEmails().size());
        assertEquals("betty@bedrock.com", response.getBody().getCoauthors().get(2).getEmails().get(0));
        assertEquals("Betty", response.getBody().getCoauthors().get(2).getFirstName());
        assertEquals("Betty", response.getBody().getCoauthors().get(2).getDisplayName());
        assertNull(response.getBody().getCoauthors().get(2).getLastName());
        assertNull(response.getBody().getCoauthors().get(2).getHindex());
        assertNull(response.getBody().getCoauthors().get(2).getCoauthoredCount());
        assertNull(response.getBody().getCoauthors().get(2).getPublishedInJournalCount());
        assertNull(response.getBody().getCoauthors().get(2).getAffiliationName());
        assertNull(response.getBody().getCoauthors().get(2).getAffiliationCity());
        assertNull(response.getBody().getCoauthors().get(2).getAffiliationCountry());

        assertEquals(1, response.getBody().getCoauthors().get(3).getScopusIds().size());
        assertEquals("4001234567", response.getBody().getCoauthors().get(3).getScopusIds().get(0));
        assertEquals(1, response.getBody().getCoauthors().get(3).getEmails().size());
        assertEquals("barney@bedrock.com", response.getBody().getCoauthors().get(3).getEmails().get(0));
        assertEquals("Barney", response.getBody().getCoauthors().get(3).getFirstName());
        assertEquals("Barney", response.getBody().getCoauthors().get(3).getDisplayName());
        assertNull(response.getBody().getCoauthors().get(3).getLastName());
        assertNull(response.getBody().getCoauthors().get(3).getHindex());
        assertNull(response.getBody().getCoauthors().get(3).getCoauthoredCount());
        assertNull(response.getBody().getCoauthors().get(3).getPublishedInJournalCount());
        assertEquals("Mining Department", response.getBody().getCoauthors().get(3).getAffiliationName());
        assertNull(response.getBody().getCoauthors().get(3).getAffiliationCity());
        assertNull(response.getBody().getCoauthors().get(3).getAffiliationCountry());
    }

    @Test
    void testNoCoauthors() {
        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(webClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just("{\"data\": {}}"))
                .thenReturn(Mono.just("{\"data\": {\"person\": {}}}"))
                .thenReturn(Mono.just("{\"data\": {\"person\": null}}"))
                .thenReturn(Mono.just("{\"data\": {\"person\": {\"coauthorsDistinct\":{}}}}"))
                .thenReturn(Mono.just("{\"data\": {\"person\": {\"coauthorsDistinct\":{\"nodes\":[]}}}}"))
                .thenReturn(Mono.just("{\"data\": {\"person\": {\"coauthorsDistinct\":{\"pageInfo\":{}}}}}"));

        for (int i = 0; i < 6; i++) {
            ResponseEntity<ScopusCoauthorResponse> response = scopusService.getCoauthors("123", null, " ");

            assertNotNull(response, "Null Response");
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertNotNull(response.getBody(), "Body not valid");
            assertEquals(0, response.getBody().getCoauthors().size());
            assertNull(response.getBody().getTotalCoauthors());
        }
    }

    @Test
    void testInvalidInput() {
        assertThrows(InternalException.class, () -> scopusService.getCoauthors(null, null, null));
        assertThrows(InternalException.class, () -> scopusService.getCoauthors("", null, null));

        ScopusGraph.GraphDataCoauthor graphDataCoauthor = new ScopusGraph.GraphDataCoauthor();
        assertEquals(0, graphDataCoauthor.getCoauthors().size());
    }

    @Test
    void testGraphCoauthorErrorReturn() {
        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(webClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class))
                .thenReturn(null)
                .thenReturn(Mono.empty())
                .thenReturn(Mono.just(""))
                .thenReturn(Mono.just("{}"))
                .thenReturn(Mono.just("{\"error\": {}}"))
                .thenReturn(Mono.just("Invalid JSON"));

        for (int i = 0; i < 6; i++) {
            InternalException e = assertThrows(InternalException.class, () -> scopusService.getCoauthors("123", null, ""));
            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getHttpStatus(), "Invalid status");
            assertEquals(ErrorResponse.IdEnum.SCOPUSGRAPHFAILURE, e.toErrorResponse().getId(), "Invalid error Id");
        }
    }

    @Test
    void testCoauthorHttpError() {
        final WebClient.RequestBodyUriSpec bodyUriSpecMock = Mockito.mock(WebClient.RequestBodyUriSpec.class);
        final WebClient.RequestBodySpec bodySpecMock = Mockito.mock(WebClient.RequestBodySpec.class);
        final WebClient.RequestHeadersSpec headersSpecMock = Mockito.mock(WebClient.RequestHeadersSpec.class);
        Mockito.when(webClient.post()).thenReturn(bodyUriSpecMock);
        Mockito.when(bodyUriSpecMock.uri(Mockito.anyString())).thenReturn(bodySpecMock);
        Mockito.when(bodySpecMock.header(Mockito.anyString(), Mockito.anyString())).thenReturn(bodySpecMock);
        Mockito.when(bodySpecMock.accept(Mockito.notNull())).thenReturn(bodySpecMock);
        Mockito.when(bodySpecMock.contentType(Mockito.notNull())).thenReturn(bodySpecMock);
        Mockito.when(bodySpecMock.bodyValue(Mockito.anyString())).thenReturn(headersSpecMock);
        Mockito.when(headersSpecMock.retrieve()).thenThrow(new WebClientResponseException(500, "Internal Error", null, null, null))
                .thenThrow(new RuntimeException());

        InternalException e = assertThrows(InternalException.class, () -> scopusService.getCoauthors("123", null, null));
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getHttpStatus(), "Invalid status");
        assertEquals(ErrorResponse.IdEnum.SCOPUSGRAPHFAILURE, e.toErrorResponse().getId(), "Invalid error Id");

        e = assertThrows(InternalException.class, () -> scopusService.getCoauthors("123", null, ""));
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getHttpStatus(), "Invalid status");
        assertEquals(ErrorResponse.IdEnum.SCOPUSGRAPHFAILURE, e.toErrorResponse().getId(), "Invalid error Id");
    }
}
