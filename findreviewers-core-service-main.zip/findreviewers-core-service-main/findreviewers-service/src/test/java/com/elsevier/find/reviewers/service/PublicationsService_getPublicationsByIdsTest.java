package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.enums.ProductType;
import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.generated.model.ScopusPublicationsResponse;
import com.elsevier.find.reviewers.testutils.TestBase;
import com.elsevier.find.reviewers.utils.CookieManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.data.jdbc.JdbcRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, JdbcRepositoriesAutoConfiguration.class})
public class PublicationsService_getPublicationsByIdsTest extends TestBase {
    @Autowired
    private PublicationsService publicationsService;

    @MockBean(name = "scopussharedsearch")
    private WebClient sharedSearchWebClient;

    @BeforeEach
    void setup() {
        SessionContext.initialize(new CookieManager.SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", false, true));
    }

    @Test
    void testInvalidInput() {
        assertThrows(InternalException.class, () -> publicationsService.getPublicationsByIds(null, null));
        assertThrows(InternalException.class, () -> publicationsService.getPublicationsByIds(Collections.emptyList(), null));
    }

    @Test
    void testNoPublicationResponses() {
        final WebClient.ResponseSpec sharedSearchSpecMock = createWebClientResponseSpecMock(sharedSearchWebClient);
        Mockito.when(sharedSearchSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just(""))
                .thenReturn(Mono.just("{}"))
                .thenReturn(Mono.just("{\"hits\":[]}"));

        for (int i = 0; i < 3; i++) {
            ResponseEntity<ScopusPublicationsResponse> response = publicationsService.getPublicationsByIds(List.of("eid-value"), null);

            assertNotNull(response, "Null Response");
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertNotNull(response.getBody(), "Body not valid");
            assertEquals(0, response.getBody().getPublications().size());
        }
    }

    @Test
    void testPublicationError() {
        final WebClient.ResponseSpec sharedSearchSpecMock = createWebClientResponseSpecMock(sharedSearchWebClient);
        Mockito.when(sharedSearchSpecMock.bodyToMono(String.class))
                .thenThrow(new WebClientResponseException(404, "Not Found", null, null, null))
                .thenReturn(Mono.just("{Json Error}"));

        ResponseEntity<ScopusPublicationsResponse> response = publicationsService.getPublicationsByIds(List.of("eid-value"), null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(0, response.getBody().getPublications().size());

        assertThrows(InternalException.class, () -> publicationsService.getPublicationsByIds(List.of("eid-value"), null));
    }

    @Test
    void testPublications() {
        final WebClient.ResponseSpec sharedSearchSpecMock = createWebClientResponseSpecMock(sharedSearchWebClient);
        Mockito.when(sharedSearchSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just("""
                        {"hits":[
                            {
                                "eid": "2-s2.0-85063983501",
                                "itemtitle": ["The Strength of Rocks"],
                                "srctitle": "Journal of Stones",
                                "numcitedby": 11,
                                "pubyr": "2019",
                                "authors": [
                                     {
                                         "authid": "35926176700",
                                         "authidxname": "Fintstone F."
                                     }
                                ]
                            },
                            {
                                "eid": "2-s2.0-84986571265",
                                "itemtitle": [],
                                "srctitle": "Without pub title",
                                "pubyr": "Not a Number"
                            },
                            {
                                "eid": "2-s2.0-84986571266"
                            }
                        ]}
                        """));

        ResponseEntity<ScopusPublicationsResponse> response = publicationsService.getPublicationsByIds(
                List.of("2-s2.0-85063983501", "2-s2.0-84986571265"), null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(3, response.getBody().getPublications().size());
        assertEquals("2-s2.0-85063983501", response.getBody().getPublications().get(0).getEid());
        assertEquals("Journal of Stones", response.getBody().getPublications().get(0).getJournalTitle());
        assertEquals("The Strength of Rocks", response.getBody().getPublications().get(0).getTitle());
        assertEquals(2019, response.getBody().getPublications().get(0).getYear());
        assertEquals(11, response.getBody().getPublications().get(0).getCitationCount());
        assertEquals(1, response.getBody().getPublications().get(0).getAuthorCount());
        assertEquals("35926176700", response.getBody().getPublications().get(0).getAuthors().get(0).getId());
        assertEquals("Fintstone F.", response.getBody().getPublications().get(0).getAuthors().get(0).getName());

        assertEquals("2-s2.0-84986571265", response.getBody().getPublications().get(1).getEid());
        assertEquals("Without pub title", response.getBody().getPublications().get(1).getJournalTitle());
        assertNull(response.getBody().getPublications().get(1).getTitle());
        assertNull(response.getBody().getPublications().get(1).getYear());
        assertNull(response.getBody().getPublications().get(1).getCitationCount());
        assertNull(response.getBody().getPublications().get(1).getAuthorCount());
        assertNull(response.getBody().getPublications().get(1).getAuthors());

        assertEquals("2-s2.0-84986571266", response.getBody().getPublications().get(2).getEid());
        assertNull(response.getBody().getPublications().get(2).getJournalTitle());
        assertNull(response.getBody().getPublications().get(2).getTitle());
        assertNull(response.getBody().getPublications().get(2).getYear());
        assertNull(response.getBody().getPublications().get(2).getCitationCount());
        assertNull(response.getBody().getPublications().get(2).getAuthorCount());
        assertNull(response.getBody().getPublications().get(2).getAuthors());
    }
}
