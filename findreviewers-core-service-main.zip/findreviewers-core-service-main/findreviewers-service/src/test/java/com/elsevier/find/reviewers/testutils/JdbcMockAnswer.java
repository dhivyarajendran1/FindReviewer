package com.elsevier.find.reviewers.testutils;

import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.OptionalInt;
import java.util.OptionalLong;

/**
 * Mock instance of the JDBC invocation method
 */
public class JdbcMockAnswer implements Answer<Object> {
    private static class OptionalIntAnswer implements Answer<Integer> {
        private OptionalInt optionalInt = null;
        private ResultSet rs;

        public OptionalIntAnswer(ResultSet resultSet, OptionalInt value) {
            optionalInt = value;
            rs = resultSet;
        }

        public Integer answer(InvocationOnMock invocation) throws Throwable {
            Mockito.when(rs.wasNull()).thenReturn(!optionalInt.isPresent());
            if (optionalInt.isPresent()) {
                return optionalInt.getAsInt();
            }
            return null;
        }
    }

    private static class OptionalLongAnswer implements Answer<Long> {
        private OptionalLong optionalLong = null;
        private ResultSet rs;

        public OptionalLongAnswer(ResultSet resultSet, OptionalLong value) {
            optionalLong = value;
            rs = resultSet;
        }

        public Long answer(InvocationOnMock invocation) throws Throwable {
            Mockito.when(rs.wasNull()).thenReturn(!optionalLong.isPresent());
            if (optionalLong.isPresent()) {
                return optionalLong.getAsLong();
            }
            return null;
        }
    }

    // An ordered Queue (FIFO) so that multiple result sets can be processed in the
    // expected order
    private LinkedList<ResultSet> resultSetMock = new LinkedList<>();

    // The SQL that the JDBC call was made with, populated after the call is made
    private String inputSql = null;

    // The parameters that are passed into the DB operation as parameters
    private MapSqlParameterSource parameters = null;

    public void addNullResultMap() throws SQLException {
        ResultSet resultSet = Mockito.mock(ResultSet.class);
        Mockito.when(resultSet.next()).thenReturn(false);
        resultSetMock.add(resultSet);
    }

    /**
     * Adds a given set of results that are to be returned, these are name-value pairs that
     * map onto the database column names that in the live system they would have been read from
     *
     * @param valueMap A Map of column names to values
     * @throws SQLException
     */
    public void addResultMapping(Map<String, Object> valueMap) throws SQLException {
        ResultSet resultSet = Mockito.mock(ResultSet.class);
        Mockito.when(resultSet.next()).thenReturn(true).thenReturn(false);

        for (Map.Entry<String, Object> mapEntry : valueMap.entrySet()) {
            if (mapEntry.getValue() instanceof String) {
                if ("-null-".equals(mapEntry.getValue())) {
                    Mockito.when(resultSet.getString(mapEntry.getKey())).thenReturn(null);
                } else {
                    Mockito.when(resultSet.getString(mapEntry.getKey())).thenReturn((String) mapEntry.getValue());
                }
            } else if (mapEntry.getValue() instanceof Integer) {
                Mockito.when(resultSet.getInt(mapEntry.getKey())).thenReturn((Integer) mapEntry.getValue());
            } else if (mapEntry.getValue() instanceof Long) {
                Mockito.when(resultSet.getLong(mapEntry.getKey())).thenReturn((Long) mapEntry.getValue());
            } else if (mapEntry.getValue() instanceof OptionalInt) {
                Mockito.when(resultSet.getInt(mapEntry.getKey())).thenAnswer(new OptionalIntAnswer(resultSet, ((OptionalInt) mapEntry.getValue())));
            } else if (mapEntry.getValue() instanceof OptionalLong) {
                Mockito.when(resultSet.getLong(mapEntry.getKey())).thenAnswer(new OptionalLongAnswer(resultSet, ((OptionalLong) mapEntry.getValue())));
            } else if (mapEntry.getValue() instanceof Boolean) {
                Mockito.when(resultSet.getBoolean(mapEntry.getKey())).thenReturn((Boolean) mapEntry.getValue());
            } else if (mapEntry.getValue() instanceof byte[]) {
                Mockito.when(resultSet.getBytes(mapEntry.getKey())).thenReturn((byte[]) mapEntry.getValue());
            } else {
                // Create an error so we know if more test mappings are required, took me a while to work
                // out when I needed another one - this exception will make it obvious
                throw new SQLException("No mapping provided for type " + mapEntry.getValue().getClass().getName());
            }
        }
        resultSetMock.add(resultSet);
    }

    public void addResultMapping(Map<String, Object> valueMap1, Map<String, Object> valueMap2) throws SQLException {
        ResultSet resultSet = Mockito.mock(ResultSet.class);
        Mockito.when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false);

        for (Map.Entry<String, Object> firstValueMapEntry : valueMap1.entrySet()) {
            if (firstValueMapEntry.getValue() instanceof String) {
                Mockito.when(resultSet.getString(firstValueMapEntry.getKey()))
                        .thenReturn(firstValueMapEntry.getValue().equals("-null-") ? null : (String) firstValueMapEntry.getValue())
                        .thenReturn(valueMap2.get(firstValueMapEntry.getKey()).equals("-null-") ? null : (String) valueMap2.get(firstValueMapEntry.getKey()));
            } else if (firstValueMapEntry.getValue() instanceof Integer) {
                Mockito.when(resultSet.getInt(firstValueMapEntry.getKey()))
                        .thenReturn((Integer) firstValueMapEntry.getValue())
                        .thenReturn((Integer) valueMap2.get(firstValueMapEntry.getKey()));
            } else if (firstValueMapEntry.getValue() instanceof Long) {
                Mockito.when(resultSet.getLong(firstValueMapEntry.getKey()))
                        .thenReturn((Long) firstValueMapEntry.getValue())
                        .thenReturn((Long) valueMap2.get(firstValueMapEntry.getKey()));
            } else if (firstValueMapEntry.getValue() instanceof OptionalInt) {
                Mockito.when(resultSet.getInt(firstValueMapEntry.getKey()))
                        .thenAnswer(new OptionalIntAnswer(resultSet, (OptionalInt) firstValueMapEntry.getValue()))
                        .thenAnswer(new OptionalIntAnswer(resultSet, (OptionalInt) valueMap2.get(firstValueMapEntry.getKey())));
            } else if (firstValueMapEntry.getValue() instanceof OptionalLong) {
                Mockito.when(resultSet.getLong(firstValueMapEntry.getKey()))
                        .thenAnswer(new OptionalLongAnswer(resultSet, (OptionalLong) firstValueMapEntry.getValue()))
                        .thenAnswer(new OptionalLongAnswer(resultSet, (OptionalLong) valueMap2.get(firstValueMapEntry.getKey())));
            } else if (firstValueMapEntry.getValue() instanceof Boolean) {
                Mockito.when(resultSet.getBoolean(firstValueMapEntry.getKey()))
                        .thenReturn((Boolean) firstValueMapEntry.getValue())
                        .thenReturn((Boolean) valueMap2.get(firstValueMapEntry.getKey()));
            } else if (firstValueMapEntry.getValue() instanceof byte[]) {
                Mockito.when(resultSet.getBytes(firstValueMapEntry.getKey()))
                        .thenReturn((byte[]) firstValueMapEntry.getValue())
                        .thenReturn((byte[]) valueMap2.get(firstValueMapEntry.getKey()));
            } else {
                // Create an error so we know if more test mappings are required, took me a while to work
                // out when I needed another one - this exception will make it obvious
                throw new SQLException("No mapping provided for type " + firstValueMapEntry.getValue().getClass().getName());
            }
        }
        resultSetMock.add(resultSet);
    }

    public void addResultMapping(Map<String, Object> valueMap1, Map<String, Object> valueMap2, Map<String, Object> valueMap3) throws SQLException {
        ResultSet resultSet = Mockito.mock(ResultSet.class);
        Mockito.when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(false);

        for (Map.Entry<String, Object> firstValueMapEntry : valueMap1.entrySet()) {
            if (firstValueMapEntry.getValue() instanceof String) {
                Mockito.when(resultSet.getString(firstValueMapEntry.getKey()))
                        .thenReturn(firstValueMapEntry.getValue().equals("-null-") ? null : (String) firstValueMapEntry.getValue())
                        .thenReturn(valueMap2.get(firstValueMapEntry.getKey()).equals("-null-") ? null : (String) valueMap2.get(firstValueMapEntry.getKey()))
                        .thenReturn(valueMap3.get(firstValueMapEntry.getKey()).equals("-null-") ? null : (String) valueMap3.get(firstValueMapEntry.getKey()));
            } else if (firstValueMapEntry.getValue() instanceof Integer) {
                Mockito.when(resultSet.getInt(firstValueMapEntry.getKey()))
                        .thenReturn((Integer) firstValueMapEntry.getValue())
                        .thenReturn((Integer) valueMap2.get(firstValueMapEntry.getKey()))
                        .thenReturn((Integer) valueMap3.get(firstValueMapEntry.getKey()));
            } else if (firstValueMapEntry.getValue() instanceof Long) {
                Mockito.when(resultSet.getLong(firstValueMapEntry.getKey()))
                        .thenReturn((Long) firstValueMapEntry.getValue())
                        .thenReturn((Long) valueMap2.get(firstValueMapEntry.getKey()))
                        .thenReturn((Long) valueMap3.get(firstValueMapEntry.getKey()));
            } else if (firstValueMapEntry.getValue() instanceof OptionalInt) {
                Mockito.when(resultSet.getInt(firstValueMapEntry.getKey()))
                        .thenAnswer(new OptionalIntAnswer(resultSet, (OptionalInt) firstValueMapEntry.getValue()))
                        .thenAnswer(new OptionalIntAnswer(resultSet, (OptionalInt) valueMap2.get(firstValueMapEntry.getKey())))
                        .thenAnswer(new OptionalIntAnswer(resultSet, (OptionalInt) valueMap3.get(firstValueMapEntry.getKey())));
            } else if (firstValueMapEntry.getValue() instanceof OptionalLong) {
                Mockito.when(resultSet.getLong(firstValueMapEntry.getKey()))
                        .thenAnswer(new OptionalLongAnswer(resultSet, (OptionalLong) firstValueMapEntry.getValue()))
                        .thenAnswer(new OptionalLongAnswer(resultSet, (OptionalLong) valueMap2.get(firstValueMapEntry.getKey())))
                        .thenAnswer(new OptionalLongAnswer(resultSet, (OptionalLong) valueMap3.get(firstValueMapEntry.getKey())));
            } else if (firstValueMapEntry.getValue() instanceof Boolean) {
                Mockito.when(resultSet.getBoolean(firstValueMapEntry.getKey()))
                        .thenReturn((Boolean) firstValueMapEntry.getValue())
                        .thenReturn((Boolean) valueMap2.get(firstValueMapEntry.getKey()))
                        .thenReturn((Boolean) valueMap3.get(firstValueMapEntry.getKey()));
            } else if (firstValueMapEntry.getValue() instanceof byte[]) {
                Mockito.when(resultSet.getBytes(firstValueMapEntry.getKey()))
                        .thenReturn((byte[]) firstValueMapEntry.getValue())
                        .thenReturn((byte[]) valueMap2.get(firstValueMapEntry.getKey()))
                        .thenReturn((byte[]) valueMap3.get(firstValueMapEntry.getKey()));
            } else {
                // Create an error so we know if more test mappings are required, took me a while to work
                // out when I needed another one - this exception will make it obvious
                throw new SQLException("No mapping provided for type " + firstValueMapEntry.getValue().getClass().getName());
            }
        }
        resultSetMock.add(resultSet);
    }

    public void addResultMapping(Map<String, Object> valueMap1, Map<String, Object> valueMap2, Map<String, Object> valueMap3, Map<String, Object> valueMap4) throws SQLException {
        ResultSet resultSet = Mockito.mock(ResultSet.class);
        Mockito.when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(false);

        for (Map.Entry<String, Object> firstValueMapEntry : valueMap1.entrySet()) {
            if (firstValueMapEntry.getValue() instanceof String) {
                Mockito.when(resultSet.getString(firstValueMapEntry.getKey()))
                        .thenReturn(firstValueMapEntry.getValue().equals("-null-") ? null : (String) firstValueMapEntry.getValue())
                        .thenReturn(valueMap2.get(firstValueMapEntry.getKey()).equals("-null-") ? null : (String) valueMap2.get(firstValueMapEntry.getKey()))
                        .thenReturn(valueMap3.get(firstValueMapEntry.getKey()).equals("-null-") ? null : (String) valueMap3.get(firstValueMapEntry.getKey()))
                        .thenReturn(valueMap4.get(firstValueMapEntry.getKey()).equals("-null-") ? null : (String) valueMap4.get(firstValueMapEntry.getKey()));
            } else if (firstValueMapEntry.getValue() instanceof Integer) {
                Mockito.when(resultSet.getInt(firstValueMapEntry.getKey()))
                        .thenReturn((Integer) firstValueMapEntry.getValue())
                        .thenReturn((Integer) valueMap2.get(firstValueMapEntry.getKey()))
                        .thenReturn((Integer) valueMap3.get(firstValueMapEntry.getKey()))
                        .thenReturn((Integer) valueMap4.get(firstValueMapEntry.getKey()));
            } else if (firstValueMapEntry.getValue() instanceof Long) {
                Mockito.when(resultSet.getLong(firstValueMapEntry.getKey()))
                        .thenReturn((Long) firstValueMapEntry.getValue())
                        .thenReturn((Long) valueMap2.get(firstValueMapEntry.getKey()))
                        .thenReturn((Long) valueMap3.get(firstValueMapEntry.getKey()))
                        .thenReturn((Long) valueMap4.get(firstValueMapEntry.getKey()));
            } else if (firstValueMapEntry.getValue() instanceof OptionalInt) {
                Mockito.when(resultSet.getInt(firstValueMapEntry.getKey()))
                        .thenAnswer(new OptionalIntAnswer(resultSet, (OptionalInt) firstValueMapEntry.getValue()))
                        .thenAnswer(new OptionalIntAnswer(resultSet, (OptionalInt) valueMap2.get(firstValueMapEntry.getKey())))
                        .thenAnswer(new OptionalIntAnswer(resultSet, (OptionalInt) valueMap3.get(firstValueMapEntry.getKey())))
                        .thenAnswer(new OptionalIntAnswer(resultSet, (OptionalInt) valueMap4.get(firstValueMapEntry.getKey())));
            } else if (firstValueMapEntry.getValue() instanceof OptionalLong) {
                Mockito.when(resultSet.getLong(firstValueMapEntry.getKey()))
                        .thenAnswer(new OptionalLongAnswer(resultSet, (OptionalLong) firstValueMapEntry.getValue()))
                        .thenAnswer(new OptionalLongAnswer(resultSet, (OptionalLong) valueMap2.get(firstValueMapEntry.getKey())))
                        .thenAnswer(new OptionalLongAnswer(resultSet, (OptionalLong) valueMap3.get(firstValueMapEntry.getKey())))
                        .thenAnswer(new OptionalLongAnswer(resultSet, (OptionalLong) valueMap4.get(firstValueMapEntry.getKey())));
            } else if (firstValueMapEntry.getValue() instanceof Boolean) {
                Mockito.when(resultSet.getBoolean(firstValueMapEntry.getKey()))
                        .thenReturn((Boolean) firstValueMapEntry.getValue())
                        .thenReturn((Boolean) valueMap2.get(firstValueMapEntry.getKey()))
                        .thenReturn((Boolean) valueMap3.get(firstValueMapEntry.getKey()))
                        .thenReturn((Boolean) valueMap4.get(firstValueMapEntry.getKey()));
            } else if (firstValueMapEntry.getValue() instanceof byte[]) {
                Mockito.when(resultSet.getBytes(firstValueMapEntry.getKey()))
                        .thenReturn((byte[]) firstValueMapEntry.getValue())
                        .thenReturn((byte[]) valueMap2.get(firstValueMapEntry.getKey()))
                        .thenReturn((byte[]) valueMap3.get(firstValueMapEntry.getKey()))
                        .thenReturn((byte[]) valueMap4.get(firstValueMapEntry.getKey()));
            } else {
                // Create an error so we know if more test mappings are required, took me a while to work
                // out when I needed another one - this exception will make it obvious
                throw new SQLException("No mapping provided for type " + firstValueMapEntry.getValue().getClass().getName());
            }
        }
        resultSetMock.add(resultSet);
    }

    @Override
    public Object answer(InvocationOnMock invocation) throws Throwable {
        int argIndex = 0;
        // Extract the SQL for the call, as it is the first argument
        inputSql = invocation.getArgument(argIndex, String.class);
        argIndex++;

        if (invocation.getArguments().length > 2) {
            parameters = invocation.getArgument(argIndex, MapSqlParameterSource.class);
            argIndex++;
        }

        // This is the invocation of the Row Mapper to make sure we test the
        // processing of any database results returned
        Object returnObject = new HashMap<>();
        Object nextRawArg = invocation.getArgument(argIndex);
        if (nextRawArg instanceof RowMapper ||
                nextRawArg.getClass().getName().contains("CandidateDetailsResultsExtractor")) {
            returnObject = new ArrayList<>();
        } else if (nextRawArg instanceof ResultSetExtractor) {
            if (nextRawArg.getClass().getName().contains("InitialisationResultsExtractor") ||
                    nextRawArg.getClass().getName().contains("JournalResultsExtractor") ||
                    nextRawArg.getClass().getName().contains("InitialisationInfoResultsExtractor")) {
                returnObject = null;
            }
        }

        if (!resultSetMock.isEmpty()) {
            if (nextRawArg instanceof RowMapper) {
                while (!resultSetMock.isEmpty()) {
                    RowMapper argument3 = invocation.getArgument(argIndex, RowMapper.class);
                    ((List) returnObject).add(argument3.mapRow(resultSetMock.remove(), 1));
                }
            } else {
                ResultSetExtractor argument3 = invocation.getArgument(argIndex, ResultSetExtractor.class);
                returnObject = argument3.extractData(resultSetMock.remove());
            }
        }
        return returnObject;
    }

    /**
     * Gets the SQL that was passed into the JDBC call
     *
     * @return
     */
    public String getInputSql() {
        return inputSql;
    }

    /**
     * Retrieves the value of a parameter that the JDBC was invoked with
     *
     * @param name  Name of the parameter
     * @param clazz The type of the parameter
     * @return Value of the parameter in it's correct type
     */
    public <T> T getParameter(String name, Class<T> clazz) {
        return (T) parameters.getValue(name);
    }

    /**
     * Checks if a parameter was provided
     *
     * @param name Name of the parameter
     * @return
     */
    public boolean hasParameter(String name) {
        return parameters.hasValue(name);
    }
}
