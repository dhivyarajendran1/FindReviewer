package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.dao.impl.AdditionalInfoDaoImpl.InitialisationInfoResultsExtractor;
import com.elsevier.find.reviewers.enums.ProductType;
import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.external.ScopusSources;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.generated.model.InitialisationDetails;
import com.elsevier.find.reviewers.generated.model.ReviewerStatus;
import com.elsevier.find.reviewers.testutils.JdbcMockAnswer;
import com.elsevier.find.reviewers.testutils.TestBase;
import com.elsevier.find.reviewers.utils.CookieManager.SessionData;
import org.apache.logging.log4j.ThreadContext;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.data.jdbc.JdbcRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.test.context.TestPropertySource;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@TestPropertySource(properties = {
        "em.web.api.client.host=https://localhost/api/",
        "scopussources.client.base.url=https://localhost/api/",
        "logging.level.com.elsevier.find.reviewers=DEBUG"
})
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, JdbcRepositoriesAutoConfiguration.class})
public class Initialisation_getInitialisationNonUrsdbTest extends TestBase {
    // Wire to the service that we want to test
    @Autowired
    private InitialisationService initialisationService;

    @MockBean(name = "httpClient")
    private HttpClient mockHttpClient;

    @MockBean(name = "httpClientWithoutCertificateCheck")
    private HttpClient httpClientWithoutCertificateCheck;

    @Captor
    private ArgumentCaptor<HttpRequest> requestCaptor;

    @MockBean(name = "emWebClient")
    private WebClient emWebClient;

    @MockBean(name = "scopussharedsearch")
    private WebClient sharedSearchWebClient;

    @Autowired
    private ScopusSources scopusSources;

    @BeforeEach
    void setup() {
        ThreadContext.put("correlationId", "1234-5678");
        SessionContext.initialize(new SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", true, false));
    }

    @AfterEach
    void tearDown() {
        SessionContext.destroy();
    }

    @Test
    void testInvalidInput() {
        assertThrows(InternalException.class, () -> initialisationService.getInitialisation(null, null, null));
        assertThrows(InternalException.class, () -> initialisationService.getInitialisation(null, "ACR", null));
        assertThrows(InternalException.class, () -> initialisationService.getInitialisation(null, "", 123L));
    }

    @Test
    void testNonUrsdbManuscriptNoReviewers() throws IOException, InterruptedException, SQLException {
        SessionContext.initialize(new SessionData(ProductType.FindReviewers, "code", "bearer", "CANCER-CELL", false, false));

        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(Map.of(
                "issn_l", "1535-6108",
                "classifications", "-null-",
                "has_ebms", false,
                "crowdsourced_reviewers", "-null-"));
        mockAnswer.addResultMapping(Map.of(
                "issn_l", "1535-6108",
                "classifications", "-null-",
                "has_ebms", true,
                "crowdsourced_reviewers", "-null-"));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(InitialisationInfoResultsExtractor.class))).thenAnswer(mockAnswer);

        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(200);
        Mockito.when(mockTokenResponse.body()).thenReturn("{\"reviewers\": []}").thenReturn("{}");

        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        final WebClient.ResponseSpec manuscriptSpecMock = createWebClientResponseSpecMock(emWebClient, "metadata");
        Mockito.when(manuscriptSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just(
                        "{\"Response\": {\"result\": {\"e\": {\"keywords\": [], \"classifications\": []}}}}"))
                .thenReturn(Mono.just(
                        "{\"Response\": {\"result\": {\"e\": {\"keywords\": [{}], \"classifications\": [{}]}}}}"));

        ResponseEntity<InitialisationDetails> response = initialisationService.getInitialisation(null, "CANCER-CELL", 123L);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isIsElsevier());
        assertNull(response.getBody().getReviewers(), "Reviews not valid");
        assertEquals(List.of(InitialisationDetails.PermittedFeaturesEnum.ADDEDREVIEWERS,
                InitialisationDetails.PermittedFeaturesEnum.AUTHORSEARCH,
                InitialisationDetails.PermittedFeaturesEnum.KEYWORDSEARCH,
                InitialisationDetails.PermittedFeaturesEnum.SESSIONPREFERENCES,
                InitialisationDetails.PermittedFeaturesEnum.MANUSCRIPTDETAILS,
                InitialisationDetails.PermittedFeaturesEnum.REVIEWERHISTORY,
                InitialisationDetails.PermittedFeaturesEnum.REVIEWERLIMITS), response.getBody().getPermittedFeatures());
        assertEquals("1535-6108", response.getBody().getJournalIssnl());
        assertNull(response.getBody().getKeywords());
        assertNull(response.getBody().getClassifications());

        response = initialisationService.getInitialisation(null, "CELL", 123L);

        Mockito.verify(mockHttpClient, Mockito.times(2)).send(requestCaptor.capture(),
                Mockito.any(HttpResponse.BodyHandler.class));
        assertTrue(requestCaptor.getValue().uri().toString().endsWith("/journals/CELL/document/123/reviewers"), "Incorrect URL");
        assertEquals("GET", requestCaptor.getValue().method());

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNull(response.getBody().getReviewers(), "Reviews not valid");
        assertEquals(List.of(InitialisationDetails.PermittedFeaturesEnum.ADDEDREVIEWERS,
                InitialisationDetails.PermittedFeaturesEnum.AUTHORSEARCH,
                InitialisationDetails.PermittedFeaturesEnum.KEYWORDSEARCH,
                InitialisationDetails.PermittedFeaturesEnum.SESSIONPREFERENCES,
                InitialisationDetails.PermittedFeaturesEnum.MANUSCRIPTDETAILS,
                InitialisationDetails.PermittedFeaturesEnum.REVIEWERHISTORY,
                InitialisationDetails.PermittedFeaturesEnum.REVIEWERLIMITS,
                InitialisationDetails.PermittedFeaturesEnum.EDITORIALBOARDMEMBERS), response.getBody().getPermittedFeatures());
        assertNull(response.getBody().getKeywords());
        assertNull(response.getBody().getClassifications());
    }

    @Test
    void testNonUrsdbManuscriptAuthorsAndReviewers() {
        SessionContext.initialize(new SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", true, false));

        final WebClient.ResponseSpec authorsSpecMock = createWebClientResponseSpecMock(emWebClient, "authors");
        Mockito.when(authorsSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just("""
                        {"Response": {"result": {"e":
                        {"authorFullName": "Fred Flintstone","isCorresponding": "true","authorFirstName": "Fred",
                         "authorLastName": "Flintstone","authorPrimaryEmailAddress": "Fred@bedrock.com"}
                        }}}
                        """))
                .thenReturn(Mono.just("""
                        {"Response": {"result": {"e": [
                        {"authorFullName": "Fred Flintstone","isCorresponding": "false","authorFirstName": "Fred",
                         "authorLastName": "Flintstone","authorPrimaryEmailAddress": "fred@Bedrock.com"},
                        {"isCorresponding": "false","authorFirstName": "Barney","authorLastName": "Rubble"},
                        {}
                        ]}}}
                        """));

        final WebClient.ResponseSpec reviewersSpecMock = createWebClientResponseSpecMock(emWebClient, "reviewer");
        Mockito.when(reviewersSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just("{\"Response\": {" +
                        "\"result\": {\"e\": [" +
                        "{\"reviewerPrimaryEmailAddress\": \"Barney@bedrock.com\", " +
                        "\"reviewerFirstName\": \"Barney\", \"reviewerLastName\": \"Rubble\", " +
                        "\"reviewerFullName\": \"Barney Rubble\", \"reviewerAssignmentStatus\": \"Complete\"}, " +
                        "{\"reviewerFirstName\": \"NO_EMAIL\"}]}}}"))
                .thenReturn(Mono.just("{\"Response\": {" +
                        "\"result\": {\"e\": [" +
                        "{\"reviewerPrimaryEmailAddress\": \"betty@bedrock.com\", " +
                        "\"reviewerFirstName\": \"Betty\", \"reviewerLastName\": \"Rubble\", " +
                        "\"reviewerFullName\": \"Betty Rubble\", \"reviewerAssignmentStatus\": \"Agreed\"," +
                        "\"ReviewerInvitationResponse\": \"Declined\"}" +
                        "]}}}"));

        // EM might send arrays for classifications without the array
        final WebClient.ResponseSpec manuscriptSpecMock = createWebClientResponseSpecMock(emWebClient, "metadata");
        Mockito.when(manuscriptSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just("""
                        {"Response": {"result": {"e": {"journalName": "",
                            "keywords": [{"word": "keyword1"}],
                            "classifications": {"description": "classification1"}}}}}
                        """))
                .thenReturn(Mono.just("""
                        {"Response": {"result": {"e": {"journalName": "",
                            "keywords": [{"word": ""}],
                            "classifications": [{"description": ""}]}}}}
                        """));

        final String author1 = "{\"authid\":\"000000800\",\"authemail\":\"fred@bedrock.com\"}";

        final WebClient.ResponseSpec sharedSearchSpecMock = createWebClientResponseSpecMock(sharedSearchWebClient);
        Mockito.when(sharedSearchSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just("{\"hits\":[" + author1 + "]}"))
                .thenReturn(Mono.just(""));

        ResponseEntity<InitialisationDetails> response = initialisationService.getInitialisation(null, "ACR", 123L);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertFalse(response.getBody().isIsElsevier());
        assertEquals(List.of(InitialisationDetails.PermittedFeaturesEnum.ADDEDREVIEWERS,
                InitialisationDetails.PermittedFeaturesEnum.AUTHORSEARCH,
                InitialisationDetails.PermittedFeaturesEnum.KEYWORDSEARCH,
                InitialisationDetails.PermittedFeaturesEnum.SESSIONPREFERENCES,
                InitialisationDetails.PermittedFeaturesEnum.MANUSCRIPTDETAILS), response.getBody().getPermittedFeatures());
        assertEquals(1, response.getBody().getKeywords().size());
        assertEquals("keyword1", response.getBody().getKeywords().get(0));
        assertEquals(1, response.getBody().getClassifications().size());
        assertEquals("NONE", response.getBody().getClassifications().get(0).getCode());
        assertEquals("classification1", response.getBody().getClassifications().get(0).getDescription());

        assertEquals(1, response.getBody().getCorrespondingAuthors().size());
        assertEquals("Fred Flintstone", response.getBody().getCorrespondingAuthors().get(0).getDisplayName());
        assertEquals("Fred", response.getBody().getCorrespondingAuthors().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getCorrespondingAuthors().get(0).getLastName());
        assertEquals("fred@bedrock.com", response.getBody().getCorrespondingAuthors().get(0).getEmails().get(0));
        assertEquals(1, response.getBody().getCorrespondingAuthors().get(0).getScopusIds().size());
        assertEquals("000000800", response.getBody().getCorrespondingAuthors().get(0).getScopusIds().get(0));

        assertEquals(1, response.getBody().getReviewers().size());
        assertEquals(1, response.getBody().getReviewers().get(0).getEmails().size());
        assertEquals("barney@bedrock.com", response.getBody().getReviewers().get(0).getEmails().get(0));
        assertEquals("Barney", response.getBody().getReviewers().get(0).getFirstName());
        assertEquals("Rubble", response.getBody().getReviewers().get(0).getLastName());
        assertEquals("Barney Rubble", response.getBody().getReviewers().get(0).getDisplayName());
        assertEquals(ReviewerStatus.COMPLETED, response.getBody().getReviewers().get(0).getStatus());
        assertNull(response.getBody().getCoAuthors());

        response = initialisationService.getInitialisation(null, "ACR", 123L);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertFalse(response.getBody().isIsElsevier());
        assertEquals(List.of(InitialisationDetails.PermittedFeaturesEnum.ADDEDREVIEWERS,
                InitialisationDetails.PermittedFeaturesEnum.AUTHORSEARCH,
                InitialisationDetails.PermittedFeaturesEnum.KEYWORDSEARCH,
                InitialisationDetails.PermittedFeaturesEnum.SESSIONPREFERENCES,
                InitialisationDetails.PermittedFeaturesEnum.MANUSCRIPTDETAILS), response.getBody().getPermittedFeatures());
        assertNull(response.getBody().getKeywords());
        assertNull(response.getBody().getClassifications());

        assertEquals(2, response.getBody().getCoAuthors().size());
        assertEquals("Fred Flintstone", response.getBody().getCoAuthors().get(0).getDisplayName());
        assertEquals("Fred", response.getBody().getCoAuthors().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getCoAuthors().get(0).getLastName());
        assertEquals("fred@bedrock.com", response.getBody().getCoAuthors().get(0).getEmails().get(0));
        assertEquals("Barney Rubble", response.getBody().getCoAuthors().get(1).getDisplayName());
        assertEquals("Barney", response.getBody().getCoAuthors().get(1).getFirstName());
        assertEquals("Rubble", response.getBody().getCoAuthors().get(1).getLastName());
        assertNull(response.getBody().getCoAuthors().get(1).getEmails());
        assertEquals(1, response.getBody().getReviewers().get(0).getEmails().size());
        assertNull(response.getBody().getReviewers().get(0).getScopusIds());
        assertEquals("betty@bedrock.com", response.getBody().getReviewers().get(0).getEmails().get(0));
        assertEquals("Betty", response.getBody().getReviewers().get(0).getFirstName());
        assertEquals("Rubble", response.getBody().getReviewers().get(0).getLastName());
        assertEquals("Betty Rubble", response.getBody().getReviewers().get(0).getDisplayName());
        assertEquals(ReviewerStatus.DECLINED, response.getBody().getReviewers().get(0).getStatus());
        assertNull(response.getBody().getCorrespondingAuthors());
    }

    @Test
    void testNonUrsdbManuscriptMixedReviewers() throws IOException, InterruptedException {
        SessionContext.initialize(new SessionData(ProductType.FindReviewers, "code", "bearer", "TIBS", false, false));

        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(200);
        Mockito.when(mockTokenResponse.body()).thenReturn("{\"reviewers\":[" +
                "{\"status\":\"invited\",\"journal-code\":\"ACR\",\"given-name\":\"Fred\",\"middle-name\":\"B\"," +
                "\"family-name\":\"Flintstone\", \"email-addresses\":[\"fred@bedrock.com\"], " +
                "\"identifiers\": [{\"system\": \"scopus\", \"identifier\": \"8888\"}]}, " +

                "{\"status\":\"proposed\",\"journal-code\":\"ACR\",\"given-name\":\"Betty\"," +
                "\"family-name\":\"Rubble\",\"email-addresses\":[\"diffbetty@bedrock.com\", \"betty@bedrock.com\"], " +
                "\"identifiers\": [{\"system\": \"scopus\", \"identifier\": \"9999\"}]} " +

                "]}");

        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        final WebClient.ResponseSpec authorsSpecMock = createWebClientResponseSpecMock(emWebClient, "authors");
        Mockito.when(authorsSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("{\"Response\": {}}"));

        final WebClient.ResponseSpec reviewersSpecMock = createWebClientResponseSpecMock(emWebClient, "reviewer");
        Mockito.when(reviewersSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just("{\"Response\": {" +
                        "\"result\": {\"e\": [" +
                        // This will match the one passed over the Reviewers call above and will be skipped
                        "{\"reviewerPrimaryEmailAddress\": \"fred@bedrock.com\", " +
                        "\"reviewerFirstName\": \"Fred\", \"reviewerLastName\": \"Flintstone\", " +
                        "\"reviewerFullName\": \"Fred Flintstone\", \"reviewerAssignmentStatus\": \"Agreed\"}, " +

                        "{\"reviewerPrimaryEmailAddress\": \"wilma@bedrock.com\", " +
                        "\"reviewerFirstName\": \"Wilma\", \"reviewerLastName\": \"Flintstone\", " +
                        "\"reviewerFullName\": \"Wilma Flintstone\", \"reviewerAssignmentStatus\": \"Uninvited\"}, " +

                        "{\"reviewerPrimaryEmailAddress\": \"Barney@bedrock.com\", " +
                        "\"reviewerFirstName\": \"Barney\", \"reviewerLastName\": \"Rubble\", " +
                        "\"reviewerFullName\": \"Barney Rubble\", \"reviewerAssignmentStatus\": \"Complete\"}, " +

                        // Will also be skipped, but matches against a list of emails
                        "{\"reviewerPrimaryEmailAddress\": \"Betty@bedrock.com\", " +
                        "\"reviewerFirstName\": \"Betty\", \"reviewerLastName\": \"Rubble\", " +
                        "\"reviewerFullName\": \"Betty Rubble\", \"reviewerAssignmentStatus\": \"Unassigned\"}" +

                        "]}}}"));

        ResponseEntity<InitialisationDetails> response = initialisationService.getInitialisation(null, "TIBS", 123L);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isIsElsevier());
        assertEquals(List.of(InitialisationDetails.PermittedFeaturesEnum.ADDEDREVIEWERS,
                InitialisationDetails.PermittedFeaturesEnum.AUTHORSEARCH,
                InitialisationDetails.PermittedFeaturesEnum.KEYWORDSEARCH,
                InitialisationDetails.PermittedFeaturesEnum.SESSIONPREFERENCES,
                InitialisationDetails.PermittedFeaturesEnum.MANUSCRIPTDETAILS,
                InitialisationDetails.PermittedFeaturesEnum.REVIEWERHISTORY,
                InitialisationDetails.PermittedFeaturesEnum.REVIEWERLIMITS), response.getBody().getPermittedFeatures());
        assertEquals(4, response.getBody().getReviewers().size());
        assertEquals(1, response.getBody().getReviewers().get(0).getEmails().size());
        assertEquals("fred@bedrock.com", response.getBody().getReviewers().get(0).getEmails().get(0));
        assertEquals("Fred", response.getBody().getReviewers().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getReviewers().get(0).getLastName());
        assertEquals("Fred Flintstone", response.getBody().getReviewers().get(0).getDisplayName());
        assertEquals(ReviewerStatus.INVITED, response.getBody().getReviewers().get(0).getStatus());

        assertEquals(1, response.getBody().getReviewers().get(1).getEmails().size());
        assertEquals("wilma@bedrock.com", response.getBody().getReviewers().get(1).getEmails().get(0));
        assertEquals("Wilma", response.getBody().getReviewers().get(1).getFirstName());
        assertEquals("Flintstone", response.getBody().getReviewers().get(1).getLastName());
        assertEquals("Wilma Flintstone", response.getBody().getReviewers().get(1).getDisplayName());
        assertEquals(ReviewerStatus.UNINVITED, response.getBody().getReviewers().get(1).getStatus());

        assertEquals(1, response.getBody().getReviewers().get(2).getEmails().size());
        assertEquals("barney@bedrock.com", response.getBody().getReviewers().get(2).getEmails().get(0));
        assertEquals("Barney", response.getBody().getReviewers().get(2).getFirstName());
        assertEquals("Rubble", response.getBody().getReviewers().get(2).getLastName());
        assertEquals("Barney Rubble", response.getBody().getReviewers().get(2).getDisplayName());
        assertEquals(ReviewerStatus.COMPLETED, response.getBody().getReviewers().get(2).getStatus());

        assertEquals(2, response.getBody().getReviewers().get(3).getEmails().size());
        assertEquals("betty@bedrock.com", response.getBody().getReviewers().get(3).getEmails().get(0));
        assertEquals("diffbetty@bedrock.com", response.getBody().getReviewers().get(3).getEmails().get(1));
        assertEquals("Betty", response.getBody().getReviewers().get(3).getFirstName());
        assertEquals("Rubble", response.getBody().getReviewers().get(3).getLastName());
        assertEquals("Betty Rubble", response.getBody().getReviewers().get(3).getDisplayName());
        assertEquals(ReviewerStatus.TERMINATED, response.getBody().getReviewers().get(3).getStatus());

        assertNull(response.getBody().getCoAuthors());
    }

    @Test
    void testNonUrsdbManuscriptZeroAuthorsOrReviewers() {
        SessionContext.initialize(new SessionData(ProductType.FindReviewers, "code", "bearer", "TREPAR", false, false));
        SessionContext.initializeIdentity(1234L, "fred@bedrock.com", null, null, null);

        final List<InitialisationDetails.PermittedFeaturesEnum> permittedFeatures =
                List.of(InitialisationDetails.PermittedFeaturesEnum.ADDEDREVIEWERS,
                        InitialisationDetails.PermittedFeaturesEnum.AUTHORSEARCH,
                        InitialisationDetails.PermittedFeaturesEnum.KEYWORDSEARCH,
                        InitialisationDetails.PermittedFeaturesEnum.SESSIONPREFERENCES,
                        InitialisationDetails.PermittedFeaturesEnum.MANUSCRIPTDETAILS,
                        InitialisationDetails.PermittedFeaturesEnum.REVIEWERHISTORY,
                        InitialisationDetails.PermittedFeaturesEnum.REVIEWERLIMITS);

        final List<InitialisationDetails.PermittedFeaturesEnum> nonElsevierPermittedFeatures =
                List.of(InitialisationDetails.PermittedFeaturesEnum.ADDEDREVIEWERS,
                        InitialisationDetails.PermittedFeaturesEnum.AUTHORSEARCH,
                        InitialisationDetails.PermittedFeaturesEnum.KEYWORDSEARCH,
                        InitialisationDetails.PermittedFeaturesEnum.SESSIONPREFERENCES,
                        InitialisationDetails.PermittedFeaturesEnum.MANUSCRIPTDETAILS);

        final WebClient.ResponseSpec authorSpecMock = createWebClientResponseSpecMock(emWebClient, "authors");
        Mockito.when(authorSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just("{\"Response\": {\"result\": {\"e\": []}}}"))
                .thenReturn(Mono.just("{\"Response\": {\"result\": {}}}"))
                .thenReturn(Mono.just("{\"Response\": {}}"))
                .thenReturn(Mono.just("{\"Response\": }"))
                .thenReturn(Mono.just("{}"))
                .thenReturn(Mono.just(""));

        final WebClient.ResponseSpec reviewersSpecMock = createWebClientResponseSpecMock(emWebClient, "reviewer");
        Mockito.when(reviewersSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just("{\"Response\": {\"result\": {\"e\": []}}}"))
                .thenReturn(Mono.just("{\"Response\": {\"result\": {}}}"))
                .thenReturn(Mono.just("{\"Response\": {}}"))
                .thenReturn(Mono.just("{\"Response\": }"))
                .thenReturn(Mono.just("{}"))
                .thenReturn(Mono.just(""));

        final WebClient.ResponseSpec manuscriptBasicSpecMock = createWebClientResponseSpecMock(emWebClient, "metadata");
        Mockito.when(manuscriptBasicSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just("{\"Response\": {\"result\": {\"e\": {\"journalName\": \"\", \"keywords\": [], \"classifications\": []}}}}"))
                .thenReturn(Mono.just("{\"Response\": {\"result\": {\"e\": {}}}}"))
                .thenReturn(Mono.just("Invalid JSON"))
                .thenReturn(Mono.just(""))
                .thenReturn(null);

        ResponseEntity<InitialisationDetails> response = initialisationService.getInitialisation(null, "TREPAR", 123L);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isIsElsevier());
        assertEquals(permittedFeatures, response.getBody().getPermittedFeatures());
        assertNull(response.getBody().getCorrespondingAuthors());
        assertNull(response.getBody().getCoAuthors());
        assertNull(response.getBody().getReviewers());

        // Check the case where we have a journal that is not an Elsevier journal
        SessionContext.initialize(new SessionData(ProductType.FindReviewers, "code", "bearer", "NON-ELS1", false, false));
        response = initialisationService.getInitialisation(null, "NON-ELS1", 123L);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertFalse(response.getBody().isIsElsevier());
        assertEquals(nonElsevierPermittedFeatures, response.getBody().getPermittedFeatures());
        assertNull(response.getBody().getJournalIssnl());
        assertNull(response.getBody().getCorrespondingAuthors());
        assertNull(response.getBody().getCoAuthors());
        assertNull(response.getBody().getReviewers());

        response = initialisationService.getInitialisation(null, "NON-ELS2", 123L);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertFalse(response.getBody().isIsElsevier());
        assertEquals(nonElsevierPermittedFeatures, response.getBody().getPermittedFeatures());
        assertNull(response.getBody().getJournalIssnl());
        assertNull(response.getBody().getCorrespondingAuthors());
        assertNull(response.getBody().getCoAuthors());
        assertNull(response.getBody().getReviewers());

        response = initialisationService.getInitialisation(null, "NON-ELS3", 123L);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertFalse(response.getBody().isIsElsevier());
        assertEquals(nonElsevierPermittedFeatures, response.getBody().getPermittedFeatures());
        assertNull(response.getBody().getJournalIssnl());
        assertNull(response.getBody().getCorrespondingAuthors());
        assertNull(response.getBody().getCoAuthors());
        assertNull(response.getBody().getReviewers());

        response = initialisationService.getInitialisation(null, "NON-ELS4", 123L);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertFalse(response.getBody().isIsElsevier());
        assertEquals(nonElsevierPermittedFeatures, response.getBody().getPermittedFeatures());
        assertNull(response.getBody().getJournalIssnl());
        assertNull(response.getBody().getCorrespondingAuthors());
        assertNull(response.getBody().getCoAuthors());
        assertNull(response.getBody().getReviewers());

        SessionContext.initialize(new SessionData(ProductType.FindReviewers, "code", "bearer", "JHKCC", false, false));
        response = initialisationService.getInitialisation(null, "JHKCC", 123L);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertFalse(response.getBody().isIsElsevier());
        assertEquals(nonElsevierPermittedFeatures, response.getBody().getPermittedFeatures());
        assertNull(response.getBody().getJournalIssnl());
        assertNull(response.getBody().getCorrespondingAuthors());
        assertNull(response.getBody().getCoAuthors());
        assertNull(response.getBody().getReviewers());

        // Check the case where we have Find Editors
        SessionContext.initialize(new SessionData(ProductType.FindEditors, "code", "bearer", "JHKCC", false, false));
        response = initialisationService.getInitialisation(null, "JHKCC", null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isIsElsevier());
        assertEquals(List.of(InitialisationDetails.PermittedFeaturesEnum.ADDEDREVIEWERS,
                InitialisationDetails.PermittedFeaturesEnum.AUTHORSEARCH,
                InitialisationDetails.PermittedFeaturesEnum.CANDIDATESEARCH,
                InitialisationDetails.PermittedFeaturesEnum.REVIEWERHISTORY,
                InitialisationDetails.PermittedFeaturesEnum.VOLUNTEERS), response.getBody().getPermittedFeatures());
        assertNull(response.getBody().getJournalIssnl());
        assertNull(response.getBody().getCorrespondingAuthors());
        assertNull(response.getBody().getCoAuthors());
        assertNull(response.getBody().getReviewers());
    }

    @Test
    void testNonUrsdbManuscriptAuthorsNotFound() {
        SessionContext.initialize(new SessionData(ProductType.FindReviewers, "code", "bearer", "THELANCETDE", true, false));

        final List<InitialisationDetails.PermittedFeaturesEnum> permittedFeatures =
                List.of(InitialisationDetails.PermittedFeaturesEnum.ADDEDREVIEWERS,
                        InitialisationDetails.PermittedFeaturesEnum.AUTHORSEARCH,
                        InitialisationDetails.PermittedFeaturesEnum.KEYWORDSEARCH,
                        InitialisationDetails.PermittedFeaturesEnum.SESSIONPREFERENCES,
                        InitialisationDetails.PermittedFeaturesEnum.MANUSCRIPTDETAILS,
                        InitialisationDetails.PermittedFeaturesEnum.REVIEWERHISTORY,
                        InitialisationDetails.PermittedFeaturesEnum.REVIEWERLIMITS);

        final WebClient.RequestHeadersUriSpec uriSpecMock = Mockito.mock(WebClient.RequestHeadersUriSpec.class);
        final WebClient.RequestHeadersSpec headersSpecMock = Mockito.mock(WebClient.RequestHeadersSpec.class);
        Mockito.when(emWebClient.get()).thenReturn(uriSpecMock);
        Mockito.when(uriSpecMock.uri(Mockito.any(URI.class))).thenReturn(headersSpecMock);
        Mockito.when(headersSpecMock.header(Mockito.anyString(), Mockito.anyString())).thenReturn(headersSpecMock);
        Mockito.when(headersSpecMock.accept(Mockito.notNull())).thenReturn(headersSpecMock);
        Mockito.when(headersSpecMock.retrieve())
                .thenThrow(new WebClientResponseException(404, "Not Found", null, null, null))
                .thenThrow(new WebClientResponseException(404, "Not Found", null, null, null))
                .thenThrow(new WebClientResponseException(404, "Not Found", null, null, null));

        ResponseEntity<InitialisationDetails> response = initialisationService.getInitialisation(null, "THELANCETDE", 123L);

        Mockito.verify(headersSpecMock, Mockito.times(3)).retrieve();

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isIsElsevier());
        assertEquals(permittedFeatures, response.getBody().getPermittedFeatures());
        assertNull(response.getBody().getCorrespondingAuthors());
        assertNull(response.getBody().getCoAuthors());
        assertNull(response.getBody().getReviewers());
    }

    @Test
    void testNonUrsdbManuscriptAuthorsError() {
        SessionContext.initialize(new SessionData(ProductType.FindReviewers, "code", "bearer", "THELANCETDE", true, false));

        final List<InitialisationDetails.PermittedFeaturesEnum> permittedFeatures =
                List.of(InitialisationDetails.PermittedFeaturesEnum.ADDEDREVIEWERS,
                        InitialisationDetails.PermittedFeaturesEnum.AUTHORSEARCH,
                        InitialisationDetails.PermittedFeaturesEnum.KEYWORDSEARCH,
                        InitialisationDetails.PermittedFeaturesEnum.SESSIONPREFERENCES,
                        InitialisationDetails.PermittedFeaturesEnum.MANUSCRIPTDETAILS,
                        InitialisationDetails.PermittedFeaturesEnum.REVIEWERHISTORY,
                        InitialisationDetails.PermittedFeaturesEnum.REVIEWERLIMITS);

        final WebClient.RequestHeadersUriSpec uriSpecMock = Mockito.mock(WebClient.RequestHeadersUriSpec.class);
        final WebClient.RequestHeadersSpec headersSpecMock = Mockito.mock(WebClient.RequestHeadersSpec.class);
        Mockito.when(emWebClient.get()).thenReturn(uriSpecMock);
        Mockito.doReturn(headersSpecMock).when(uriSpecMock).uri((URI) Mockito.argThat(u -> u.toString().contains("authors")));
        Mockito.when(headersSpecMock.header(Mockito.anyString(), Mockito.anyString())).thenReturn(headersSpecMock);
        Mockito.when(headersSpecMock.accept(Mockito.notNull())).thenReturn(headersSpecMock);
        Mockito.when(headersSpecMock.retrieve())
                .thenThrow(new WebClientResponseException(500, "Internal Error", null, null, null))
                .thenThrow(new WebClientResponseException(401, "Unauthorized", null, null, null))
                .thenThrow(new WebClientResponseException(504, "Gateway Timeout", null, null, null));

        ResponseEntity<InitialisationDetails> response = initialisationService.getInitialisation(null, "THELANCETDE", 123L);

        // Check the error retries
        Mockito.verify(headersSpecMock, Mockito.times(3)).retrieve();

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isIsElsevier());
        assertEquals(permittedFeatures, response.getBody().getPermittedFeatures());
        assertNull(response.getBody().getCorrespondingAuthors());
        assertNull(response.getBody().getCoAuthors());
        assertNull(response.getBody().getReviewers());
    }

    @Test
    void testFindEditors() throws SQLException {
        SessionContext.initialize(new SessionData(ProductType.FindEditors, null, null, null, false, false));

        ResponseEntity<InitialisationDetails> response = initialisationService.getInitialisation(null, null, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isIsElsevier());
        assertNull(response.getBody().getReviewers(), "Reviews not valid");
        assertEquals(List.of(InitialisationDetails.PermittedFeaturesEnum.ADDEDREVIEWERS,
                InitialisationDetails.PermittedFeaturesEnum.AUTHORSEARCH,
                InitialisationDetails.PermittedFeaturesEnum.CANDIDATESEARCH,
                InitialisationDetails.PermittedFeaturesEnum.REVIEWERHISTORY), response.getBody().getPermittedFeatures());
        assertNull(response.getBody().getCrowdsourcedReviewers(), "Crowdsourced not valid");
        assertNull(response.getBody().getSuggestedReviewers(), "Suggested Reviewers not valid");
        assertNull(response.getBody().getOpposedReviewers(), "Opposed Reviewers not valid");
        assertNull(response.getBody().getJournalClassifications(), "Non Null Journal Classifications");
        assertNull(response.getBody().getJournalIssnl(), "Non Null ISSN");

        response = initialisationService.getInitialisation(null, "", null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isIsElsevier());
        assertNull(response.getBody().getReviewers(), "Reviews not valid");
        assertEquals(List.of(InitialisationDetails.PermittedFeaturesEnum.ADDEDREVIEWERS,
                InitialisationDetails.PermittedFeaturesEnum.AUTHORSEARCH,
                InitialisationDetails.PermittedFeaturesEnum.CANDIDATESEARCH,
                InitialisationDetails.PermittedFeaturesEnum.REVIEWERHISTORY), response.getBody().getPermittedFeatures());
        assertNull(response.getBody().getCrowdsourcedReviewers(), "Crowdsourced not valid");
        assertNull(response.getBody().getSuggestedReviewers(), "Suggested Reviewers not valid");
        assertNull(response.getBody().getOpposedReviewers(), "Opposed Reviewers not valid");
        assertNull(response.getBody().getJournalClassifications(), "Non Null Journal Classifications");
        assertNull(response.getBody().getJournalIssnl(), "Non Null ISSN");

        JdbcMockAnswer mockAnswer1 = new JdbcMockAnswer();
        mockAnswer1.addResultMapping(Map.of(
                "issn_l", "1535-6108",
                "classifications", "-null-",
                "has_ebms", true,
                "crowdsourced_reviewers", "-null-"));

        JdbcMockAnswer mockAnswer2 = new JdbcMockAnswer();
        mockAnswer2.addResultMapping(Map.of(
                "issn_l", "-null-",
                "classifications", "-null-",
                "has_ebms", false,
                "crowdsourced_reviewers", "-null-"));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(InitialisationInfoResultsExtractor.class))).thenAnswer(mockAnswer1).thenAnswer(mockAnswer2);

        response = initialisationService.getInitialisation(null, "ACR", null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isIsElsevier());
        assertNull(response.getBody().getReviewers(), "Reviews not valid");
        assertEquals(List.of(InitialisationDetails.PermittedFeaturesEnum.ADDEDREVIEWERS,
                InitialisationDetails.PermittedFeaturesEnum.AUTHORSEARCH,
                InitialisationDetails.PermittedFeaturesEnum.CANDIDATESEARCH,
                InitialisationDetails.PermittedFeaturesEnum.REVIEWERHISTORY,
                InitialisationDetails.PermittedFeaturesEnum.VOLUNTEERS,
                InitialisationDetails.PermittedFeaturesEnum.EDITORIALBOARDMEMBERS), response.getBody().getPermittedFeatures());
        assertNull(response.getBody().getCrowdsourcedReviewers(), "Crowdsourced not valid");
        assertNull(response.getBody().getSuggestedReviewers(), "Suggested Reviewers not valid");
        assertNull(response.getBody().getOpposedReviewers(), "Opposed Reviewers not valid");
        assertNull(response.getBody().getJournalClassifications(), "Non Null Journal Classifications");
        assertEquals("1535-6108", response.getBody().getJournalIssnl());

        response = initialisationService.getInitialisation(null, "ACR", null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isIsElsevier());
        assertNull(response.getBody().getReviewers(), "Reviews not valid");
        assertEquals(List.of(InitialisationDetails.PermittedFeaturesEnum.ADDEDREVIEWERS,
                InitialisationDetails.PermittedFeaturesEnum.AUTHORSEARCH,
                InitialisationDetails.PermittedFeaturesEnum.CANDIDATESEARCH,
                InitialisationDetails.PermittedFeaturesEnum.REVIEWERHISTORY,
                InitialisationDetails.PermittedFeaturesEnum.VOLUNTEERS), response.getBody().getPermittedFeatures());
        assertNull(response.getBody().getCrowdsourcedReviewers(), "Crowdsourced not valid");
        assertNull(response.getBody().getSuggestedReviewers(), "Suggested Reviewers not valid");
        assertNull(response.getBody().getOpposedReviewers(), "Opposed Reviewers not valid");
        assertNull(response.getBody().getJournalClassifications(), "Non Null Journal Classifications");
        assertNull(response.getBody().getJournalIssnl(), "Non Null ISSN");
    }

    @Test
    void testNonElsevierISSN() throws IOException, InterruptedException {
        SessionContext.initialize(new SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", false, false));
        SessionContext.initializeIdentity(1234L, "fred@bedrock.com", null, null, null);

        final List<InitialisationDetails.PermittedFeaturesEnum> nonElsevierPermittedFeatures =
                List.of(InitialisationDetails.PermittedFeaturesEnum.ADDEDREVIEWERS,
                        InitialisationDetails.PermittedFeaturesEnum.AUTHORSEARCH,
                        InitialisationDetails.PermittedFeaturesEnum.KEYWORDSEARCH,
                        InitialisationDetails.PermittedFeaturesEnum.SESSIONPREFERENCES,
                        InitialisationDetails.PermittedFeaturesEnum.MANUSCRIPTDETAILS);

        final WebClient.ResponseSpec authorSpecMock = createWebClientResponseSpecMock(emWebClient, "authors");
        Mockito.when(authorSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("{}"));

        final WebClient.ResponseSpec reviewersSpecMock = createWebClientResponseSpecMock(emWebClient, "reviewer");
        Mockito.when(reviewersSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("{}"));

        final WebClient.ResponseSpec manuscriptBasicSpecMock = createWebClientResponseSpecMock(emWebClient, "metadata");
        Mockito.when(manuscriptBasicSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just("{\"Response\": {\"result\": {\"e\": {\"journalName\": \"Test Journal\"}}}}"));

        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode())
                .thenReturn(200).thenReturn(200)
                .thenReturn(200).thenReturn(200)
                .thenReturn(200).thenReturn(200)
                .thenReturn(200).thenReturn(200)
                .thenReturn(200)
                .thenReturn(500);
        Mockito.when(mockTokenResponse.body())
                .thenReturn("[{\"prefsrctitle\": \"Test Journal\", \"eissn\": \"1234-5678\"}]")
                .thenReturn("[{\"prefsrctitle\": \"Test Journal\", \"issnp\": \"2222-3333\"}, {}]")
                .thenReturn("Invalid JSON")
                .thenReturn("")
                .thenReturn(null)
                .thenReturn("[]")
                .thenReturn("[{}]")
                .thenReturn("[{\"prefsrctitle\": \"Not Test Journal\"}]")
                .thenReturn("[{\"prefsrctitle\": \"Test Journal\"}]");

        Mockito.when(httpClientWithoutCertificateCheck.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse).thenReturn(mockTokenResponse)
                .thenReturn(mockTokenResponse).thenReturn(mockTokenResponse)
                .thenReturn(mockTokenResponse).thenReturn(mockTokenResponse)
                .thenReturn(mockTokenResponse).thenReturn(mockTokenResponse)
                .thenReturn(mockTokenResponse).thenReturn(mockTokenResponse);

        ResponseEntity<InitialisationDetails> response = initialisationService.getInitialisation(null, "NON-ELS1", 123L);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertFalse(response.getBody().isIsElsevier());
        assertEquals(nonElsevierPermittedFeatures, response.getBody().getPermittedFeatures());
        assertEquals("1234-5678", response.getBody().getJournalIssnl());

        response = initialisationService.getInitialisation(null, "NON-ELS2", 123L);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertFalse(response.getBody().isIsElsevier());
        assertEquals(nonElsevierPermittedFeatures, response.getBody().getPermittedFeatures());
        assertEquals("2222-3333", response.getBody().getJournalIssnl());

        // Test all the empty response data
        for (int i = 0; i < 8; i++) {
            System.out.println("Running Iteration " + i);
            response = initialisationService.getInitialisation(null, "NON-ELS3", 123L);

            assertNotNull(response, "Null Response");
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertFalse(response.getBody().isIsElsevier());
            assertEquals(nonElsevierPermittedFeatures, response.getBody().getPermittedFeatures());
            assertNull(response.getBody().getJournalIssnl());
            assertNull(response.getBody().getCorrespondingAuthors());
            assertNull(response.getBody().getCoAuthors());
            assertNull(response.getBody().getReviewers());
        }

        Mockito.verify(httpClientWithoutCertificateCheck, Mockito.times(10)).send(requestCaptor.capture(),
                Mockito.any(HttpResponse.BodyHandler.class));
        assertEquals("title=Test+Journal&fields=id&fields=issn&fields=title", getHttpRequestBody(requestCaptor));
    }

    @Test
    void testNonElsevierISSNInterruptedException() throws IOException, InterruptedException {
        Mockito.when(httpClientWithoutCertificateCheck.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenThrow(new InterruptedException());

        assertNull(scopusSources.getJournalIssn("Title"));
    }
}
