package com.elsevier.find.reviewers;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.filter.SessionRequestFilter;
import com.elsevier.find.reviewers.utils.CookieManager;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.Cookie;
import org.junit.jupiter.api.Test;
import org.springframework.boot.actuate.endpoint.web.EndpointMapping;
import org.springframework.boot.actuate.endpoint.web.servlet.ControllerEndpointHandlerMapping;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockCookie;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.mvc.method.RequestMappingInfo;

import java.io.IOException;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Test handling of the Session Cookie enforcement
 */
public class SessionRequestFilterTest {

    @Test
    void testNoAuthenticationCookie() throws ServletException, IOException {
        MockHttpServletRequest httpServletRequest = new MockHttpServletRequest();
        MockHttpServletResponse httpServletResponse = new MockHttpServletResponse();
        MockFilterChain filterChain = new MockFilterChain();

        SessionRequestFilter reqFilter = new SessionRequestFilter(null, new CookieManager(new ObjectMapper()), null);
        reqFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);

        assertEquals(401, httpServletResponse.getStatus());

        httpServletRequest.setCookies(new Cookie[]{});
        reqFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);

        assertEquals(401, httpServletResponse.getStatus());

        httpServletRequest.setCookies(new MockCookie("Unknown", "Unknown"));
        reqFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);

        assertEquals(401, httpServletResponse.getStatus());

        assertThrows(InternalException.class, SessionContext::isReadOnly);
        assertThrows(InternalException.class, SessionContext::getBearerToken);
    }

    @Test
    void testAuthenticationCookie() throws ServletException, IOException {
        MockHttpServletRequest httpServletRequest = new MockHttpServletRequest();
        MockHttpServletResponse httpServletResponse = new MockHttpServletResponse();

        final Boolean[] sessionReadOnly = {null};
        final String[] sessionBearer = {null};

        FilterChain filterChain = new FilterChain() {
            public void doFilter(ServletRequest request, ServletResponse response) throws IOException, ServletException {
                sessionReadOnly[0] = SessionContext.isReadOnly();
                sessionBearer[0] = SessionContext.getBearerToken();
            }
        };

        httpServletRequest.addHeader("X-Scope", "FR-EM-ACR");
        httpServletRequest.addHeader("X-CorrelationId", "12345");
        httpServletRequest.setCookies(new MockCookie("FR-EM-ACR",
                Base64.getEncoder().encodeToString("{\"c\": \"code\", \"b\": \"bearer2\", \"j\": \"ACR\", \"r\": true}".getBytes())));

        SessionRequestFilter reqFilter = new SessionRequestFilter(null, new CookieManager(new ObjectMapper()), null);
        reqFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);

        assertEquals(200, httpServletResponse.getStatus());
        assertEquals(true, sessionReadOnly[0]);
        assertEquals("bearer2", sessionBearer[0]);

        httpServletRequest.setCookies(new MockCookie("Unknown", "Unknown"),
                new MockCookie("FR-EM-ACR", "SingleElementNotValidForOldStructure"));
        reqFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);

        assertEquals(401, httpServletResponse.getStatus());

        // Test the case where there is an invalid cookie format
        httpServletRequest.setCookies(new MockCookie("FindReviewers-Session-ACR",
                Base64.getEncoder().encodeToString("INVALID JSON".getBytes())));
        reqFilter = new SessionRequestFilter(null, new CookieManager(new ObjectMapper()), null);
        reqFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);

        assertEquals(401, httpServletResponse.getStatus());
    }

    /**
     * Test when there are both the journal specific and the generic cookie (the journal one should be used)
     */
    @Test
    void testAuthenticationCookieOrder() throws ServletException, IOException {
        MockHttpServletRequest httpServletRequest = new MockHttpServletRequest();
        MockHttpServletResponse httpServletResponse = new MockHttpServletResponse();

        final Boolean[] sessionReadOnly = {null};
        final String[] sessionBearer = {null};

        FilterChain filterChain = new FilterChain() {
            public void doFilter(ServletRequest request, ServletResponse response) throws IOException, ServletException {
                sessionReadOnly[0] = SessionContext.isReadOnly();
                sessionBearer[0] = SessionContext.getBearerToken();
            }
        };

        httpServletRequest.addHeader("X-Scope", "FR-IDP-ACR");
        httpServletRequest.addHeader("X-CorrelationId", "");
        httpServletRequest.setCookies(new MockCookie("FindReviewers-Session-ACR",
                        Base64.getEncoder().encodeToString("{\"p\": \"R\", \"c\": \"code\", \"b\": \"bearer\", \"j\": \"ACR\", \"r\": false}".getBytes())),
                new MockCookie("FR-IDP-ACR",
                        Base64.getEncoder().encodeToString("{\"p\": \"R\", \"c\": \"code\", \"b\": \"bearer-journal\", \"j\": \"ACR\", \"r\": false}".getBytes())));

        SessionRequestFilter reqFilter = new SessionRequestFilter(null, new CookieManager(new ObjectMapper()), null);
        reqFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);

        assertEquals(200, httpServletResponse.getStatus());
        assertEquals(false, sessionReadOnly[0]);
        assertEquals("bearer-journal", sessionBearer[0]);

        sessionReadOnly[0] = null;
        sessionBearer[0] = null;
        httpServletRequest.setCookies(new MockCookie("FR-IDP-ACR",
                        Base64.getEncoder().encodeToString("{\"c\": \"code\", \"b\": \"bearer-journal\", \"j\": \"ACR\", \"r\": false}".getBytes())),
                new MockCookie("FindReviewers-Session-ACR",
                        Base64.getEncoder().encodeToString("{\"c\": \"code\", \"b\": \"bearer\", \"j\": \"ACR\", \"r\": false}".getBytes())));

        reqFilter = new SessionRequestFilter(null, new CookieManager(new ObjectMapper()), null);
        reqFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);

        assertEquals(200, httpServletResponse.getStatus());
        assertEquals(false, sessionReadOnly[0]);
        assertEquals("bearer-journal", sessionBearer[0]);
    }

    /**
     * Test endpoints that do not require Authentication
     */
    @Test
    void testOpenEndpoints() throws IOException, ServletException {
        MockHttpServletRequest httpServletRequest = new MockHttpServletRequest();
        httpServletRequest.setRequestURI("/");
        MockHttpServletResponse httpServletResponse = new MockHttpServletResponse();

        final Boolean[] filterCalled = {false};

        FilterChain filterChain = new FilterChain() {
            public void doFilter(ServletRequest request, ServletResponse response) throws IOException, ServletException {
                filterCalled[0] = true;
            }
        };

        SessionRequestFilter reqFilter = new SessionRequestFilter(null, new CookieManager(new ObjectMapper()), null);
        reqFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);

        assertTrue(filterCalled[0], "Filter was never called for /");

        httpServletRequest.setRequestURI(null);
        filterCalled[0] = false;
        reqFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);

        assertTrue(filterCalled[0], "Filter was never called for null");
    }

    /**
     * Test endpoints that do not implemented endpoints
     */
    @Test
    void testUnknownEndpoints() throws IOException, ServletException {
        MockHttpServletRequest httpServletRequest = new MockHttpServletRequest();
        httpServletRequest.setRequestURI("/brian");
        MockHttpServletResponse httpServletResponse = new MockHttpServletResponse();

        final Boolean[] filterCalled = {false};

        FilterChain filterChain = new FilterChain() {
            public void doFilter(ServletRequest request, ServletResponse response) throws IOException, ServletException {
                filterCalled[0] = true;
            }
        };

        ControllerEndpointHandlerMapping handlerMapping = new ControllerEndpointHandlerMapping(
                new EndpointMapping("/"), Collections.emptyList(), null) {
            public Map<RequestMappingInfo, HandlerMethod> getHandlerMethods() {
                RequestMappingInfo mappingInfo = RequestMappingInfo
                        .paths("/the/url")
                        .methods(RequestMethod.POST)
                        .consumes(MediaType.APPLICATION_JSON_VALUE)
                        .produces(MediaType.APPLICATION_JSON_VALUE)
                        .build();
                Map<RequestMappingInfo, HandlerMethod> map = new HashMap<>();
                map.put(mappingInfo, null);
                return map;
            }
        };

        SessionRequestFilter reqFilter = new SessionRequestFilter(handlerMapping, new CookieManager(new ObjectMapper()), null);
        reqFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);

        assertFalse(filterCalled[0], "Filter was called for /brian");
    }

    @Test
    void testInvalidJWT() throws ServletException, IOException {
        MockHttpServletRequest httpServletRequest = new MockHttpServletRequest();
        httpServletRequest.setRequestURI("/");
        httpServletRequest.addHeader("x-amzn-oidc-data", "INVALID_CLAIM_STRUCTURE");
        MockHttpServletResponse httpServletResponse = new MockHttpServletResponse();

        final String[] emails = {null};
        final Boolean[] called = {false};

        FilterChain filterChain = new FilterChain() {
            public void doFilter(ServletRequest request, ServletResponse response) throws IOException, ServletException {
                emails[0] = SessionContext.getAllEmails().isEmpty() ? null : String.join(",", SessionContext.getAllEmails());
                called[0] = true;
            }
        };

        SessionRequestFilter reqFilter = new SessionRequestFilter(null, new CookieManager(new ObjectMapper()), null);
        reqFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);

        assertTrue(called[0]);
        assertNull(emails[0]);
        assertNull(SessionContext.getDisplayName());
    }

    @Test
    void testEmptyJWT() throws ServletException, IOException {
        String token = JWT.create().withIssuer("Elsevier").sign(Algorithm.HMAC256("secret"));

        MockHttpServletRequest httpServletRequest = new MockHttpServletRequest();
        httpServletRequest.setRequestURI("/");
        httpServletRequest.addHeader("x-amzn-oidc-data", token);
        MockHttpServletResponse httpServletResponse = new MockHttpServletResponse();

        final String[] emails = {null};
        final Boolean[] called = {false};

        FilterChain filterChain = new FilterChain() {
            public void doFilter(ServletRequest request, ServletResponse response) throws IOException, ServletException {
                emails[0] = SessionContext.getAllEmails().isEmpty() ? null : String.join(",", SessionContext.getAllEmails());
                called[0] = true;
            }
        };

        SessionRequestFilter reqFilter = new SessionRequestFilter(null, new CookieManager(new ObjectMapper()), null);
        reqFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);

        assertTrue(called[0]);
        assertNull(emails[0]);

        // Check with non-numeric webUserId
        token = JWT.create().withIssuer("Elsevier").withSubject("NaN")
                .withClaim("email", "johnsmith@mydomain.com")
                .withClaim("email_verified", false)
                .sign(Algorithm.HMAC256("secret"));
        httpServletRequest = new MockHttpServletRequest();
        httpServletRequest.setRequestURI("/");
        httpServletRequest.addHeader("x-amzn-oidc-data", token);

        called[0] = false;
        reqFilter = new SessionRequestFilter(null, new CookieManager(new ObjectMapper()), null);
        reqFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);

        assertTrue(called[0]);
        assertNull(emails[0]);

        token = JWT.create().withIssuer("Elsevier").withSubject("123")
                .withClaim("email", (String) null)
                .sign(Algorithm.HMAC256("secret"));
        httpServletRequest = new MockHttpServletRequest();
        httpServletRequest.setRequestURI("/");
        httpServletRequest.addHeader("x-amzn-oidc-data", token);

        called[0] = false;
        reqFilter = new SessionRequestFilter(null, new CookieManager(new ObjectMapper()), null);
        reqFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);

        assertTrue(called[0]);
        assertNull(emails[0]);
    }

    @Test
    void testPopulatedJWT() throws ServletException, IOException {
        String token = JWT.create().withIssuer("Elsevier")
                .withSubject("111")
                .withClaim("email", "johnsmith@mydomain.com")
                .withClaim("email_verified", true)
                .withClaim("secondary_emails", List.of(
                        Map.of("email", "JohnSmith@gmail.com", "email_verified", true),
                        Map.of("email", "wilma@gmail.com", "email_verified", false),
                        Map.of("email", "john@smith.com", "email_verified", true)))
                .withClaim("name", "John Smith")
                .withClaim("analytics_info", Map.of(
                        "accessType", "ae:REG:SHIBBOLETH:INST:SHIBBOLETH",
                        "userId", "19768614"))
                .sign(Algorithm.HMAC256("secret"));

        MockHttpServletRequest httpServletRequest = new MockHttpServletRequest();
        httpServletRequest.setRequestURI("/");
        httpServletRequest.addHeader("x-amzn-oidc-data", token);
        MockHttpServletResponse httpServletResponse = new MockHttpServletResponse();

        final String[] emails = {null};
        final String[] name = {null};
        final Object[] analytics = {null};
        final Boolean[] called = {false};

        FilterChain filterChain = new FilterChain() {
            public void doFilter(ServletRequest request, ServletResponse response) throws IOException, ServletException {
                emails[0] = SessionContext.getAllEmails().isEmpty() ? null : String.join(",", SessionContext.getAllEmails());
                name[0] = SessionContext.getDisplayName();
                analytics[0] = SessionContext.getAnalyticsInfo();
                called[0] = true;
            }
        };

        SessionRequestFilter reqFilter = new SessionRequestFilter(null, new CookieManager(new ObjectMapper()), null);
        reqFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);

        assertTrue(called[0]);
        assertEquals("johnsmith@mydomain.com,johnsmith@gmail.com,john@smith.com", emails[0]);
        assertEquals("John Smith", name[0]);
        assertNotNull(analytics[0]);
    }

    @Test
    void testUnvalidatedEmailJWT() throws ServletException, IOException {
        String token = JWT.create().withIssuer("Elsevier")
                .withClaim("email", "johnsmith@mydomain.com")
                .withClaim("email_verified", false)
                .withClaim("name", "")
                .withClaim("given_name", "John")
                .withClaim("family_name", "Smith")
                .sign(Algorithm.HMAC256("secret"));
        MockHttpServletRequest httpServletRequest = new MockHttpServletRequest();
        httpServletRequest.setRequestURI("/");
        httpServletRequest.addHeader("x-amzn-oidc-data", token);
        MockHttpServletResponse httpServletResponse = new MockHttpServletResponse();

        final String[] emails = {null};
        final String[] name = {null};
        final Boolean[] called = {false};

        FilterChain filterChain = new FilterChain() {
            public void doFilter(ServletRequest request, ServletResponse response) throws IOException, ServletException {
                emails[0] = SessionContext.getAllEmails().isEmpty() ? null : String.join(",", SessionContext.getAllEmails());
                name[0] = SessionContext.getDisplayName();
                called[0] = true;
            }
        };

        SessionRequestFilter reqFilter = new SessionRequestFilter(null, new CookieManager(new ObjectMapper()), null);
        reqFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);

        assertTrue(called[0]);
        assertNull(emails[0]);
        assertEquals("John Smith", name[0]);

        token = JWT.create().withIssuer("Elsevier")
                .withClaim("email", "johnsmith@mydomain.com").sign(Algorithm.HMAC256("secret"));
        httpServletRequest = new MockHttpServletRequest();
        httpServletRequest.setRequestURI("/");
        httpServletRequest.addHeader("x-amzn-oidc-data", token);

        called[0] = false;
        reqFilter = new SessionRequestFilter(null, new CookieManager(new ObjectMapper()), null);
        reqFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);

        assertTrue(called[0]);
        assertNull(emails[0]);

        token = JWT.create().withIssuer("Elsevier")
                .withClaim("email", "johnsmith@mydomain.com")
                .withClaim("email_verified", (Boolean) null)
                .withClaim("secondary_emails", (String) null)
                .withClaim("analytics_info", (Map<String, Object>) null)
                .sign(Algorithm.HMAC256("secret"));
        httpServletRequest = new MockHttpServletRequest();
        httpServletRequest.setRequestURI("/");
        httpServletRequest.addHeader("x-amzn-oidc-data", token);

        called[0] = false;
        reqFilter = new SessionRequestFilter(null, new CookieManager(new ObjectMapper()), null);
        reqFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);

        assertTrue(called[0]);
        assertNull(emails[0]);
    }

    @Test
    void testCookieAndPopulatedJWT() throws ServletException, IOException {
        String token = JWT.create().withIssuer("Elsevier")
                .withSubject("111")
                .withClaim("email", "johnsmith@mydomain.com")
                .withClaim("email_verified", true)
                .withClaim("secondary_emails", List.of(
                        Map.of("email", "JohnSmith@gmail.com", "email_verified", true),
                        Map.of("email", "wilma@gmail.com", "email_verified", false),
                        Map.of("email", "john@smith.com", "email_verified", true)))
                .withClaim("analytics_info", Map.of(
                        "accessType", "ae:REG:SHIBBOLETH:INST:SHIBBOLETH",
                        "userId", "19768614"))
                .withClaim("name", (String) null)
                .withClaim("given_name", (String) null)
                .withClaim("family_name", (String) null)
                .sign(Algorithm.HMAC256("secret"));

        MockHttpServletRequest httpServletRequest = new MockHttpServletRequest();
        httpServletRequest.addHeader("x-amzn-oidc-data", token);
        httpServletRequest.addHeader("X-CorrelationId", " ");
        httpServletRequest.addHeader("X-Scope", "FR-IDP-ACR");
        httpServletRequest.setCookies(new MockCookie("FR-IDP-ACR",
                Base64.getEncoder().encodeToString("{\"c\": \"code\", \"b\": \"bearer\", \"j\": \"ACR\", \"r\": false}".getBytes())));
        MockHttpServletResponse httpServletResponse = new MockHttpServletResponse();

        final String[] emails = {null};
        final Object[] analytics = {null};
        final Boolean[] called = {false};
        final Boolean[] sessionReadOnly = {null};
        final String[] sessionBearer = {null};

        FilterChain filterChain = new FilterChain() {
            public void doFilter(ServletRequest request, ServletResponse response) throws IOException, ServletException {
                emails[0] = SessionContext.getAllEmails().isEmpty() ? null : String.join(",", SessionContext.getAllEmails());
                analytics[0] = SessionContext.getAnalyticsInfo();
                sessionReadOnly[0] = SessionContext.isReadOnly();
                sessionBearer[0] = SessionContext.getBearerToken();
                called[0] = true;
            }
        };

        SessionRequestFilter reqFilter = new SessionRequestFilter(null, new CookieManager(new ObjectMapper()), null);
        reqFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);

        assertTrue(called[0]);
        assertEquals("johnsmith@mydomain.com,johnsmith@gmail.com,john@smith.com", emails[0]);
        assertNotNull(analytics[0]);
        assertEquals(200, httpServletResponse.getStatus());
        assertEquals(false, sessionReadOnly[0]);
        assertEquals("bearer", sessionBearer[0]);
    }


    @Test
    void testNonprodAuth() throws ServletException, IOException {
        MockHttpServletRequest httpServletRequest = new MockHttpServletRequest();
        httpServletRequest.setRequestURI("/");
        MockHttpServletResponse httpServletResponse = new MockHttpServletResponse();

        final String[] emails = {null};
        final String[] name = {null};
        final Boolean[] called = {false};

        FilterChain filterChain = new FilterChain() {
            public void doFilter(ServletRequest request, ServletResponse response) throws IOException, ServletException {
                emails[0] = SessionContext.getAllEmails().isEmpty() ? null : String.join(",", SessionContext.getAllEmails());
                name[0] = SessionContext.getDisplayName();
                called[0] = true;
            }
        };

        SessionRequestFilter reqFilter = new SessionRequestFilter(null, new CookieManager(new ObjectMapper()), "nonprod");
        reqFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);

        assertTrue(called[0]);
        assertNull(emails[0]);
        assertNull(name[0]);
        called[0] = false;

        httpServletRequest.addHeader("X-Nonprod-Authorization", "INVALID_FORMAT");
        reqFilter = new SessionRequestFilter(null, new CookieManager(new ObjectMapper()), "nonprod");
        reqFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);

        assertTrue(called[0]);
        assertNull(emails[0]);
        assertNull(name[0]);
        called[0] = false;

        httpServletRequest = new MockHttpServletRequest();
        httpServletRequest.setRequestURI("/");
        httpServletRequest.addHeader("X-Nonprod-Authorization", "fred@bedrock.com;Fred Flinstone");
        reqFilter = new SessionRequestFilter(null, new CookieManager(new ObjectMapper()), "nonprod");
        reqFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);

        assertTrue(called[0]);
        assertEquals("fred@bedrock.com", emails[0]);
        assertEquals("Fred Flinstone", name[0]);
    }
}
