package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.dao.impl.AdditionalInfoDaoImpl.AdditionalInfoResultsExtractor;
import com.elsevier.find.reviewers.enums.ProductType;
import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.generated.model.Indicators;
import com.elsevier.find.reviewers.generated.model.ScopusSearchAuthor;
import com.elsevier.find.reviewers.testutils.JdbcMockAnswer;
import com.elsevier.find.reviewers.testutils.TestBase;
import com.elsevier.find.reviewers.utils.CookieManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.data.jdbc.JdbcRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.sql.SQLException;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, JdbcRepositoriesAutoConfiguration.class})
public class Scopus_getUserScopusDetailsTest extends TestBase {
    // Wire to the service that we want to test
    @Autowired
    private ScopusService scopusService;

    @MockBean(name = "personfinder")
    private WebClient personFinderWebClient;

    @MockBean(name = "scopussharedsearch")
    private WebClient sharedSearchWebClient;

    @MockBean(name = "httpClient")
    private HttpClient mockHttpClient;

    @BeforeEach
    void setup() {
        SessionContext.initialize(new CookieManager.SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", true, true));
    }

    @Test
    void testNoScopusDetails() throws IOException, InterruptedException {
        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(personFinderWebClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("[]"));

        // Block List API Call
        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(200);
        Mockito.when(mockTokenResponse.body()).thenReturn("[]");
        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        ResponseEntity<ScopusSearchAuthor> response = scopusService.getScopusDetailsById("123", null, "ACR", null, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody(), "Body not valid");
    }

    @Test
    void testInvalidInput() {
        assertThrows(InternalException.class, () -> scopusService.getScopusDetailsById(null, null, null, null, null));
        assertThrows(InternalException.class, () -> scopusService.getScopusDetailsById(null, null, "ACR", null, null));
        assertThrows(InternalException.class, () -> scopusService.getScopusDetailsById("", null, "ACR", null, null));
    }

    @Test
    void testScopusDetails() throws IOException, InterruptedException {
        final String author = "{\"authid\":\"000000800\", \"authemail\": \"fred@bedrock.com\", " +
                "\"preffirst\":\"Fred\",\"authlast\":\"Flintstone\", " +
                "\"afdispname\":\"Bedrock Uni\",\"afdispcity\":\"Red Rock\", " +
                "\"afdispctry\":\"Bedrock\",\"count\":182,\"h_index\":\"24\", \"num_cited_by\":\"76\"}";

        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(personFinderWebClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("[" + author + "]"));

        // Block List API Call
        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(200);
        Mockito.when(mockTokenResponse.body()).thenReturn("[]");
        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(ResultSetExtractor.class))).thenAnswer(new JdbcMockAnswer());

        ResponseEntity<ScopusSearchAuthor> response = scopusService.getScopusDetailsById("000000800", null, "ACR", "", null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertEquals("fred@bedrock.com", response.getBody().getEmails().get(0));
        assertEquals("Fred Flintstone", response.getBody().getDisplayName());
        assertEquals("Fred", response.getBody().getFirstName());
        assertEquals("Flintstone", response.getBody().getLastName());
        assertEquals("Bedrock Uni", response.getBody().getAffiliationName());
        assertEquals("Red Rock", response.getBody().getAffiliationCity());
        assertEquals("Bedrock", response.getBody().getAffiliationCountry());
        assertEquals(182, response.getBody().getPublicationCount());
        assertEquals(76, response.getBody().getCitationCount());
        assertEquals(24, response.getBody().getHindex());
        assertNull(response.getBody().getKeywordMatchCount());
        assertNull(response.getBody().getReviewStatistics());
    }

    @Test
    void testScopusDetailsWithAdditionalInfo() throws IOException, InterruptedException, SQLException {
        final String author = "{\"authid\":\"000000800\", \"authemail\": \"fred@bedrock.com\", " +
                "\"preffirst\":\"Fred\",\"authlast\":\"Flintstone\", " +
                "\"afdispname\":\"Bedrock Uni\",\"afdispcity\":\"Red Rock\", " +
                "\"afdispctry\":\"Bedrock\",\"count\":182,\"h_index\":\"24\", \"num_cited_by\":\"76\"}";

        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(personFinderWebClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("[" + author + "]"));

        final WebClient.ResponseSpec sharedSearchSpecMock = createWebClientResponseSpecMock(sharedSearchWebClient);
        Mockito.when(sharedSearchSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just("{\"totalResultsCount\": 2, \"hits\": [{\"eid\": \"1\", \"authors\": [{\"authid\": \"000000800\"},{\"authid\": \"1234567\"}]}, {\"eid\": \"2\", \"authors\": [{\"authid\": \"000000800\"}]}]}"));

        // Block List API Call
        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(200);
        Mockito.when(mockTokenResponse.body()).thenReturn("[]");
        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(Map.ofEntries(
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("volunteer", false),
                Map.entry("unavailability", "-null-"),
                Map.entry("concurrent_review_limit", 100),
                Map.entry("this_recently_accepted_author", true),
                Map.entry("other_recently_accepted_author", false)));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(AdditionalInfoResultsExtractor.class))).thenAnswer(mockAnswer);

        ResponseEntity<ScopusSearchAuthor> response = scopusService.getScopusDetailsById("000000800", null, "ACR", "content matches", null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertEquals("fred@bedrock.com", response.getBody().getEmails().get(0));
        assertEquals("Fred Flintstone", response.getBody().getDisplayName());
        assertEquals("Fred", response.getBody().getFirstName());
        assertEquals("Flintstone", response.getBody().getLastName());
        assertEquals("Bedrock Uni", response.getBody().getAffiliationName());
        assertEquals("Red Rock", response.getBody().getAffiliationCity());
        assertEquals("Bedrock", response.getBody().getAffiliationCountry());
        assertEquals(182, response.getBody().getPublicationCount());
        assertEquals(76, response.getBody().getCitationCount());
        assertEquals(24, response.getBody().getHindex());
        assertEquals(1, response.getBody().getIndicators().size());
        assertEquals(Indicators.RECENTLYACCEPTEDAUTHORTHISJOURNAL, response.getBody().getIndicators().get(0));
        assertEquals(2, response.getBody().getKeywordMatchCount());
        assertNull(response.getBody().getReviewStatistics());
    }

    @Test
    void testInBlockList() throws IOException, InterruptedException {
        final String author = "{\"authid\":\"000000800\", \"authemail\": \"fred@bedrock.com\", " +
                "\"preffirst\":\"Fred\",\"authlast\":\"Flintstone\", " +
                "\"afdispname\":\"Bedrock Uni\",\"afdispcity\":\"Red Rock\", " +
                "\"afdispctry\":\"Bedrock\",\"count\":182,\"h_index\":\"24\", \"num_cited_by\":\"76\"}";

        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(personFinderWebClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("[" + author + "]"));

        // Block List API Call
        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(200);
        Mockito.when(mockTokenResponse.body()).thenReturn("[\"fred@bedrock.com\"]");
        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(ResultSetExtractor.class))).thenAnswer(new JdbcMockAnswer());

        ResponseEntity<ScopusSearchAuthor> response = scopusService.getScopusDetailsById("000000800", null, "ACR", null, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody(), "Body not valid");
    }
}
