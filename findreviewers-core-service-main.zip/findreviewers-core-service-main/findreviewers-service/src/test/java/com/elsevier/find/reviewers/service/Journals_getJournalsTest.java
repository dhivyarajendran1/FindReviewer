package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.generated.model.JournalsResponse;
import com.elsevier.find.reviewers.testutils.JdbcMockAnswer;
import com.elsevier.find.reviewers.testutils.TestBase;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.data.jdbc.JdbcRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.sql.SQLException;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, JdbcRepositoriesAutoConfiguration.class})
public class Journals_getJournalsTest extends TestBase {
    @Autowired
    private JournalsService journalsService;

    @Test
    void testNoJournals() {
        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(RowMapper.class))).thenAnswer(mockAnswer);

        ResponseEntity<JournalsResponse> response = journalsService.getJournals(null);

        assertEquals(1, mockAnswer.getParameter("status", Integer.class));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertEquals(0, response.getBody().getJournals().size());
    }

    @Test
    void testJournals() throws SQLException {
        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(Map.ofEntries(
                Map.entry("acronym", "ACR1"),
                Map.entry("title", "Journal 1"),
                Map.entry("issn", "1234-5678")));
        mockAnswer.addResultMapping(Map.ofEntries(
                Map.entry("acronym", "ACR2"),
                Map.entry("title", "Journal 2"),
                Map.entry("issn", "-null-")));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(RowMapper.class))).thenAnswer(mockAnswer);

        ResponseEntity<JournalsResponse> response = journalsService.getJournals(null);

        assertEquals(1, mockAnswer.getParameter("status", Integer.class));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertEquals(2, response.getBody().getJournals().size());
        assertEquals("ACR1", response.getBody().getJournals().get(0).getEmJournalAcronym());
        assertEquals("Journal 1", response.getBody().getJournals().get(0).getTitle());
        assertEquals("1234-5678", response.getBody().getJournals().get(0).getIssnl());
        assertEquals("ACR2", response.getBody().getJournals().get(1).getEmJournalAcronym());
        assertEquals("Journal 2", response.getBody().getJournals().get(1).getTitle());
        assertNull(response.getBody().getJournals().get(1).getIssnl());
    }
}
