package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.dao.impl.AdditionalInfoDaoImpl.AdditionalInfoResultsExtractor;
import com.elsevier.find.reviewers.dao.impl.CandidateInfoDaoImpl;
import com.elsevier.find.reviewers.dao.impl.CandidateInfoDaoImpl.ReviewStatisticsResultsExtractor;
import com.elsevier.find.reviewers.enums.ProductType;
import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.generated.model.Indicators;
import com.elsevier.find.reviewers.generated.model.KeywordSearchLogic;
import com.elsevier.find.reviewers.generated.model.ScopusKeywordSearchResponse;
import com.elsevier.find.reviewers.testutils.JdbcMockAnswer;
import com.elsevier.find.reviewers.testutils.TestBase;
import com.elsevier.find.reviewers.utils.CookieManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.data.jdbc.JdbcRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.test.context.TestPropertySource;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@TestPropertySource(properties = {
        "personfinder.client.base.url=https://localhost/api/",
        "emsupport.client.base.url=https://localhost/api/",
        "findreviewers.cloud.ursdb=true"
})
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, JdbcRepositoriesAutoConfiguration.class})
public class Scopus_keywordSearchTest extends TestBase {
    // Wire to the service that we want to test
    @Autowired
    private ScopusService scopusService;

    @MockBean(name = "personfinder")
    private WebClient personFinderWebClient;

    @MockBean(name = "httpClient")
    private HttpClient mockHttpClient;

    @Captor
    private ArgumentCaptor<HttpRequest> requestCaptor;

    @BeforeEach
    void setup() {
        SessionContext.initialize(new CookieManager.SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", true, true));
    }

    @Test
    void testNoAuthors() {
        final WebClient.RequestBodyUriSpec bodyUriSpecMock = Mockito.mock(WebClient.RequestBodyUriSpec.class);
        final WebClient.RequestBodySpec bodySpecMock = Mockito.mock(WebClient.RequestBodySpec.class);
        final WebClient.RequestHeadersSpec headersSpecMock = Mockito.mock(WebClient.RequestHeadersSpec.class);
        final WebClient.ResponseSpec responseSpecMock = Mockito.mock(WebClient.ResponseSpec.class);
        Mockito.when(personFinderWebClient.post()).thenReturn(bodyUriSpecMock);
        Mockito.when(bodyUriSpecMock.uri(Mockito.anyString())).thenReturn(bodySpecMock);
        Mockito.when(bodySpecMock.header(Mockito.anyString(), Mockito.anyString())).thenReturn(bodySpecMock);
        Mockito.when(bodySpecMock.accept(Mockito.notNull())).thenReturn(bodySpecMock);
        Mockito.when(bodySpecMock.contentType(Mockito.notNull())).thenReturn(bodySpecMock);
        Mockito.when(bodySpecMock.bodyValue(Mockito.matches(".*pf_recentPublishedModel.*keyword.*relevance.*"))).thenReturn(headersSpecMock);
        Mockito.when(headersSpecMock.retrieve()).thenReturn(responseSpecMock)
                .thenReturn(responseSpecMock).thenReturn(responseSpecMock)
                .thenThrow(new WebClientResponseException(404, "Not Found", null, null, null));
        Mockito.when(responseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("{\"authors\":[]}"))
                .thenReturn(Mono.just("{}")).thenReturn(Mono.just(""));

        ResponseEntity<ScopusKeywordSearchResponse> response =
                scopusService.keywordSearch("Search", null, "ACR", null, KeywordSearchLogic.AND, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(0, response.getBody().getAuthors().size());

        response = scopusService.keywordSearch("Search", null, "ACR", "", KeywordSearchLogic.OR, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(0, response.getBody().getAuthors().size());

        response = scopusService.keywordSearch("Search", null, "ACR", " ", null, 2021);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(0, response.getBody().getAuthors().size());

        response = scopusService.keywordSearch("Search", null, "ACR", "1234-5678", null, 2021);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(0, response.getBody().getAuthors().size());
    }

    @Test
    void testInvalidInput() {
        assertThrows(InternalException.class, () -> scopusService.keywordSearch(null, null, null, null, null, null));
        assertThrows(InternalException.class, () -> scopusService.keywordSearch(null, null, "ACR", null, null, null));
        assertThrows(InternalException.class, () -> scopusService.keywordSearch("12", null, "ACR", null, null, null));
    }

    @Test
    void testMessageProcessingError() {
        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(personFinderWebClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("{ invalid json }"));

        InternalException e = assertThrows(InternalException.class, () -> scopusService.keywordSearch("Search", null, "ACR", null, null, null));
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getHttpStatus(), "Invalid status");
        assertEquals(ErrorResponse.IdEnum.PERSONFINDERFAILURE, e.toErrorResponse().getId(), "Invalid error Id");
    }

    @Test
    void testSingleSearchResultNoAdditionalInfo() throws IOException, InterruptedException {
        final String author = """
                {
                	"authid": "000000800",
                	"authemail": "fred@bedrock.com",
                	"preffirst": "Fred",
                	"authlast": "Flintstone",
                	"afdispname": "Bedrock Uni",
                	"afdispcity": "Red Rock",
                	"afdispctry": "Bedrock",
                	"count": 182,
                	"count_matching": 39,
                	"h_index": "24",
                	"num_cited_by": "19"
                }
                """;

        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(personFinderWebClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("{\"authors\":[" + author + "]}"));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(ResultSetExtractor.class))).thenAnswer(new JdbcMockAnswer());

        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(200);
        Mockito.when(mockTokenResponse.body()).thenReturn("[]");
        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        ResponseEntity<ScopusKeywordSearchResponse> response =
                scopusService.keywordSearch("Search", null, "ACR", null, KeywordSearchLogic.AND, null);

        Mockito.verify(mockHttpClient, Mockito.times(1)).send(requestCaptor.capture(),
                Mockito.any(HttpResponse.BodyHandler.class));
        assertTrue(requestCaptor.getValue().uri().toString().endsWith("/blocked-reviewers?em-acronym=ACR&reviewers=fred%40bedrock.com"), "Incorrect URL");
        assertEquals("GET", requestCaptor.getValue().method());

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(1, response.getBody().getAuthors().size());
        assertEquals(1, response.getBody().getAuthors().get(0).getScopusIds().size());
        assertEquals("000000800", response.getBody().getAuthors().get(0).getScopusIds().get(0));
        assertEquals("fred@bedrock.com", response.getBody().getAuthors().get(0).getEmails().get(0));
        assertEquals("Fred Flintstone", response.getBody().getAuthors().get(0).getDisplayName());
        assertEquals("Fred", response.getBody().getAuthors().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getAuthors().get(0).getLastName());
        assertEquals("Bedrock Uni", response.getBody().getAuthors().get(0).getAffiliationName());
        assertEquals("Red Rock", response.getBody().getAuthors().get(0).getAffiliationCity());
        assertEquals("Bedrock", response.getBody().getAuthors().get(0).getAffiliationCountry());
        assertEquals(182, response.getBody().getAuthors().get(0).getPublicationCount());
        assertEquals(39, response.getBody().getAuthors().get(0).getKeywordMatchCount());
        assertEquals(19, response.getBody().getAuthors().get(0).getCitationCount());
        assertEquals(24, response.getBody().getAuthors().get(0).getHindex());
        assertNull(response.getBody().getAuthors().get(0).getPublishedInJournalCount());
        assertNull(response.getBody().getAuthors().get(0).getIndicators());
        assertNull(response.getBody().getAuthors().get(0).getEditorialHistoryCount());
        assertNull(response.getBody().getAuthors().get(0).getEditorialHistoryCount());
        assertNull(response.getBody().getAuthors().get(0).getReviewStatistics());
    }

    @Test
    void testMultipleSearchResult() throws SQLException, IOException, InterruptedException {
        final String author1 = """
                {
                	"authid": "000000800",
                	"authemail": "fred@bedrock.com",
                	"authlast": "Flintstone",
                	"afdispname": "Bedrock Uni",
                	"afdispcity": "Red Rock",
                	"afdispctry": "Bedrock",
                	"count": 182,
                	"count_matching": 39,
                	"h_index": "invalid",
                	"authkeywords": [{"keyword": "keyword"}],
                	"subjmain": [{"keyword": "3610"}],
                	"issn": [{"keyword": "1234-5678", "count": 1}]
                }
                """;

        final String author2 = """
                {
                	"authid": "000000900",
                	"authemail": "wilma@bedrock.com",
                	"preffirst": "Wilma",
                	"afdispname": "Bedrock Uni",
                	"afdispcity": "Red Rock",
                	"afdispctry": "Bedrock",
                	"count": 182,
                	"count_matching": 39,
                	"h_index": "3",
                	"authkeywords": [{"keyword": "keyword1"},{"keyword": "keyword2"}],
                	"subjmain": [{"keyword": "3602"},{"keyword": "3503"}],
                	"issn": [{"keyword": "1234-5678", "count": 1}, {"keyword": "1234-5678", "count": 2}]
                }
                """;

        final String author3 = """
                {
                	"authid": "000000700",
                	"authemail": "barney@bedrock.com",
                	"preffirst": "Barney",
                	"afdispname": "Bedrock Uni",
                	"afdispcity": "Red Rock",
                	"afdispctry": "Bedrock",
                	"count": 182,
                	"count_matching": 39,
                	"h_index": "3",
                	"issn": [{"keyword": null, "count": null}]
                }
                """;

        final String author4 = "{\"preffirst\":\"Missing Email\"}";

        final String author5 = "{\"preffirst\":\"Missing Email\",\"authemail\":\"\"}";

        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(personFinderWebClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("{\"authors\":[" +
                author1 + ", " + author2 + ", " + author3 + ", " + author4 + ", " + author5 + "]}"));

        Map<String, Object> resultMapping1 = Map.ofEntries(
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("volunteer", false),
                Map.entry("unavailability", "-null-"),
                Map.entry("concurrent_review_limit", 100),
                Map.entry("this_recently_accepted_author", true),
                Map.entry("other_recently_accepted_author", false),
                Map.entry("is_ebm", true),
                Map.entry("editorial_history_count", 2));
        Map<String, Object> resultMapping2 = Map.ofEntries(
                Map.entry("email", "wilma@bedrock.com"),
                Map.entry("volunteer", true),
                Map.entry("unavailability", "-null-"),
                Map.entry("concurrent_review_limit", 0),
                Map.entry("this_recently_accepted_author", false),
                Map.entry("other_recently_accepted_author", true),
                Map.entry("is_ebm", false),
                Map.entry("editorial_history_count", 3));
        Map<String, Object> resultMapping3 = Map.ofEntries(
                Map.entry("email", "barney@bedrock.com"),
                Map.entry("volunteer", false),
                Map.entry("unavailability", "[{\"start\": 1643720400000,\"stop\": 2644940798000}]"),
                Map.entry("concurrent_review_limit", 10),
                Map.entry("this_recently_accepted_author", true),
                Map.entry("other_recently_accepted_author", true),
                Map.entry("is_ebm", false),
                Map.entry("editorial_history_count", 0));

        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(resultMapping1, resultMapping2, resultMapping3);

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(AdditionalInfoResultsExtractor.class))).thenAnswer(mockAnswer);

        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(500);
        Mockito.when(mockTokenResponse.body()).thenReturn("{\"Message\": \"Error message\"}");
        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        ResponseEntity<ScopusKeywordSearchResponse> response =
                scopusService.keywordSearch("S{e}arch", null, "ACR", "1234-5678", KeywordSearchLogic.AND, null);

        Mockito.verify(mockHttpClient, Mockito.times(2)).send(requestCaptor.capture(),
                Mockito.any(HttpResponse.BodyHandler.class));
        assertTrue(requestCaptor.getValue().uri().toString().endsWith("/blocked-reviewers?em-acronym=ACR&reviewers=fred%40bedrock.com%2Cwilma%40bedrock.com%2Cbarney%40bedrock.com"), "Incorrect URL");
        assertEquals("GET", requestCaptor.getValue().method());

        assertEquals("ACR", mockAnswer.getParameter("emJournalAcronym", String.class));
        assertEquals(List.of("fred@bedrock.com", "wilma@bedrock.com", "barney@bedrock.com"), mockAnswer.getParameter("emails", List.class));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(2, response.getBody().getAuthors().size());
        assertEquals(1, response.getBody().getAuthors().get(0).getScopusIds().size());
        assertEquals("000000800", response.getBody().getAuthors().get(0).getScopusIds().get(0));
        assertEquals("fred@bedrock.com", response.getBody().getAuthors().get(0).getEmails().get(0));
        assertEquals("Flintstone", response.getBody().getAuthors().get(0).getDisplayName());
        assertNull(response.getBody().getAuthors().get(0).getFirstName(), "Invalid given name");
        assertEquals("Flintstone", response.getBody().getAuthors().get(0).getLastName());
        assertEquals("Bedrock Uni", response.getBody().getAuthors().get(0).getAffiliationName());
        assertEquals("Red Rock", response.getBody().getAuthors().get(0).getAffiliationCity());
        assertEquals("Bedrock", response.getBody().getAuthors().get(0).getAffiliationCountry());
        assertEquals(182, response.getBody().getAuthors().get(0).getPublicationCount());
        assertEquals(39, response.getBody().getAuthors().get(0).getKeywordMatchCount());
        assertNull(response.getBody().getAuthors().get(0).getHindex(), "Invalid hIndex");
        assertEquals(1, response.getBody().getAuthors().get(0).getKeywords().size());
        assertEquals("keyword", response.getBody().getAuthors().get(0).getKeywords().get(0));
        assertEquals(1, response.getBody().getAuthors().get(0).getSubjectAreas().size());
        assertEquals("Optometry", response.getBody().getAuthors().get(0).getSubjectAreas().get(0));
        assertEquals(1, response.getBody().getAuthors().get(0).getPublishedInJournalCount());
        assertEquals(2, response.getBody().getAuthors().get(0).getEditorialHistoryCount());

        assertEquals(2, response.getBody().getAuthors().get(0).getIndicators().size());
        assertEquals(Indicators.RECENTLYACCEPTEDAUTHORTHISJOURNAL, response.getBody().getAuthors().get(0).getIndicators().get(0));
        assertEquals(Indicators.EDITORIALBOARDMEMBER, response.getBody().getAuthors().get(0).getIndicators().get(1));
        assertNull(response.getBody().getAuthors().get(0).getReviewStatistics());

        assertEquals(1, response.getBody().getAuthors().get(1).getScopusIds().size());
        assertEquals("000000900", response.getBody().getAuthors().get(1).getScopusIds().get(0));
        assertEquals("wilma@bedrock.com", response.getBody().getAuthors().get(1).getEmails().get(0));
        assertEquals("Wilma", response.getBody().getAuthors().get(1).getDisplayName());
        assertEquals("Wilma", response.getBody().getAuthors().get(1).getFirstName());
        assertNull(response.getBody().getAuthors().get(1).getLastName(), "Invalid Last Name");
        assertEquals("Bedrock Uni", response.getBody().getAuthors().get(1).getAffiliationName());
        assertEquals("Red Rock", response.getBody().getAuthors().get(1).getAffiliationCity());
        assertEquals("Bedrock", response.getBody().getAuthors().get(1).getAffiliationCountry());
        assertEquals(182, response.getBody().getAuthors().get(1).getPublicationCount());
        assertEquals(39, response.getBody().getAuthors().get(1).getKeywordMatchCount());
        assertEquals(3, response.getBody().getAuthors().get(1).getHindex());
        assertEquals(2, response.getBody().getAuthors().get(1).getKeywords().size());
        assertEquals("keyword1", response.getBody().getAuthors().get(1).getKeywords().get(0));
        assertEquals("keyword2", response.getBody().getAuthors().get(1).getKeywords().get(1));
        assertEquals(2, response.getBody().getAuthors().get(1).getSubjectAreas().size());
        assertEquals("Chiropractics", response.getBody().getAuthors().get(1).getSubjectAreas().get(0));
        assertEquals("Dental Hygiene", response.getBody().getAuthors().get(1).getSubjectAreas().get(1));
        assertEquals(3, response.getBody().getAuthors().get(1).getPublishedInJournalCount());
        assertEquals(3, response.getBody().getAuthors().get(1).getEditorialHistoryCount());

        assertEquals(2, response.getBody().getAuthors().get(1).getIndicators().size());
        assertEquals(Indicators.VOLUNTEERTHISJOURNAL, response.getBody().getAuthors().get(1).getIndicators().get(0));
        assertEquals(Indicators.RECENTLYACCEPTEDAUTHOROTHERJOURNAL, response.getBody().getAuthors().get(1).getIndicators().get(1));
        assertNull(response.getBody().getAuthors().get(1).getReviewStatistics());

        assertEquals(1, getAnalyticsCounterValue("custom.preferences.reviewer", "availability"));
        assertEquals(0, getAnalyticsCounterValue("custom.preferences.reviewer", "concurrent.limit"));
    }

    @Test
    void testSearchResultWithInvalidUser() throws SQLException, IOException, InterruptedException {
        final String author1 = "{\"authid\":\"000000800\",\"authemail\":\"fred@bedrock.com\"," +
                "\"authlast\":\"Flintstone\",\"afdispname\":\"Bedrock Uni\",\"afdispcity\":\"Red Rock\"," +
                "\"afdispctry\":\"Bedrock\",\"count\":182,\"count_matching\":39,\"h_index\":\"invalid\"," +
                "\"authkeywords\": [], \"subjmain\": []}";

        final String author2 = "{\"authid\":\"000001000\",\"authemail\":\"barney@bedrock.com\"," +
                "\"preffirst\":\"\", \"authlast\":\"\",\"afdispname\":\"Bedrock Uni\",\"afdispcity\":\"Red Rock\"," +
                "\"afdispctry\":\"Bedrock\",\"count\":182,\"count_matching\":39,\"h_index\":\"3\"," +
                "\"authkeywords\": [], \"subjmain\": []}";

        final String author3 = "{\"authid\":\"000000900\",\"authemail\":\"wilma@bedrock.com\"," +
                "\"preffirst\":\"Wilma\",\"afdispname\":\"Bedrock Uni\",\"afdispcity\":\"Red Rock\"," +
                "\"afdispctry\":\"Bedrock\",\"count\":182,\"count_matching\":39,\"h_index\":\"3\"," +
                "\"authkeywords\": [], \"subjmain\": []}";

        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(personFinderWebClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("{\"authors\":[" +
                author1 + ", " + author2 + ", " + author3 + "]}"));

        Map<String, Object> resultMapping1 = Map.ofEntries(
                Map.entry("email", "wilma@bedrock.com"),
                Map.entry("is_inoperative", false),
                Map.entry("concurrent_review_limit", 1),
                Map.entry("editorial_history", " invalid json "));
        Map<String, Object> resultMapping2 = Map.ofEntries(
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("is_inoperative", true),
                Map.entry("concurrent_review_limit", 5),
                Map.entry("editorial_history", "-null-"));

        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(resultMapping1, resultMapping2);

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(AdditionalInfoResultsExtractor.class))).thenAnswer(mockAnswer);

        JdbcMockAnswer mockEmAnswer = new JdbcMockAnswer();
        mockEmAnswer.addResultMapping(Map.ofEntries(
                        Map.entry("email", "wilma@bedrock.com"),
                        Map.entry("journal_acronym", "ACR"),
                        Map.entry("rstop", 1589809511783L),
                        Map.entry("work_in_progress", false),
                        Map.entry("declined", false),
                        Map.entry("terminated", false),
                        Map.entry("completed", false),
                        Map.entry("uninvited", false),
                        Map.entry("assigned_not_invited", true)),
                Map.ofEntries(
                        Map.entry("email", "wilma@bedrock.com"),
                        Map.entry("journal_acronym", "ACR"),
                        Map.entry("rstop", 1589809511783L),
                        Map.entry("work_in_progress", false),
                        Map.entry("declined", true),
                        Map.entry("terminated", false),
                        Map.entry("completed", false),
                        Map.entry("uninvited", false),
                        Map.entry("assigned_not_invited", false)));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(ReviewStatisticsResultsExtractor.class))).thenAnswer(mockEmAnswer);

        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(200);
        Mockito.when(mockTokenResponse.body()).thenReturn(null);
        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        ResponseEntity<ScopusKeywordSearchResponse> response =
                scopusService.keywordSearch("Search", null, "ACR", null, KeywordSearchLogic.AND, null);

        Mockito.verify(mockHttpClient, Mockito.times(1)).send(requestCaptor.capture(),
                Mockito.any(HttpResponse.BodyHandler.class));
        assertTrue(requestCaptor.getValue().uri().toString().endsWith("/blocked-reviewers?em-acronym=ACR&reviewers=fred%40bedrock.com%2Cbarney%40bedrock.com%2Cwilma%40bedrock.com"), "Incorrect URL");
        assertEquals("GET", requestCaptor.getValue().method());

        assertEquals("ACR", mockAnswer.getParameter("emJournalAcronym", String.class));
        assertEquals(List.of("fred@bedrock.com", "barney@bedrock.com", "wilma@bedrock.com"), mockAnswer.getParameter("emails", List.class));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(1, response.getBody().getAuthors().size());
        assertEquals(1, response.getBody().getAuthors().get(0).getScopusIds().size());
        assertEquals("000001000", response.getBody().getAuthors().get(0).getScopusIds().get(0));
        assertEquals("barney@bedrock.com", response.getBody().getAuthors().get(0).getEmails().get(0));
        assertNull(response.getBody().getAuthors().get(0).getDisplayName(), "Invalid Display Name");
        assertNull(response.getBody().getAuthors().get(0).getFirstName(), "Invalid First Name");
        assertNull(response.getBody().getAuthors().get(0).getLastName(), "Invalid Last Name");
        assertNull(response.getBody().getAuthors().get(0).getSubjectAreas(), "Invalid Subject Areas");
        assertNull(response.getBody().getAuthors().get(0).getKeywords(), "Invalid Keywords");
        assertEquals("Bedrock Uni", response.getBody().getAuthors().get(0).getAffiliationName());
        assertEquals("Red Rock", response.getBody().getAuthors().get(0).getAffiliationCity());
        assertEquals("Bedrock", response.getBody().getAuthors().get(0).getAffiliationCountry());
        assertEquals(182, response.getBody().getAuthors().get(0).getPublicationCount());
        assertEquals(39, response.getBody().getAuthors().get(0).getKeywordMatchCount());
        assertEquals(3, response.getBody().getAuthors().get(0).getHindex());
        assertNull(response.getBody().getAuthors().get(0).getReviewStatistics());

        assertEquals(1, getAnalyticsCounterValue("custom.blocked.reviewer", "inoperative"));
        assertEquals(1, getAnalyticsCounterValue("custom.preferences.reviewer", "concurrent.limit"));
    }

    @Test
    void testBlockListFailure() throws IOException, InterruptedException {
        final String author = "{\"authid\":\"000000800\",\"authemail\":\"fred@bedrock.com\"," +
                "\"preffirst\":\"Fred\",\"authlast\":\"Flintstone\"," +
                "\"afdispname\":\"Bedrock Uni\",\"afdispcity\":\"Red Rock\",\"afdispctry\":\"Bedrock\"," +
                "\"count\":182,\"count_matching\":39,\"issn\": [{\"keyword\": \"1234-5678\", \"count\": null}]}";

        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(personFinderWebClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("{\"authors\":[" + author + "]}"));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(ResultSetExtractor.class))).thenAnswer(new JdbcMockAnswer());

        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenThrow(new IOException()).thenThrow(new RuntimeException()).thenThrow(new InterruptedException());

        ResponseEntity<ScopusKeywordSearchResponse> response =
                scopusService.keywordSearch("Search", null, "ACR", "1234-5678", KeywordSearchLogic.AND, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(1, response.getBody().getAuthors().size());
        assertEquals(1, response.getBody().getAuthors().get(0).getScopusIds().size());
        assertEquals("000000800", response.getBody().getAuthors().get(0).getScopusIds().get(0));
        assertEquals("fred@bedrock.com", response.getBody().getAuthors().get(0).getEmails().get(0));
        assertNull(response.getBody().getAuthors().get(0).getPublishedInJournalCount());

        response = scopusService.keywordSearch("Search", null, "ACR", null, KeywordSearchLogic.AND, null);

        Mockito.verify(mockHttpClient, Mockito.times(3)).send(requestCaptor.capture(),
                Mockito.any(HttpResponse.BodyHandler.class));
        assertTrue(requestCaptor.getValue().uri().toString().endsWith("/blocked-reviewers?em-acronym=ACR&reviewers=fred%40bedrock.com"), "Incorrect URL");
        assertEquals("GET", requestCaptor.getValue().method());

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(1, response.getBody().getAuthors().size());
        assertEquals(1, response.getBody().getAuthors().get(0).getScopusIds().size());
        assertEquals("000000800", response.getBody().getAuthors().get(0).getScopusIds().get(0));
        assertEquals("fred@bedrock.com", response.getBody().getAuthors().get(0).getEmails().get(0));
        assertNull(response.getBody().getAuthors().get(0).getPublishedInJournalCount());
    }

    @Test
    void testBlockList() throws IOException, InterruptedException {
        final String author1 = "{\"authid\":\"000000800\",\"authemail\":\"fred@bedrock.com\"," +
                "\"preffirst\":\"Fred\",\"authlast\":\"Flintstone\"," +
                "\"afdispname\":\"Bedrock Uni\",\"afdispcity\":\"Red Rock\",\"afdispctry\":\"Bedrock\"," +
                "\"count\":182,\"count_matching\":39,\"h_index\":\"24\",\"issn\": []}";

        final String author2 = "{\"authid\":\"000000900\",\"authemail\":\"wilma@bedrock.com\"," +
                "\"preffirst\":\"Wilma\", " +
                "\"afdispname\":\"Bedrock Uni\",\"afdispcity\":\"Red Rock\",\"afdispctry\":\"Bedrock\"," +
                "\"count\":182,\"count_matching\":39,\"h_index\":\"3\",\"issn\": null}";

        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(personFinderWebClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("{\"authors\":[" + author1 + "]}"))
                .thenReturn(Mono.just("{\"authors\":[" + author1 + "," + author2 + "]}"))
                .thenReturn(Mono.just("{\"authors\":[" + author1 + "]}"));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(ResultSetExtractor.class))).thenAnswer(new JdbcMockAnswer());

        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(200);
        Mockito.when(mockTokenResponse.body()).thenReturn("[\"FRED@bedrock.com\"]").thenReturn("[\"fred@bedrock.com\"]");
        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        ResponseEntity<ScopusKeywordSearchResponse> response =
                scopusService.keywordSearch("Search", null, "ACR", "Empty", KeywordSearchLogic.AND, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(0, response.getBody().getAuthors().size());
        assertEquals(1, getAnalyticsCounterValue("custom.blocked.reviewer", "blocklist"));

        response = scopusService.keywordSearch("Search", null, "ACR", "null", KeywordSearchLogic.AND, null);

        Mockito.verify(mockHttpClient, Mockito.times(2)).send(requestCaptor.capture(),
                Mockito.any(HttpResponse.BodyHandler.class));
        assertEquals("GET", requestCaptor.getValue().method());

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(1, response.getBody().getAuthors().size());
        assertEquals(1, response.getBody().getAuthors().get(0).getScopusIds().size());
        assertEquals("000000900", response.getBody().getAuthors().get(0).getScopusIds().get(0));
        assertEquals("wilma@bedrock.com", response.getBody().getAuthors().get(0).getEmails().get(0));
        assertNull(response.getBody().getAuthors().get(0).getPublishedInJournalCount());
        assertEquals(1, getAnalyticsCounterValue("custom.blocked.reviewer", "blocklist"));
    }

    @Test
    void testRemoveNonResponder() throws IOException, InterruptedException, SQLException {
        final String author = """
                {
                	"authid": "000000800",
                	"authemail": "fred@bedrock.com",
                	"preffirst": "Fred",
                	"authlast": "Flintstone",
                	"afdispname": "Bedrock Uni",
                	"afdispcity": "Red Rock",
                	"afdispctry": "Bedrock",
                	"count": 182,
                	"count_matching": 39,
                	"h_index": "24",
                	"num_cited_by": "19"
                }
                """;

        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(personFinderWebClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("{\"authors\":[" + author + "]}"));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(AdditionalInfoResultsExtractor.class))).thenAnswer(new JdbcMockAnswer());

        JdbcMockAnswer mockEmAnswer = new JdbcMockAnswer();
        mockEmAnswer.addResultMapping(Map.ofEntries(
                        Map.entry("email", "fred@bedrock.com"),
                        Map.entry("journal_acronym", "ACR1"),
                        Map.entry("rstop", 1589809511783L),
                        Map.entry("terminated", true),
                        Map.entry("recent", true)),
                Map.ofEntries(
                        Map.entry("email", "fred@bedrock.com"),
                        Map.entry("journal_acronym", "ACR2"),
                        Map.entry("rstop", 1589809511783L),
                        Map.entry("terminated", true),
                        Map.entry("recent", true)),
                Map.ofEntries(
                        Map.entry("email", "fred@bedrock.com"),
                        Map.entry("journal_acronym", "ACR2"),
                        Map.entry("rstop", 1589809511783L),
                        Map.entry("terminated", true),
                        Map.entry("recent", true)),
                Map.ofEntries(
                        Map.entry("email", "fred@bedrock.com"),
                        Map.entry("journal_acronym", "ACR2"),
                        Map.entry("rstop", 1589809511783L),
                        Map.entry("terminated", true),
                        Map.entry("recent", true)));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(ReviewStatisticsResultsExtractor.class))).thenAnswer(mockEmAnswer);

        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(200);
        Mockito.when(mockTokenResponse.body()).thenReturn("[]");
        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        ResponseEntity<ScopusKeywordSearchResponse> response =
                scopusService.keywordSearch("Search", null, "ACR", null, KeywordSearchLogic.AND, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(0, response.getBody().getAuthors().size());

        assertNull(new CandidateInfoDaoImpl.ReviewStatisticsImpl().getStatistics(), "Empty Statistics incorrect return");
    }
}
