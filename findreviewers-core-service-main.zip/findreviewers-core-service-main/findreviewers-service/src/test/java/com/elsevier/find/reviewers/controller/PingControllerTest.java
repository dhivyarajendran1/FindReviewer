package com.elsevier.find.reviewers.controller;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;

public class PingControllerTest {

    private final PingController controller = new PingController();

    @Test
    void pingReturnsMessage() {

        ResponseEntity<String> response = controller.ping();

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
    }
}
