package com.elsevier.find.reviewers;

import com.elsevier.find.reviewers.config.ApplicationConfig;
import com.elsevier.find.reviewers.config.WebConfig;
import com.elsevier.find.reviewers.generated.model.KeywordSearchLogic;
import com.elsevier.find.reviewers.generated.model.SortOrder;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.core.convert.converter.Converter;
import org.springframework.format.FormatterRegistry;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

/**
 * Tests for the WebConfig and the converters passed into it
 */
@ExtendWith(SpringExtension.class)
public class WebConfigTest {
    @TestConfiguration
    static class ContextConfiguration {
        @Bean
        public WebConfig webConfig() {
            return new WebConfig();
        }
    }

    // Wire to the service that we want to test
    @Autowired
    private WebConfig webConfig;

    /**
     * Test that all of the converters are correctly added
     */
    @Test
    void testConvertersSet() {
        FormatterRegistry mockFormatReg = Mockito.mock(FormatterRegistry.class);

        ArgumentCaptor<Converter<String, ?>> captor = ArgumentCaptor.forClass(Converter.class);
        Mockito.doNothing().when(mockFormatReg).addConverter(captor.capture());

        webConfig.addFormatters(mockFormatReg);

        assertEquals(2, captor.getAllValues().size());
        assertNull(captor.getAllValues().get(0).convert(null));
        assertNull(captor.getAllValues().get(1).convert(null));

        assertEquals(SortOrder.ASCENDING, captor.getAllValues().get(0).convert("Ascending"));
        assertEquals(SortOrder.DESCENDING, captor.getAllValues().get(0).convert("Descending"));

        assertEquals(KeywordSearchLogic.AND, captor.getAllValues().get(1).convert("And"));
        assertEquals(KeywordSearchLogic.OR, captor.getAllValues().get(1).convert("Or"));
    }

    @Test
    void testApplicationConfig() {
        ApplicationConfig app = new ApplicationConfig();
        assertEquals(7L, app.httpClient().connectTimeout().get().getSeconds());
    }
}
