package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.dao.impl.AdditionalInfoDaoImpl.AdditionalInfoResultsExtractor;
import com.elsevier.find.reviewers.dao.impl.CandidateInfoDaoImpl.ReviewStatisticsResultsExtractor;
import com.elsevier.find.reviewers.enums.ProductType;
import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.generated.model.Indicators;
import com.elsevier.find.reviewers.generated.model.Volunteer;
import com.elsevier.find.reviewers.generated.model.VolunteersResponse;
import com.elsevier.find.reviewers.testutils.JdbcMockAnswer;
import com.elsevier.find.reviewers.testutils.TestBase;
import com.elsevier.find.reviewers.utils.CookieManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.data.jdbc.JdbcRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.sql.SQLException;
import java.time.Year;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, JdbcRepositoriesAutoConfiguration.class})
public class Volunteers_getVolunteersTest extends TestBase {
    // Wire to the service that we want to test
    @Autowired
    private VolunteersService volunteersService;

    @MockBean(name = "personfinder")
    private WebClient personFinderWebClient;

    @MockBean(name = "scopussharedsearch")
    private WebClient sharedSearchWebClient;

    @BeforeEach
    void setup() {
        SessionContext.initialize(new CookieManager.SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", true, true));
    }

    @Test
    void testNoVolunteers() {
        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(RowMapper.class))).thenAnswer(mockAnswer);

        ResponseEntity<VolunteersResponse> response = volunteersService.getVolunteers("ACR", null, null, null, 10, 100);

        assertEquals("ACR", mockAnswer.getParameter("emJournalAcronym", String.class));
        assertEquals(10, mockAnswer.getParameter("offset", Integer.class));
        assertEquals(100, mockAnswer.getParameter("limit", Integer.class));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertEquals(0, response.getBody().getVolunteers().size());
        assertEquals(false, response.getBody().isMore());
    }

    @Test
    void testDatabaseException() {
        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(RowMapper.class))).thenThrow(new DataAccessException("Test Exception") {
        });

        assertThrows(DataAccessException.class, () -> volunteersService.getVolunteers("ACR", null, null, null, null, null));
    }

    @Test
    void testInvalidInput() {
        assertThrows(InternalException.class, () -> volunteersService.getVolunteers(null, null, null, null, null, null));
        assertThrows(InternalException.class, () -> volunteersService.getVolunteers("", null, null, null, null, null));
        assertThrows(InternalException.class, () -> volunteersService.getVolunteers(" ", null, null, null, null, null));
    }

    @Test
    void testNonElsevierJournal() {
        SessionContext.initialize(new CookieManager.SessionData(ProductType.FindReviewers, "code", "bearer", "NOT-LANCET", true, false));

        ResponseEntity<VolunteersResponse> response = volunteersService.getVolunteers("NOT-LANCET", null, null, null, 10, 100);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNull(response.getBody().getVolunteers(), "Body not valid");
    }

    @Test
    void testAllDataVolunteer() throws SQLException {
        Map<String, Object> resultMapping1 = Map.ofEntries(
                Map.entry("web_user_id", 123L),
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("display_name", "Fred Flintstone"),
                Map.entry("given_name", "Fred"),
                Map.entry("family_name", "Flintstone"),
                Map.entry("em_journal_acronym", "ARC1"),
                Map.entry("volunteer_date", 1579866980000L),
                Map.entry("reason", "ExpertOrInterest"),
                Map.entry("message", "My message"),
                Map.entry("classifications", "[\"10\",\"10.1\"]"),
                Map.entry("scopus_ids", "[\"111111\",\"222222\"]"),
                Map.entry("campaign", "DinoCampaign"));

        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(resultMapping1);

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(RowMapper.class))).thenAnswer(mockAnswer);

        JdbcMockAnswer mockAnswer2 = new JdbcMockAnswer();
        mockAnswer2.addResultMapping(Map.ofEntries(
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("unavailability", "[{\"start\": 2644940700000,\"stop\": 2644940798000}]"),
                Map.entry("is_forbidden", false),
                Map.entry("is_ebm", true),
                Map.entry("editorial_history_count", 1)));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(AdditionalInfoResultsExtractor.class))).thenAnswer(mockAnswer2);

        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(personFinderWebClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("[]"));

        final WebClient.ResponseSpec sharedSearchSpecMock = createWebClientResponseSpecMock(sharedSearchWebClient);
        Mockito.when(sharedSearchSpecMock.bodyToMono(String.class)).thenReturn(Mono.just(""));

        ResponseEntity<VolunteersResponse> response = volunteersService.getVolunteers("ARC1", null, "empty response", null, 10, 30);

        assertEquals("ARC1", mockAnswer.getParameter("emJournalAcronym", String.class));
        assertEquals(10, mockAnswer.getParameter("offset", Integer.class));
        assertEquals(30, mockAnswer.getParameter("limit", Integer.class));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertEquals(false, response.getBody().isMore());
        assertEquals(1, response.getBody().getVolunteers().size());
        assertEquals(123L, response.getBody().getVolunteers().get(0).getWebUserId());
        assertEquals("fred@bedrock.com", response.getBody().getVolunteers().get(0).getEmails().get(0));
        assertEquals("Fred Flintstone", response.getBody().getVolunteers().get(0).getDisplayName());
        assertEquals("Fred", response.getBody().getVolunteers().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getVolunteers().get(0).getLastName());
        assertEquals("ARC1", response.getBody().getVolunteers().get(0).getEmJournalAcronym());
        assertEquals(1579866980000L, response.getBody().getVolunteers().get(0).getVolunteerDate());
        assertEquals(Volunteer.ReasonEnum.EXPERTORINTEREST, response.getBody().getVolunteers().get(0).getReason());
        assertEquals("My message", response.getBody().getVolunteers().get(0).getMessage());
        assertEquals("DinoCampaign", response.getBody().getVolunteers().get(0).getCampaign());
        assertEquals(2, response.getBody().getVolunteers().get(0).getClassificationCodes().size());
        assertEquals("10", response.getBody().getVolunteers().get(0).getClassificationCodes().get(0));
        assertEquals("10.1", response.getBody().getVolunteers().get(0).getClassificationCodes().get(1));
        assertEquals(2, response.getBody().getVolunteers().get(0).getScopusIds().size());
        assertEquals("111111", response.getBody().getVolunteers().get(0).getScopusIds().get(0));
        assertEquals("222222", response.getBody().getVolunteers().get(0).getScopusIds().get(1));
        assertEquals(1, response.getBody().getVolunteers().get(0).getEditorialHistoryCount());
        assertEquals(1, response.getBody().getVolunteers().get(0).getIndicators().size());
        assertEquals(Indicators.EDITORIALBOARDMEMBER, response.getBody().getVolunteers().get(0).getIndicators().get(0));
        assertNull(response.getBody().getVolunteers().get(0).getReviewStatistics());

        assertEquals(0, getAnalyticsCounterValue("custom.preferences.reviewer", "availability"));
    }

    @Test
    void testPartialDataVolunteer() throws SQLException {
        Map<String, Object> resultMapping1 = Map.ofEntries(
                Map.entry("web_user_id", 123L),
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("given_name", "Fred"),
                Map.entry("family_name", "Flintstone"),
                Map.entry("em_journal_acronym", "ARC1"),
                Map.entry("volunteer_date", 1579866980000L),
                Map.entry("reason", "PrestigeOfJournal"),
                Map.entry("message", "My message"),
                Map.entry("scopus_ids", "[\"222222\"]"));

        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(resultMapping1);

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(RowMapper.class))).thenAnswer(mockAnswer);

        JdbcMockAnswer mockAnswer2 = new JdbcMockAnswer();
        mockAnswer2.addResultMapping(Map.ofEntries(
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("concurrent_review_limit", 1),
                Map.entry("this_recently_accepted_author", true),
                Map.entry("other_recently_accepted_author", true),
                Map.entry("is_forbidden", true)));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(AdditionalInfoResultsExtractor.class))).thenAnswer(mockAnswer2);

        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(personFinderWebClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("{ invalid json }"));

        ResponseEntity<VolunteersResponse> response = volunteersService.getVolunteers("ACR", null, "", null, null, null);

        assertEquals("ACR", mockAnswer.getParameter("emJournalAcronym", String.class));
        assertFalse(mockAnswer.hasParameter("offset"));
        assertFalse(mockAnswer.hasParameter("limit"));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertEquals(false, response.getBody().isMore());
        assertEquals(1, response.getBody().getVolunteers().size());
        assertEquals(123L, response.getBody().getVolunteers().get(0).getWebUserId());
        assertEquals("fred@bedrock.com", response.getBody().getVolunteers().get(0).getEmails().get(0));
        assertEquals("Fred Flintstone", response.getBody().getVolunteers().get(0).getDisplayName());
        assertEquals("Fred", response.getBody().getVolunteers().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getVolunteers().get(0).getLastName());
        assertEquals("ARC1", response.getBody().getVolunteers().get(0).getEmJournalAcronym());
        assertEquals(1579866980000L, response.getBody().getVolunteers().get(0).getVolunteerDate());
        assertEquals(Volunteer.ReasonEnum.PRESTIGEOFJOURNAL, response.getBody().getVolunteers().get(0).getReason());
        assertEquals("My message", response.getBody().getVolunteers().get(0).getMessage());
        assertNull(response.getBody().getVolunteers().get(0).getClassificationCodes());
        assertEquals(1, response.getBody().getVolunteers().get(0).getScopusIds().size());
        assertEquals("222222", response.getBody().getVolunteers().get(0).getScopusIds().get(0));
        assertEquals(3, response.getBody().getVolunteers().get(0).getIndicators().size());
        assertEquals(Indicators.RECENTLYACCEPTEDAUTHORTHISJOURNAL, response.getBody().getVolunteers().get(0).getIndicators().get(0));
        assertEquals(Indicators.RECENTLYACCEPTEDAUTHOROTHERJOURNAL, response.getBody().getVolunteers().get(0).getIndicators().get(1));
        assertEquals(Indicators.FORBIDDENREVIEWER, response.getBody().getVolunteers().get(0).getIndicators().get(2));
        assertNull(response.getBody().getVolunteers().get(0).getReviewStatistics());
    }

    @Test
    void testMultipleVolunteers() throws SQLException {
        Map<String, Object> resultMapping1 = Map.ofEntries(
                Map.entry("web_user_id", 123L),
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("em_journal_acronym", "ARC1"),
                Map.entry("volunteer_date", 1579866980000L),
                Map.entry("reason", "PreviouslyPublished"));

        Map<String, Object> resultMapping2 = Map.ofEntries(
                Map.entry("web_user_id", 456L),
                Map.entry("email", "barney@bedrock.com"),
                Map.entry("display_name", ""),
                Map.entry("family_name", "Rubble"),
                Map.entry("em_journal_acronym", "ARC1"),
                Map.entry("volunteer_date", 1579877980000L),
                Map.entry("reason", "LearnAndStayUpToDate"),
                Map.entry("classifications", ""),
                Map.entry("scopus_ids", ""));

        Map<String, Object> resultMapping3 = Map.ofEntries(
                Map.entry("web_user_id", 457L),
                Map.entry("email", "wilma@bedrock.com"));

        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(resultMapping1);
        mockAnswer.addResultMapping(resultMapping2);
        mockAnswer.addResultMapping(resultMapping3);

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(RowMapper.class))).thenAnswer(mockAnswer);

        JdbcMockAnswer mockAnswer2 = new JdbcMockAnswer();
        mockAnswer2.addResultMapping(
                Map.ofEntries(Map.entry("email", "fred@bedrock.com"),
                        Map.entry("concurrent_review_limit", 100),
                        Map.entry("unavailability", "[ 1, 2, 3]"),
                        Map.entry("editorial_history", "[]")),
                Map.ofEntries(Map.entry("email", "barney@bedrock.com"),
                        Map.entry("concurrent_review_limit", 3),
                        Map.entry("unavailability", ""),
                        Map.entry("editorial_history", "[]")),
                Map.ofEntries(Map.entry("email", "wilma@bedrock.com"),
                        Map.entry("concurrent_review_limit", 1),
                        Map.entry("unavailability", "-null-"),
                        Map.entry("editorial_history", "-null-")));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(AdditionalInfoResultsExtractor.class))).thenAnswer(mockAnswer2);

        JdbcMockAnswer mockEmAnswer = new JdbcMockAnswer();
        mockEmAnswer.addResultMapping(Map.ofEntries(
                Map.entry("email", "wilma@bedrock.com"),
                Map.entry("journal_acronym", "ACR"),
                Map.entry("rstop", 1589809511783L),
                Map.entry("work_in_progress", true),
                Map.entry("declined", false),
                Map.entry("terminated", false),
                Map.entry("completed", false),
                Map.entry("alternate", false),
                Map.entry("assigned_not_invited", false)));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(ReviewStatisticsResultsExtractor.class))).thenAnswer(mockEmAnswer);

        ResponseEntity<VolunteersResponse> response = volunteersService.getVolunteers("ACR", null, null, null, null, 3);

        assertEquals("ACR", mockAnswer.getParameter("emJournalAcronym", String.class));
        assertFalse(mockAnswer.hasParameter("offset"));
        assertEquals(3, mockAnswer.getParameter("limit", Integer.class));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertEquals(true, response.getBody().isMore());
        assertEquals(2, response.getBody().getVolunteers().size());
        assertEquals(123L, response.getBody().getVolunteers().get(0).getWebUserId());
        assertEquals("fred@bedrock.com", response.getBody().getVolunteers().get(0).getEmails().get(0));
        assertNull(response.getBody().getVolunteers().get(0).getDisplayName());
        assertNull(response.getBody().getVolunteers().get(0).getFirstName());
        assertNull(response.getBody().getVolunteers().get(0).getLastName());
        assertEquals("ARC1", response.getBody().getVolunteers().get(0).getEmJournalAcronym());
        assertEquals(1579866980000L, response.getBody().getVolunteers().get(0).getVolunteerDate());
        assertEquals(Volunteer.ReasonEnum.PREVIOUSLYPUBLISHED, response.getBody().getVolunteers().get(0).getReason());
        assertNull(response.getBody().getVolunteers().get(0).getMessage());
        assertNull(response.getBody().getVolunteers().get(0).getClassificationCodes());
        assertNull(response.getBody().getVolunteers().get(0).getScopusIds());
        assertNull(response.getBody().getVolunteers().get(0).getReviewStatistics());

        assertEquals(456L, response.getBody().getVolunteers().get(1).getWebUserId());
        assertEquals("barney@bedrock.com", response.getBody().getVolunteers().get(1).getEmails().get(0));
        assertEquals("Rubble", response.getBody().getVolunteers().get(1).getDisplayName());
        assertNull(response.getBody().getVolunteers().get(1).getFirstName());
        assertEquals("Rubble", response.getBody().getVolunteers().get(1).getLastName());
        assertEquals("ARC1", response.getBody().getVolunteers().get(1).getEmJournalAcronym());
        assertEquals(1579877980000L, response.getBody().getVolunteers().get(1).getVolunteerDate());
        assertEquals(Volunteer.ReasonEnum.LEARNANDSTAYUPTODATE, response.getBody().getVolunteers().get(1).getReason());
        assertNull(response.getBody().getVolunteers().get(1).getMessage());
        assertNull(response.getBody().getVolunteers().get(1).getClassificationCodes());
        assertNull(response.getBody().getVolunteers().get(1).getScopusIds());
        assertNull(response.getBody().getVolunteers().get(1).getReviewStatistics());

        assertEquals(1, getAnalyticsCounterValue("custom.preferences.reviewer", "concurrent.limit"));
    }

    @Test
    void testInvalidColumnValues() throws SQLException {
        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(Map.ofEntries(
                Map.entry("web_user_id", 123L),
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("given_name", "Fred"),
                Map.entry("em_journal_acronym", "ARC1"),
                Map.entry("volunteer_date", 1579866980000L),
                Map.entry("reason", "NonValidReason"),
                Map.entry("classifications", "[ not json ]"),
                Map.entry("scopus_ids", "[1 2 3]")));
        mockAnswer.addResultMapping(Map.ofEntries(
                Map.entry("web_user_id", 456L),
                Map.entry("email", "barney@bedrock.com"),
                Map.entry("em_journal_acronym", "ARC1"),
                Map.entry("volunteer_date", 1579877980000L)));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(RowMapper.class))).thenAnswer(mockAnswer);

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(AdditionalInfoResultsExtractor.class))).thenAnswer(new JdbcMockAnswer());

        JdbcMockAnswer mockAnswerEmpty = new JdbcMockAnswer();
        mockAnswerEmpty.addResultMapping(Map.ofEntries());

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(ReviewStatisticsResultsExtractor.class))).thenAnswer(mockAnswerEmpty);

        ResponseEntity<VolunteersResponse> response = volunteersService.getVolunteers("ACR", null, null, null, null, null);

        assertEquals("ACR", mockAnswer.getParameter("emJournalAcronym", String.class));
        assertFalse(mockAnswer.hasParameter("offset"));
        assertFalse(mockAnswer.hasParameter("limit"));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertEquals(false, response.getBody().isMore());
        assertEquals(2, response.getBody().getVolunteers().size());
        assertEquals(123L, response.getBody().getVolunteers().get(0).getWebUserId());
        assertEquals("fred@bedrock.com", response.getBody().getVolunteers().get(0).getEmails().get(0));
        assertEquals("Fred", response.getBody().getVolunteers().get(0).getDisplayName());
        assertEquals("Fred", response.getBody().getVolunteers().get(0).getFirstName());
        assertNull(response.getBody().getVolunteers().get(0).getLastName());
        assertEquals("ARC1", response.getBody().getVolunteers().get(0).getEmJournalAcronym());
        assertEquals(1579866980000L, response.getBody().getVolunteers().get(0).getVolunteerDate());
        assertNull(response.getBody().getVolunteers().get(0).getReason());
        assertNull(response.getBody().getVolunteers().get(0).getMessage());
        assertNull(response.getBody().getVolunteers().get(0).getClassificationCodes());
        assertNull(response.getBody().getVolunteers().get(0).getScopusIds());
        assertNull(response.getBody().getVolunteers().get(0).getReviewStatistics());

        assertNull(response.getBody().getVolunteers().get(1).getReason());
    }

    @Test
    void testExtraScopusData() throws SQLException {
        final String author = "{\"authid\":\"000000800\",\"afdispname\":\"Bedrock Uni\",\"afdispcity\":\"Red Rock\"," +
                "\"afdispctry\":\"Bedrock\",\"count\":182,\"h_index\":\"24\", \"num_cited_by\":\"76\"}";

        Map<String, Object> resultMapping1 = Map.ofEntries(
                Map.entry("web_user_id", 123L),
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("given_name", "Fred"),
                Map.entry("family_name", "Flintstone"),
                Map.entry("em_journal_acronym", "ARC1"),
                Map.entry("scopus_ids", "[\"000000800\"]"));

        Map<String, Object> resultMapping2 = Map.ofEntries(
                Map.entry("web_user_id", 124L),
                Map.entry("email", "wilma@bedrock.com"),
                Map.entry("given_name", "Wilma"),
                Map.entry("family_name", "Flintstone"),
                Map.entry("em_journal_acronym", "ARC1"),
                Map.entry("scopus_ids", "[\"000000000\"]"));

        Map<String, Object> resultMapping3 = Map.ofEntries(
                Map.entry("web_user_id", 125L),
                Map.entry("email", "barney@bedrock.com"),
                Map.entry("given_name", "Barney"),
                Map.entry("family_name", "Rubble"),
                Map.entry("em_journal_acronym", "ARC1"),
                Map.entry("scopus_ids", "-null-"));

        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(resultMapping1);
        mockAnswer.addResultMapping(resultMapping2);
        mockAnswer.addResultMapping(resultMapping3);

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(RowMapper.class))).thenAnswer(mockAnswer);

        JdbcMockAnswer mockAnswer2 = new JdbcMockAnswer();
        mockAnswer2.addResultMapping(
                Map.ofEntries(Map.entry("email", "fred@bedrock.com"),
                        Map.entry("concurrent_review_limit", 0)),
                Map.ofEntries(Map.entry("email", "barney@bedrock.com"),
                        Map.entry("concurrent_review_limit", 10)),
                Map.ofEntries(Map.entry("email", "wilma@bedrock.com"),
                        Map.entry("concurrent_review_limit", 0)));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(AdditionalInfoResultsExtractor.class))).thenAnswer(mockAnswer2);

        final WebClient.RequestHeadersUriSpec uriSpecMock = Mockito.mock(WebClient.RequestHeadersUriSpec.class);
        final WebClient.RequestHeadersSpec headersSpecMock = Mockito.mock(WebClient.RequestHeadersSpec.class);
        final WebClient.ResponseSpec responseSpecMock = Mockito.mock(WebClient.ResponseSpec.class);
        Mockito.when(personFinderWebClient.get()).thenReturn(uriSpecMock);
        Mockito.when(uriSpecMock.uri(Mockito.any(URI.class))).thenReturn(headersSpecMock);
        Mockito.when(headersSpecMock.header(Mockito.anyString(), Mockito.anyString())).thenReturn(headersSpecMock);
        Mockito.when(headersSpecMock.accept(Mockito.notNull())).thenReturn(headersSpecMock);
        Mockito.when(headersSpecMock.retrieve()).thenReturn(responseSpecMock).thenReturn(responseSpecMock)
                .thenThrow(new WebClientResponseException(404, "Not Found", null, null, null));
        Mockito.when(responseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("[" + author + "]")).thenReturn(Mono.just(""));

        final WebClient.RequestBodyUriSpec bodyUriSpecMock2 = Mockito.mock(WebClient.RequestBodyUriSpec.class);
        final WebClient.RequestBodySpec bodySpecMock2 = Mockito.mock(WebClient.RequestBodySpec.class);
        final WebClient.RequestHeadersSpec headersSpecMock2 = Mockito.mock(WebClient.RequestHeadersSpec.class);
        final WebClient.ResponseSpec responseSpecMock2 = Mockito.mock(WebClient.ResponseSpec.class);
        Mockito.when(sharedSearchWebClient.post()).thenReturn(bodyUriSpecMock2);
        Mockito.when(bodyUriSpecMock2.uri(Mockito.anyString())).thenReturn(bodySpecMock2);
        Mockito.when(bodySpecMock2.header(Mockito.anyString(), Mockito.anyString())).thenReturn(bodySpecMock2);
        Mockito.when(bodySpecMock2.accept(Mockito.notNull())).thenReturn(bodySpecMock2);
        Mockito.when(bodySpecMock2.contentType(Mockito.notNull())).thenReturn(bodySpecMock2);
        Mockito.when(bodySpecMock2.bodyValue(Mockito.contains(Integer.toString(Year.now().plusYears(1).getValue()))))
                .thenReturn(headersSpecMock2);
        Mockito.when(headersSpecMock2.retrieve()).thenReturn(responseSpecMock2)
                .thenThrow(new WebClientResponseException(404, "Not Found", null, null, null));
        Mockito.when(responseSpecMock2.bodyToMono(String.class)).thenReturn(Mono.just("{\"totalResultsCount\": null, \"hits\": null}"));

        ResponseEntity<VolunteersResponse> response = volunteersService.getVolunteers("ACR", null, "null facetResults", null, null, null);

        assertEquals("ACR", mockAnswer.getParameter("emJournalAcronym", String.class));
        assertFalse(mockAnswer.hasParameter("offset"));
        assertFalse(mockAnswer.hasParameter("limit"));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(false, response.getBody().isMore());
        assertNotNull(response.getBody(), "Null body");
        assertEquals(3, response.getBody().getVolunteers().size());
        assertEquals(123L, response.getBody().getVolunteers().get(0).getWebUserId());
        assertEquals("fred@bedrock.com", response.getBody().getVolunteers().get(0).getEmails().get(0));
        assertEquals("Fred Flintstone", response.getBody().getVolunteers().get(0).getDisplayName());
        assertEquals("Fred", response.getBody().getVolunteers().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getVolunteers().get(0).getLastName());
        assertEquals("ARC1", response.getBody().getVolunteers().get(0).getEmJournalAcronym());
        assertEquals(1, response.getBody().getVolunteers().get(0).getScopusIds().size());
        assertEquals("000000800", response.getBody().getVolunteers().get(0).getScopusIds().get(0));
        assertEquals("Bedrock Uni", response.getBody().getVolunteers().get(0).getAffiliationName());
        assertEquals("Red Rock", response.getBody().getVolunteers().get(0).getAffiliationCity());
        assertEquals("Bedrock", response.getBody().getVolunteers().get(0).getAffiliationCountry());
        assertEquals(182, response.getBody().getVolunteers().get(0).getPublicationCount());
        assertEquals(76, response.getBody().getVolunteers().get(0).getCitationCount());
        assertEquals(24, response.getBody().getVolunteers().get(0).getHindex());

        mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(resultMapping1);

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(RowMapper.class))).thenAnswer(mockAnswer);

        response = volunteersService.getVolunteers("ACR", null, "404 not found", null, null, null);
        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertEquals(1, response.getBody().getVolunteers().size());

        mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(resultMapping1);

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(RowMapper.class))).thenAnswer(mockAnswer);

        response = volunteersService.getVolunteers("ACR", null, null, null, null, null);
        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertEquals(1, response.getBody().getVolunteers().size());
    }
}
