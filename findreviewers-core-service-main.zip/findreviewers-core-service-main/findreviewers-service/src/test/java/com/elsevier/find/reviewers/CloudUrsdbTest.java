package com.elsevier.find.reviewers;

import com.elsevier.find.reviewers.dao.CandidateInfoDao;
import com.elsevier.find.reviewers.dao.EditorDao;
import com.elsevier.find.reviewers.dao.JournalDao;
import com.elsevier.find.reviewers.dao.ManuscriptDao;
import com.elsevier.find.reviewers.dao.VolunteerDao;
import com.elsevier.find.reviewers.testutils.TestBase;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.data.jdbc.JdbcRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.test.context.TestPropertySource;

import java.util.List;

@TestPropertySource(properties = {
        "findreviewers.cloud.ursdb=true"
})
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, JdbcRepositoriesAutoConfiguration.class})
public class CloudUrsdbTest extends TestBase {
    @Autowired
    CandidateInfoDao candidateInfoDao;

    @Autowired
    JournalDao journalDao;

    @Autowired
    EditorDao editorDao;

    @Autowired
    VolunteerDao volunteerDao;

    @Autowired
    ManuscriptDao manuscriptDao;

    @Test
    void testDaos() {
        // This test class is just to fire into each of the statements for the Cloud URSDB to ensure
        // we cover that piece of code, the actual SQL is validated in the service tests. This test
        // class will be removed when we do the switch over
        candidateInfoDao.getCandidateDetails("ACR", List.of("fred@bedrock.com"));
        candidateInfoDao.getReviewStatistics(List.of("fred@bedrock.com"));

        journalDao.getEmJournalId("ACR");
        try {
            journalDao.isUrsdbJournal("ACR");
        } catch (Exception ignored) {
        }
        journalDao.getJournals();
        journalDao.getJournalReviewers("ACR", 100, 100);

        editorDao.getEditorialBoardMembersByEmJournalAcronym("ACR", 100, 100);
        try {
            editorDao.isEditor("ACR", List.of("fred@bedrock.com"));
        } catch (Exception ignored) {
        }

        volunteerDao.getVolunteersByEmJournalAcronym("ACR", 100, 100);
        volunteerDao.getCrowdsourcedReviewerIds("ACR", 1, List.of("fred@bedrock.com"));

        manuscriptDao.getManuscriptDetails("ACR", 1L);
        manuscriptDao.getInitialisationDetails("ACR", 1L);
        manuscriptDao.getReferenceIdentifiers("ACR", 1L);
    }
}
