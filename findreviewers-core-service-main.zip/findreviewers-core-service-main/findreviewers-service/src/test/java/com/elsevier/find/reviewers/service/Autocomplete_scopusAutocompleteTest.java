package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.generated.model.AutocompleteResponse;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.testutils.TestBase;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.data.jdbc.JdbcRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.net.URI;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

@TestPropertySource(properties = {
        "scopusautocomplete.client.base.url=https://localhost/api/"
})
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, JdbcRepositoriesAutoConfiguration.class})
public class Autocomplete_scopusAutocompleteTest extends TestBase {
    @Autowired
    private AutocompleteService autocompleteService;

    @MockBean(name = "scopusautocomplete")
    private WebClient scopusautocompleteWebClient;

    @Test
    void testNoSuggestions404() {
        final WebClient.RequestHeadersUriSpec uriSpecMock = Mockito.mock(WebClient.RequestHeadersUriSpec.class);
        final WebClient.RequestHeadersSpec headersSpecMock = Mockito.mock(WebClient.RequestHeadersSpec.class);
        Mockito.when(scopusautocompleteWebClient.get()).thenReturn(uriSpecMock);
        Mockito.when(uriSpecMock.uri(Mockito.any(URI.class))).thenReturn(headersSpecMock);
        Mockito.when(headersSpecMock.header(Mockito.anyString(), Mockito.anyString())).thenReturn(headersSpecMock);
        Mockito.when(headersSpecMock.accept(Mockito.notNull())).thenReturn(headersSpecMock);
        Mockito.when(headersSpecMock.retrieve()).thenThrow(new WebClientResponseException(404, "Not Found", null, null, null));

        ResponseEntity<AutocompleteResponse> response =
                autocompleteService.scopusAutocomplete("testQuery", null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(0, response.getBody().getSuggestions().size());
    }

    @Test
    void testHttpErrorResponse() {
        final WebClient.RequestHeadersUriSpec uriSpecMock = Mockito.mock(WebClient.RequestHeadersUriSpec.class);
        final WebClient.RequestHeadersSpec headersSpecMock = Mockito.mock(WebClient.RequestHeadersSpec.class);
        Mockito.when(scopusautocompleteWebClient.get()).thenReturn(uriSpecMock);
        Mockito.when(uriSpecMock.uri(Mockito.any(URI.class))).thenReturn(headersSpecMock);
        Mockito.when(headersSpecMock.header(Mockito.anyString(), Mockito.anyString())).thenReturn(headersSpecMock);
        Mockito.when(headersSpecMock.accept(Mockito.notNull())).thenReturn(headersSpecMock);
        Mockito.when(headersSpecMock.retrieve())
                .thenThrow(new WebClientResponseException(500, "Internal Error", null, null, null))
                .thenThrow(new RuntimeException("Error Test"))
                .thenThrow(new WebClientResponseException(400, "Bad Request", null, null, null));

        InternalException e = assertThrows(InternalException.class, () -> autocompleteService.scopusAutocomplete("testQuery", null));
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getHttpStatus(), "Invalid status");
        assertEquals(ErrorResponse.IdEnum.SCOPUSAUTOCOMPLETEFAILURE, e.toErrorResponse().getId(), "Invalid error Id");

        e = assertThrows(InternalException.class, () -> autocompleteService.scopusAutocomplete("testQuery", null));
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getHttpStatus(), "Invalid status");
        assertEquals(ErrorResponse.IdEnum.SCOPUSAUTOCOMPLETEFAILURE, e.toErrorResponse().getId(), "Invalid error Id");

        e = assertThrows(InternalException.class, () -> autocompleteService.scopusAutocomplete("testQuery", null));
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getHttpStatus(), "Invalid status");
        assertEquals(ErrorResponse.IdEnum.SCOPUSAUTOCOMPLETEFAILURE, e.toErrorResponse().getId(), "Invalid error Id");
    }

    @Test
    void testNoSuggestions() {
        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(scopusautocompleteWebClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just("{\"suggestions\":[]}"))
                .thenReturn(Mono.just("{}"))
                .thenReturn(Mono.just(""))
                .thenReturn(Mono.just("{\"suggestions\":[{\"term\": null}]}"));

        for (int i = 1; i <= 5; i++) {
            ResponseEntity<AutocompleteResponse> response =
                    autocompleteService.scopusAutocomplete("term", null);

            assertNotNull(response, "Null Response " + i);
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertNotNull(response.getBody(), "Body not valid " + i);
            assertEquals(0, response.getBody().getSuggestions().size());
        }
    }

    @Test
    void testInvalidInput() {
        assertThrows(InternalException.class, () -> autocompleteService.scopusAutocomplete(null, null));
        assertThrows(InternalException.class, () -> autocompleteService.scopusAutocomplete("", null));
        assertThrows(InternalException.class, () -> autocompleteService.scopusAutocomplete("ab", null));
    }

    @Test
    void testMessageProcessingError() {
        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(scopusautocompleteWebClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("{ invalid json }"));

        InternalException e = assertThrows(InternalException.class, () -> autocompleteService.scopusAutocomplete("testQuery", null));
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getHttpStatus(), "Invalid status");
        assertEquals(ErrorResponse.IdEnum.SCOPUSAUTOCOMPLETEFAILURE, e.toErrorResponse().getId(), "Invalid error Id");
    }

    @Test
    void testSingleSuggestion() {
        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(scopusautocompleteWebClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just("{\"suggestions\":[{\"term\":\"termOne\"}]}"));

        ResponseEntity<AutocompleteResponse> response =
                autocompleteService.scopusAutocomplete("term", null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(1, response.getBody().getSuggestions().size());
        assertEquals("termOne", response.getBody().getSuggestions().get(0));
    }

    @Test
    void testMultipleSuggestions() {
        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(scopusautocompleteWebClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just("{\"suggestions\":[{\"term\":\"termOne\"}, {\"term\":\"termTwo\"}, {\"term\":null}, {\"term\":\"termThree\"}]}"));

        ResponseEntity<AutocompleteResponse> response =
                autocompleteService.scopusAutocomplete("term", null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(3, response.getBody().getSuggestions().size());
        assertEquals("termOne", response.getBody().getSuggestions().get(0));
        assertEquals("termTwo", response.getBody().getSuggestions().get(1));
        assertEquals("termThree", response.getBody().getSuggestions().get(2));
    }
}
