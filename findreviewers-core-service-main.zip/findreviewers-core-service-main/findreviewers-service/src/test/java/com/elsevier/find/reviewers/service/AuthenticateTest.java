package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.dao.EditorDao;
import com.elsevier.find.reviewers.dao.JournalDao;
import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.generated.model.AuthenticateBody;
import com.elsevier.find.reviewers.generated.model.AuthenticateResponse;
import com.elsevier.find.reviewers.testutils.TestBase;
import com.elsevier.find.reviewers.utils.CookieManager;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.data.jdbc.JdbcRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.io.IOException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.util.Base64;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, JdbcRepositoriesAutoConfiguration.class})
public class AuthenticateTest extends TestBase {
    // Wire to the service that we want to test
    @Autowired
    private AuthenticateService authenticateService;

    @MockBean(name = "httpClient")
    private HttpClient mockHttpClient;

    @Captor
    private ArgumentCaptor<HttpRequest> requestCaptor;

    @Test
    void testAuthenticateSuccess() throws IOException, InterruptedException {
        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(200);
        Mockito.when(mockTokenResponse.headers()).thenReturn(null);
        Mockito.when(mockTokenResponse.body())
                .thenReturn("{\"access_token\": \"eyJhbGciOiJIUzI1NiIsInR5cCI\",\"token_type\": \"bearer\",\"expires_in\": \"43200\"}");

        Mockito.when(coreDb.queryForObject(Mockito.contains("exists(select 1 from rr_ursdb"),
                Mockito.any(SqlParameterSource.class),
                Mockito.eq(Boolean.class))).thenReturn(true).thenReturn(false);

        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        AuthenticateBody body = new AuthenticateBody();
        body.setAuthenticationCode("authentication_code");
        body.setEmJournalAcronym("ACR");
        ResponseEntity<AuthenticateResponse> response = authenticateService.authenticate("FR-EM-ACR", body, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FR-EM-ACR"));
        assertNotNull(response.getBody(), "Null body");
        assertNotNull(response.getBody().getExpires(), "No expiry");
        assertTrue(response.getBody().isAnalyticsEnabled(), "Analytics not enabled");

        body.setEmJournalAcronym("CELL");
        response = authenticateService.authenticate("FR-EM-CELL", body, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FR-EM-CELL="));
        assertNotNull(response.getBody(), "Null body");
        assertNotNull(response.getBody().getExpires(), "No expiry");
        assertTrue(response.getBody().isAnalyticsEnabled(), "Analytics not enabled");

        authenticateService.getObjectMapper();
        authenticateService.getRequest();
    }

    @Test
    void testInvalidInput() {
        ResponseEntity<AuthenticateResponse> response = authenticateService.authenticate(null, null, null);
        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertTrue(response.getHeaders().isEmpty());

        response = authenticateService.authenticate("", null, null);
        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertTrue(response.getHeaders().isEmpty());

        response = authenticateService.authenticate("FR-EM-ACR", null, null);
        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FR-EM-ACR=;"));

        response = authenticateService.authenticate("FR-EM-ACR", new AuthenticateBody(), null);
        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FR-EM-ACR=;"));

        AuthenticateBody body = new AuthenticateBody();
        body.setAuthenticationCode("");
        response = authenticateService.authenticate("FR-EM-ACR", body, null);
        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FR-EM-ACR=;"));

        body = new AuthenticateBody();
        body.setEmJournalAcronym("");
        response = authenticateService.authenticate("FR-EM-ACR", body, null);
        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FR-EM-ACR=;"));

        // There will be no emails in the JWT
        body = new AuthenticateBody();
        body.setEmJournalAcronym("ACR");
        response = authenticateService.authenticate("FR-EM-ACR", body,
                Base64.getEncoder().encodeToString("{\"c\": \"Existing-code\", \"b\": \"bearer\", \"j\": \"ACR\", \"r\": false}".getBytes()));
        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FR-EM-ACR=;"));

        SessionContext.initializeIdentity(123L, "fred@bedrock.com", null, null, null);
        response = authenticateService.authenticate(null, body, null);
        SessionContext.destroy();

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertTrue(response.getHeaders().isEmpty());
    }

    @Test
    void testAuthorisationFailure() throws IOException, InterruptedException {
        HttpResponse<String> mockTokenResponse1 = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse1.statusCode()).thenReturn(500);

        HttpResponse<String> mockTokenResponse2 = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse2.statusCode()).thenReturn(200);
        Mockito.when(mockTokenResponse2.body())
                .thenReturn("{\"no_access_token\": \"e\",\"token_type\": \"bearer\",\"expires_in\": \"43200\"}");

        HttpResponse<String> mockTokenResponse3 = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse3.statusCode()).thenReturn(200);
        Mockito.when(mockTokenResponse3.body())
                .thenReturn("{\"access_token\": \"eyJhbGciOiJIUzI1NiIsInR5cCI\",\"token_type\": \"bearer\",\"no_expires_in\": \"43200\"}");

        HttpResponse<String> mockTokenResponse4 = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse4.statusCode()).thenReturn(200);
        Mockito.when(mockTokenResponse4.body()).thenReturn(null);

        HttpResponse<String> mockTokenResponse5 = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse5.statusCode()).thenReturn(403);
        Mockito.when(mockTokenResponse5.body()).thenReturn("{\"message\": \"error details\"}");

        HttpResponse<String> mockTokenResponse6 = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse6.statusCode()).thenReturn(400);
        Mockito.when(mockTokenResponse6.body()).thenReturn("{\"Message\": \"Authorization code ImeUkA expired\"}");

        HttpResponse<String> mockTokenResponse7 = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse7.statusCode()).thenReturn(400);
        Mockito.when(mockTokenResponse7.body()).thenReturn("{\"Message\": \"Other error not e x p i r e d\"}");

        HttpResponse<String> mockTokenResponse8 = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse8.statusCode()).thenReturn(400);
        Mockito.when(mockTokenResponse8.body()).thenReturn(null);

        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse1)
                .thenReturn(mockTokenResponse2)
                .thenReturn(mockTokenResponse3)
                .thenReturn(mockTokenResponse4)
                .thenReturn(mockTokenResponse5)
                .thenReturn(mockTokenResponse6)
                .thenReturn(mockTokenResponse7)
                .thenReturn(mockTokenResponse8)
                .thenThrow(new RuntimeException())
                .thenThrow(new InterruptedException());

        AuthenticateBody body = new AuthenticateBody();
        body.setAuthenticationCode("authentication_code");
        body.setEmJournalAcronym("ACR");

        ResponseEntity<AuthenticateResponse> response = authenticateService.authenticate("FR-EM-ACR", body, "");
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FR-EM-ACR=;"));

        response = authenticateService.authenticate("FR-EM-ACR", body, "one");
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FR-EM-ACR=;"));

        response = authenticateService.authenticate("FR-EM-ACR", body, "one---");
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FR-EM-ACR=;"));

        response = authenticateService.authenticate("FR-EM-ACR", body, "one---two");
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FR-EM-ACR=;"));

        response = authenticateService.authenticate("FR-EM-ACR", body, null);
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FR-EM-ACR=;"));

        response = authenticateService.authenticate("FR-EM-ACR", body, "---two");
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FR-EM-ACR=;"));

        response = authenticateService.authenticate("FR-EM-ACR", body, null);
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FR-EM-ACR=;"));

        response = authenticateService.authenticate("FR-EM-ACR", body, null);
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FR-EM-ACR=;"));

        response = authenticateService.authenticate("FR-EM-ACR", body, null);
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FR-EM-ACR=;"));

        response = authenticateService.authenticate("FR-EM-ACR", body, null);
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FR-EM-ACR=;"));
    }

    @Test
    void testAuthorisationRetry() throws IOException, InterruptedException {
        HttpResponse<String> mockServiceUnavailableResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockServiceUnavailableResponse.statusCode()).thenReturn(503);

        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockServiceUnavailableResponse)
                .thenThrow(new HttpTimeoutException("Timeout test"))
                .thenThrow(new IOException("IO Exception test"));

        AuthenticateBody body = new AuthenticateBody();
        body.setAuthenticationCode("authentication_code");
        body.setEmJournalAcronym("ACR");

        ResponseEntity<AuthenticateResponse> response = authenticateService.authenticate("FR-EM-ACR", body, "");

        Mockito.verify(mockHttpClient, Mockito.times(3)).send(requestCaptor.capture(),
                Mockito.any(HttpResponse.BodyHandler.class));

        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FR-EM-ACR=;"));
    }

    @Test
    void testAuthenticateReadOnly() {
        JournalDao mockJournalDao = Mockito.mock(JournalDao.class);
        Mockito.when(mockJournalDao.isUrsdbJournal(Mockito.anyString())).thenReturn(true);

        EditorDao mockEditorDao = Mockito.mock(EditorDao.class);
        Mockito.when(mockEditorDao.isEditor(Mockito.anyString(), Mockito.any())).thenReturn(false);

        AuthenticateService testAuthService = new AuthenticateService(null, null, null,
                mockJournalDao, mockEditorDao,
                null,
                new CookieManager(new ObjectMapper()),
                "READ_ONLY_CODE");

        AuthenticateBody body = new AuthenticateBody();
        body.setAuthenticationCode("READ_ONLY_CODE");
        body.setEmJournalAcronym("ACR");
        ResponseEntity<AuthenticateResponse> response = testAuthService.authenticate("FR-EM-ACR", body, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        String cookieHeader = response.getHeaders().getFirst("Set-Cookie");
        assertEquals("FR-EM-ACR", cookieHeader.split("=")[0]);
        String cookieContent = (cookieHeader.split(";")[0]).substring(cookieHeader.indexOf("=") + 1);
        assertTrue(new String(Base64.getDecoder().decode(cookieContent.getBytes())).contains("\"r\":true"));
        assertNotNull(response.getBody(), "Null body");
        assertNotNull(response.getBody().getExpires(), "No expiry");
        assertTrue(response.getBody().isAnalyticsEnabled(), "Analytics not enabled");

        // Now check with ID+ login - overriding not being an editor
        SessionContext.initializeIdentity(123L, "fred@bedrock.com", null, null, null);
        response = testAuthService.authenticate("FR-EM-ACR", body, "");

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        cookieHeader = response.getHeaders().getFirst("Set-Cookie");
        assertEquals("FR-EM-ACR", cookieHeader.split("=")[0]);
        cookieContent = (cookieHeader.split(";")[0]).substring(cookieHeader.indexOf("=") + 1);
        assertTrue(new String(Base64.getDecoder().decode(cookieContent.getBytes())).contains("\"r\":true"));
        assertNotNull(response.getBody(), "Null body");
        assertNotNull(response.getBody().getExpires(), "No expiry");
        assertTrue(response.getBody().isAnalyticsEnabled(), "Analytics not enabled");
    }

    @Test
    void testDuplicateAuthenticate() {
        AuthenticateService testAuthService = new AuthenticateService(null, null, null,
                null, null, null, new CookieManager(new ObjectMapper()), null);

        AuthenticateBody body = new AuthenticateBody();
        body.setAuthenticationCode("Reused-code");
        body.setEmJournalAcronym("ACR");
        ResponseEntity<AuthenticateResponse> response = testAuthService.authenticate("FR-EM-ACR", body,
                Base64.getEncoder().encodeToString("{\"c\": \"Reused-code\", \"b\": \"bearer\", \"j\": \"ACR\", \"r\": false}".getBytes()));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNull(response.getHeaders().getFirst("Set-Cookie"));
        assertNull(response.getBody(), "Not null body");
    }

    @Test
    void testCookieCreationFailure() throws JsonProcessingException {
        ObjectMapper objectMapper = Mockito.mock(ObjectMapper.class);
        Mockito.when(objectMapper.writeValueAsString(CookieManager.SessionData.class)).thenThrow(new RuntimeException());

        JournalDao mockJournalDao = Mockito.mock(JournalDao.class);
        Mockito.when(mockJournalDao.isUrsdbJournal(Mockito.anyString())).thenReturn(false);

        CookieManager cookieManager = new CookieManager(objectMapper);

        AuthenticateService testAuthService = new AuthenticateService(null, null, null, mockJournalDao,
                null, null, cookieManager, "READ_ONLY_CODE");

        AuthenticateBody body = new AuthenticateBody();
        body.setAuthenticationCode("READ_ONLY_CODE");
        body.setEmJournalAcronym("ACR");
        assertThrows(InternalException.class, () -> testAuthService.authenticate("FR-EM-ACR", body, null));
    }

    @Test
    void testIdPlusAuthenticateSuccess() {
        SessionContext.initializeIdentity(123L, "fred@bedrock.com", null, "Fred Flintstone", null);

        Mockito.when(coreDb.queryForObject(Mockito.contains("exists(select 1 from rr_ursdb"),
                Mockito.any(SqlParameterSource.class),
                Mockito.eq(Boolean.class))).thenReturn(true).thenReturn(false).thenReturn(false);

        Mockito.when(coreDb.queryForObject(Mockito.contains("rh_editor"),
                Mockito.any(SqlParameterSource.class),
                Mockito.eq(Boolean.class))).thenReturn(true).thenReturn(true).thenReturn(false);

        AuthenticateBody body = new AuthenticateBody();
        body.setEmJournalAcronym("ACR");
        ResponseEntity<AuthenticateResponse> response = authenticateService.authenticate("FR-IDP-ACR", body, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FR-IDP-ACR="));
        assertNotNull(response.getBody(), "Null body");
        assertNotNull(response.getBody().getExpires(), "No expiry");
        assertEquals(List.of("fred@bedrock.com"), response.getBody().getEmails());
        assertEquals("Fred Flintstone", response.getBody().getDisplayName());
        assertTrue(response.getBody().isAnalyticsEnabled(), "Analytics not enabled");

        body.setEmJournalAcronym("CELL");
        response = authenticateService.authenticate("FR-IDP-CELL", body, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FR-IDP-CELL="));
        assertNotNull(response.getBody(), "Null body");
        assertNotNull(response.getBody().getExpires(), "No expiry");
        assertTrue(response.getBody().isAnalyticsEnabled(), "Analytics not enabled");

        body.setEmJournalAcronym("NON-ELSEVIER");
        body.setAuthenticationCode("READONLY_CODE");
        response = authenticateService.authenticate("FR-IDP-NON-ELSEVIER", body, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FR-IDP-NON-ELSEVIER="));
        assertNotNull(response.getBody(), "Null body");
        assertNotNull(response.getBody().getExpires(), "No expiry");
        assertFalse(response.getBody().isAnalyticsEnabled(), "Analytics enabled");

        SessionContext.destroy();
    }

    @Test
    void testIdPlusAuthenticateFailure() {
        SessionContext.destroy();
        AuthenticateBody body = new AuthenticateBody();
        body.setEmJournalAcronym("ACR");
        ResponseEntity<AuthenticateResponse> response = authenticateService.authenticate("FR-IDP-ACR", body, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FR-IDP-ACR="));

        SessionContext.initializeIdentity(123L, null, Collections.emptyList(), null, null);

        response = authenticateService.authenticate("FR-IDP-ACR", body, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FR-IDP-ACR="));

        SessionContext.initializeIdentity(123L, "fred@bedrock.com",
                List.of("freddy@bedrock.com", "flintstone@bedrock.com"), null, null);

        Mockito.when(coreDb.queryForObject(Mockito.contains("rh_editor"),
                Mockito.any(SqlParameterSource.class),
                Mockito.eq(Boolean.class))).thenReturn(false);

        response = authenticateService.authenticate("FR-IDP-ACR", body, null);

        SessionContext.destroy();

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FR-IDP-ACR="));
    }

    @Test
    void testNonElsevierAuthenticateSuccess() throws IOException, InterruptedException {
        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(200);
        Mockito.when(mockTokenResponse.headers()).thenReturn(null);
        Mockito.when(mockTokenResponse.body())
                .thenReturn("{\"access_token\": \"eyJhbGciOiJIUzI1NiIsInR5cCI\",\"token_type\": \"bearer\",\"expires_in\": \"43200\"}");

        Mockito.when(coreDb.queryForObject(Mockito.contains("exists(select 1 from rr_ursdb"),
                Mockito.any(SqlParameterSource.class),
                Mockito.eq(Boolean.class))).thenReturn(false);

        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        AuthenticateBody body = new AuthenticateBody();
        body.setAuthenticationCode("authentication_code");
        body.setEmJournalAcronym("ACR");
        ResponseEntity<AuthenticateResponse> response = authenticateService.authenticate("FR-EM-ACR", body, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FR-EM-ACR="));
        assertNotNull(response.getBody(), "Null body");
        assertNotNull(response.getBody().getExpires(), "No expiry");
        assertFalse(response.getBody().isAnalyticsEnabled(), "Analytics are enabled");
    }

    @Test
    public void testFindEditors() {
        SessionContext.initializeIdentity(123L, null, null, null, null);

        ResponseEntity<AuthenticateResponse> response = authenticateService.authenticate("FE-IDP", null, null);
        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FE-IDP=;"));

        Mockito.when(coreDb.queryForObject(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.eq(Boolean.class))).thenReturn(false);

        SessionContext.initializeIdentity(123L, "fred@bedrock.com", null, null, null);
        response = authenticateService.authenticate("FE-IDP", null, null);
        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FE-IDP=;"));

        SessionContext.initializeIdentity(123L, "r.hudson@elsevier.com", null, "Display Name", null);
        response = authenticateService.authenticate("FE-IDP", null, null);
        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null Response");
        assertEquals(List.of("r.hudson@elsevier.com"), response.getBody().getEmails());
        assertEquals("Display Name", response.getBody().getDisplayName());
        assertTrue(response.getBody().isAnalyticsEnabled());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FE-IDP="));

        response = authenticateService.authenticate("FE-IDP", new AuthenticateBody(), null);
        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null Response");
        assertTrue(response.getBody().isAnalyticsEnabled());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FE-IDP="));

        response = authenticateService.authenticate("FE-IDP", new AuthenticateBody().emJournalAcronym(""), null);
        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null Response");
        assertTrue(response.getBody().isAnalyticsEnabled());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FE-IDP="));
    }

    @Test
    public void testFindEditorsDbAccess() {
        SessionContext.initializeIdentity(123L, "fred@bedrock.com", null, null, null);

        Mockito.when(coreDb.queryForObject(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.eq(Boolean.class))).thenReturn(false).thenReturn(true);

        ResponseEntity<AuthenticateResponse> response = authenticateService.authenticate("FE-IDP", null, null);
        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FE-IDP=;"));

        response = authenticateService.authenticate("FE-IDP", new AuthenticateBody().emJournalAcronym(""), null);
        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null Response");
        assertTrue(response.getBody().isAnalyticsEnabled());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FE-IDP="));
    }

    @Test
    public void testFindEditorsRHAccess() throws IOException, InterruptedException {
        SessionContext.initializeIdentity(123L, "fred@bedrock.com", null, null, null);

        Mockito.when(coreDb.queryForObject(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.eq(Boolean.class))).thenReturn(false);

        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode())
                .thenReturn(200)
                .thenReturn(500)
                .thenReturn(200)
                .thenReturn(200)
                .thenReturn(200)
                .thenReturn(200);
        Mockito.when(mockTokenResponse.body())
                .thenReturn("{\"access\": [\"fred@bedrock.com\"]}")
                .thenReturn(null)
                .thenReturn("")
                .thenReturn("{}")
                .thenReturn("{\"access\": []}");

        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse)
                .thenReturn(mockTokenResponse)
                .thenReturn(mockTokenResponse)
                .thenReturn(mockTokenResponse)
                .thenReturn(mockTokenResponse)
                .thenReturn(mockTokenResponse)
                .thenThrow(new InterruptedException());

        ResponseEntity<AuthenticateResponse> response = authenticateService.authenticate("FE-IDP", null, null);
        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null Response");
        assertTrue(response.getBody().isAnalyticsEnabled());
        assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FE-IDP="));

        for (int i = 0; i < 6; i++) {
            response = authenticateService.authenticate("FE-IDP", null, null);
            assertNotNull(response, "Null Response");
            assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
            assertTrue(response.getHeaders().getFirst("Set-Cookie").contains("FE-IDP=;"));
        }
    }
}
