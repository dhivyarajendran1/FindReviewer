package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.dao.impl.AdditionalInfoDaoImpl.AdditionalInfoResultsExtractor;
import com.elsevier.find.reviewers.dao.impl.CandidateInfoDaoImpl.ReviewStatisticsResultsExtractor;
import com.elsevier.find.reviewers.enums.ProductType;
import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.generated.model.Indicators;
import com.elsevier.find.reviewers.generated.model.JournalReviewersResponse;
import com.elsevier.find.reviewers.generated.model.PersonDetails;
import com.elsevier.find.reviewers.generated.model.ScopusSearchAuthor;
import com.elsevier.find.reviewers.service.base.DataGatherRules;
import com.elsevier.find.reviewers.service.base.PersonDetailsSupportService;
import com.elsevier.find.reviewers.testutils.JdbcMockAnswer;
import com.elsevier.find.reviewers.testutils.TestBase;
import com.elsevier.find.reviewers.utils.CookieManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.data.jdbc.JdbcRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, JdbcRepositoriesAutoConfiguration.class})
public class JournalReviewer_getJournalReviewersTest extends TestBase {
    // Wire to the service that we want to test
    @Autowired
    private JournalReviewerService journalReviewerService;

    @Autowired
    private PersonDetailsSupportService personDetailsSupportService;

    @MockBean(name = "personfinder")
    private WebClient personFinderWebClient;

    @MockBean(name = "scopussharedsearch")
    private WebClient sharedSearchWebClient;

    @MockBean(name = "httpClient")
    private HttpClient mockHttpClient;

    @BeforeEach
    void setup() {
        SessionContext.initialize(new CookieManager.SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", true, true));
    }

    @Test
    void testNoCandidates() {
        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(RowMapper.class))).thenAnswer(mockAnswer);

        ResponseEntity<JournalReviewersResponse> response = journalReviewerService.getJournalReviewers("ACR", "keyword", null, null, 10, 100);

        assertEquals("ACR", mockAnswer.getParameter("emJournalAcronym", String.class));
        assertEquals(10, mockAnswer.getParameter("offset", Integer.class));
        assertEquals(100, mockAnswer.getParameter("limit", Integer.class));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertEquals(0, response.getBody().getReviewers().size());
        assertEquals(false, response.getBody().isMore());
    }

    @Test
    void testInvalidInput() {
        assertThrows(InternalException.class, () -> journalReviewerService.getJournalReviewers(null, "keyword", null, null, null, 100));
        assertThrows(InternalException.class, () -> journalReviewerService.getJournalReviewers("", "keyword", null, null, null, 100));
        assertThrows(InternalException.class, () -> journalReviewerService.getJournalReviewers("ACR", null, null, null, null, 100));
        assertThrows(InternalException.class, () -> journalReviewerService.getJournalReviewers("ACR", "ab", null, null, null, 100));
        assertThrows(InternalException.class, () -> journalReviewerService.getJournalReviewers("ACR", "keyword", null, null, null, null));
        assertThrows(InternalException.class, () -> journalReviewerService.getJournalReviewers("ACR", "keyword", null, null, null, 1000));
    }

    @Test
    void testNonUrsdbJournal() {
        SessionContext.initialize(new CookieManager.SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", true, false));

        ResponseEntity<JournalReviewersResponse> response = journalReviewerService.getJournalReviewers("ACR", "keyword", null, null, 10, 100);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().getReviewers().isEmpty());
    }

    @Test
    void testCandidates() throws SQLException, IOException, InterruptedException {
        JdbcMockAnswer mockEmAnswer = new JdbcMockAnswer();
        mockEmAnswer.addResultMapping(Map.ofEntries(
                Map.entry("emails", "[\"fred@bedrock.com\"]"),
                Map.entry("first_name", "Fred"),
                Map.entry("last_name", "Flintstone"),
                Map.entry("scopus_id", "111111")));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(RowMapper.class))).thenAnswer(mockEmAnswer);

        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(Map.ofEntries(
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("volunteer", false),
                Map.entry("unavailability", "-null-"),
                Map.entry("concurrent_review_limit", 100),
                Map.entry("this_recently_accepted_author", true),
                Map.entry("other_recently_accepted_author", false)));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(AdditionalInfoResultsExtractor.class))).thenAnswer(mockAnswer);

        JdbcMockAnswer mockEmReviewHistoryAnswer = new JdbcMockAnswer();
        mockEmReviewHistoryAnswer.addResultMapping(Map.ofEntries(
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("journal_acronym", "ACR"),
                Map.entry("rstop", 1589809511783L),
                Map.entry("work_in_progress", false),
                Map.entry("declined", false),
                Map.entry("terminated", true),
                Map.entry("completed", false),
                Map.entry("uninvited", false),
                Map.entry("assigned_not_invited", false),
                Map.entry("recent", true)));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(ReviewStatisticsResultsExtractor.class))).thenAnswer(mockEmReviewHistoryAnswer);

        final WebClient.ResponseSpec personFinderResponseSpecMock = createWebClientResponseSpecMock(personFinderWebClient);
        Mockito.when(personFinderResponseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just(
                "[{\"authid\":\"111111\",\"afdispname\":\"Bedrock Uni\",\"afdispcity\":\"Red Rock\"," +
                        "\"afdispctry\":\"Bedrock\",\"count\":182,\"h_index\":\"24\", \"num_cited_by\":\"76\"}]"));

        final WebClient.ResponseSpec sharedSearchSpecMock = createWebClientResponseSpecMock(sharedSearchWebClient);
        Mockito.when(sharedSearchSpecMock.bodyToMono(String.class)).thenReturn(Mono.just(
                "{\"totalResultsCount\": 1, \"hits\": [{\"eid\": \"1\", \"authors\": [{\"authid\": \"111111\"}]," +
                        "\"authkeywords\": [\"Keyword1\", \"Keyword2\"]," +
                        "\"subjmain\": [\"1000\"]}," +
                        "{\"eid\": \"2\", \"authors\": [{\"authid\": \"111111\"}]," +
                        "\"authkeywords\": [\"keyword3\", \"keyword2\"]," +
                        "\"subjmain\": [\"1202\",\"1000\"]}]}"));

        // EM Support call
        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(200);
        Mockito.when(mockTokenResponse.body()).thenReturn("[]");
        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        ResponseEntity<JournalReviewersResponse> response = journalReviewerService.getJournalReviewers("ACR", "keyword", null, null, null, 1);

        assertEquals("ACR", mockEmAnswer.getParameter("emJournalAcronym", String.class));
        assertEquals(1, mockEmAnswer.getParameter("limit", Integer.class));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertEquals(true, response.getBody().isMore());
        assertEquals(1, response.getBody().getReviewers().size());
        assertEquals("111111", response.getBody().getReviewers().get(0).getScopusIds().get(0));
        assertEquals("fred@bedrock.com", response.getBody().getReviewers().get(0).getEmails().get(0));
        assertEquals("Fred Flintstone", response.getBody().getReviewers().get(0).getDisplayName());
        assertEquals("Fred", response.getBody().getReviewers().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getReviewers().get(0).getLastName());
        assertEquals("Bedrock Uni", response.getBody().getReviewers().get(0).getAffiliationName());
        assertEquals("Red Rock", response.getBody().getReviewers().get(0).getAffiliationCity());
        assertEquals("Bedrock", response.getBody().getReviewers().get(0).getAffiliationCountry());
        assertEquals(182, response.getBody().getReviewers().get(0).getPublicationCount());
        assertEquals(76, response.getBody().getReviewers().get(0).getCitationCount());
        assertEquals(24, response.getBody().getReviewers().get(0).getHindex());
        assertEquals(1, response.getBody().getReviewers().get(0).getIndicators().size());
        assertEquals(Indicators.RECENTLYACCEPTEDAUTHORTHISJOURNAL, response.getBody().getReviewers().get(0).getIndicators().get(0));
        assertEquals(2, response.getBody().getReviewers().get(0).getKeywordMatchCount());
        assertEquals(3, response.getBody().getReviewers().get(0).getKeywords().size());
        assertEquals("keyword2", response.getBody().getReviewers().get(0).getKeywords().get(0));
        assertEquals("keyword1", response.getBody().getReviewers().get(0).getKeywords().get(1));
        assertEquals("keyword3", response.getBody().getReviewers().get(0).getKeywords().get(2));
        assertEquals(2, response.getBody().getReviewers().get(0).getSubjectAreas().size());
        assertEquals("General", response.getBody().getReviewers().get(0).getSubjectAreas().get(0));
        assertEquals("History", response.getBody().getReviewers().get(0).getSubjectAreas().get(1));

        assertEquals(1, response.getBody().getReviewers().get(0).getReviewStatistics().size());
        assertEquals("ACR", response.getBody().getReviewers().get(0).getReviewStatistics().get(0).getEmJournalAcronym());
        assertEquals(1, response.getBody().getReviewers().get(0).getReviewStatistics().get(0).getInvitationCount());
        assertEquals(0, response.getBody().getReviewers().get(0).getReviewStatistics().get(0).getWorkInProgressCount());
        assertEquals(0, response.getBody().getReviewers().get(0).getReviewStatistics().get(0).getCompletedCount());
        assertNull(response.getBody().getReviewers().get(0).getReviewStatistics().get(0).getMostRecentCompleted());
    }

    @Test
    void testCandidatesNoIdentifiers() throws SQLException {
        JdbcMockAnswer mockEmAnswer = new JdbcMockAnswer();
        mockEmAnswer.addResultMapping(Map.ofEntries(
                Map.entry("emails", ""),
                Map.entry("first_name", "Fred"),
                Map.entry("last_name", "Flintstone"),
                Map.entry("scopus_id", "-null-")));
        mockEmAnswer.addResultMapping(Map.ofEntries(
                Map.entry("emails", "-null-"),
                Map.entry("first_name", "Barney"),
                Map.entry("last_name", "Rubble"),
                Map.entry("scopus_id", "")));
        mockEmAnswer.addResultMapping(Map.ofEntries(
                Map.entry("emails", "Invalid json"),
                Map.entry("first_name", "Betty"),
                Map.entry("last_name", "Rubble"),
                Map.entry("scopus_id", "")));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(RowMapper.class))).thenAnswer(mockEmAnswer);

        ResponseEntity<JournalReviewersResponse> response = journalReviewerService.getJournalReviewers("ACR", "keyword", null, null, null, 1);

        assertEquals("ACR", mockEmAnswer.getParameter("emJournalAcronym", String.class));
        assertEquals(1, mockEmAnswer.getParameter("limit", Integer.class));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertEquals(true, response.getBody().isMore());
        assertEquals(0, response.getBody().getReviewers().size());
    }

    @Test
    void testCandidatesWithOtherJournalHistory() throws SQLException, IOException, InterruptedException {
        JdbcMockAnswer mockEmAnswer = new JdbcMockAnswer();
        mockEmAnswer.addResultMapping(Map.ofEntries(
                Map.entry("emails", "[\"fred@bedrock.com\"]"),
                Map.entry("first_name", "Fred"),
                Map.entry("last_name", "Flintstone"),
                Map.entry("scopus_id", "111111")));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(RowMapper.class))).thenAnswer(mockEmAnswer);

        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(Map.ofEntries(
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("volunteer", false),
                Map.entry("unavailability", "-null-"),
                Map.entry("concurrent_review_limit", 100),
                Map.entry("this_recently_accepted_author", true),
                Map.entry("other_recently_accepted_author", false)));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(AdditionalInfoResultsExtractor.class))).thenAnswer(mockAnswer);

        JdbcMockAnswer mockEmReviewHistoryAnswer = new JdbcMockAnswer();
        mockEmReviewHistoryAnswer.addResultMapping(Map.ofEntries(
                        Map.entry("email", "fred@bedrock.com"),
                        Map.entry("journal_acronym", "ACR2"),
                        Map.entry("rstop", 1589809511783L),
                        Map.entry("work_in_progress", false),
                        Map.entry("declined", false),
                        Map.entry("completed", false),
                        Map.entry("uninvited", false),
                        Map.entry("assigned_not_invited", true),
                        Map.entry("recent", true)),
                Map.ofEntries(
                        Map.entry("email", "fred@bedrock.com"),
                        Map.entry("journal_acronym", "ACR2"),
                        Map.entry("rstop", 1589809511783L),
                        Map.entry("work_in_progress", true),
                        Map.entry("declined", false),
                        Map.entry("terminated", false),
                        Map.entry("completed", false),
                        Map.entry("uninvited", false),
                        Map.entry("assigned_not_invited", false),
                        Map.entry("recent", true)),
                Map.ofEntries(
                        Map.entry("email", "fred@bedrock.com"),
                        Map.entry("journal_acronym", "ACR2"),
                        Map.entry("rstop", 1589809511783L),
                        Map.entry("work_in_progress", true),
                        Map.entry("declined", false),
                        Map.entry("terminated", false),
                        Map.entry("completed", false),
                        Map.entry("uninvited", false),
                        Map.entry("assigned_not_invited", false),
                        Map.entry("recent", true)),
                Map.ofEntries(
                        Map.entry("email", "fred@bedrock.com"),
                        Map.entry("journal_acronym", "ACR2"),
                        Map.entry("rstop", 1589809511783L),
                        Map.entry("work_in_progress", true),
                        Map.entry("declined", false),
                        Map.entry("terminated", false),
                        Map.entry("completed", false),
                        Map.entry("uninvited", false),
                        Map.entry("assigned_not_invited", false),
                        Map.entry("recent", true)));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(ReviewStatisticsResultsExtractor.class))).thenAnswer(mockEmReviewHistoryAnswer);

        final WebClient.ResponseSpec personFinderResponseSpecMock = createWebClientResponseSpecMock(personFinderWebClient);
        Mockito.when(personFinderResponseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just(
                "[{\"authid\":\"111111\",\"afdispname\":\"Bedrock Uni\",\"afdispcity\":\"Red Rock\"," +
                        "\"afdispctry\":\"Bedrock\",\"count\":182,\"h_index\":\"24\", \"num_cited_by\":\"76\"}]"));

        final WebClient.ResponseSpec sharedSearchSpecMock = createWebClientResponseSpecMock(sharedSearchWebClient);
        Mockito.when(sharedSearchSpecMock.bodyToMono(String.class)).thenReturn(Mono.just(
                "{\"totalResultsCount\": 1, \"hits\": [{\"eid\": \"1\", \"authors\": [{\"authid\": \"111111\"}]}," +
                        "{\"eid\": \"2\", \"authors\": [{\"authid\": \"111111\"}]}]}"));

        // EM Support call
        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(200);
        Mockito.when(mockTokenResponse.body()).thenReturn("[]");
        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        ResponseEntity<JournalReviewersResponse> response = journalReviewerService.getJournalReviewers("ACR", "keyword", null, null, null, 1);

        assertEquals("ACR", mockEmAnswer.getParameter("emJournalAcronym", String.class));
        assertEquals(1, mockEmAnswer.getParameter("limit", Integer.class));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertEquals(true, response.getBody().isMore());
        assertEquals(0, response.getBody().getReviewers().size());
    }

    @Test
    void testCandidatesNoKeywordMatch() throws SQLException, IOException, InterruptedException {
        JdbcMockAnswer mockEmAnswer = new JdbcMockAnswer();
        mockEmAnswer.addResultMapping(Map.ofEntries(
                Map.entry("emails", "[\"fred@bedrock.com\"]"),
                Map.entry("first_name", "Fred"),
                Map.entry("last_name", "Flintstone"),
                Map.entry("scopus_id", "111111")));
        mockEmAnswer.addResultMapping(Map.ofEntries(
                Map.entry("emails", "[\"wilma@bedrock.com\"]"),
                Map.entry("first_name", "Wilma"),
                Map.entry("last_name", "Flintstone"),
                Map.entry("scopus_id", "222222")));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(RowMapper.class))).thenAnswer(mockEmAnswer);

        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(Map.ofEntries(
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("volunteer", false),
                Map.entry("unavailability", "-null-"),
                Map.entry("concurrent_review_limit", 100),
                Map.entry("this_recently_accepted_author", true),
                Map.entry("other_recently_accepted_author", false)));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(AdditionalInfoResultsExtractor.class))).thenAnswer(mockAnswer);

        JdbcMockAnswer mockEmReviewHistoryAnswer = new JdbcMockAnswer();
        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(ReviewStatisticsResultsExtractor.class))).thenAnswer(mockEmReviewHistoryAnswer);

        final WebClient.ResponseSpec personFinderResponseSpecMock = createWebClientResponseSpecMock(personFinderWebClient);
        Mockito.when(personFinderResponseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just(
                "[{\"authid\":\"111111\",\"afdispname\":\"Bedrock Uni\",\"afdispcity\":\"Red Rock\"," +
                        "\"afdispctry\":\"Bedrock\",\"count\":182,\"h_index\":\"24\", \"num_cited_by\":\"76\"}]"));

        final WebClient.ResponseSpec sharedSearchSpecMock = createWebClientResponseSpecMock(sharedSearchWebClient);
        Mockito.when(sharedSearchSpecMock.bodyToMono(String.class)).thenReturn(Mono.just(
                "{\"totalResultsCount\": 1, \"hits\": [{\"eid\": \"1\", \"authors\": [{\"authid\": \"111111\"}]}," +
                        "{\"eid\": \"2\", \"authors\": [{\"authid\": \"222222\"}], " +
                        "\"authkeywords\": [\"Keyword1\"]}," +
                        "{\"eid\": \"3\", \"authors\": [{\"authid\": \"222222\"}]," +
                        "\"subjmain\": [\"2701\",\"2736\"]}]}"));

        // EM Support call
        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(200);
        Mockito.when(mockTokenResponse.body()).thenReturn("[]");
        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        ResponseEntity<JournalReviewersResponse> response = journalReviewerService.getJournalReviewers("ACR", "keyword", null, null, null, 3);

        assertEquals("ACR", mockEmAnswer.getParameter("emJournalAcronym", String.class));
        assertEquals(3, mockEmAnswer.getParameter("limit", Integer.class));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertEquals(false, response.getBody().isMore());
        assertEquals(1, response.getBody().getReviewers().size());
        assertEquals("222222", response.getBody().getReviewers().get(0).getScopusIds().get(0));
        assertEquals("wilma@bedrock.com", response.getBody().getReviewers().get(0).getEmails().get(0));
        assertEquals("Wilma Flintstone", response.getBody().getReviewers().get(0).getDisplayName());
        assertEquals("Wilma", response.getBody().getReviewers().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getReviewers().get(0).getLastName());
        assertEquals(1, response.getBody().getReviewers().get(0).getKeywords().size());
        assertEquals("keyword1", response.getBody().getReviewers().get(0).getKeywords().get(0));
        assertEquals(2, response.getBody().getReviewers().get(0).getSubjectAreas().size());
        assertEquals("Medicine (miscellaneous)", response.getBody().getReviewers().get(0).getSubjectAreas().get(0));
        assertEquals("Pharmacology (medical)", response.getBody().getReviewers().get(0).getSubjectAreas().get(1));
    }

    @Test
    void testRules() {
        PersonDetails personDetails = new PersonDetails();
        personDetails.setEmails(null);
        DataGatherRules<PersonDetails> rules = new DataGatherRules<>(List.of(personDetails))
                .addBlockList().addInternalDbData().addReviewStatistics(false).addScopusData();

        assertFalse(rules.isReviewStatistics());
        assertFalse(rules.isBlockList());
        assertFalse(rules.isInternalDbData());
        assertFalse(rules.isScopusData());

        assertThrows(InputMismatchException.class, () -> rules.addContentMatch("keywords", null));

        ScopusSearchAuthor scopusAuthor = new ScopusSearchAuthor();
        scopusAuthor.addEmailsItem("fred@bedrock.com");
        personDetails.setEmails(null);

        personDetails = new PersonDetails();
        personDetails.addScopusIdsItem("111111");
        DataGatherRules<PersonDetails> invalidRules = new DataGatherRules<>(List.of(personDetails));
        ReflectionTestUtils.setField(invalidRules, "contentMatch", true);
        ReflectionTestUtils.setField(invalidRules, "keywords", "keywords");

        assertTrue(invalidRules.isContentMatch());

        final WebClient.ResponseSpec sharedSearchSpecMock = createWebClientResponseSpecMock(sharedSearchWebClient);
        Mockito.when(sharedSearchSpecMock.bodyToMono(String.class)).thenReturn(Mono.just(
                "{\"totalResultsCount\": 1, \"hits\": [{\"eid\": \"1\", \"authors\": [{\"authid\": \"111111\"}]}]}"));

        List<PersonDetails> updatedDetails = personDetailsSupportService.gatherAdditionalData("ACR", invalidRules);

        assertNotNull(updatedDetails, "Null Response");
        assertEquals(1, updatedDetails.size());
        assertEquals("111111", updatedDetails.get(0).getScopusIds().get(0));
        assertFalse(updatedDetails.get(0) instanceof ScopusSearchAuthor);
    }
}
