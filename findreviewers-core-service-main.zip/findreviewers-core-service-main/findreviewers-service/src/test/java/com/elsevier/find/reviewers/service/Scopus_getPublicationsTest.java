package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.generated.model.KeywordSearchLogic;
import com.elsevier.find.reviewers.generated.model.ScopusPublicationsResponse;
import com.elsevier.find.reviewers.testutils.TestBase;
import org.apache.logging.log4j.ThreadContext;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.data.jdbc.JdbcRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

@TestPropertySource(properties = {
        "personfinder.client.base.url=https://localhost/api/"
})
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, JdbcRepositoriesAutoConfiguration.class})
public class Scopus_getPublicationsTest extends TestBase {
    // Wire to the service that we want to test
    @Autowired
    private ScopusService scopusService;

    @MockBean(name = "personfinder")
    private WebClient webClient;

    @Test
    void testNoPublications() {
        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(webClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("{\"publications\":[]}"))
                .thenReturn(Mono.just("{}")).thenReturn(Mono.just(""));

        ResponseEntity<ScopusPublicationsResponse> response = scopusService.getPublications("123", null, null, null, null, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(0, response.getBody().getPublications().size());

        response = scopusService.getPublications("123", null, null, KeywordSearchLogic.OR, 2020, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(0, response.getBody().getPublications().size());

        response = scopusService.getPublications("123", null, "k{e}yw<o>r\r\nds", KeywordSearchLogic.AND, null, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(0, response.getBody().getPublications().size());
    }

    @Test
    void testInvalidInput() {
        assertThrows(InternalException.class, () -> scopusService.getPublications(null, null, null, null, null, null));
        assertThrows(InternalException.class, () -> scopusService.getPublications("", null, null, null, null, null));
    }

    @Test
    void testPublicationHttpError() {
        final WebClient.RequestBodyUriSpec bodyUriSpecMock = Mockito.mock(WebClient.RequestBodyUriSpec.class);
        final WebClient.RequestBodySpec bodySpecMock = Mockito.mock(WebClient.RequestBodySpec.class);
        final WebClient.RequestHeadersSpec headersSpecMock = Mockito.mock(WebClient.RequestHeadersSpec.class);
        final WebClient.ResponseSpec responseSpecMock = Mockito.mock(WebClient.ResponseSpec.class);
        Mockito.when(webClient.post()).thenReturn(bodyUriSpecMock);
        Mockito.when(bodyUriSpecMock.uri(Mockito.anyString())).thenReturn(bodySpecMock);
        Mockito.when(bodySpecMock.header(Mockito.anyString(), Mockito.anyString())).thenReturn(bodySpecMock);
        Mockito.when(bodySpecMock.accept(Mockito.notNull())).thenReturn(bodySpecMock);
        Mockito.when(bodySpecMock.contentType(Mockito.notNull())).thenReturn(bodySpecMock);
        Mockito.when(bodySpecMock.bodyValue(Mockito.anyString())).thenReturn(headersSpecMock);
        Mockito.when(headersSpecMock.retrieve()).thenThrow(new WebClientResponseException(404, "Not Found", null, null, null))
                .thenThrow(new WebClientResponseException(500, "Internal Error", null, null, null))
                .thenThrow(new RuntimeException());

        // First HTTP exception is not-found that will just be handled normally with no publications
        ResponseEntity<ScopusPublicationsResponse> response = scopusService.getPublications("123", null, "", null, null, null);
        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(0, response.getBody().getPublications().size());

        InternalException e = assertThrows(InternalException.class, () -> scopusService.getPublications("123", null, null, null, null, null));
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getHttpStatus(), "Invalid status");
        assertEquals(ErrorResponse.IdEnum.PERSONFINDERFAILURE, e.toErrorResponse().getId(), "Invalid error Id");

        e = assertThrows(InternalException.class, () -> scopusService.getPublications("123", null, null, null, null, null));
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getHttpStatus(), "Invalid status");
        assertEquals(ErrorResponse.IdEnum.PERSONFINDERFAILURE, e.toErrorResponse().getId(), "Invalid error Id");
    }

    @Test
    void testMessageProcessingError() {
        ThreadContext.put("correlationId", "1234-5678");

        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(webClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("{ invalid json }"));

        InternalException e = assertThrows(InternalException.class, () -> scopusService.getPublications("123", null, null, null, null, null));
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getHttpStatus(), "Invalid status");
        assertEquals(ErrorResponse.IdEnum.PERSONFINDERFAILURE, e.toErrorResponse().getId(), "Invalid error Id");
    }

    @Test
    void testSinglePublications() {
        final String publication = "{\"authspan\": \"Flintstone, F.\", \"eid\": \"2-s2.0-00000000036\", " +
                "\"authid\": \"0000004700\", \"srctitle\": \"Journal Title\", \"pubyr\": \"2021\", " +
                "\"itemtitle\": \"Test Manuscript\",\"numcitedby\": 90}";

        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(webClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("{\"publications\":[" + publication + "]}"));

        ResponseEntity<ScopusPublicationsResponse> response = scopusService.getPublications("123", null, "KeyWo#rd R&D", KeywordSearchLogic.OR, null, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(1, response.getBody().getPublications().size());
        assertEquals("2-s2.0-00000000036", response.getBody().getPublications().get(0).getEid());
        assertEquals("Test Manuscript", response.getBody().getPublications().get(0).getTitle());
        assertEquals("Journal Title", response.getBody().getPublications().get(0).getJournalTitle());
        assertEquals(2021, response.getBody().getPublications().get(0).getYear());
        assertEquals(90, response.getBody().getPublications().get(0).getCitationCount());
        assertEquals(1, response.getBody().getPublications().get(0).getAuthors().size());
        assertEquals("Flintstone, F.", response.getBody().getPublications().get(0).getAuthors().get(0).getName());
        assertEquals("0000004700", response.getBody().getPublications().get(0).getAuthors().get(0).getId());
    }

    @Test
    void testMultiplePublications() {
        final String publication1 = "{\"authspan\": \"Flintstone, F. | Rubble, B.\", \"eid\": \"2-s2.0-00000000036\", " +
                "\"authid\": \"0000004700\", \"srctitle\": \"Journal Title\", \"pubyr\": \"2021\", " +
                "\"itemtitle\": \"Test Manuscript\",\"numcitedby\": 10}";

        final String publication2 = "{\"authspan\": \"Flintstone, W. | Rubble, B.\", \"eid\": \"3-s2.0-00000000055\", " +
                "\"authid\": \"0000004800 | 1234567\", \"srctitle\": \"Journal Title 2\", \"pubyr\": \"Invalid\", " +
                "\"itemtitle\": \"Test Manuscript 2\",\"numcitedby\": 20}";

        final String publication3 = "{\"eid\": \"4-s2.0-00000000066\", \"srctitle\": \"Journal Title 3\", " +
                "\"itemtitle\": \"Test Manuscript 3\",\"numcitedby\": 30}";

        final String publication4 = "{\"eid\": \"More than limit - will not be returned\"}";

        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(webClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just(
                "{\"publications\":[" + publication1 + "," + publication2 + "," + publication3 + "," + publication4 + "]}"));

        ResponseEntity<ScopusPublicationsResponse> response = scopusService.getPublications("123", null, null, null, null, 3);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(3, response.getBody().getPublications().size());
        assertEquals("2-s2.0-00000000036", response.getBody().getPublications().get(0).getEid());
        assertEquals("Test Manuscript", response.getBody().getPublications().get(0).getTitle());
        assertEquals("Journal Title", response.getBody().getPublications().get(0).getJournalTitle());
        assertEquals(2021, response.getBody().getPublications().get(0).getYear());
        assertEquals(10, response.getBody().getPublications().get(0).getCitationCount());
        assertEquals(2, response.getBody().getPublications().get(0).getAuthors().size());
        assertEquals("Flintstone, F.", response.getBody().getPublications().get(0).getAuthors().get(0).getName());
        assertEquals("0000004700", response.getBody().getPublications().get(0).getAuthors().get(0).getId());
        assertEquals("Rubble, B.", response.getBody().getPublications().get(0).getAuthors().get(1).getName());
        assertNull(response.getBody().getPublications().get(0).getAuthors().get(1).getId());

        assertEquals("3-s2.0-00000000055", response.getBody().getPublications().get(1).getEid());
        assertEquals("Test Manuscript 2", response.getBody().getPublications().get(1).getTitle());
        assertEquals("Journal Title 2", response.getBody().getPublications().get(1).getJournalTitle());
        assertNull(response.getBody().getPublications().get(1).getYear());
        assertEquals(20, response.getBody().getPublications().get(1).getCitationCount());
        assertEquals(2, response.getBody().getPublications().get(1).getAuthors().size());
        assertEquals("Flintstone, W.", response.getBody().getPublications().get(1).getAuthors().get(0).getName());
        assertEquals("0000004800", response.getBody().getPublications().get(1).getAuthors().get(0).getId());
        assertEquals("Rubble, B.", response.getBody().getPublications().get(1).getAuthors().get(1).getName());
        assertEquals("1234567", response.getBody().getPublications().get(1).getAuthors().get(1).getId());

        assertEquals("4-s2.0-00000000066", response.getBody().getPublications().get(2).getEid());
        assertEquals("Test Manuscript 3", response.getBody().getPublications().get(2).getTitle());
        assertEquals("Journal Title 3", response.getBody().getPublications().get(2).getJournalTitle());
        assertNull(response.getBody().getPublications().get(2).getYear());
        assertEquals(30, response.getBody().getPublications().get(2).getCitationCount());
        assertNull(response.getBody().getPublications().get(2).getAuthors());

        response = scopusService.getPublications("123", null, null, null, null, 5);
        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(4, response.getBody().getPublications().size());
    }
}
