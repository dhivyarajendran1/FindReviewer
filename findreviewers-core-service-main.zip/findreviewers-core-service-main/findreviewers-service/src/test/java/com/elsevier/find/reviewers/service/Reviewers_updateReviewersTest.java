package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.enums.ProductType;
import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.exception.RetryableException;
import com.elsevier.find.reviewers.external.EditorialManager;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.generated.model.ReviewerStatus;
import com.elsevier.find.reviewers.generated.model.ReviewersRequest;
import com.elsevier.find.reviewers.generated.model.ReviewersRequestItem;
import com.elsevier.find.reviewers.testutils.TestBase;
import com.elsevier.find.reviewers.utils.CookieManager.SessionData;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.data.jdbc.JdbcRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, JdbcRepositoriesAutoConfiguration.class})
public class Reviewers_updateReviewersTest extends TestBase {
    // Wire to the service that we want to test
    @Autowired
    private ReviewersService reviewersService;

    @MockBean(name = "httpClient")
    private HttpClient mockHttpClient;

    @Captor
    private ArgumentCaptor<HttpRequest> requestCaptor;

    @BeforeEach
    void setup() {
        SessionContext.initialize(new SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", false, true));
    }

    @AfterEach
    void tearDown() {
        SessionContext.destroy();
    }

    @Test
    void testUpdateReviewerSuccess() throws IOException, InterruptedException {
        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(200);
        Mockito.when(mockTokenResponse.body()).thenReturn("{\"message\": \"some response message\"}");

        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        ReviewersRequest body = new ReviewersRequest();
        ReviewersRequestItem reviewer = new ReviewersRequestItem();
        reviewer.addEmailsItem("fred@bedrock.com");
        body.addReviewersItem(reviewer);
        ResponseEntity<Void> response = reviewersService.updateReviewers(null, "ACR", 12L, body);

        Mockito.verify(mockHttpClient, Mockito.times(1)).send(requestCaptor.capture(),
                Mockito.any(HttpResponse.BodyHandler.class));
        assertTrue(requestCaptor.getValue().uri().toString().endsWith("/journals/ACR/document/12/reviewers"), "Incorrect URL");
        assertEquals("POST", requestCaptor.getValue().method());
        assertEquals("{\"reviewers\":[{\"status\":\"selected\",\"journal-code\":\"ACR\",\"email-addresses\":[\"fred@bedrock.com\"]}]}",
                getHttpRequestBody(requestCaptor));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNull(response.getBody(), "Not null body");
    }

    @Test
    void testUpdateReviewerAllDataSuccess() throws IOException, InterruptedException {
        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(201);
        Mockito.when(mockTokenResponse.body()).thenReturn("{\"message\": \"some response message\"}");

        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        ReviewersRequest body = new ReviewersRequest();
        ReviewersRequestItem reviewer = new ReviewersRequestItem();
        reviewer.setStatus(ReviewerStatus.INVITED);
        reviewer.addEmailsItem("fred@bedrock.com");
        reviewer.addEmailsItem("fredflintstone@bedrock.com");
        reviewer.setFirstName("Fred");
        reviewer.setLastName("Flintstone");
        reviewer.setAffiliation("Bedrock Uni");
        reviewer.setKeywords(List.of("Dino", "Wilma", "Stones", "Rocks", "Barney", "Betty", "7", "8", "9", "10", "More-than-10"));
        reviewer.addScopusIdsItem("12345");
        body.addReviewersItem(reviewer);
        ResponseEntity<Void> response = reviewersService.updateReviewers(null, "ACR", 12L, body);

        Mockito.verify(mockHttpClient, Mockito.times(1)).send(requestCaptor.capture(),
                Mockito.any(HttpResponse.BodyHandler.class));
        assertTrue(requestCaptor.getValue().uri().toString().endsWith("/journals/ACR/document/12/reviewers"), "Incorrect URL");
        assertEquals("POST", requestCaptor.getValue().method());
        assertEquals("{\"reviewers\":[{\"status\":\"invited\",\"journal-code\":\"ACR\",\"given-name\":\"Fred\",\"family-name\":\"Flintstone\",\"address\":{\"affiliation\":\"Bedrock Uni\"},\"email-addresses\":[\"fred@bedrock.com\",\"fredflintstone@bedrock.com\"],\"identifiers\":[{\"system\":\"scopus\",\"identifier\":\"12345\",\"url\":\"https://www.scopus.com/authid/detail.uri?authorId=12345\"}],\"keywords\":[\"Dino\",\"Wilma\",\"Stones\",\"Rocks\",\"Barney\",\"Betty\",\"7\",\"8\",\"9\",\"10\"]}]}",
                getHttpRequestBody(requestCaptor));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNull(response.getBody(), "Not null body");
    }

    @Test
    void testUpdateReviewerAllDataSuccess2() throws IOException, InterruptedException {
        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(201);
        Mockito.when(mockTokenResponse.body()).thenReturn("{\"message\": \"some response message\"}");

        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        ReviewersRequest body = new ReviewersRequest();
        ReviewersRequestItem reviewer = new ReviewersRequestItem();
        reviewer.setStatus(ReviewerStatus.INVITED);
        reviewer.addEmailsItem("fred@bedrock.com");
        reviewer.addEmailsItem("fredflintstone@bedrock.com");
        reviewer.setFirstName("Fred");
        reviewer.setLastName("Flintstone");
        reviewer.setAffiliation("Bedrock Uni");
        reviewer.setKeywords(List.of("Dino", "Wilma", "Stones", "Rocks", "Barney", "Betty", "7", "8", "9", "10", "More-than-10"));
        reviewer.addScopusIdsItem("12345");
        body.addReviewersItem(reviewer);
        ResponseEntity<Void> response = reviewersService.updateReviewers(null, "ACR", 12L, body);

        Mockito.verify(mockHttpClient, Mockito.times(1)).send(requestCaptor.capture(),
                Mockito.any(HttpResponse.BodyHandler.class));
        assertTrue(requestCaptor.getValue().uri().toString().endsWith("/journals/ACR/document/12/reviewers"), "Incorrect URL");
        assertEquals("POST", requestCaptor.getValue().method());
        assertEquals("{\"reviewers\":[{\"status\":\"invited\",\"journal-code\":\"ACR\",\"given-name\":\"Fred\",\"family-name\":\"Flintstone\",\"address\":{\"affiliation\":\"Bedrock Uni\"},\"email-addresses\":[\"fred@bedrock.com\",\"fredflintstone@bedrock.com\"],\"identifiers\":[{\"system\":\"scopus\",\"identifier\":\"12345\",\"url\":\"https://www.scopus.com/authid/detail.uri?authorId=12345\"}],\"keywords\":[\"Dino\",\"Wilma\",\"Stones\",\"Rocks\",\"Barney\",\"Betty\",\"7\",\"8\",\"9\",\"10\"]}]}",
                getHttpRequestBody(requestCaptor));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNull(response.getBody(), "Not null body");
    }

    @Test
    void testInvalidArguments() {
        assertThrows(InternalException.class, () -> reviewersService.updateReviewers(null, "ACR", 12L, null));

        ReviewersRequest body = new ReviewersRequest();
        assertThrows(InternalException.class, () -> reviewersService.updateReviewers(null, "ACR", 12L, body));

        body.setReviewers(new ArrayList<>());
        assertThrows(InternalException.class, () -> reviewersService.updateReviewers(null, "ACR", 12L, body));

        body.getReviewers().add(new ReviewersRequestItem());
        assertThrows(InternalException.class, () -> reviewersService.updateReviewers(null, null, 12L, body));
        assertThrows(InternalException.class, () -> reviewersService.updateReviewers(null, "", 12L, body));
        assertThrows(InternalException.class, () -> reviewersService.updateReviewers(null, "ACR", null, body));
    }

    @Test
    void testReadOnlySession() {
        SessionContext.destroy();
        SessionContext.initialize(new SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", true, true));

        ReviewersRequest body = new ReviewersRequest();
        body.addReviewersItem(new ReviewersRequestItem());
        ResponseEntity<Void> response = reviewersService.updateReviewers(null, "ACR", 12L, body);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());
        assertNull(response.getBody(), "Not null body");
    }

    @Test
    void testEmApiValue() {
        EditorialManager testReviewerAuthService = new EditorialManager(null, mockHttpClient, null, null, "http://api.em.com", "http://api.em.com/redirect");
        assertNotNull(testReviewerAuthService, "EM API not processed");
        testReviewerAuthService = new EditorialManager(null, mockHttpClient, null, null, "http://api.mydomain.com/", "http://api.em.com/redirect");
        assertNotNull(testReviewerAuthService, "EM API not processed");
    }

    @Test
    void testUpdateReviewerFailure() throws IOException, InterruptedException {
        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(400).thenReturn(401);
        Mockito.when(mockTokenResponse.body()).thenReturn("{\"message\": \"some response message\"}");

        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        ReviewersRequest body = new ReviewersRequest();
        ReviewersRequestItem reviewer = new ReviewersRequestItem();
        reviewer.setStatus(ReviewerStatus.ALTERNATE);
        reviewer.addEmailsItem("fred@bedrock.com");
        reviewer.setAffiliation("");
        reviewer.setScopusIds(new ArrayList<>());
        body.addReviewersItem(reviewer);
        assertThrows(InternalException.class, () -> reviewersService.updateReviewers(null, "ACR", 12L, body));

        assertThrows(InternalException.class, () -> reviewersService.updateReviewers(null, "ACR", 12L, body));
    }

    @Test
    void testUpdateReviewerHttpError() throws IOException, InterruptedException {
        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenThrow(new IOException()).thenThrow(new IOException()).thenThrow(new InterruptedException());

        ReviewersRequest body = new ReviewersRequest();
        ReviewersRequestItem reviewer = new ReviewersRequestItem();
        reviewer.setStatus(ReviewerStatus.PROPOSED);
        reviewer.addEmailsItem("fred@bedrock.com");
        reviewer.addScopusIdsItem("12345");
        reviewer.addScopusIdsItem("67890");
        body.addReviewersItem(reviewer);
        assertThrows(InternalException.class, () -> reviewersService.updateReviewers(null, "ACR", 12L, body));

        new RetryableException(null, null);
        new RetryableException(new Exception(), null).logWarn();
        new RetryableException(new Exception(""), null).logError();
    }

    /**
     * Test the case where the Json conversion fails
     */
    @Test
    void testJsonException() throws JsonProcessingException {
        Object editorialManagerClass = ReflectionTestUtils.getField(reviewersService, "editorialManager");
        Object originalObjectMapper = ReflectionTestUtils.getField(editorialManagerClass, "objectMapper");

        ObjectMapper objectMapper = Mockito.mock(ObjectMapper.class);
        ReflectionTestUtils.setField(editorialManagerClass, "objectMapper", objectMapper);

        Mockito.when(objectMapper.writeValueAsString(Mockito.any())).
                thenThrow(new JsonProcessingException("Test Exception") {
                });

        ReviewersRequest body = new ReviewersRequest();
        ReviewersRequestItem reviewer = new ReviewersRequestItem();
        reviewer.setStatus(ReviewerStatus.ASSIGNED);
        reviewer.addEmailsItem("fred@bedrock.com");
        body.addReviewersItem(reviewer);
        assertThrows(InternalException.class, () -> reviewersService.updateReviewers(null, "ACR", 12L, body));

        ReflectionTestUtils.setField(editorialManagerClass, "objectMapper", originalObjectMapper);
    }
}
