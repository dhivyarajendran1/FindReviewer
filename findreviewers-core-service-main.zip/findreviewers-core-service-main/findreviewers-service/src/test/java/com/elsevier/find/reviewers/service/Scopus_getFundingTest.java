package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.enums.ProductType;
import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.generated.model.FundingResponse;
import com.elsevier.find.reviewers.testutils.TestBase;
import com.elsevier.find.reviewers.utils.CookieManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.data.jdbc.JdbcRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, JdbcRepositoriesAutoConfiguration.class})
public class Scopus_getFundingTest extends TestBase {
    @Autowired
    private ScopusService scopusService;

    @MockBean(name = "scopussharedsearch")
    private WebClient sharedSearchWebClient;

    @BeforeEach
    void setup() {
        SessionContext.initialize(new CookieManager.SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", true, true));
    }

    @Test
    void testInvalidInput() {
        assertThrows(InternalException.class, () -> scopusService.getFunding(null, null));
        assertThrows(InternalException.class, () -> scopusService.getFunding("", null));
    }

    @Test
    void testNoData() {
        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(sharedSearchWebClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just(""))
                .thenReturn(Mono.just("{}"))
                .thenReturn(Mono.just("{\"hits\": []}"))
                .thenThrow(new WebClientResponseException(404, "Not Found", null, null, null));

        for (int i = 0; i < 4; i++) {
            ResponseEntity<FundingResponse> response = scopusService.getFunding("000000800", null);

            assertNotNull(response, "Null Response");
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertNotNull(response.getBody(), "Null body");
            assertNull(response.getBody().getFundingAwards());
        }
    }

    @Test
    void testError() {
        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(sharedSearchWebClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just("{ Invalid JSON }"));

        InternalException e = assertThrows(InternalException.class, () -> scopusService.getFunding("123", null));
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getHttpStatus(), "Invalid status");
        assertEquals(ErrorResponse.IdEnum.SCOPUSSHAREDSEARCHFAILURE, e.toErrorResponse().getId(), "Invalid error Id");
    }

    @Test
    void testAwardDetails() {
        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(sharedSearchWebClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just("""
                        { "hits": [
                        {
                            "grantAwardId": 1000010483320,
                            "startDate": "2012-01-01T00:00:00",
                            "endDate": "2023-11-30T12:11:00",
                            "title": [{"language": "en", "value": null},
                                      {"language": "en", "value": ""},
                                      {"language": "de", "value": "Not English"},
                                       {"language": "en", "value": "Award Title"}],
                            "funderName": "Funder Name",
                            "synopsis": [{"abstract": {"language": "en", "value": null}},
                                         {"abstract": {"language": "en","value": ""}},
                                         {"abstract": {"language": "de","value": "Not English"}},
                                         {"abstract": {"language": "en","value": "The abstract description"}},
                                         {"abstract": {"language": "fr","value": "Still Not English"}}],
                            "awardeeDetail": [
                                {
                                    "affiliationOf": [
                                        {
                                            "identifier": [{"type": "SCOPUSAUTHORID","value": "7005078007"}],
                                            "fundingBodyPersonId": "1872615",
                                            "role": "PI",
                                            "givenName": "Barney",
                                            "familyName": "Rubble"
                                        },
                                        {
                                            "identifier": [{"type": "A","value": "1"},
                                                           {"type": "SCOPUSAUTHORID","value": ""},
                                                           {"type": "SCOPUSAUTHORID","value": null},
                                                           {"type": "SCOPUSAUTHORID","value": "56822340200"}],
                                            "fundingBodyPersonId": "1995639",
                                            "role": "COPI",
                                            "givenName": "Fred",
                                            "familyName": "Flintstone",
                                            "name": [{"language": "en","value": "F. Flintstone"}]
                                        }
                                    ]
                                }
                            ]
                        }
                        ]}
                        """));

        ResponseEntity<FundingResponse> response = scopusService.getFunding("000000800", null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertNotNull(response.getBody().getFundingAwards());
        assertEquals(1, response.getBody().getFundingAwards().size());
        assertEquals("1000010483320", response.getBody().getFundingAwards().get(0).getAwardId());
        assertEquals("Award Title", response.getBody().getFundingAwards().get(0).getTitle());
        assertEquals("Funder Name", response.getBody().getFundingAwards().get(0).getFunderName());
        assertEquals("The abstract description", response.getBody().getFundingAwards().get(0).getAbstract());
        assertEquals(1325376000000L, response.getBody().getFundingAwards().get(0).getStartDate());
        assertEquals(1701303060000L, response.getBody().getFundingAwards().get(0).getEndDate());
        assertEquals(2, response.getBody().getFundingAwards().get(0).getAwardees().size());
        assertEquals("7005078007", response.getBody().getFundingAwards().get(0).getAwardees().get(0).getId());
        assertEquals("Barney Rubble", response.getBody().getFundingAwards().get(0).getAwardees().get(0).getName());
        assertEquals("56822340200", response.getBody().getFundingAwards().get(0).getAwardees().get(1).getId());
        assertEquals("F. Flintstone", response.getBody().getFundingAwards().get(0).getAwardees().get(1).getName());
    }

    @Test
    void testMultipleAwardDetails() {
        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(sharedSearchWebClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just("""
                        { "hits": [
                        {
                            "grantAwardId": 1000010483320,
                            "funderName": "Funder Name"
                        },
                        {
                            "grantAwardId": 1000010483321,
                            "startDate": "2012-01-01T00:00:00",
                            "endDate": "2023-11-30T12:11:00",
                            "title": [{"value": "Award Title"}],
                            "funderName": "Funder Name 2",
                            "synopsis": [{"abstract": {"value": "The abstract description"}}],
                            "awardeeDetail": [
                                {
                                    "affiliationOf": null
                                },
                                {
                                    "affiliationOf": [
                                        {
                                            "fundingBodyPersonId": "1995639",
                                            "role": "COPI",
                                            "familyName": "Flintstone",
                                            "name": [{"language": "en"}]
                                        },
                                        {
                                            "identifier": [{"type": "SCOPUSAUTHORID","value": "7005078007"}],
                                            "fundingBodyPersonId": "1872615",
                                            "role": "COPI",
                                            "givenName": "Barney",
                                            "name": [{"language": "en","value": ""}]
                                        }
                                    ]
                                },
                                {
                                    "affiliationOf": [
                                        {
                                            "identifier": [{"type": "SCOPUSAUTHORID","value": "8005078007"}],
                                            "role": "PI",
                                            "name": [{"language": "en","value": "Wilma Flintstone"}]
                                        },
                                        {
                                            "identifier": [{"type": "SCOPUSAUTHORID","value": "7005078007"}],
                                            "fundingBodyPersonId": "1872615",
                                            "role": "COPI",
                                            "givenName": "Barney",
                                            "name": [{"language": "en","value": ""}]
                                        }
                                    ]
                                },
                                {
                                    "affiliationOf": [
                                        {
                                            "identifier": [{"type": "SCOPUSAUTHORID","value": "7005078007"}],
                                            "role": "COPI",
                                            "givenName": "Duplicate on Scopus"
                                        },
                                        {
                                            "role": "COPI",
                                            "name": [{"language": "Duplicate on name", "value": "Wilma Flintstone"}]
                                        }
                                    ]
                                }
                            ]
                        }
                        ]}
                        """));

        ResponseEntity<FundingResponse> response = scopusService.getFunding("000000800", null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertNotNull(response.getBody().getFundingAwards());
        assertEquals(2, response.getBody().getFundingAwards().size());
        assertEquals("1000010483320", response.getBody().getFundingAwards().get(0).getAwardId());
        assertNull(response.getBody().getFundingAwards().get(0).getTitle());
        assertEquals("Funder Name", response.getBody().getFundingAwards().get(0).getFunderName());
        assertNull(response.getBody().getFundingAwards().get(0).getAbstract());
        assertNull(response.getBody().getFundingAwards().get(0).getStartDate());
        assertNull(response.getBody().getFundingAwards().get(0).getEndDate());
        assertEquals(0, response.getBody().getFundingAwards().get(0).getAwardees().size());

        assertEquals("1000010483321", response.getBody().getFundingAwards().get(1).getAwardId());
        assertEquals("Award Title", response.getBody().getFundingAwards().get(1).getTitle());
        assertEquals("Funder Name 2", response.getBody().getFundingAwards().get(1).getFunderName());
        assertEquals("The abstract description", response.getBody().getFundingAwards().get(1).getAbstract());
        assertEquals(1325376000000L, response.getBody().getFundingAwards().get(1).getStartDate());
        assertEquals(1701303060000L, response.getBody().getFundingAwards().get(1).getEndDate());
        assertEquals(3, response.getBody().getFundingAwards().get(1).getAwardees().size());
        assertEquals("8005078007", response.getBody().getFundingAwards().get(1).getAwardees().get(0).getId());
        assertEquals("Wilma Flintstone", response.getBody().getFundingAwards().get(1).getAwardees().get(0).getName());
        assertNull(response.getBody().getFundingAwards().get(1).getAwardees().get(1).getId());
        assertEquals("Flintstone", response.getBody().getFundingAwards().get(1).getAwardees().get(1).getName());
        assertEquals("7005078007", response.getBody().getFundingAwards().get(1).getAwardees().get(2).getId());
        assertEquals("Barney", response.getBody().getFundingAwards().get(1).getAwardees().get(2).getName());
    }
}
