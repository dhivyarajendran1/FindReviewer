package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.enums.ProductType;
import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.testutils.JdbcMockAnswer;
import com.elsevier.find.reviewers.testutils.TestBase;
import com.elsevier.find.reviewers.utils.CookieManager.SessionData;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.data.jdbc.JdbcRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.test.context.TestPropertySource;

import java.io.IOException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.sql.SQLException;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@TestPropertySource(properties = {
        "reviewerhub.client.base.url=https://localhost/api/"
})
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, JdbcRepositoriesAutoConfiguration.class})
public class Reviewers_deleteReviewersTest extends TestBase {
    // Wire to the service that we want to test
    @Autowired
    private ReviewersService reviewersService;

    @MockBean(name = "httpClient")
    private HttpClient mockHttpClient;

    @Captor
    private ArgumentCaptor<HttpRequest> requestCaptor;

    @BeforeEach
    void setup() {
        SessionContext.initialize(new SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", false, true));
    }

    @AfterEach
    void tearDown() {
        SessionContext.destroy();
    }

    @Test
    void testDeleteReviewerSuccess() throws IOException, InterruptedException, SQLException {
        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(Map.of("id", 123L));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(RowMapper.class))).thenAnswer(mockAnswer);

        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(200).thenReturn(204);
        Mockito.when(mockTokenResponse.body()).thenReturn("{\"message\": \"some response message\"}");

        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        ResponseEntity<Void> response = reviewersService.deleteReviewers("ACR", 12L, List.of("fred@bedrock.com"), null);

        Mockito.verify(mockHttpClient, Mockito.times(1)).send(requestCaptor.capture(),
                Mockito.any(HttpResponse.BodyHandler.class));
        assertTrue(requestCaptor.getValue().uri().toString().endsWith("/crowdsourcedReviews/123"), "Incorrect URL");
        assertEquals("DELETE", requestCaptor.getValue().method());

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNull(response.getBody(), "Not null body");
    }

    @Test
    void testDeleteMultipleReviewerSuccess() throws IOException, InterruptedException, SQLException {
        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(Map.of("id", 123L));
        mockAnswer.addResultMapping(Map.of("id", 456L));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(RowMapper.class))).thenAnswer(mockAnswer);

        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(200).thenReturn(204);
        Mockito.when(mockTokenResponse.body()).thenReturn("{\"message\": \"some response message\"}");

        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        ResponseEntity<Void> response = reviewersService.deleteReviewers("ACR", 12L, List.of("fred@bedrock.com", "wilma@bedrock.com"), null);

        Mockito.verify(mockHttpClient, Mockito.times(2)).send(requestCaptor.capture(),
                Mockito.any(HttpResponse.BodyHandler.class));
        assertTrue(requestCaptor.getAllValues().get(0).uri().toString().endsWith("/crowdsourcedReviews/123"), "Incorrect URL");
        assertTrue(requestCaptor.getAllValues().get(1).uri().toString().endsWith("/crowdsourcedReviews/456"), "Incorrect URL");
        assertEquals("DELETE", requestCaptor.getAllValues().get(0).method());
        assertEquals("DELETE", requestCaptor.getAllValues().get(1).method());

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNull(response.getBody(), "Not null body");
    }

    @Test
    void testInvalidInput() {
        assertThrows(InternalException.class, () -> reviewersService.deleteReviewers(null, null, null, null));
        assertThrows(InternalException.class, () -> reviewersService.deleteReviewers("", 1L, List.of("email1"), null));
        assertThrows(InternalException.class, () -> reviewersService.deleteReviewers("ACR", null, List.of("email1"), null));
        assertThrows(InternalException.class, () -> reviewersService.deleteReviewers("ACR", 1L, null, null));
        assertThrows(InternalException.class, () -> reviewersService.deleteReviewers("ACR", 1L, Collections.emptyList(), null));
    }

    @Test
    void testDeleteReviewerFailed() throws IOException, InterruptedException, SQLException {
        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(Map.of("id", 123L));

        JdbcMockAnswer mockAnswer2 = new JdbcMockAnswer();
        mockAnswer2.addResultMapping(Map.of("id", 123L));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(RowMapper.class))).thenAnswer(mockAnswer).thenAnswer(mockAnswer2);

        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(500);
        Mockito.when(mockTokenResponse.body()).thenReturn("{\"message\": \"some response message\"}");

        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse).thenThrow(new InterruptedException());

        InternalException e = assertThrows(InternalException.class, () ->
                reviewersService.deleteReviewers("ACR", 12L, List.of("fred@bedrock.com"), null));
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getHttpStatus(), "Invalid status");
        assertEquals(ErrorResponse.IdEnum.REVIEWERHUBFAILURE, e.toErrorResponse().getId(), "Invalid error Id");

        Mockito.verify(mockHttpClient, Mockito.times(1)).send(requestCaptor.capture(),
                Mockito.any(HttpResponse.BodyHandler.class));
        assertTrue(requestCaptor.getValue().uri().toString().endsWith("/crowdsourcedReviews/123"), "Incorrect URL");
        assertEquals("DELETE", requestCaptor.getValue().method());

        e = assertThrows(InternalException.class, () ->
                reviewersService.deleteReviewers("ACR", 12L, List.of("fred@bedrock.com"), null));
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getHttpStatus(), "Invalid status for interrupt exception");
        assertEquals(ErrorResponse.IdEnum.REVIEWERHUBFAILURE, e.toErrorResponse().getId(), "Invalid error Id");
    }
}
