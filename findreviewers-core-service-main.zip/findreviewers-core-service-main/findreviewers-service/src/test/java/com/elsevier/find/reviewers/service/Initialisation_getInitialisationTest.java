package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.dao.ManuscriptDao;
import com.elsevier.find.reviewers.dao.impl.AdditionalInfoDaoImpl.InitialisationInfoResultsExtractor;
import com.elsevier.find.reviewers.dao.impl.ManuscriptDaoImpl.InitialisationResultsExtractor;
import com.elsevier.find.reviewers.enums.ProductType;
import com.elsevier.find.reviewers.enums.ReviewerStatusType;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.generated.model.InitialisationDetails;
import com.elsevier.find.reviewers.generated.model.ReviewerStatus;
import com.elsevier.find.reviewers.testutils.JdbcMockAnswer;
import com.elsevier.find.reviewers.testutils.TestBase;
import com.elsevier.find.reviewers.utils.CookieManager.SessionData;
import org.apache.logging.log4j.ThreadContext;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.data.jdbc.JdbcRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.sql.SQLException;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@TestPropertySource(properties = {
        "logging.level.com.elsevier.find.reviewers=DEBUG"
})
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, JdbcRepositoriesAutoConfiguration.class})
public class Initialisation_getInitialisationTest extends TestBase {
    // Wire to the service that we want to test
    @Autowired
    private InitialisationService initialisationService;

    @MockBean(name = "httpClient")
    private HttpClient mockHttpClient;

    @Captor
    private ArgumentCaptor<HttpRequest> requestCaptor;

    @MockBean(name = "scopussharedsearch")
    private WebClient sharedSearchWebClient;

    @Autowired
    private ManuscriptDao manuscriptDao;

    @BeforeEach
    void setup() {
        ThreadContext.put("correlationId", "1234-5678");
        SessionContext.initialize(new SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", true, true));

    }

    @AfterEach
    void tearDown() {
        SessionContext.destroy();
    }

    @Test
    void testNoManuscript() throws SQLException {
        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(ResultSetExtractor.class))).thenAnswer(mockAnswer);

        ResponseEntity<InitialisationDetails> response = initialisationService.getInitialisation(null, "ACR", 123L);

        assertEquals("ACR", mockAnswer.getParameter("emJournalAcronym", String.class));
        assertEquals(123L, mockAnswer.getParameter("documentId", Long.class));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNull(response.getBody().getReviewers(), "Reviews not valid");
        assertTrue(response.getBody().isIsElsevier());
        assertEquals(List.of(InitialisationDetails.PermittedFeaturesEnum.ADDEDREVIEWERS,
                InitialisationDetails.PermittedFeaturesEnum.AUTHORSEARCH,
                InitialisationDetails.PermittedFeaturesEnum.KEYWORDSEARCH,
                InitialisationDetails.PermittedFeaturesEnum.SESSIONPREFERENCES,
                InitialisationDetails.PermittedFeaturesEnum.RECOMMENDATIONS,
                InitialisationDetails.PermittedFeaturesEnum.VOLUNTEERS,
                InitialisationDetails.PermittedFeaturesEnum.MANUSCRIPTDETAILS,
                InitialisationDetails.PermittedFeaturesEnum.REVIEWERHISTORY,
                InitialisationDetails.PermittedFeaturesEnum.REVIEWERLIMITS,
                InitialisationDetails.PermittedFeaturesEnum.JOURNALREVIEWERS), response.getBody().getPermittedFeatures());
        assertNull(response.getBody().getCrowdsourcedReviewers(), "Crowdsourced not valid");
        assertNull(response.getBody().getSuggestedReviewers(), "Suggested Reviewers not valid");
        assertNull(response.getBody().getOpposedReviewers(), "Opposed Reviewers not valid");
        assertNull(response.getBody().getJournalClassifications(), "Non Null Journal Classifications");
        assertNull(response.getBody().getJournalIssnl(), "Non Null ISSN");

        SessionContext.initialize(new SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", false, true));
        mockAnswer.addNullResultMap();
        response = initialisationService.getInitialisation(null, "ACR", 123L);
        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isIsElsevier());
        assertNull(response.getBody().getReviewers(), "Reviews not valid");
        assertEquals(List.of(InitialisationDetails.PermittedFeaturesEnum.ADDEDREVIEWERS,
                InitialisationDetails.PermittedFeaturesEnum.AUTHORSEARCH,
                InitialisationDetails.PermittedFeaturesEnum.KEYWORDSEARCH,
                InitialisationDetails.PermittedFeaturesEnum.SESSIONPREFERENCES,
                InitialisationDetails.PermittedFeaturesEnum.RECOMMENDATIONS,
                InitialisationDetails.PermittedFeaturesEnum.VOLUNTEERS,
                InitialisationDetails.PermittedFeaturesEnum.MANUSCRIPTDETAILS,
                InitialisationDetails.PermittedFeaturesEnum.REVIEWERHISTORY,
                InitialisationDetails.PermittedFeaturesEnum.REVIEWERLIMITS,
                InitialisationDetails.PermittedFeaturesEnum.JOURNALREVIEWERS), response.getBody().getPermittedFeatures());
        assertNull(response.getBody().getCrowdsourcedReviewers(), "Crowdsourced not valid");
        assertNull(response.getBody().getSuggestedReviewers(), "Suggested Reviewers not valid");
        assertNull(response.getBody().getOpposedReviewers(), "Opposed Reviewers not valid");
        assertNull(response.getBody().getJournalClassifications(), "Non Null Journal Classifications");
        assertNull(response.getBody().getJournalIssnl(), "Non Null ISSN");

        SessionContext.initializeIdentity(123L, "fred@bedrock.com", null, "Fred Flintstone", null);
        response = initialisationService.getInitialisation(null, "ACR", 123L);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isIsElsevier());
        assertNull(response.getBody().getReviewers(), "Reviews not valid");
        assertEquals(List.of(InitialisationDetails.PermittedFeaturesEnum.ADDEDREVIEWERS,
                InitialisationDetails.PermittedFeaturesEnum.AUTHORSEARCH,
                InitialisationDetails.PermittedFeaturesEnum.KEYWORDSEARCH,
                InitialisationDetails.PermittedFeaturesEnum.SESSIONPREFERENCES,
                InitialisationDetails.PermittedFeaturesEnum.RECOMMENDATIONS,
                InitialisationDetails.PermittedFeaturesEnum.VOLUNTEERS,
                InitialisationDetails.PermittedFeaturesEnum.MANUSCRIPTDETAILS,
                InitialisationDetails.PermittedFeaturesEnum.REVIEWERHISTORY,
                InitialisationDetails.PermittedFeaturesEnum.REVIEWERLIMITS,
                InitialisationDetails.PermittedFeaturesEnum.JOURNALREVIEWERS), response.getBody().getPermittedFeatures());
        assertNull(response.getBody().getCrowdsourcedReviewers(), "Crowdsourced not valid");
        assertNull(response.getBody().getSuggestedReviewers(), "Suggested Reviewers not valid");
        assertNull(response.getBody().getOpposedReviewers(), "Opposed Reviewers not valid");
        assertNull(response.getBody().getJournalClassifications(), "Non Null Journal Classifications");
        assertNull(response.getBody().getJournalIssnl(), "Non Null ISSN");
        SessionContext.destroy();
    }

    @Test
    void testDatabaseException() {
        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(ResultSetExtractor.class))).thenThrow(new DataAccessException("Test Exception") {
        });

        assertThrows(DataAccessException.class, () -> initialisationService.getInitialisation(null, "ACR", 1L));
    }

    @Test
    void testManuscriptEditorDataAndIssn() throws SQLException {
        JdbcMockAnswer mockAnswer1 = new JdbcMockAnswer();
        mockAnswer1.addResultMapping(Map.ofEntries());

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(InitialisationResultsExtractor.class))).thenAnswer(mockAnswer1);

        JdbcMockAnswer mockAnswer2 = new JdbcMockAnswer();
        mockAnswer2.addResultMapping(Map.of(
                "issn_l", "1234-5678",
                "classifications", "[]",
                "has_ebms", true,
                "crowdsourced_reviewers", "[{\"email\" : \"betty@bedrock.com\", \"scopusIds\" : [\"333222111\"]}]"));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(InitialisationInfoResultsExtractor.class))).thenAnswer(mockAnswer2);

        ResponseEntity<InitialisationDetails> response = initialisationService.getInitialisation(null, "ACR", 123L);

        assertEquals("ACR", mockAnswer1.getParameter("emJournalAcronym", String.class));
        assertEquals(123L, mockAnswer1.getParameter("documentId", Long.class));

        assertEquals("ACR", mockAnswer2.getParameter("emJournalAcronym", String.class));
        assertEquals(123L, mockAnswer2.getParameter("documentId", Long.class));
        assertEquals("editorialBoardMember", mockAnswer2.getParameter("classification", String.class));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertTrue(response.getBody().isIsElsevier());
        assertNull(response.getBody().getKeywords(), "Keywords not valid");
        assertNull(response.getBody().getClassifications(), "Classifications not valid");
        assertNull(response.getBody().getReviewers(), "Not Null reviewers");
        assertEquals(List.of(InitialisationDetails.PermittedFeaturesEnum.ADDEDREVIEWERS,
                InitialisationDetails.PermittedFeaturesEnum.AUTHORSEARCH,
                InitialisationDetails.PermittedFeaturesEnum.KEYWORDSEARCH,
                InitialisationDetails.PermittedFeaturesEnum.SESSIONPREFERENCES,
                InitialisationDetails.PermittedFeaturesEnum.RECOMMENDATIONS,
                InitialisationDetails.PermittedFeaturesEnum.VOLUNTEERS,
                InitialisationDetails.PermittedFeaturesEnum.MANUSCRIPTDETAILS,
                InitialisationDetails.PermittedFeaturesEnum.REVIEWERHISTORY,
                InitialisationDetails.PermittedFeaturesEnum.REVIEWERLIMITS,
                InitialisationDetails.PermittedFeaturesEnum.JOURNALREVIEWERS,
                InitialisationDetails.PermittedFeaturesEnum.EDITORIALBOARDMEMBERS), response.getBody().getPermittedFeatures());

        assertNotNull(response.getBody().getCrowdsourcedReviewers(), "Crowdsourced not valid");
        assertEquals(1, response.getBody().getCrowdsourcedReviewers().size());
        assertEquals("betty@bedrock.com", response.getBody().getCrowdsourcedReviewers().get(0).getEmail());
        assertEquals(1, response.getBody().getCrowdsourcedReviewers().get(0).getScopusIds().size());
        assertEquals("333222111", response.getBody().getCrowdsourcedReviewers().get(0).getScopusIds().get(0));

        assertNull(response.getBody().getSuggestedReviewers(), "Suggested Reviewers not valid");
        assertNull(response.getBody().getOpposedReviewers(), "Opposed Reviewers not valid");
        assertEquals("1234-5678", response.getBody().getJournalIssnl());
        assertNull(response.getBody().getJournalClassifications(), "Unexpected classifications");
    }

    @Test
    void testManuscriptDataEmptyEmailSingleJournalClassification() throws SQLException {
        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(Map.ofEntries(
                Map.entry("keywords", "[\"key\", \"w{o}rd\\\", \\\\two*\"]"),
                Map.entry("classifications", "[{\"code\": \"10.100\", \"description\": \"class1\"}]"),
                Map.entry("email", ""),
                Map.entry("has_references", false),
                Map.entry("suggested_reviewers", ""),
                Map.entry("opposed_reviewers", "not valid json")));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(InitialisationResultsExtractor.class))).thenAnswer(mockAnswer);

        JdbcMockAnswer mockAnswer2 = new JdbcMockAnswer();
        mockAnswer2.addResultMapping(Map.of(
                "issn_l", "1234-5678",
                "classifications", "[{\"code\": \"10\", \"description\": \"First Classification\"}]",
                "has_ebms", false,
                "crowdsourced_reviewers", "-null-"));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(InitialisationInfoResultsExtractor.class))).thenAnswer(mockAnswer2);

        ResponseEntity<InitialisationDetails> response = initialisationService.getInitialisation(null, "ACR", 123L);

        assertEquals("ACR", mockAnswer.getParameter("emJournalAcronym", String.class));
        assertEquals(123L, mockAnswer.getParameter("documentId", Long.class));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertTrue(response.getBody().isIsElsevier());
        assertEquals(List.of(InitialisationDetails.PermittedFeaturesEnum.ADDEDREVIEWERS,
                InitialisationDetails.PermittedFeaturesEnum.AUTHORSEARCH,
                InitialisationDetails.PermittedFeaturesEnum.KEYWORDSEARCH,
                InitialisationDetails.PermittedFeaturesEnum.SESSIONPREFERENCES,
                InitialisationDetails.PermittedFeaturesEnum.RECOMMENDATIONS,
                InitialisationDetails.PermittedFeaturesEnum.VOLUNTEERS,
                InitialisationDetails.PermittedFeaturesEnum.MANUSCRIPTDETAILS,
                InitialisationDetails.PermittedFeaturesEnum.REVIEWERHISTORY,
                InitialisationDetails.PermittedFeaturesEnum.REVIEWERLIMITS,
                InitialisationDetails.PermittedFeaturesEnum.JOURNALREVIEWERS), response.getBody().getPermittedFeatures());
        assertEquals(2, response.getBody().getKeywords().size());
        assertEquals("key", response.getBody().getKeywords().get(0));
        assertEquals("word, two", response.getBody().getKeywords().get(1));
        assertEquals(1, response.getBody().getClassifications().size());
        assertEquals("10.100", response.getBody().getClassifications().get(0).getCode());
        assertEquals("class1", response.getBody().getClassifications().get(0).getDescription());
        assertNull(response.getBody().getReviewers(), "Not Null reviewers");
        assertNull(response.getBody().getCrowdsourcedReviewers(), "Crowdsourced not valid");
        assertNull(response.getBody().getSuggestedReviewers(), "Suggested Reviewers not valid");
        assertNull(response.getBody().getOpposedReviewers(), "Opposed Reviewers not valid");
        assertEquals("1234-5678", response.getBody().getJournalIssnl());
        assertEquals(1, response.getBody().getJournalClassifications().size());
        assertEquals("10", response.getBody().getJournalClassifications().get(0).getCode());
        assertEquals("First Classification", response.getBody().getJournalClassifications().get(0).getDescription());
        assertNull(response.getBody().getJournalClassifications().get(0).getChildren(), "Unexpected children");
    }

    @Test
    void testManuscriptDataWithReviewers() throws SQLException {
        Map<String, Object> resultMapping1 = Map.ofEntries(
                Map.entry("review_udb_id", 1L),
                Map.entry("keywords", ""),
                Map.entry("classifications", ""),
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("first_name", "Fred"),
                Map.entry("last_name", "Flintstone"),
                Map.entry("scopus_id", "-null-"),
                Map.entry("workinprogress", false),
                Map.entry("has_references", false),
                Map.entry("corresponding_authors", "[{\"emails\" : [\"barney@bedrock.com\", \"b.rubble@bedrock.com\"], \"firstName\" : \"Barney\", \"lastName\" : \"Rubble\"}]"),
                Map.entry("co_authors", "[{\"emails\" : [\"wilma@bedrock.com\", \"w***a@bedrock.com\"], \"firstName\" : \"Wilma\", \"lastName\" : \"Flintstone\"}]"),
                Map.entry("suggested_reviewers", "[{\"emails\" : [\"barney@bedrock.com ; \"], \"firstName\" : \"Barney\", \"lastName\" : \"Rubble\"}]"),
                Map.entry("opposed_reviewers", "[{\"emails\" : [\"wilma@bedrock.com\"], \"firstName\" : \"Wilma\", \"lastName\" : \"Flintstone\"}, {\"emails\" : [\"betty@bedrock.com\"], \"firstName\" : \"Betty\", \"lastName\" : \"Rubble\"}]"));

        Map<String, Object> resultMapping2 = Map.ofEntries(
                Map.entry("review_udb_id", 2L),
                Map.entry("keywords", ""),
                Map.entry("classifications", ""),
                Map.entry("email", "wilma@bedrock.com"),
                Map.entry("first_name", "Wilma"),
                Map.entry("last_name", "Flintstone"),
                Map.entry("scopus_id", "123456"),
                Map.entry("workinprogress", true),
                Map.entry("has_references", false),
                Map.entry("corresponding_authors", "[{\"emails\" : [\"barney@bedrock.com\", \"b.rubble@bedrock.com\"], \"firstName\" : \"Barney\", \"lastName\" : \"Rubble\"}]"),
                Map.entry("co_authors", "[{\"emails\" : [\"wilma@bedrock.com\", \"w***a@bedrock.com\"], \"firstName\" : \"Wilma\", \"lastName\" : \"Flintstone\"}]"),
                Map.entry("suggested_reviewers", "[{\"emails\" : [\"barney@bedrock.com ; \"], \"firstName\" : \"Barney\", \"lastName\" : \"Rubble\"}]"),
                Map.entry("opposed_reviewers", "[{\"emails\" : [\"wilma@bedrock.com\"], \"firstName\" : \"Wilma\", \"lastName\" : \"Flintstone\"}, {\"emails\" : [\"betty@bedrock.com\"], \"firstName\" : \"Betty\", \"lastName\" : \"Rubble\"}]"));

        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(resultMapping1, resultMapping2);

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(InitialisationResultsExtractor.class))).thenAnswer(mockAnswer);

        JdbcMockAnswer mockAnswer2 = new JdbcMockAnswer();
        mockAnswer2.addResultMapping(Map.of(
                "issn_l", "-null-",
                "classifications", "Invalid Json",
                "has_ebms", "-null-",
                "crowdsourced_reviewers", "Invalid Json"));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(InitialisationInfoResultsExtractor.class))).thenAnswer(mockAnswer2);

        final String author1 = "{\"authid\":\"000000100\",\"authemail\":\"wilma@bedrock.com\"}";
        final String author2 = "{\"authid\":\"000000210\",\"authemail\":\"b.rubble@bedrock.com\"}";
        final String author3 = "{\"authid\":\"000000200\",\"authemail\":\"barney@bedrock.com\"}";
        final String author4 = "{\"authid\":\"000000300\",\"authemail\":\"wilma@bedrock.com\"}";
        final String author5 = "{\"authemail\":\"wilma@bedrock.com\"}";
        final String author6 = "{\"authid\":\"000000400\"}";

        final WebClient.ResponseSpec sharedSearchSpecMock = createWebClientResponseSpecMock(sharedSearchWebClient);
        Mockito.when(sharedSearchSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("{\"hits\":[" +
                String.join(",", List.of(author1, author2, author3, author4, author5, author6)) + "]}"));

        ResponseEntity<InitialisationDetails> response = initialisationService.getInitialisation(null, "ACR", 123L);

        assertEquals("ACR", mockAnswer.getParameter("emJournalAcronym", String.class));
        assertEquals(123L, mockAnswer.getParameter("documentId", Long.class));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertTrue(response.getBody().isIsElsevier());
        assertNull(response.getBody().getKeywords(), "Keywords not valid");
        assertNull(response.getBody().getClassifications(), "Classifications not valid");
        assertEquals(2, response.getBody().getReviewers().size());
        assertEquals("Fred", response.getBody().getReviewers().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getReviewers().get(0).getLastName());
        assertEquals("Fred Flintstone", response.getBody().getReviewers().get(0).getDisplayName());
        assertEquals(1, response.getBody().getReviewers().get(0).getEmails().size());
        assertEquals("fred@bedrock.com", response.getBody().getReviewers().get(0).getEmails().get(0));
        assertEquals(ReviewerStatus.INVITED, response.getBody().getReviewers().get(0).getStatus());
        assertNull(response.getBody().getReviewers().get(0).getScopusIds());

        assertEquals("Wilma", response.getBody().getReviewers().get(1).getFirstName());
        assertEquals("Flintstone", response.getBody().getReviewers().get(1).getLastName());
        assertEquals("Wilma Flintstone", response.getBody().getReviewers().get(1).getDisplayName());
        assertEquals(1, response.getBody().getReviewers().get(1).getEmails().size());
        assertEquals("wilma@bedrock.com", response.getBody().getReviewers().get(1).getEmails().get(0));
        assertEquals(ReviewerStatus.INPROGRESS, response.getBody().getReviewers().get(1).getStatus());
        assertEquals(1, response.getBody().getReviewers().get(1).getScopusIds().size());
        assertEquals("123456", response.getBody().getReviewers().get(1).getScopusIds().get(0));

        assertEquals(1, response.getBody().getSuggestedReviewers().size());
        assertEquals("barney@bedrock.com", response.getBody().getSuggestedReviewers().get(0).getEmails().get(0));
        assertEquals("Barney", response.getBody().getSuggestedReviewers().get(0).getFirstName());
        assertEquals("Rubble", response.getBody().getSuggestedReviewers().get(0).getLastName());
        assertEquals("Barney Rubble", response.getBody().getSuggestedReviewers().get(0).getDisplayName());

        assertEquals(2, response.getBody().getOpposedReviewers().size());
        assertEquals("wilma@bedrock.com", response.getBody().getOpposedReviewers().get(0).getEmails().get(0));
        assertEquals("Wilma", response.getBody().getOpposedReviewers().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getOpposedReviewers().get(0).getLastName());
        assertEquals("Wilma Flintstone", response.getBody().getOpposedReviewers().get(0).getDisplayName());
        assertEquals("betty@bedrock.com", response.getBody().getOpposedReviewers().get(1).getEmails().get(0));
        assertEquals("Betty", response.getBody().getOpposedReviewers().get(1).getFirstName());
        assertEquals("Rubble", response.getBody().getOpposedReviewers().get(1).getLastName());
        assertEquals("Betty Rubble", response.getBody().getOpposedReviewers().get(1).getDisplayName());

        assertEquals(1, response.getBody().getCorrespondingAuthors().size());
        assertEquals(2, response.getBody().getCorrespondingAuthors().get(0).getEmails().size());
        assertEquals("barney@bedrock.com", response.getBody().getCorrespondingAuthors().get(0).getEmails().get(0));
        assertEquals("b.rubble@bedrock.com", response.getBody().getCorrespondingAuthors().get(0).getEmails().get(1));
        assertEquals("Barney", response.getBody().getCorrespondingAuthors().get(0).getFirstName());
        assertEquals("Rubble", response.getBody().getCorrespondingAuthors().get(0).getLastName());
        assertEquals("Barney Rubble", response.getBody().getCorrespondingAuthors().get(0).getDisplayName());
        assertEquals(2, response.getBody().getCorrespondingAuthors().get(0).getScopusIds().size());
        assertEquals("000000200", response.getBody().getCorrespondingAuthors().get(0).getScopusIds().get(0));
        assertEquals("000000210", response.getBody().getCorrespondingAuthors().get(0).getScopusIds().get(1));

        assertEquals(1, response.getBody().getCoAuthors().size());
        assertEquals("wilma@bedrock.com", response.getBody().getCoAuthors().get(0).getEmails().get(0));
        assertEquals("Wilma", response.getBody().getCoAuthors().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getCoAuthors().get(0).getLastName());
        assertEquals("Wilma Flintstone", response.getBody().getCoAuthors().get(0).getDisplayName());
        assertEquals(2, response.getBody().getCoAuthors().get(0).getScopusIds().size());
        assertEquals("000000100", response.getBody().getCoAuthors().get(0).getScopusIds().get(0));
        assertEquals("000000300", response.getBody().getCoAuthors().get(0).getScopusIds().get(1));

        assertNull(response.getBody().getCrowdsourcedReviewers(), "Crowdsourced not valid");
        assertNull(response.getBody().getJournalIssnl());
        assertNull(response.getBody().getJournalClassifications(), "Unexpected Classifications");
    }

    @Test
    void testManuscriptDataAuthorError() throws SQLException {
        Map<String, Object> resultMapping1 = Map.ofEntries(
                Map.entry("corresponding_authors", "[{\"emails\" : [\"bar*ney@bedrock.com\"], \"firstName\" : \"Barney\", \"lastName\" : \"Rubble\"}]"),
                Map.entry("co_authors", "[{\"firstName\" : \"Wilma\", \"lastName\" : \"Flintstone\", \"emails\" : null}]"));

        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(resultMapping1);
        mockAnswer.addResultMapping(resultMapping1);

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(InitialisationResultsExtractor.class))).thenAnswer(mockAnswer);

        JdbcMockAnswer mockAnswer2 = new JdbcMockAnswer();
        mockAnswer2.addResultMapping(Map.of());

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(InitialisationInfoResultsExtractor.class))).thenAnswer(mockAnswer2);

        final WebClient.ResponseSpec sharedSearchSpecMock = createWebClientResponseSpecMock(sharedSearchWebClient);
        Mockito.when(sharedSearchSpecMock.bodyToMono(String.class))
                .thenThrow(new WebClientResponseException(404, "Not Found", null, null, null))
                .thenReturn(Mono.just("{Json Error}"));

        ResponseEntity<InitialisationDetails> response = initialisationService.getInitialisation(null, "ACR", 123L);

        assertEquals("ACR", mockAnswer.getParameter("emJournalAcronym", String.class));
        assertEquals(123L, mockAnswer.getParameter("documentId", Long.class));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertTrue(response.getBody().isIsElsevier());
        assertNull(response.getBody().getKeywords(), "Keywords not valid");
        assertNull(response.getBody().getClassifications(), "Classifications not valid");
        assertNull(response.getBody().getReviewers(), "Reviewers not valid");

        assertEquals(1, response.getBody().getCorrespondingAuthors().size());
        assertEquals("bar*ney@bedrock.com", response.getBody().getCorrespondingAuthors().get(0).getEmails().get(0));
        assertEquals("Barney", response.getBody().getCorrespondingAuthors().get(0).getFirstName());
        assertEquals("Rubble", response.getBody().getCorrespondingAuthors().get(0).getLastName());
        assertEquals("Barney Rubble", response.getBody().getCorrespondingAuthors().get(0).getDisplayName());
        assertNull(response.getBody().getCorrespondingAuthors().get(0).getScopusIds());

        assertEquals(1, response.getBody().getCoAuthors().size());
        assertNull(response.getBody().getCoAuthors().get(0).getEmails());
        assertEquals("Wilma", response.getBody().getCoAuthors().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getCoAuthors().get(0).getLastName());
        assertEquals("Wilma Flintstone", response.getBody().getCoAuthors().get(0).getDisplayName());
        assertNull(response.getBody().getCoAuthors().get(0).getScopusIds());

        assertNull(response.getBody().getCrowdsourcedReviewers(), "Crowdsourced not valid");
        assertNull(response.getBody().getJournalIssnl());
        assertNull(response.getBody().getJournalClassifications(), "Unexpected Classifications");

        response = initialisationService.getInitialisation(null, "ACR", 1L);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertTrue(response.getBody().isIsElsevier());
        assertEquals(1, response.getBody().getCorrespondingAuthors().size());
        assertEquals("bar*ney@bedrock.com", response.getBody().getCorrespondingAuthors().get(0).getEmails().get(0));
        assertEquals("Barney Rubble", response.getBody().getCorrespondingAuthors().get(0).getDisplayName());
        assertNull(response.getBody().getCorrespondingAuthors().get(0).getScopusIds());

        assertEquals(1, response.getBody().getCoAuthors().size());
        assertNull(response.getBody().getCoAuthors().get(0).getEmails());
        assertEquals("Wilma Flintstone", response.getBody().getCoAuthors().get(0).getDisplayName());
        assertNull(response.getBody().getCoAuthors().get(0).getScopusIds());
    }

    @Test
    void testManuscriptDataWithMultipleEmailsAndNestedMultipleClassification() throws SQLException {
        Map<String, Object> resultMapping1 = Map.ofEntries(
                Map.entry("review_udb_id", 1L),
                Map.entry("keywords", "Invalid Json"),
                Map.entry("classifications", "Invalid Json"),
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("first_name", "Fred"),
                Map.entry("last_name", "Flintstone"),
                Map.entry("scopus_id", "123456"),
                Map.entry("workinprogress", false),
                Map.entry("has_references", true),
                Map.entry("corresponding_authors", "[{\"emails\" : [\"Invalid\"], \"firstName\" : \"Barney\", \"lastName\" : \"Rubble\"}]"));

        Map<String, Object> resultMapping2 = Map.ofEntries(
                Map.entry("review_udb_id", 1L),
                Map.entry("keywords", "Invalid Json"),
                Map.entry("classifications", "Invalid Json"),
                Map.entry("email", "flintstone@bedrock.com"),
                Map.entry("first_name", "Fred"),
                Map.entry("last_name", "Flintstone"),
                Map.entry("scopus_id", "654321"),
                Map.entry("workinprogress", false),
                Map.entry("has_references", true),
                Map.entry("corresponding_authors", "[{\"emails\" : [\"Invalid\"], \"firstName\" : \"Barney\", \"lastName\" : \"Rubble\"}]"));

        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(resultMapping1, resultMapping2, resultMapping2);

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(InitialisationResultsExtractor.class))).thenAnswer(mockAnswer);

        JdbcMockAnswer mockAnswer2 = new JdbcMockAnswer();
        mockAnswer2.addResultMapping(Map.of(
                "classifications", "[" +
                        "{\"code\": \"10\", \"description\": \"First Classification\"}," +
                        "{\"code\": \"10.100\", \"description\": \"Nested First Classification\", \"parentCode\": \"10\"}," +
                        "{\"code\": \"10.200\", \"description\": \"Nested First Classification 2\", \"parentCode\": \"10\"}," +
                        "{\"code\": \"20.100\", \"description\": \"Nested Second Classification\", \"parentCode\": \"20\"}," +
                        "{\"code\": \"20.100.1\", \"description\": \"Nested Second Deep Classification\", \"parentCode\": \"20.100\"}," +
                        "{\"code\": \"20\", \"description\": \"Second Classification\"}," +
                        "{\"code\": \"30\", \"description\": \"Third Classification\"}" +
                        "]"));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(InitialisationInfoResultsExtractor.class))).thenAnswer(mockAnswer2);

        ResponseEntity<InitialisationDetails> response = initialisationService.getInitialisation(null, "ACR", 123L);

        assertEquals("ACR", mockAnswer.getParameter("emJournalAcronym", String.class));
        assertEquals(123L, mockAnswer.getParameter("documentId", Long.class));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertTrue(response.getBody().isIsElsevier());
        assertNull(response.getBody().getKeywords(), "Keywords not valid");
        assertNull(response.getBody().getClassifications(), "Classifications not valid");
        assertEquals(List.of(InitialisationDetails.PermittedFeaturesEnum.REFERENCEDAUTHORS,
                InitialisationDetails.PermittedFeaturesEnum.ADDEDREVIEWERS,
                InitialisationDetails.PermittedFeaturesEnum.AUTHORSEARCH,
                InitialisationDetails.PermittedFeaturesEnum.KEYWORDSEARCH,
                InitialisationDetails.PermittedFeaturesEnum.SESSIONPREFERENCES,
                InitialisationDetails.PermittedFeaturesEnum.RECOMMENDATIONS,
                InitialisationDetails.PermittedFeaturesEnum.VOLUNTEERS,
                InitialisationDetails.PermittedFeaturesEnum.MANUSCRIPTDETAILS,
                InitialisationDetails.PermittedFeaturesEnum.REVIEWERHISTORY,
                InitialisationDetails.PermittedFeaturesEnum.REVIEWERLIMITS,
                InitialisationDetails.PermittedFeaturesEnum.JOURNALREVIEWERS), response.getBody().getPermittedFeatures());

        assertEquals(1, response.getBody().getReviewers().size());
        assertEquals("Fred", response.getBody().getReviewers().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getReviewers().get(0).getLastName());
        assertEquals(2, response.getBody().getReviewers().get(0).getEmails().size());
        assertEquals("fred@bedrock.com", response.getBody().getReviewers().get(0).getEmails().get(0));
        assertEquals("flintstone@bedrock.com", response.getBody().getReviewers().get(0).getEmails().get(1));
        assertEquals(ReviewerStatus.INVITED, response.getBody().getReviewers().get(0).getStatus());
        assertEquals(2, response.getBody().getReviewers().get(0).getScopusIds().size());
        assertEquals("123456", response.getBody().getReviewers().get(0).getScopusIds().get(0));
        assertEquals("654321", response.getBody().getReviewers().get(0).getScopusIds().get(1));

        assertNull(response.getBody().getJournalIssnl(), "Non Null ISSN");
        assertEquals(3, response.getBody().getJournalClassifications().size());
        assertEquals("10", response.getBody().getJournalClassifications().get(0).getCode());
        assertEquals("First Classification", response.getBody().getJournalClassifications().get(0).getDescription());
        assertEquals(2, response.getBody().getJournalClassifications().get(0).getChildren().size());
        assertEquals("10.100", response.getBody().getJournalClassifications().get(0).getChildren().get(0).getCode());
        assertEquals("Nested First Classification", response.getBody().getJournalClassifications().get(0).getChildren().get(0).getDescription());
        assertNull(response.getBody().getJournalClassifications().get(0).getChildren().get(0).getChildren(), "Unexpected children");
        assertEquals("10.200", response.getBody().getJournalClassifications().get(0).getChildren().get(1).getCode());
        assertEquals("Nested First Classification 2", response.getBody().getJournalClassifications().get(0).getChildren().get(1).getDescription());
        assertNull(response.getBody().getJournalClassifications().get(0).getChildren().get(1).getChildren(), "Unexpected children");
        assertEquals("20", response.getBody().getJournalClassifications().get(1).getCode());
        assertEquals("Second Classification", response.getBody().getJournalClassifications().get(1).getDescription());
        assertEquals(1, response.getBody().getJournalClassifications().get(1).getChildren().size());
        assertEquals("20.100", response.getBody().getJournalClassifications().get(1).getChildren().get(0).getCode());
        assertEquals("Nested Second Classification", response.getBody().getJournalClassifications().get(1).getChildren().get(0).getDescription());
        assertEquals(1, response.getBody().getJournalClassifications().get(1).getChildren().get(0).getChildren().size());
        assertEquals("20.100.1", response.getBody().getJournalClassifications().get(1).getChildren().get(0).getChildren().get(0).getCode());
        assertEquals("Nested Second Deep Classification", response.getBody().getJournalClassifications().get(1).getChildren().get(0).getChildren().get(0).getDescription());
        assertNull(response.getBody().getJournalClassifications().get(1).getChildren().get(0).getChildren().get(0).getChildren(), "Unexpected children");
        assertEquals("30", response.getBody().getJournalClassifications().get(2).getCode());
        assertEquals("Third Classification", response.getBody().getJournalClassifications().get(2).getDescription());
        assertNull(response.getBody().getJournalClassifications().get(2).getChildren(), "Unexpected children");
    }

    @Test
    void testManuscriptDataWithReviewersStatuses() throws SQLException {
        Map<String, Object> resultMapping1 = Map.ofEntries(
                Map.entry("review_udb_id", 1L),
                Map.entry("keywords", "[\"single:\"]"),
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("completed", Boolean.FALSE),
                Map.entry("assigned_not_invited", Boolean.TRUE),
                Map.entry("corresponding_authors", "[{\"emails\" : [\"barney@bedrock.com\", \"b.rubble@bedrock.com\"], \"firstName\" : \"Barney\", \"lastName\" : \"Rubble\"}]"));

        Map<String, Object> resultMapping2 = Map.ofEntries(
                Map.entry("review_udb_id", 2L),
                Map.entry("keywords", "[\"single:\"]"),
                Map.entry("email", "wilma@bedrock.com"),
                Map.entry("completed", Boolean.TRUE),
                Map.entry("assigned_not_invited", Boolean.FALSE),
                Map.entry("corresponding_authors", "[{\"emails\" : [\"barney@bedrock.com\", \"b.rubble@bedrock.com\"], \"firstName\" : \"Barney\", \"lastName\" : \"Rubble\"}]"));

        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(resultMapping1, resultMapping2);

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(InitialisationResultsExtractor.class))).thenAnswer(mockAnswer);

        final WebClient.ResponseSpec sharedSearchSpecMock = createWebClientResponseSpecMock(sharedSearchWebClient);
        Mockito.when(sharedSearchSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("{}"));

        ResponseEntity<InitialisationDetails> response = initialisationService.getInitialisation(null, "ACR", 123L);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertEquals(1, response.getBody().getKeywords().size());
        assertEquals("single", response.getBody().getKeywords().get(0));
        assertEquals(2, response.getBody().getReviewers().size());
        assertEquals(1, response.getBody().getReviewers().get(0).getEmails().size());
        assertEquals("fred@bedrock.com", response.getBody().getReviewers().get(0).getEmails().get(0));
        assertEquals(ReviewerStatus.ASSIGNED, response.getBody().getReviewers().get(0).getStatus());

        assertEquals(1, response.getBody().getReviewers().get(1).getEmails().size());
        assertEquals("wilma@bedrock.com", response.getBody().getReviewers().get(1).getEmails().get(0));
        assertEquals(ReviewerStatus.COMPLETED, response.getBody().getReviewers().get(1).getStatus());

        resultMapping1 = Map.ofEntries(
                Map.entry("review_udb_id", 1L),
                Map.entry("keywords", "[\"one, two , three,four\"]"),
                Map.entry("classifications", "[{\"code\": \"10.100\", \"description\": \"class1\"},{\"code\": \"10.200\", \"description\": \"class2\"}]"),
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("uninvited", Boolean.FALSE),
                Map.entry("alternate", Boolean.TRUE));

        resultMapping2 = Map.ofEntries(
                Map.entry("review_udb_id", 2L),
                Map.entry("keywords", "[\"one, two , three,four\"]"),
                Map.entry("classifications", "[{\"code\": \"10.100\", \"description\": \"class1\"},{\"code\": \"10.200\", \"description\": \"class2\"}]"),
                Map.entry("email", "wilma@bedrock.com"),
                Map.entry("uninvited", Boolean.TRUE),
                Map.entry("alternate", Boolean.FALSE));

        mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(resultMapping1, resultMapping2);

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(InitialisationResultsExtractor.class))).thenAnswer(mockAnswer);

        JdbcMockAnswer mockAnswer2 = new JdbcMockAnswer();
        mockAnswer2.addNullResultMap();

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(InitialisationInfoResultsExtractor.class))).thenAnswer(mockAnswer2);

        response = initialisationService.getInitialisation(null, "ACR", 123L);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(4, response.getBody().getKeywords().size());
        assertEquals("one", response.getBody().getKeywords().get(0));
        assertEquals("two", response.getBody().getKeywords().get(1));
        assertEquals("three", response.getBody().getKeywords().get(2));
        assertEquals("four", response.getBody().getKeywords().get(3));
        assertEquals(2, response.getBody().getClassifications().size());
        assertEquals("10.100", response.getBody().getClassifications().get(0).getCode());
        assertEquals("class1", response.getBody().getClassifications().get(0).getDescription());
        assertEquals("10.200", response.getBody().getClassifications().get(1).getCode());
        assertEquals("class2", response.getBody().getClassifications().get(1).getDescription());
        assertEquals(1, response.getBody().getReviewers().get(0).getEmails().size());
        assertEquals("fred@bedrock.com", response.getBody().getReviewers().get(0).getEmails().get(0));
        assertEquals(ReviewerStatus.ALTERNATE, response.getBody().getReviewers().get(0).getStatus());
        assertEquals(1, response.getBody().getReviewers().get(1).getEmails().size());
        assertEquals("wilma@bedrock.com", response.getBody().getReviewers().get(1).getEmails().get(0));
        assertEquals(ReviewerStatus.UNINVITED, response.getBody().getReviewers().get(1).getStatus());
    }

    @Test
    void testManuscriptWithReviewerMix() throws SQLException, IOException, InterruptedException {
        SessionContext.initialize(new SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", false, true));

        Map<String, Object> resultMapping1 = Map.ofEntries(
                Map.entry("review_udb_id", 1L),
                Map.entry("keywords", "[\"one\\r\\n [two] \\r\\nth#ree\"]"),
                Map.entry("first_name", "Fred"),
                Map.entry("last_name", "Flintstone"),
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("scopus_id", "-null-"),
                Map.entry("terminated", Boolean.FALSE),
                Map.entry("declined", Boolean.TRUE));

        Map<String, Object> resultMapping2 = Map.ofEntries(
                Map.entry("review_udb_id", 2L),
                Map.entry("keywords", "[\"one\\r\\n [two] \\r\\nthr#ee\"]"),
                Map.entry("first_name", "Wilma"),
                Map.entry("last_name", "Flintstone"),
                Map.entry("email", "wilma@BEDROCK.com"),
                Map.entry("scopus_id", "-null-"),
                Map.entry("terminated", Boolean.TRUE),
                Map.entry("declined", Boolean.FALSE));

        Map<String, Object> resultMapping3 = Map.ofEntries(
                Map.entry("review_udb_id", 3L),
                Map.entry("keywords", "[\"one\\r\\n [two] \\r\\nthr#ee\"]"),
                Map.entry("first_name", "Betty"),
                Map.entry("last_name", "Rubble"),
                Map.entry("email", "Betty@Bedrock.com"),
                Map.entry("scopus_id", "9999"),
                Map.entry("terminated", Boolean.FALSE),
                Map.entry("declined", Boolean.FALSE));

        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(resultMapping1, resultMapping2, resultMapping3);

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(InitialisationResultsExtractor.class))).thenAnswer(mockAnswer);

        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(200);
        Mockito.when(mockTokenResponse.body()).thenReturn("{\"reviewers\":[" +
                "{\"status\":\"invited\",\"journal-code\":\"ACR\",\"given-name\":\"Fred\",\"middle-name\":\"B\"," +
                "\"family-name\":\"Flintstone\", \"email-addresses\":[\"FRED@bedrock.com\",\"fredflintstone@bedrock.com\"]}, " +

                "{\"status\":\"proposed\",\"journal-code\":\"ACR\",\"given-name\":\"Barney\"," +
                "\"family-name\":\"Rubble\",\"email-addresses\":[\"barney@bedrock.com\"], " +
                "\"identifiers\": [{\"system\": \"scopus\", \"identifier\": \"12345\"}]}, " +

                "{\"status\":\"proposed\",\"journal-code\":\"ACR\",\"given-name\":\"Betty\"," +
                "\"family-name\":\"Rubble\",\"email-addresses\":[\"betty@bedrock.com\"], " +
                "\"identifiers\": [{\"system\": \"scopus\", \"identifier\": \"9999\"}]}, " +

                "{\"status\":\"proposed\",\"journal-code\":\"ACR\",\"given-name\":\"No-Email\"," +
                "\"family-name\":\"remove\"}, " +

                "{\"status\":\"proposed\",\"journal-code\":\"ACR\",\"given-name\":\"Empty-Email\"," +
                "\"family-name\":\"remove\",\"email-addresses\":[]} " +
                "]}");

        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        ResponseEntity<InitialisationDetails> response = initialisationService.getInitialisation(null, "ACR", 123L);

        assertEquals("ACR", mockAnswer.getParameter("emJournalAcronym", String.class));
        assertEquals(123L, mockAnswer.getParameter("documentId", Long.class));

        Mockito.verify(mockHttpClient, Mockito.times(1)).send(requestCaptor.capture(),
                Mockito.any(HttpResponse.BodyHandler.class));
        assertTrue(requestCaptor.getValue().uri().toString().endsWith("/journals/ACR/document/123/reviewers"), "Incorrect URL");
        assertEquals("GET", requestCaptor.getValue().method());

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isIsElsevier());
        assertEquals(3, response.getBody().getKeywords().size());
        assertEquals("one", response.getBody().getKeywords().get(0));
        assertEquals("two", response.getBody().getKeywords().get(1));
        assertEquals("three", response.getBody().getKeywords().get(2));
        assertEquals(4, response.getBody().getReviewers().size());
        assertEquals("Fred", response.getBody().getReviewers().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getReviewers().get(0).getLastName());
        assertEquals(2, response.getBody().getReviewers().get(0).getEmails().size());
        assertEquals("fred@bedrock.com", response.getBody().getReviewers().get(0).getEmails().get(0));
        assertEquals("fredflintstone@bedrock.com", response.getBody().getReviewers().get(0).getEmails().get(1));
        assertNull(response.getBody().getReviewers().get(0).getScopusIds());
        assertEquals(ReviewerStatus.INVITED, response.getBody().getReviewers().get(0).getStatus());

        assertEquals(1, response.getBody().getReviewers().get(1).getEmails().size());
        assertEquals("wilma@bedrock.com", response.getBody().getReviewers().get(1).getEmails().get(0));
        assertEquals(ReviewerStatus.TERMINATED, response.getBody().getReviewers().get(1).getStatus());

        assertEquals("Betty", response.getBody().getReviewers().get(2).getFirstName());
        assertEquals("Rubble", response.getBody().getReviewers().get(2).getLastName());
        assertEquals(1, response.getBody().getReviewers().get(2).getEmails().size());
        assertEquals("betty@bedrock.com", response.getBody().getReviewers().get(2).getEmails().get(0));
        assertEquals(1, response.getBody().getReviewers().get(2).getScopusIds().size());
        assertEquals("9999", response.getBody().getReviewers().get(2).getScopusIds().get(0));
        assertEquals(ReviewerStatus.INVITED, response.getBody().getReviewers().get(2).getStatus());

        assertEquals("Barney", response.getBody().getReviewers().get(3).getFirstName());
        assertEquals("Rubble", response.getBody().getReviewers().get(3).getLastName());
        assertEquals(1, response.getBody().getReviewers().get(3).getEmails().size());
        assertEquals("barney@bedrock.com", response.getBody().getReviewers().get(3).getEmails().get(0));
        assertEquals(1, response.getBody().getReviewers().get(3).getScopusIds().size());
        assertEquals("12345", response.getBody().getReviewers().get(3).getScopusIds().get(0));
        assertEquals(ReviewerStatus.PROPOSED, response.getBody().getReviewers().get(3).getStatus());
    }

    @Test
    void testManuscriptWithReviewerScopusMix() throws SQLException, IOException, InterruptedException {
        SessionContext.initialize(new SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", false, true));

        Map<String, Object> resultMapping1 = Map.ofEntries(
                Map.entry("review_udb_id", 1L),
                Map.entry("first_name", "Fred"),
                Map.entry("last_name", "Flintstone"),
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("scopus_id", "6666"),
                Map.entry("terminated", Boolean.FALSE),
                Map.entry("declined", Boolean.TRUE));

        Map<String, Object> resultMapping2 = Map.ofEntries(
                Map.entry("review_udb_id", 3L),
                Map.entry("first_name", "Betty"),
                Map.entry("last_name", "Rubble"),
                Map.entry("email", "Betty@Bedrock.com"),
                Map.entry("scopus_id", "-null-"),
                Map.entry("terminated", Boolean.FALSE),
                Map.entry("declined", Boolean.FALSE));

        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(resultMapping1, resultMapping2);

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(InitialisationResultsExtractor.class))).thenAnswer(mockAnswer);

        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(200);
        Mockito.when(mockTokenResponse.body()).thenReturn("{\"reviewers\":[" +
                "{\"status\":\"invited\",\"journal-code\":\"ACR\",\"given-name\":\"Fred\",\"middle-name\":\"B\"," +
                "\"family-name\":\"Flintstone\", \"email-addresses\":[\"fred@bedrock.com\"], " +
                "\"identifiers\": [{\"system\": \"scopus\", \"identifier\": \"8888\"}]}, " +

                "{\"status\":\"proposed\",\"journal-code\":\"ACR\",\"given-name\":\"Betty\"," +
                "\"family-name\":\"Rubble\",\"email-addresses\":[\"betty@bedrock.com\"], " +
                "\"identifiers\": [{\"system\": \"scopus\", \"identifier\": \"9999\"}]} " +

                "]}");

        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        ResponseEntity<InitialisationDetails> response = initialisationService.getInitialisation(null, "ACR", 123L);

        assertEquals("ACR", mockAnswer.getParameter("emJournalAcronym", String.class));
        assertEquals(123L, mockAnswer.getParameter("documentId", Long.class));

        Mockito.verify(mockHttpClient, Mockito.times(1)).send(requestCaptor.capture(),
                Mockito.any(HttpResponse.BodyHandler.class));
        assertTrue(requestCaptor.getValue().uri().toString().endsWith("/journals/ACR/document/123/reviewers"), "Incorrect URL");
        assertEquals("GET", requestCaptor.getValue().method());

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(2, response.getBody().getReviewers().size());
        assertEquals("Fred", response.getBody().getReviewers().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getReviewers().get(0).getLastName());
        assertEquals(1, response.getBody().getReviewers().get(0).getEmails().size());
        assertEquals("fred@bedrock.com", response.getBody().getReviewers().get(0).getEmails().get(0));
        assertEquals(2, response.getBody().getReviewers().get(0).getScopusIds().size());
        assertEquals("6666", response.getBody().getReviewers().get(0).getScopusIds().get(0));
        assertEquals("8888", response.getBody().getReviewers().get(0).getScopusIds().get(1));
        assertEquals(ReviewerStatus.INVITED, response.getBody().getReviewers().get(0).getStatus());

        assertEquals("Betty", response.getBody().getReviewers().get(1).getFirstName());
        assertEquals("Rubble", response.getBody().getReviewers().get(1).getLastName());
        assertEquals(1, response.getBody().getReviewers().get(1).getEmails().size());
        assertEquals("betty@bedrock.com", response.getBody().getReviewers().get(1).getEmails().get(0));
        assertEquals(1, response.getBody().getReviewers().get(1).getScopusIds().size());
        assertEquals("9999", response.getBody().getReviewers().get(1).getScopusIds().get(0));
        assertEquals(ReviewerStatus.INVITED, response.getBody().getReviewers().get(1).getStatus());
    }

    @Test
    void testGetManuscriptsHttpError() throws IOException, InterruptedException {
        SessionContext.initialize(new SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", false, true));

        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(500);
        Mockito.when(mockTokenResponse.body()).thenReturn("{\"error\":\"Message\"}");

        HttpResponse<String> mockUnauthenticatedTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockUnauthenticatedTokenResponse.statusCode()).thenReturn(401);
        Mockito.when(mockUnauthenticatedTokenResponse.body()).thenReturn("{\"error\":\"Message\"}");

        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse).thenThrow(new IOException()).thenThrow(new InterruptedException())
                .thenReturn(mockUnauthenticatedTokenResponse).thenReturn(mockUnauthenticatedTokenResponse).thenReturn(mockUnauthenticatedTokenResponse);

        ResponseEntity<InitialisationDetails> response = initialisationService.getInitialisation(null, "CELL", 123L);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());

        response = initialisationService.getInitialisation(null, "CELL", 123L);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    void testManuscriptWithReviewerOnApi() throws IOException, InterruptedException, SQLException {
        SessionContext.initialize(new SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", false, true));

        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addNullResultMap();

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(InitialisationResultsExtractor.class))).thenAnswer(mockAnswer);

        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(200);
        Mockito.when(mockTokenResponse.body()).thenReturn("{\"reviewers\":[" +
                "{\"status\":\"invited\",\"journal-code\":\"ACR\",\"given-name\":\"Fred\",\"middle-name\":\"B\"," +
                "\"family-name\":\"Flintstone\", \"email-addresses\":[\"fred@bedrock.com\",\"fredflintstone@bedrock.com\"], " +
                "\"identifiers\": [{\"system\": \"scopus\"}, {\"system\": \"em\", \"identifier\": \"12345\"}]}]}");

        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        JdbcMockAnswer mockAnswer2 = new JdbcMockAnswer();
        mockAnswer2.addResultMapping(Map.of("classifications", "-null-"));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(InitialisationInfoResultsExtractor.class))).thenAnswer(mockAnswer2);

        ResponseEntity<InitialisationDetails> response = initialisationService.getInitialisation(null, "ACR", 123L);

        assertEquals("ACR", mockAnswer.getParameter("emJournalAcronym", String.class));
        assertEquals(123L, mockAnswer.getParameter("documentId", Long.class));

        Mockito.verify(mockHttpClient, Mockito.times(1)).send(requestCaptor.capture(),
                Mockito.any(HttpResponse.BodyHandler.class));
        assertTrue(requestCaptor.getValue().uri().toString().endsWith("/journals/ACR/document/123/reviewers"), "Incorrect URL");
        assertEquals("GET", requestCaptor.getValue().method());

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isIsElsevier());
        assertEquals(1, response.getBody().getReviewers().size());
        assertEquals("Fred", response.getBody().getReviewers().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getReviewers().get(0).getLastName());
        assertEquals("Fred Flintstone", response.getBody().getReviewers().get(0).getDisplayName());
        assertEquals(2, response.getBody().getReviewers().get(0).getEmails().size());
        assertEquals("fred@bedrock.com", response.getBody().getReviewers().get(0).getEmails().get(0));
        assertEquals("fredflintstone@bedrock.com", response.getBody().getReviewers().get(0).getEmails().get(1));
        assertEquals(ReviewerStatus.INVITED, response.getBody().getReviewers().get(0).getStatus());
        assertNull(response.getBody().getReviewers().get(0).getScopusIds());
    }

    @Test
    void testGetManuscriptsHttpRequestError() {
        SessionContext.initialize(new SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", false, true));

        Object editorialManagerClass = ReflectionTestUtils.getField(initialisationService, "editorialManager");
        Object originalRetryTemplate = ReflectionTestUtils.getField(editorialManagerClass, "emRetry");

        // Generate a null pointer exception to test generic error handling
        ReflectionTestUtils.setField(editorialManagerClass, "emRetry", null);

        ResponseEntity<InitialisationDetails> response = initialisationService.getInitialisation(null, "CELL", 123L);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());

        ReflectionTestUtils.setField(editorialManagerClass, "emRetry", originalRetryTemplate);
    }

    @Test
    void testManuscriptWithReviewerNumericStatusOnApi() throws IOException, InterruptedException, SQLException {
        SessionContext.initialize(new SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", false, true));

        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(Map.of(), Collections.emptyMap());

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(InitialisationResultsExtractor.class))).thenAnswer(mockAnswer);

        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(200);
        Mockito.when(mockTokenResponse.body()).thenReturn("{\"reviewers\":[" +
                "{\"status\": 5,\"journal-code\":\"ACR\",\"given-name\":\"Fred\",\"middle-name\":\"B\"," +
                "\"family-name\":\"Flintstone\", \"email-addresses\":[\"fred@bedrock.com\"]}]}");

        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        ResponseEntity<InitialisationDetails> response = initialisationService.getInitialisation(null, "ACR", 123L);

        assertEquals("ACR", mockAnswer.getParameter("emJournalAcronym", String.class));
        assertEquals(123L, mockAnswer.getParameter("documentId", Long.class));

        Mockito.verify(mockHttpClient, Mockito.times(1)).send(requestCaptor.capture(),
                Mockito.any(HttpResponse.BodyHandler.class));
        assertTrue(requestCaptor.getValue().uri().toString().endsWith("/journals/ACR/document/123/reviewers"), "Incorrect URL");
        assertEquals("GET", requestCaptor.getValue().method());

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, response.getBody().getReviewers().size());
        assertEquals("Fred", response.getBody().getReviewers().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getReviewers().get(0).getLastName());
        assertEquals(1, response.getBody().getReviewers().get(0).getEmails().size());
        assertEquals("fred@bedrock.com", response.getBody().getReviewers().get(0).getEmails().get(0));
        assertEquals(ReviewerStatus.ALTERNATE, response.getBody().getReviewers().get(0).getStatus());
    }

    @Test
    void testManuscriptDataWithCrowdsourcedReviewersAndDuplicateAndOrphanClassification() throws SQLException {
        Map<String, Object> resultMapping1 = Map.ofEntries(
                Map.entry("review_udb_id", 1L),
                Map.entry("keywords", "[\"one * two *t\\\\hree\"]"),
                Map.entry("classifications", ""),
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("first_name", "Fred"),
                Map.entry("last_name", "Flintstone"),
                Map.entry("workinprogress", false));

        Map<String, Object> resultMapping2 = Map.ofEntries(
                Map.entry("review_udb_id", 2L),
                Map.entry("keywords", "[\"one * two *t\\\\hree\"]"),
                Map.entry("classifications", ""),
                Map.entry("email", "wilma@bedrock.com"),
                Map.entry("first_name", "Wilma"),
                Map.entry("last_name", "Flintstone"),
                Map.entry("workinprogress", true));

        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(resultMapping1, resultMapping2);

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(InitialisationResultsExtractor.class))).thenAnswer(mockAnswer);

        JdbcMockAnswer mockAnswer2 = new JdbcMockAnswer();
        mockAnswer2.addResultMapping(Map.of(
                "classifications", "[" +
                        "{\"code\": \"10\", \"description\": \"First Classification\"}," +
                        "{\"code\": \"10\", \"description\": \"First Classification\"}," +
                        "{\"code\": \"10.100\", \"description\": \"Nested First Classification\", \"parentCode\": \"10\"}," +
                        "{\"code\": \"10.100\", \"description\": \"Nested First Classification\", \"parentCode\": \"10\"}," +
                        "{\"code\": \"10.200\", \"description\": \"Orphan Classification\", \"parentCode\": \"999\"}" +
                        "]",
                "has_ebms", false,
                "crowdsourced_reviewers", "[{\"email\" : \"wilma@bedrock.com\", \"scopusIds\" : [\"333222111\"]}," +
                        "{\"email\" : \"betty@bedrock.com\", \"scopusIds\" : [\"444333222111\"]}]"));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(InitialisationInfoResultsExtractor.class))).thenAnswer(mockAnswer2);

        ResponseEntity<InitialisationDetails> response = initialisationService.getInitialisation(null, "ACR", 123L);

        assertEquals("ACR", mockAnswer.getParameter("emJournalAcronym", String.class));
        assertEquals(123L, mockAnswer.getParameter("documentId", Long.class));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertTrue(response.getBody().isIsElsevier());
        assertEquals(3, response.getBody().getKeywords().size());
        assertEquals("one", response.getBody().getKeywords().get(0));
        assertEquals("two", response.getBody().getKeywords().get(1));
        assertEquals("three", response.getBody().getKeywords().get(2));
        assertNull(response.getBody().getClassifications(), "Classifications not valid");
        assertEquals(2, response.getBody().getReviewers().size());
        assertEquals("Fred", response.getBody().getReviewers().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getReviewers().get(0).getLastName());
        assertEquals(1, response.getBody().getReviewers().get(0).getEmails().size());
        assertEquals("fred@bedrock.com", response.getBody().getReviewers().get(0).getEmails().get(0));
        assertEquals(ReviewerStatus.INVITED, response.getBody().getReviewers().get(0).getStatus());

        assertEquals("Wilma", response.getBody().getReviewers().get(1).getFirstName());
        assertEquals("Flintstone", response.getBody().getReviewers().get(1).getLastName());
        assertEquals(1, response.getBody().getReviewers().get(0).getEmails().size());
        assertEquals("wilma@bedrock.com", response.getBody().getReviewers().get(1).getEmails().get(0));
        assertEquals(ReviewerStatus.INPROGRESS, response.getBody().getReviewers().get(1).getStatus());

        assertNotNull(response.getBody().getCrowdsourcedReviewers(), "Crowdsourced not valid");
        assertEquals(1, response.getBody().getCrowdsourcedReviewers().size());
        assertEquals("betty@bedrock.com", response.getBody().getCrowdsourcedReviewers().get(0).getEmail());
        assertEquals(1, response.getBody().getCrowdsourcedReviewers().get(0).getScopusIds().size());
        assertEquals("444333222111", response.getBody().getCrowdsourcedReviewers().get(0).getScopusIds().get(0));

        assertNull(response.getBody().getSuggestedReviewers(), "Suggested Reviewers not valid");
        assertNull(response.getBody().getOpposedReviewers(), "Opposed Reviewers not valid");
        assertNull(response.getBody().getJournalIssnl(), "Non Null ISSN");
        assertEquals(1, response.getBody().getJournalClassifications().size());
        assertEquals("10", response.getBody().getJournalClassifications().get(0).getCode());
        assertEquals("First Classification", response.getBody().getJournalClassifications().get(0).getDescription());
        assertEquals(1, response.getBody().getJournalClassifications().get(0).getChildren().size());
        assertEquals("10.100", response.getBody().getJournalClassifications().get(0).getChildren().get(0).getCode());
        assertEquals("Nested First Classification", response.getBody().getJournalClassifications().get(0).getChildren().get(0).getDescription());
    }

    @Test
    void testReviewerEnumValues() {
        Set<ReviewerStatus> statusEnums = new HashSet<>();
        for (ReviewerStatusType status : ReviewerStatusType.values()) {
            ReviewerStatus statusEnum = ReviewerStatusType.toInterface(status);
            assertNotNull(statusEnum, "Status for " + status + " has null interface");
            statusEnums.add(statusEnum);
            assertEquals(status, ReviewerStatusType.getEnumFromValue(status.getValue()));
        }
        assertEquals(ReviewerStatus.PROPOSED, ReviewerStatusType.toInterface(null));
        assertEquals(ReviewerStatusType.Selected, ReviewerStatusType.fromInterface(ReviewerStatus.COMPLETED));
        assertEquals(ReviewerStatusType.Selected, ReviewerStatusType.getEnumFromValue(1L));
        assertEquals(ReviewerStatusType.Invited, ReviewerStatusType.getEnumFromValue(2L));
        assertEquals(ReviewerStatusType.Assigned, ReviewerStatusType.getEnumFromValue(3L));
        assertEquals(ReviewerStatusType.Proposed, ReviewerStatusType.getEnumFromValue(4L));
        assertEquals(ReviewerStatusType.Alternate, ReviewerStatusType.getEnumFromValue(5L));
        assertNull(ReviewerStatusType.getEnumFromValue(null));
        assertNull(ReviewerStatusType.getEnumFromValue("unknown"));
        assertNull(ReviewerStatusType.getEnumFromValue(6L));
    }
}
