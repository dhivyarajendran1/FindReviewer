package com.elsevier.find.reviewers.testutils;

import com.newrelic.telemetry.micrometer.NewRelicRegistry;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.search.RequiredSearch;
import io.micrometer.core.instrument.step.StepDouble;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.web.reactive.function.client.WebClient;

import javax.sql.DataSource;
import java.net.URI;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.Flow;
import java.util.concurrent.atomic.DoubleAdder;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@TestPropertySource(properties = {
        "em.client.id=EM_CLIENT_ID",
        "em.client.secret=EM_CLIENT_SECRET",
        "em.client.api.host=https://api.editorialmanager.com/",
        "em.client.redirect.url=https://findreviewers.scopus.com/redirect",
        "em.web.api.client.username=EM_WEB_API_CLIENT_USERNAME",
        "em.web.api.client.password=EM_WEB_API_CLIENT_PASSWORD",
        "em.web.api.client.host=https://localhost/api",
        "scopusautocomplete.client.id=SCOPUS_AUTOCOMPLETE_CLIENT_ID",
        "scopusautocomplete.client.secret=SCOPUS_AUTOCOMPLETE_CLIENT_SECRET",
        "scopusautocomplete.client.base.url=https://localhost/api",
        "personfinder.client.id=PERSON_FINDER_CLIENT_ID",
        "personfinder.client.secret=PERSON_FINDER_CLIENT_SECRET",
        "personfinder.client.base.url=https://localhost/api",
        "scopussharedsearch.client.id=SCOPUS_SHARED_SEARCH_CLIENT_ID",
        "scopussharedsearch.client.secret=SCOPUS_SHARED_SEARCH_CLIENT_SECRET",
        "scopussharedsearch.client.base.url=https://localhost/api",
        "scopussources.client.base.url=https://localhost/api",
        "scopusgraph.client.id=SCOPUS_GRAPH_CLIENT_ID",
        "scopusgraph.client.secret=SCOPUS_GRAPH_CLIENT_SECRET",
        "scopusgraph.client.base.url=https://localhost/api",
        "emsupport.client.username=EM_SUPPORT_INTERNAL_API_USERNAME",
        "emsupport.client.password=EM_SUPPORT_INTERNAL_API_PASSWORD",
        "emsupport.client.base.url=https://localhost/api",
        "reviewerhub.client.username=EM_SUPPORT_INTERNAL_API_USERNAME",
        "reviewerhub.client.password=EM_SUPPORT_INTERNAL_API_PASSWORD",
        "reviewerhub.client.base.url=https://localhost/api",
        "recommender.base.url=https://localhost/api",
        "findreviewers.manuscript.audit.tablename=rev-rec-test-manuscript-audit",
        "findreviewers.reflow.queuename=rev-rec-test-reflow-queue",
        "management.metrics.export.newrelic.api-key=NEW_RELIC_INSIGHTS_KEY",
        "management.metrics.export.newrelic.enabled=false",
        "management.metrics.export.newrelic.step=999s",
        "logging.level.com.newrelic.telemetry=ERROR",
        "read.only.authentication.code=READONLY_CODE"
})
public abstract class TestBase {
    @Autowired
    private NewRelicRegistry newRelicRegistry;

    // Mock the interface to the database
    @MockBean(name = "coreDbSource")
    protected NamedParameterJdbcTemplate coreDb;

    // Always use the same base for the URI Spec that supports Web call so that we can generate multiple different
    // returns based on the call made
    private WebClient.RequestHeadersUriSpec uriSpecMock = Mockito.mock(WebClient.RequestHeadersUriSpec.class);

    // The following is to support testing HTTP requests and reading the body of the message
    protected static final class StringSubscriber implements Flow.Subscriber<ByteBuffer> {
        final HttpResponse.BodySubscriber<String> wrapped;

        public StringSubscriber(HttpResponse.BodySubscriber<String> wrapped) {
            this.wrapped = wrapped;
        }

        @Override
        public void onSubscribe(Flow.Subscription subscription) {
            wrapped.onSubscribe(subscription);
        }

        @Override
        public void onNext(ByteBuffer item) {
            wrapped.onNext(List.of(item));
        }

        @Override
        public void onError(Throwable throwable) {
            wrapped.onError(throwable);
        }

        @Override
        public void onComplete() {
            wrapped.onComplete();
        }
    }

    protected String getHttpRequestBody(ArgumentCaptor<HttpRequest> requestCaptor) {
        return requestCaptor.getValue().bodyPublisher().map(p -> {
            HttpResponse.BodySubscriber<String> bodySubscriber = HttpResponse.BodySubscribers.ofString(StandardCharsets.UTF_8);
            p.subscribe(new StringSubscriber(bodySubscriber));
            return bodySubscriber.getBody().toCompletableFuture().join();
        }).get();
    }

    protected int getAnalyticsCounterValue(String counterName, String tag) {
        // Get access to the raw step counter value so that we do not need to wait for the analytics to be sent
        RequiredSearch requiredSearch = newRelicRegistry.get(counterName).tag("source", tag);
        Counter counter = requiredSearch.counters().stream().findFirst().get();
        StepDouble counterValue = (StepDouble) ReflectionTestUtils.getField(counter, "value");
        final int counterIntValue = counterValue.getCurrent().intValue();

        // Reset the counter
        if (counterIntValue > 0) {
            ReflectionTestUtils.setField(counterValue, "current", new DoubleAdder());
        }

        return counterIntValue;
    }

    protected WebClient.ResponseSpec createWebClientResponseSpecMock(WebClient webClient) {
        // If there is no uri filter - create a new mock instance
        uriSpecMock = Mockito.mock(WebClient.RequestHeadersUriSpec.class);
        return createWebClientResponseSpecMock(webClient, null);
    }

    protected WebClient.ResponseSpec createWebClientResponseSpecMock(WebClient webClient, String uri) {
        // Mock support for GET
        final WebClient.RequestHeadersSpec headersSpecMock = Mockito.mock(WebClient.RequestHeadersSpec.class);
        final WebClient.ResponseSpec responseSpecMock = Mockito.mock(WebClient.ResponseSpec.class);
        Mockito.when(webClient.get()).thenReturn(uriSpecMock);
        if (uri != null) {
            Mockito.doReturn(headersSpecMock).when(uriSpecMock).uri((URI) Mockito.argThat(u -> u.toString().contains(uri)));
        } else {
            Mockito.when(uriSpecMock.uri(Mockito.any(URI.class))).thenReturn(headersSpecMock);
        }
        Mockito.when(headersSpecMock.header(Mockito.anyString(), Mockito.anyString())).thenReturn(headersSpecMock);
        Mockito.when(headersSpecMock.accept(Mockito.notNull())).thenReturn(headersSpecMock);
        Mockito.when(headersSpecMock.retrieve()).thenReturn(responseSpecMock);

        // Mock support for POST
        final WebClient.RequestBodyUriSpec bodyUriSpecMock = Mockito.mock(WebClient.RequestBodyUriSpec.class);
        final WebClient.RequestBodySpec bodySpecMock = Mockito.mock(WebClient.RequestBodySpec.class);
        Mockito.when(webClient.post()).thenReturn(bodyUriSpecMock);
        if (uri != null) {
            Mockito.when(bodyUriSpecMock.uri(Mockito.contains(uri))).thenReturn(bodySpecMock);
        } else {
            Mockito.when(bodyUriSpecMock.uri(Mockito.anyString())).thenReturn(bodySpecMock);

        }
        Mockito.when(bodySpecMock.header(Mockito.anyString(), Mockito.anyString())).thenReturn(bodySpecMock);
        Mockito.when(bodySpecMock.accept(Mockito.notNull())).thenReturn(bodySpecMock);
        Mockito.when(bodySpecMock.contentType(Mockito.notNull())).thenReturn(bodySpecMock);
        Mockito.when(bodySpecMock.bodyValue(Mockito.anyString())).thenReturn(headersSpecMock);

        return responseSpecMock;
    }
}
