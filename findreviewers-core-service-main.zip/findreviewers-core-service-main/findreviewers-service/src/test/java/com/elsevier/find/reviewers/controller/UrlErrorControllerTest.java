package com.elsevier.find.reviewers.controller;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

/**
 * Test the Error controller returns the 404 Not Found error when an invalid URL is entered
 */
public class UrlErrorControllerTest {

    private UrlErrorController controller = new UrlErrorController();

    /**
     * Test that the not found HTTP code is returned
     */
    @Test
    void notFoundMessage() {

        ResponseEntity<String> response = controller.error();

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody(), "Not Null body");
    }
}
