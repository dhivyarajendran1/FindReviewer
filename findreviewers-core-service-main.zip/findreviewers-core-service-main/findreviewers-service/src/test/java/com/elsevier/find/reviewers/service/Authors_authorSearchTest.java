package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.dao.impl.AdditionalInfoDaoImpl.AdditionalInfoResultsExtractor;
import com.elsevier.find.reviewers.dao.impl.AdditionalInfoDaoImpl.InoperativeEmailResultsExtractor;
import com.elsevier.find.reviewers.dao.impl.CandidateInfoDaoImpl.ReviewStatisticsResultsExtractor;
import com.elsevier.find.reviewers.enums.ProductType;
import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.generated.model.AuthorsResponse;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.generated.model.Indicators;
import com.elsevier.find.reviewers.testutils.JdbcMockAnswer;
import com.elsevier.find.reviewers.testutils.TestBase;
import com.elsevier.find.reviewers.utils.CookieManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.data.jdbc.JdbcRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.test.context.TestPropertySource;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.OptionalLong;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@TestPropertySource(properties = {
        "scopussharedsearch.client.base.url=https://localhost/api/"
})
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, JdbcRepositoriesAutoConfiguration.class})
public class Authors_authorSearchTest extends TestBase {
    // Wire to the service that we want to test
    @Autowired
    private AuthorsService authorsService;

    @MockBean(name = "scopussharedsearch")
    private WebClient sharedSearchWebClient;

    @MockBean(name = "httpClient")
    private HttpClient mockHttpClient;

    @Captor
    private ArgumentCaptor<HttpRequest> requestCaptor;

    @BeforeEach
    void setup() {
        SessionContext.initialize(new CookieManager.SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", true, true));
    }

    @Test
    void testNoAuthors() {
        final WebClient.RequestBodyUriSpec bodyUriSpecMock = Mockito.mock(WebClient.RequestBodyUriSpec.class);
        final WebClient.RequestBodySpec bodySpecMock = Mockito.mock(WebClient.RequestBodySpec.class);
        final WebClient.RequestHeadersSpec headersSpecMock = Mockito.mock(WebClient.RequestHeadersSpec.class);
        final WebClient.ResponseSpec responseSpecMock = Mockito.mock(WebClient.ResponseSpec.class);
        Mockito.when(sharedSearchWebClient.post()).thenReturn(bodyUriSpecMock);
        Mockito.when(bodyUriSpecMock.uri(Mockito.anyString())).thenReturn(bodySpecMock);
        Mockito.when(bodySpecMock.header(Mockito.anyString(), Mockito.anyString())).thenReturn(bodySpecMock);
        Mockito.when(bodySpecMock.accept(Mockito.notNull())).thenReturn(bodySpecMock);
        Mockito.when(bodySpecMock.contentType(Mockito.notNull())).thenReturn(bodySpecMock);
        Mockito.when(bodySpecMock.bodyValue(Mockito.anyString())).thenReturn(headersSpecMock);
        Mockito.when(headersSpecMock.retrieve()).thenReturn(responseSpecMock)
                .thenReturn(responseSpecMock).thenReturn(responseSpecMock)
                .thenThrow(new WebClientResponseException(404, "Not Found", null, null, null));
        Mockito.when(responseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("{\"hits\":[]}"))
                .thenReturn(Mono.just("{}")).thenReturn(Mono.just(""));

        ResponseEntity<AuthorsResponse> response =
                authorsService.authorSearch(null, "ACR", "Fred", null, null, null, null, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(0, response.getBody().getAuthors().size());

        response = authorsService.authorSearch(null, "ACR", null, "Flintstone", null, null, null, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(0, response.getBody().getAuthors().size());

        response = authorsService.authorSearch(null, "ACR", "", null, "*Bedrock", null, null, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(0, response.getBody().getAuthors().size());

        response = authorsService.authorSearch(null, "ACR", null, "", "", "fred@bedrock.com", null, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(0, response.getBody().getAuthors().size());
    }

    @Test
    void testInvalidInput() {
        assertThrows(InternalException.class, () -> authorsService.authorSearch(null, "ACR", null, null, null, null, null, null));
        assertThrows(InternalException.class, () -> authorsService.authorSearch(null, "ACR", null, "*last*", null, null, null, null));
    }

    @Test
    void testMessageProcessingError() {
        final WebClient.ResponseSpec sharedSearchSpecMock = createWebClientResponseSpecMock(sharedSearchWebClient);
        Mockito.when(sharedSearchSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("{ invalid json }"));

        InternalException e = assertThrows(InternalException.class, () ->
                authorsService.authorSearch(null, "ACR", null, null, null, "fred@bedrock.com", null, null));
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getHttpStatus(), "Invalid status");
        assertEquals(ErrorResponse.IdEnum.SCOPUSSHAREDSEARCHFAILURE, e.toErrorResponse().getId(), "Invalid error Id");
    }

    @Test
    void testSearchHttpError() {
        final WebClient.RequestBodyUriSpec bodyUriSpecMock = Mockito.mock(WebClient.RequestBodyUriSpec.class);
        final WebClient.RequestBodySpec bodySpecMock = Mockito.mock(WebClient.RequestBodySpec.class);
        final WebClient.RequestHeadersSpec headersSpecMock = Mockito.mock(WebClient.RequestHeadersSpec.class);
        Mockito.when(sharedSearchWebClient.post()).thenReturn(bodyUriSpecMock);
        Mockito.when(bodyUriSpecMock.uri(Mockito.anyString())).thenReturn(bodySpecMock);
        Mockito.when(bodySpecMock.header(Mockito.anyString(), Mockito.anyString())).thenReturn(bodySpecMock);
        Mockito.when(bodySpecMock.accept(Mockito.notNull())).thenReturn(bodySpecMock);
        Mockito.when(bodySpecMock.contentType(Mockito.notNull())).thenReturn(bodySpecMock);
        Mockito.when(bodySpecMock.bodyValue(Mockito.contains("authlast:Flintstone*"))).thenReturn(headersSpecMock);
        Mockito.when(bodySpecMock.bodyValue(Mockito.contains("authemail:\\\"fred@bedrock.com\\\""))).thenReturn(headersSpecMock);
        Mockito.when(bodySpecMock.bodyValue(Mockito.contains("afdispname:\\\"Bedrock\\\""))).thenReturn(headersSpecMock);
        Mockito.when(headersSpecMock.retrieve()).thenThrow(new WebClientResponseException(404, "Not Found", null, null, null))
                .thenThrow(new WebClientResponseException(500, "Internal Error", null, null, null))
                .thenThrow(new RuntimeException());

        // First HTTP exception is not-found that will just be handled normally with no publications
        ResponseEntity<AuthorsResponse> response =
                authorsService.authorSearch(null, "ACR", null, "Flintstone*", "Bed*rock", "", null, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(0, response.getBody().getAuthors().size());

        InternalException e = assertThrows(InternalException.class, () ->
                authorsService.authorSearch(null, "ACR", "Fred", null, null, "fred@bedrock.com", null, null));
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getHttpStatus(), "Invalid status");
        assertEquals(ErrorResponse.IdEnum.SCOPUSSHAREDSEARCHFAILURE, e.toErrorResponse().getId(), "Invalid error Id");

        e = assertThrows(InternalException.class, () ->
                authorsService.authorSearch(null, "ACR", null, "Flintstone", "Bedrock", null, null, null));
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getHttpStatus(), "Invalid status");
        assertEquals(ErrorResponse.IdEnum.SCOPUSSHAREDSEARCHFAILURE, e.toErrorResponse().getId(), "Invalid error Id");
    }

    @Test
    void testSingleSearchResultWithAdditionalInfo() throws IOException, InterruptedException, SQLException {
        final String author = "{\"authid\":\"000000800\",\"authemail\":\"fred@bedrock.com\"," +
                "\"preffirst\":\"Fred\",\"authlast\":\"Flintstone\"," +
                "\"afdispname\":[\"Bedrock Uni\"],\"afdispcity\":\"Red Rock\",\"afdispctry\":\"Bedrock\"," +
                "\"count\":182,\"hindex\":24, \"citedby\":19}";

        final WebClient.ResponseSpec sharedSearchSpecMock = createWebClientResponseSpecMock(sharedSearchWebClient);
        Mockito.when(sharedSearchSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("{\"hits\":[" + author + "]}"));

        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(Map.ofEntries(
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("volunteer", false),
                Map.entry("unavailability", "-null-"),
                Map.entry("concurrent_review_limit", 100),
                Map.entry("this_recently_accepted_author", true),
                Map.entry("other_recently_accepted_author", false)));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(AdditionalInfoResultsExtractor.class))).thenAnswer(mockAnswer);

        JdbcMockAnswer mockEmAnswer = new JdbcMockAnswer();
        mockEmAnswer.addResultMapping(Map.ofEntries(
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("journal_acronym", "ACR"),
                Map.entry("rstop", OptionalLong.empty()),
                Map.entry("work_in_progress", true),
                Map.entry("declined", true),
                Map.entry("terminated", true),
                Map.entry("completed", true),
                Map.entry("uninvited", true),
                Map.entry("assigned_not_invited", true)));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(ReviewStatisticsResultsExtractor.class))).thenAnswer(mockEmAnswer);

        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(200);
        Mockito.when(mockTokenResponse.body()).thenReturn("[]");
        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        ResponseEntity<AuthorsResponse> response =
                authorsService.authorSearch(null, null, null, "Flintstone", null, null, null, null);

        Mockito.verify(mockHttpClient, Mockito.times(1)).send(requestCaptor.capture(),
                Mockito.any(HttpResponse.BodyHandler.class));
        assertTrue(requestCaptor.getValue().uri().toString().endsWith("/blocked-reviewers?em-acronym=DUMMY&reviewers=fred%40bedrock.com"), "Incorrect URL");
        assertEquals("GET", requestCaptor.getValue().method());

        assertNull(mockAnswer.getParameter("emJournalAcronym", String.class));
        assertEquals(List.of("fred@bedrock.com"), mockAnswer.getParameter("emails", List.class));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(1, response.getBody().getAuthors().size());
        assertEquals("000000800", response.getBody().getAuthors().get(0).getScopusIds().get(0));
        assertEquals("fred@bedrock.com", response.getBody().getAuthors().get(0).getEmails().get(0));
        assertEquals("Fred Flintstone", response.getBody().getAuthors().get(0).getDisplayName());
        assertEquals("Fred", response.getBody().getAuthors().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getAuthors().get(0).getLastName());
        assertEquals("Bedrock Uni", response.getBody().getAuthors().get(0).getAffiliationName());
        assertEquals("Red Rock", response.getBody().getAuthors().get(0).getAffiliationCity());
        assertEquals("Bedrock", response.getBody().getAuthors().get(0).getAffiliationCountry());
        assertEquals(182, response.getBody().getAuthors().get(0).getPublicationCount());
        assertEquals(19, response.getBody().getAuthors().get(0).getCitationCount());
        assertEquals(24, response.getBody().getAuthors().get(0).getHindex());
        assertEquals(1, response.getBody().getAuthors().get(0).getIndicators().size());
        assertEquals(Indicators.RECENTLYACCEPTEDAUTHORTHISJOURNAL, response.getBody().getAuthors().get(0).getIndicators().get(0));
        assertNull(response.getBody().getAuthors().get(0).getKeywordMatchCount());

        assertEquals(1, response.getBody().getAuthors().get(0).getReviewStatistics().size());
        assertEquals("ACR", response.getBody().getAuthors().get(0).getReviewStatistics().get(0).getEmJournalAcronym());
        assertEquals(1, response.getBody().getAuthors().get(0).getReviewStatistics().get(0).getInvitationCount());
        assertEquals(0, response.getBody().getAuthors().get(0).getReviewStatistics().get(0).getWorkInProgressCount());
        assertEquals(1, response.getBody().getAuthors().get(0).getReviewStatistics().get(0).getCompletedCount());
        assertNull(response.getBody().getAuthors().get(0).getReviewStatistics().get(0).getMostRecentCompleted());
    }

    @Test
    void testMultipleSearchResult() throws IOException, InterruptedException, SQLException {
        final String author1 = "{\"authid\":\"000000800\",\"authemail\":\"fred@bedrock.com\"," +
                "\"authlast\":\"Flintstone\",\"authfirst\": \"Fred, F. | Fred\"," +
                "\"afdispname\":[\"Bedrock Uni\"],\"afdispcity\":\"Red Rock\",\"afdispctry\":\"Bedrock\"," +
                "\"count\":182,\"citedby\":39}";

        final String author2 = "{\"authid\":\"000000900\",\"authemail\":\"wilma@bedrock.com\"," +
                "\"afdispcity\":\"Red Rock\",\"afdispctry\":\"Bedrock\"," +
                "\"count\":182,\"h_index\":3}";

        final String author3 = "{\"authid\":\"000000700\",\"authemail\":\"barney@bedrock.com\"," +
                "\"preffirst\":\"\", \"authfirst\":\"\", \"authlast\":\"\"," +
                "\"afdispname\":[],\"afdispcity\":\"Red Rock\",\"afdispctry\":\"Bedrock\"}";

        final String author4 = "{\"preffirst\":\"Missing Email\"}";

        final String author5 = "{\"preffirst\":\"Missing Email\",\"authemail\":\"\"}";

        final WebClient.ResponseSpec sharedSearchSpecMock = createWebClientResponseSpecMock(sharedSearchWebClient);
        Mockito.when(sharedSearchSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("{\"hits\":[" +
                author1 + ", " + author2 + ", " + author3 + ", " + author4 + ", " + author5 + "]}"));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(AdditionalInfoResultsExtractor.class))).thenAnswer(new JdbcMockAnswer());

        JdbcMockAnswer mockStatsAnswer = new JdbcMockAnswer();
        mockStatsAnswer.addResultMapping(Map.ofEntries(
                        Map.entry("email", "fred@bedrock.com"),
                        Map.entry("journal_acronym", "ACR1"),
                        Map.entry("rstop", 1589809511783L),
                        Map.entry("work_in_progress", false),
                        Map.entry("declined", false),
                        Map.entry("terminated", false),
                        Map.entry("completed", true),
                        Map.entry("uninvited", false),
                        Map.entry("assigned_not_invited", false)),
                Map.ofEntries(
                        Map.entry("email", "fred@bedrock.com"),
                        Map.entry("journal_acronym", "ACR1"),
                        Map.entry("rstop", 1589809511800L),
                        Map.entry("work_in_progress", false),
                        Map.entry("declined", false),
                        Map.entry("terminated", false),
                        Map.entry("completed", true),
                        Map.entry("uninvited", false),
                        Map.entry("assigned_not_invited", false)),
                Map.ofEntries(
                        Map.entry("email", "fred@bedrock.com"),
                        Map.entry("journal_acronym", "ACR2"),
                        Map.entry("rstop", 1589809511783L),
                        Map.entry("work_in_progress", false),
                        Map.entry("declined", false),
                        Map.entry("terminated", false),
                        Map.entry("completed", true),
                        Map.entry("uninvited", false),
                        Map.entry("assigned_not_invited", false)));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(ReviewStatisticsResultsExtractor.class))).thenAnswer(mockStatsAnswer);

        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(500);
        Mockito.when(mockTokenResponse.body()).thenReturn("{\"Message\": \"Error message\"}");
        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        ResponseEntity<AuthorsResponse> response =
                authorsService.authorSearch(null, "ACR", null, "Flintstone", "Bedrock Uni", null, "", null);

        Mockito.verify(mockHttpClient, Mockito.times(2)).send(requestCaptor.capture(),
                Mockito.any(HttpResponse.BodyHandler.class));
        assertTrue(requestCaptor.getValue().uri().toString().endsWith("/blocked-reviewers?em-acronym=ACR&reviewers=fred%40bedrock.com%2Cwilma%40bedrock.com%2Cbarney%40bedrock.com"), "Incorrect URL");
        assertEquals("GET", requestCaptor.getValue().method());

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(3, response.getBody().getAuthors().size());
        assertEquals("000000800", response.getBody().getAuthors().get(0).getScopusIds().get(0));
        assertEquals("fred@bedrock.com", response.getBody().getAuthors().get(0).getEmails().get(0));
        assertEquals("Fred, F. Flintstone", response.getBody().getAuthors().get(0).getDisplayName());
        assertEquals("Fred, F.", response.getBody().getAuthors().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getAuthors().get(0).getLastName());
        assertEquals("Bedrock Uni", response.getBody().getAuthors().get(0).getAffiliationName());
        assertEquals("Red Rock", response.getBody().getAuthors().get(0).getAffiliationCity());
        assertEquals("Bedrock", response.getBody().getAuthors().get(0).getAffiliationCountry());
        assertEquals(182, response.getBody().getAuthors().get(0).getPublicationCount());
        assertNull(response.getBody().getAuthors().get(0).getHindex(), "Invalid hIndex");
        assertNull(response.getBody().getAuthors().get(0).getIndicators());
        assertNull(response.getBody().getAuthors().get(0).getKeywordMatchCount());

        assertEquals(2, response.getBody().getAuthors().get(0).getReviewStatistics().size());
        assertEquals("ACR1", response.getBody().getAuthors().get(0).getReviewStatistics().get(0).getEmJournalAcronym());
        assertEquals(2, response.getBody().getAuthors().get(0).getReviewStatistics().get(0).getInvitationCount());
        assertEquals(0, response.getBody().getAuthors().get(0).getReviewStatistics().get(0).getWorkInProgressCount());
        assertEquals(2, response.getBody().getAuthors().get(0).getReviewStatistics().get(0).getCompletedCount());
        assertEquals(1589809511800L, response.getBody().getAuthors().get(0).getReviewStatistics().get(0).getMostRecentCompleted());
        assertEquals("ACR2", response.getBody().getAuthors().get(0).getReviewStatistics().get(1).getEmJournalAcronym());
        assertEquals(1, response.getBody().getAuthors().get(0).getReviewStatistics().get(1).getInvitationCount());
        assertEquals(0, response.getBody().getAuthors().get(0).getReviewStatistics().get(1).getWorkInProgressCount());
        assertEquals(1, response.getBody().getAuthors().get(0).getReviewStatistics().get(1).getCompletedCount());
        assertEquals(1589809511783L, response.getBody().getAuthors().get(0).getReviewStatistics().get(1).getMostRecentCompleted());

        assertEquals("000000900", response.getBody().getAuthors().get(1).getScopusIds().get(0));
        assertEquals("wilma@bedrock.com", response.getBody().getAuthors().get(1).getEmails().get(0));
        assertNull(response.getBody().getAuthors().get(1).getDisplayName());
        assertNull(response.getBody().getAuthors().get(1).getFirstName());
        assertNull(response.getBody().getAuthors().get(1).getLastName(), "Invalid Last Name");
        assertNull(response.getBody().getAuthors().get(1).getAffiliationName());
        assertEquals("Red Rock", response.getBody().getAuthors().get(1).getAffiliationCity());
        assertEquals("Bedrock", response.getBody().getAuthors().get(1).getAffiliationCountry());
        assertEquals(182, response.getBody().getAuthors().get(1).getPublicationCount());
        assertNull(response.getBody().getAuthors().get(1).getHindex());
        assertNull(response.getBody().getAuthors().get(1).getIndicators());
        assertNull(response.getBody().getAuthors().get(1).getKeywordMatchCount());
        assertNull(response.getBody().getAuthors().get(1).getReviewStatistics());

        assertEquals("000000700", response.getBody().getAuthors().get(2).getScopusIds().get(0));
        assertEquals("barney@bedrock.com", response.getBody().getAuthors().get(2).getEmails().get(0));
        assertNull(response.getBody().getAuthors().get(2).getDisplayName());
        assertNull(response.getBody().getAuthors().get(2).getFirstName());
        assertNull(response.getBody().getAuthors().get(2).getLastName(), "Invalid Last Name");
        assertNull(response.getBody().getAuthors().get(2).getAffiliationName());
        assertEquals("Red Rock", response.getBody().getAuthors().get(2).getAffiliationCity());
        assertEquals("Bedrock", response.getBody().getAuthors().get(2).getAffiliationCountry());
        assertNull(response.getBody().getAuthors().get(2).getPublicationCount());
        assertNull(response.getBody().getAuthors().get(2).getHindex());
        assertNull(response.getBody().getAuthors().get(2).getIndicators());
        assertNull(response.getBody().getAuthors().get(2).getKeywordMatchCount());
        assertNull(response.getBody().getAuthors().get(2).getReviewStatistics());
    }

    @Test
    void testSingleSearchResultWithContentMatches() throws SQLException {
        // Non-Elsevier journal, so will not call blocklist
        SessionContext.initialize(new CookieManager.SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", true, false));

        final String author = "{\"authid\":\"000000800\",\"authemail\":\"fred@bedrock.com\"," +
                "\"preffirst\":\"Fred\",\"authlast\":\"Flintstone\"," +
                "\"afdispname\":[\"Bedrock Uni\"],\"afdispcity\":\"Red Rock\",\"afdispctry\":\"Bedrock\"," +
                "\"count\":182,\"hindex\":24, \"citedby\":19}";

        final WebClient.ResponseSpec sharedSearchSpecMock = createWebClientResponseSpecMock(sharedSearchWebClient);
        Mockito.when(sharedSearchSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("{\"hits\":[" + author + "]}"))
                .thenReturn(Mono.just("{\"totalResultsCount\": 1, \"hits\": [{\"eid\": \"1\", \"authors\": [{\"authid\": \"000000800\"}]}]}"));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(ReviewStatisticsResultsExtractor.class))).thenAnswer(new JdbcMockAnswer());

        ResponseEntity<AuthorsResponse> response =
                authorsService.authorSearch(null, "ACR", null, "Flintstone", null, null, "keyword", null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(1, response.getBody().getAuthors().size());
        assertEquals("000000800", response.getBody().getAuthors().get(0).getScopusIds().get(0));
        assertEquals("fred@bedrock.com", response.getBody().getAuthors().get(0).getEmails().get(0));
        assertEquals("Fred Flintstone", response.getBody().getAuthors().get(0).getDisplayName());
        assertEquals("Fred", response.getBody().getAuthors().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getAuthors().get(0).getLastName());
        assertEquals("Bedrock Uni", response.getBody().getAuthors().get(0).getAffiliationName());
        assertEquals("Red Rock", response.getBody().getAuthors().get(0).getAffiliationCity());
        assertEquals("Bedrock", response.getBody().getAuthors().get(0).getAffiliationCountry());
        assertEquals(182, response.getBody().getAuthors().get(0).getPublicationCount());
        assertEquals(19, response.getBody().getAuthors().get(0).getCitationCount());
        assertEquals(24, response.getBody().getAuthors().get(0).getHindex());
        assertNull(response.getBody().getAuthors().get(0).getIndicators());
        assertNull(response.getBody().getAuthors().get(0).getReviewStatistics());
        assertEquals(1, response.getBody().getAuthors().get(0).getKeywordMatchCount());
    }

    @Test
    void testInoperativeEmailNonElsevier() throws SQLException {
        SessionContext.initialize(new CookieManager.SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", true, false));

        final String author1 = "{\"authid\":\"000000800\",\"authemail\":\"fred@bedrock.com\"," +
                "\"preffirst\":\"Fred\",\"authlast\":\"Flintstone\"," +
                "\"afdispname\":[\"Bedrock Uni\"],\"afdispcity\":\"Red Rock\",\"afdispctry\":\"Bedrock\"," +
                "\"count\":182,\"hindex\":24, \"citedby\":19}";

        final String author2 = "{\"authid\":\"000000900\",\"authemail\":\"wilma@bedrock.com\"," +
                "\"preffirst\":\"Wilma\",\"authlast\":\"Flintstone\"," +
                "\"afdispname\":[\"Rock Uni\"],\"afdispcity\":\"Pink Rock\",\"afdispctry\":\"Rocky\"," +
                "\"count\":100,\"hindex\":30, \"citedby\":20}";

        final WebClient.ResponseSpec sharedSearchSpecMock = createWebClientResponseSpecMock(sharedSearchWebClient);
        Mockito.when(sharedSearchSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("{\"hits\":[" + author1 + "," + author2 + "]}"));

        // Inoperative email for Fred
        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(Map.ofEntries(Map.entry("email", "fred@bedrock.com")));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(InoperativeEmailResultsExtractor.class))).thenAnswer(mockAnswer);

        ResponseEntity<AuthorsResponse> response =
                authorsService.authorSearch(null, "ACR", null, "Flintstone", null, null, "keyword", null);

        assertEquals(List.of("fred@bedrock.com", "wilma@bedrock.com"), mockAnswer.getParameter("emails", List.class));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(1, response.getBody().getAuthors().size());
        assertEquals("000000900", response.getBody().getAuthors().get(0).getScopusIds().get(0));
        assertEquals("wilma@bedrock.com", response.getBody().getAuthors().get(0).getEmails().get(0));
        assertEquals("Wilma Flintstone", response.getBody().getAuthors().get(0).getDisplayName());
        assertEquals("Wilma", response.getBody().getAuthors().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getAuthors().get(0).getLastName());
        assertEquals("Rock Uni", response.getBody().getAuthors().get(0).getAffiliationName());
        assertEquals("Pink Rock", response.getBody().getAuthors().get(0).getAffiliationCity());
        assertEquals("Rocky", response.getBody().getAuthors().get(0).getAffiliationCountry());
        assertEquals(100, response.getBody().getAuthors().get(0).getPublicationCount());
        assertEquals(20, response.getBody().getAuthors().get(0).getCitationCount());
        assertEquals(30, response.getBody().getAuthors().get(0).getHindex());
        assertNull(response.getBody().getAuthors().get(0).getIndicators());
        assertNull(response.getBody().getAuthors().get(0).getReviewStatistics());
        assertNull(response.getBody().getAuthors().get(0).getKeywordMatchCount());
    }
}
