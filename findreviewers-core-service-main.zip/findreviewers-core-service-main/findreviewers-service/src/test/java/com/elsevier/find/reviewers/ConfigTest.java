package com.elsevier.find.reviewers;

import com.elsevier.find.reviewers.config.ApplicationConfig;
import com.elsevier.find.reviewers.config.ApplicationConfig.TrustManagerWithoutCertificateCheck;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.net.ssl.SSLEngine;
import java.net.Socket;
import java.security.GeneralSecurityException;
import java.security.cert.X509Certificate;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(SpringExtension.class)
public class ConfigTest {
    @TestConfiguration
    static class ContextConfiguration {
        @Bean
        public ApplicationConfig appConfig() {
            return new ApplicationConfig();
        }
    }

    @Autowired
    private ApplicationConfig appConfig;

    @Test
    void testSqsClient() {
        assertNotNull(appConfig.sqsClient("test-region", null), "Default SQS is null");

        assertNotNull(appConfig.sqsClient("test-region", "http://test_endpoint:123"), "Altered SQS is null");
    }

    @Test
    void testDynamoDbEnhancedClient() {
        assertNotNull(appConfig.dynamoDbEnhancedClient("test-region", null), "Default SQS is null");

        assertNotNull(appConfig.dynamoDbEnhancedClient("test-region", "http://test_endpoint:123"), "Altered SQS is null");
    }

    @Test
    void testHttpClientWithoutCertificateCheck() throws GeneralSecurityException {
        // Make sure there is never an exception
        TrustManagerWithoutCertificateCheck tm = new ApplicationConfig.TrustManagerWithoutCertificateCheck();
        tm.checkClientTrusted((X509Certificate[]) null, (String) null, (Socket) null);
        tm.checkServerTrusted((X509Certificate[]) null, (String) null, (Socket) null);
        tm.checkClientTrusted((X509Certificate[]) null, (String) null, (SSLEngine) null);
        tm.checkServerTrusted((X509Certificate[]) null, (String) null, (SSLEngine) null);
        tm.checkClientTrusted((X509Certificate[]) null, (String) null);
        tm.checkServerTrusted((X509Certificate[]) null, (String) null);
        assertNotNull(tm.getAcceptedIssuers());
    }
}
