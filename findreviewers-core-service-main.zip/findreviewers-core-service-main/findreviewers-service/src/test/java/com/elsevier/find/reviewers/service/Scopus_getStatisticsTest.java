package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.generated.model.ScopusStatisticsResponse;
import com.elsevier.find.reviewers.testutils.TestBase;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.data.jdbc.JdbcRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, JdbcRepositoriesAutoConfiguration.class})
public class Scopus_getStatisticsTest extends TestBase {
    // Wire to the service that we want to test
    @Autowired
    private ScopusService scopusService;

    @MockBean(name = "scopusgraph")
    private WebClient webClient;

    @Test
    void testNoStatistics() {
        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(webClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just("{\"data\": {}}"))
                .thenReturn(Mono.just("{\"data\": {\"person\": {}}}"))
                .thenReturn(Mono.just("{\"data\": {\"person\": null}}"))
                .thenReturn(Mono.just("{\"data\": {\"person\": {\"annualAuthorOf\":[]}}}"))
                .thenReturn(Mono.just("{\"data\": {\"person\": {\"annualReferencedBy\":[]}}}"));

        for (int i = 0; i < 6; i++) {
            ResponseEntity<ScopusStatisticsResponse> response = scopusService.getStatistics("123", null);

            assertNotNull(response, "Null Response");
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertNotNull(response.getBody(), "Body not valid");
            assertNull(response.getBody().getStatistics());
        }
    }

    @Test
    void testInvalidInput() {
        assertThrows(InternalException.class, () -> scopusService.getStatistics(null, null));
        assertThrows(InternalException.class, () -> scopusService.getStatistics("", null));
    }

    @Test
    void testErrorReturn() {
        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(webClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class))
                .thenReturn(null)
                .thenReturn(Mono.empty())
                .thenReturn(Mono.just(""))
                .thenReturn(Mono.just("{}"))
                .thenReturn(Mono.just("{\"error\": {}}"))
                .thenReturn(Mono.just("Invalid JSON"));

        for (int i = 0; i < 6; i++) {
            InternalException e = assertThrows(InternalException.class, () -> scopusService.getStatistics("123", null));
            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getHttpStatus(), "Invalid status");
            assertEquals(ErrorResponse.IdEnum.SCOPUSGRAPHFAILURE, e.toErrorResponse().getId(), "Invalid error Id");
        }
    }

    @Test
    void testPublicationStatistics() {
        String graphReturn = """
                {
                	"data": {
                		"person": {
                			"annualAuthorOf": [
                				{"startYear": "2020", "count": 47 },
                				{"startYear": "2022", "count": 33 },
                				{"startYear": "2021", "count": 41 },
                				{"startYear": "2018", "count": 24 },
                				{"startYear": "1975", "count": 0 },
                				{"startYear": "1976", "count": null }
                			],
                			"annualReferencedBy": [
                				{"startYear": "2023","count": 317},
                				{"startYear": "2021","count": 965},
                				{"startYear": "2022","count": 1095},
                				{"startYear": "2020","count": 899},
                				{"startYear": "2019","count": 765},
                				{"startYear": "1975", "count": 0 },
                				{"startYear": "1976", "count": null }
                			]
                		}
                	}
                }
                """;

        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(webClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just(graphReturn));

        ResponseEntity<ScopusStatisticsResponse> response = scopusService.getStatistics("123", null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(6, response.getBody().getStatistics().size());

        assertEquals(2018, response.getBody().getStatistics().get(0).getYear());
        assertEquals(24, response.getBody().getStatistics().get(0).getPublishedCount());
        assertNull(response.getBody().getStatistics().get(0).getCitationsCount());

        assertEquals(2019, response.getBody().getStatistics().get(1).getYear());
        assertNull(response.getBody().getStatistics().get(1).getPublishedCount());
        assertEquals(765, response.getBody().getStatistics().get(1).getCitationsCount());

        assertEquals(2020, response.getBody().getStatistics().get(2).getYear());
        assertEquals(47, response.getBody().getStatistics().get(2).getPublishedCount());
        assertEquals(899, response.getBody().getStatistics().get(2).getCitationsCount());

        assertEquals(2021, response.getBody().getStatistics().get(3).getYear());
        assertEquals(41, response.getBody().getStatistics().get(3).getPublishedCount());
        assertEquals(965, response.getBody().getStatistics().get(3).getCitationsCount());

        assertEquals(2022, response.getBody().getStatistics().get(4).getYear());
        assertEquals(33, response.getBody().getStatistics().get(4).getPublishedCount());
        assertEquals(1095, response.getBody().getStatistics().get(4).getCitationsCount());

        assertEquals(2023, response.getBody().getStatistics().get(5).getYear());
        assertNull(response.getBody().getStatistics().get(5).getPublishedCount());
        assertEquals(317, response.getBody().getStatistics().get(5).getCitationsCount());
    }
}
