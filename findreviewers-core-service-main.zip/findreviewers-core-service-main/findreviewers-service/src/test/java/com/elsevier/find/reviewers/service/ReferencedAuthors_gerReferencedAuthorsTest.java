package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.dao.impl.AdditionalInfoDaoImpl.AdditionalInfoResultsExtractor;
import com.elsevier.find.reviewers.dao.impl.CandidateInfoDaoImpl.ReviewStatisticsResultsExtractor;
import com.elsevier.find.reviewers.enums.ProductType;
import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.generated.model.Indicators;
import com.elsevier.find.reviewers.generated.model.ReferencedAuthorsResponse;
import com.elsevier.find.reviewers.testutils.JdbcMockAnswer;
import com.elsevier.find.reviewers.testutils.TestBase;
import com.elsevier.find.reviewers.utils.CookieManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.data.jdbc.JdbcRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, JdbcRepositoriesAutoConfiguration.class})
public class ReferencedAuthors_gerReferencedAuthorsTest extends TestBase {
    @Autowired
    private ReferencedAuthorsService referencedAuthorsService;

    @MockBean(name = "personfinder")
    private WebClient personFinderWebClient;

    @MockBean(name = "scopussharedsearch")
    private WebClient sharedSearchWebClient;

    @MockBean(name = "httpClient")
    private HttpClient mockHttpClient;

    @BeforeEach
    void setup() {
        SessionContext.initialize(new CookieManager.SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", false, true));
    }

    @Test
    void testInvalidInput() {
        assertThrows(InternalException.class, () -> referencedAuthorsService.getReferencedAuthors(null, 1L, null, null, null));
        assertThrows(InternalException.class, () -> referencedAuthorsService.getReferencedAuthors("", 1L, null, null, null));
        assertThrows(InternalException.class, () -> referencedAuthorsService.getReferencedAuthors(" ", 1L, null, null, null));
        assertThrows(InternalException.class, () -> referencedAuthorsService.getReferencedAuthors("NO_DOC_ID", null, null, null, null));

        SessionContext.initialize(new CookieManager.SessionData(ProductType.FindReviewers, "Non-URSDB", "bearer", "ACR", false, false));
        ResponseEntity<ReferencedAuthorsResponse> response = referencedAuthorsService.getReferencedAuthors("ACR", 1L, null, null, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertNull(response.getBody().getReferencedAuthors());
    }

    @Test
    void testNoReferences() throws SQLException {
        JdbcMockAnswer jdbcMockAnswer1 = new JdbcMockAnswer();
        JdbcMockAnswer jdbcMockAnswer2 = new JdbcMockAnswer();
        jdbcMockAnswer2.addResultMapping(Map.of("refs", ""));
        JdbcMockAnswer jdbcMockAnswer3 = new JdbcMockAnswer();
        jdbcMockAnswer3.addResultMapping(Map.of("refs", "<xml>no references</xml>"));
        JdbcMockAnswer jdbcMockAnswer4 = new JdbcMockAnswer();
        jdbcMockAnswer4.addResultMapping(Map.of("refs", "<emptyReference><pub-id pub-id-type=\"doi\"></pub-id><pub-id pub-id-type=\"doi\">  </pub-id></emptyReference>"));

        Mockito.when(coreDb.query(Mockito.anyString(), Mockito.any(SqlParameterSource.class), Mockito.any(RowMapper.class)))
                .thenAnswer(jdbcMockAnswer1)
                .thenAnswer(jdbcMockAnswer2)
                .thenAnswer(jdbcMockAnswer3)
                .thenAnswer(jdbcMockAnswer4);

        for (int i = 0; i < 4; i++) {
            ResponseEntity<ReferencedAuthorsResponse> response = referencedAuthorsService.getReferencedAuthors("ACR", 1L, null, null, null);

            assertNotNull(response, "Null Response");
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertNotNull(response.getBody(), "Body not valid");
            assertNull(response.getBody().getReferencedAuthors());
        }
    }

    @Test
    void testReferencesInvalidResponse() throws SQLException {
        JdbcMockAnswer jdbcMockAnswer = new JdbcMockAnswer();
        jdbcMockAnswer.addResultMapping(Map.of("refs", "<xml><pub-id pub-id-type=\"doi\">doi:10.1016/j.jdeveco.2016.08.003</pub-id></xml>"));

        Mockito.when(coreDb.query(Mockito.anyString(), Mockito.any(SqlParameterSource.class), Mockito.any(RowMapper.class)))
                .thenAnswer(jdbcMockAnswer);

        final WebClient.ResponseSpec sharedSearchSpecMock = createWebClientResponseSpecMock(sharedSearchWebClient);
        Mockito.when(sharedSearchSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("{ Invalid Json }"));

        assertThrows(InternalException.class, () -> referencedAuthorsService.getReferencedAuthors("ACR", 1L, null, null, null));
    }

    @Test
    void testReferencesWithoutAuthorIds() throws SQLException {
        final WebClient.ResponseSpec sharedSearchSpecMock = createWebClientResponseSpecMock(sharedSearchWebClient);
        Mockito.when(sharedSearchSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just(""))
                .thenReturn(Mono.just("{}"))
                .thenReturn(Mono.just("{\"hits\":[]}"))
                .thenReturn(Mono.just("{\"hits\":[{}]}"))
                .thenReturn(Mono.just("{\"hits\":[{\"authors\": []}]}"))
                .thenReturn(Mono.just("{\"hits\":[{\"authors\": [{\"authid\": \"NO_EMAIL\"}]}]}"))
                .thenReturn(Mono.just("{\"hits\":[{\"authors\": [{\"authemail\": \"no_authId@here.com\"}]}]}"));

        for (int i = 0; i < 7; i++) {
            JdbcMockAnswer jdbcMockAnswer = new JdbcMockAnswer();
            jdbcMockAnswer.addResultMapping(Map.of("refs", "<xml><pub-id pub-id-type=\"doi\">doi:10.1016/j.jdeveco.2016.08.003</pub-id></xml>"));

            Mockito.when(coreDb.query(Mockito.anyString(), Mockito.any(SqlParameterSource.class), Mockito.any(RowMapper.class)))
                    .thenAnswer(jdbcMockAnswer);

            ResponseEntity<ReferencedAuthorsResponse> response = referencedAuthorsService.getReferencedAuthors("ACR", 1L, null, null, null);

            assertNotNull(response, "Null Response");
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertNotNull(response.getBody(), "Body not valid");
            assertNull(response.getBody().getReferencedAuthors());
        }
    }

    @Test
    void testReferencesHttpNotFound() throws SQLException {
        JdbcMockAnswer jdbcMockAnswer = new JdbcMockAnswer();
        jdbcMockAnswer.addResultMapping(Map.of("refs", "<xml><pub-id pub-id-type=\"doi\">doi:10.1016/j.jdeveco.2016.08.003&lt;3&gt;</pub-id></xml>"));

        Mockito.when(coreDb.query(Mockito.anyString(), Mockito.any(SqlParameterSource.class), Mockito.any(RowMapper.class)))
                .thenAnswer(jdbcMockAnswer);

        final WebClient.RequestBodyUriSpec bodyUriSpecMock = Mockito.mock(WebClient.RequestBodyUriSpec.class);
        final WebClient.RequestBodySpec bodySpecMock = Mockito.mock(WebClient.RequestBodySpec.class);
        final WebClient.RequestHeadersSpec headersSpecMock = Mockito.mock(WebClient.RequestHeadersSpec.class);
        Mockito.when(sharedSearchWebClient.post()).thenReturn(bodyUriSpecMock);
        Mockito.when(bodyUriSpecMock.uri(Mockito.anyString())).thenReturn(bodySpecMock);
        Mockito.when(bodySpecMock.header(Mockito.anyString(), Mockito.anyString())).thenReturn(bodySpecMock);
        Mockito.when(bodySpecMock.accept(Mockito.notNull())).thenReturn(bodySpecMock);
        Mockito.when(bodySpecMock.contentType(Mockito.notNull())).thenReturn(bodySpecMock);
        Mockito.when(bodySpecMock.bodyValue(Mockito.contains("doi:10.1016/j.jdeveco.2016.08.003<3>"))).thenReturn(headersSpecMock);
        Mockito.when(headersSpecMock.retrieve()).thenThrow(new WebClientResponseException(404, "Not Found", null, null, null));

        ResponseEntity<ReferencedAuthorsResponse> response = referencedAuthorsService.getReferencedAuthors("ACR", 1L, null, null, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertNull(response.getBody().getReferencedAuthors());
    }

    @Test
    void testReferencesWithAuthorIds() throws SQLException, IOException, InterruptedException {
        JdbcMockAnswer jdbcMockAnswer = new JdbcMockAnswer();
        jdbcMockAnswer.addResultMapping(Map.of("refs", "<xml><pub-id pub-id-type=\"doi\">doi:10.1016/j.jdeveco.2016.08.003</pub-id></xml>"));

        Mockito.when(coreDb.query(Mockito.anyString(), Mockito.any(SqlParameterSource.class), Mockito.any(RowMapper.class)))
                .thenAnswer(jdbcMockAnswer);

        final WebClient.ResponseSpec sharedSearchSpecMock = createWebClientResponseSpecMock(sharedSearchWebClient);
        Mockito.when(sharedSearchSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just("""
                        {"hits":[{"authors": [{"authid": "000000800", "authemail": "fred@bedrock.com"}]}]}"))
                        """));

        final String author = """
                [{"authid":"000000800","preffirst":"Fred","authlast":"Flintstone",
                 "afdispname":"Bedrock Uni","afdispcity":"Red Rock",
                 "afdispctry":"Bedrock","count":182,"h_index":"24", "num_cited_by":"76"}]
                """;
        final WebClient.ResponseSpec personFinderResponseSpecMock = createWebClientResponseSpecMock(personFinderWebClient);
        Mockito.when(personFinderResponseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just(author));

        JdbcMockAnswer mockEmReviewHistoryAnswer = new JdbcMockAnswer();
        mockEmReviewHistoryAnswer.addResultMapping(Map.ofEntries(
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("journal_acronym", "ACR"),
                Map.entry("rstop", 1589809511783L),
                Map.entry("work_in_progress", false),
                Map.entry("declined", false),
                Map.entry("terminated", false),
                Map.entry("completed", false),
                Map.entry("uninvited", true),
                Map.entry("assigned_not_invited", false)));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(ReviewStatisticsResultsExtractor.class))).thenAnswer(mockEmReviewHistoryAnswer);

        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(Map.ofEntries(
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("volunteer", false),
                Map.entry("unavailability", "-null-"),
                Map.entry("concurrent_review_limit", 100),
                Map.entry("this_recently_accepted_author", true),
                Map.entry("other_recently_accepted_author", false)));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(AdditionalInfoResultsExtractor.class))).thenAnswer(mockAnswer);

        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(200);
        Mockito.when(mockTokenResponse.body()).thenReturn("[]");
        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        ResponseEntity<ReferencedAuthorsResponse> response = referencedAuthorsService.getReferencedAuthors("ACR", 1L, null, null, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertEquals(1, response.getBody().getReferencedAuthors().size());
        assertEquals("000000800", response.getBody().getReferencedAuthors().get(0).getScopusIds().get(0));
        assertEquals("fred@bedrock.com", response.getBody().getReferencedAuthors().get(0).getEmails().get(0));
        assertEquals("Fred Flintstone", response.getBody().getReferencedAuthors().get(0).getDisplayName());
        assertEquals("Fred", response.getBody().getReferencedAuthors().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getReferencedAuthors().get(0).getLastName());
        assertEquals("Bedrock Uni", response.getBody().getReferencedAuthors().get(0).getAffiliationName());
        assertEquals("Red Rock", response.getBody().getReferencedAuthors().get(0).getAffiliationCity());
        assertEquals("Bedrock", response.getBody().getReferencedAuthors().get(0).getAffiliationCountry());
        assertEquals(182, response.getBody().getReferencedAuthors().get(0).getPublicationCount());
        assertEquals(76, response.getBody().getReferencedAuthors().get(0).getCitationCount());
        assertEquals(24, response.getBody().getReferencedAuthors().get(0).getHindex());
        assertEquals(1, response.getBody().getReferencedAuthors().get(0).getIndicators().size());
        assertNull(response.getBody().getReferencedAuthors().get(0).getPublications());
        assertEquals(List.of(Indicators.RECENTLYACCEPTEDAUTHORTHISJOURNAL), response.getBody().getReferencedAuthors().get(0).getIndicators());

        assertEquals(1, response.getBody().getReferencedAuthors().get(0).getReviewStatistics().size());
        assertEquals("ACR", response.getBody().getReferencedAuthors().get(0).getReviewStatistics().get(0).getEmJournalAcronym());
        assertEquals(1, response.getBody().getReferencedAuthors().get(0).getReviewStatistics().get(0).getInvitationCount());
        assertEquals(0, response.getBody().getReferencedAuthors().get(0).getReviewStatistics().get(0).getWorkInProgressCount());
        assertEquals(0, response.getBody().getReferencedAuthors().get(0).getReviewStatistics().get(0).getCompletedCount());
        assertNull(response.getBody().getReferencedAuthors().get(0).getReviewStatistics().get(0).getMostRecentCompleted());
    }

    @Test
    void testReferencesWithDocuments() throws SQLException, IOException, InterruptedException {
        JdbcMockAnswer jdbcMockAnswer = new JdbcMockAnswer();
        jdbcMockAnswer.addResultMapping(Map.of("refs", "<xml><pub-id pub-id-type=\"doi\">doi:10.1016/j.jdeveco.2016.08.003</pub-id></xml>"));

        Mockito.when(coreDb.query(Mockito.anyString(), Mockito.any(SqlParameterSource.class), Mockito.any(RowMapper.class)))
                .thenAnswer(jdbcMockAnswer);

        final WebClient.ResponseSpec sharedSearchSpecMock = createWebClientResponseSpecMock(sharedSearchWebClient);
        Mockito.when(sharedSearchSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just("""
                        {"hits":[{"authors": [{"authid": "000000800", "authemail": "fred@bedrock.com"}], "eid": "documentEid"},
                        {"authors": [{"authid": "000000900", "authemail": "wilma@bedrock.com"}], "eid": "documentEid2"},
                        {"authors": [{"authid": "000000900", "authemail": "wilma@bedrock.com"},
                                     {"authid": "000000800", "authemail": "fred@bedrock.com"},
                                     {"authid": "000000700", "authemail": "barney@bedrock.com"}], "eid": "documentEid"},
                        {"authors": [{"authid": "000000900", "authemail": "wilma@bedrock.com"},
                                     {"authid": "000000600", "authemail": "betty@bedrock.com"},
                                     {"authid": "000000900", "authemail": "wilma@bedrock.com"}], "eid": "documentEid2"}]}"
                        """));

        final String author = """
                [{"authid":"000000800","preffirst":"Fred","authlast":"Flintstone",
                 "afdispname":"Bedrock Uni","afdispcity":"Red Rock",
                 "afdispctry":"Bedrock","count":182,"h_index":"24", "num_cited_by":"76"}]
                """;
        final WebClient.ResponseSpec personFinderResponseSpecMock = createWebClientResponseSpecMock(personFinderWebClient);
        Mockito.when(personFinderResponseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just(author));

        JdbcMockAnswer mockEmReviewHistoryAnswer = new JdbcMockAnswer();
        mockEmReviewHistoryAnswer.addResultMapping(Map.ofEntries(
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("journal_acronym", "ACR"),
                Map.entry("rstop", 1589809511783L),
                Map.entry("work_in_progress", false),
                Map.entry("declined", false),
                Map.entry("terminated", false),
                Map.entry("completed", false),
                Map.entry("uninvited", true),
                Map.entry("assigned_not_invited", false)));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(ReviewStatisticsResultsExtractor.class))).thenAnswer(mockEmReviewHistoryAnswer);

        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(Map.ofEntries(
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("volunteer", false),
                Map.entry("unavailability", "-null-"),
                Map.entry("concurrent_review_limit", 100),
                Map.entry("this_recently_accepted_author", true),
                Map.entry("other_recently_accepted_author", false)));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(AdditionalInfoResultsExtractor.class))).thenAnswer(mockAnswer);

        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(200);
        Mockito.when(mockTokenResponse.body()).thenReturn("[]");
        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        ResponseEntity<ReferencedAuthorsResponse> response = referencedAuthorsService.getReferencedAuthors("ACR", 1L, null, null, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertEquals(4, response.getBody().getReferencedAuthors().size());
        assertEquals("000000800", response.getBody().getReferencedAuthors().get(0).getScopusIds().get(0));
        assertEquals("fred@bedrock.com", response.getBody().getReferencedAuthors().get(0).getEmails().get(0));
        assertEquals("Fred Flintstone", response.getBody().getReferencedAuthors().get(0).getDisplayName());
        assertEquals("Fred", response.getBody().getReferencedAuthors().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getReferencedAuthors().get(0).getLastName());
        assertEquals("Bedrock Uni", response.getBody().getReferencedAuthors().get(0).getAffiliationName());
        assertEquals("Red Rock", response.getBody().getReferencedAuthors().get(0).getAffiliationCity());
        assertEquals("Bedrock", response.getBody().getReferencedAuthors().get(0).getAffiliationCountry());
        assertEquals(182, response.getBody().getReferencedAuthors().get(0).getPublicationCount());
        assertEquals(76, response.getBody().getReferencedAuthors().get(0).getCitationCount());
        assertEquals(24, response.getBody().getReferencedAuthors().get(0).getHindex());
        assertEquals(1, response.getBody().getReferencedAuthors().get(0).getPublications().size());
        assertEquals("documentEid", response.getBody().getReferencedAuthors().get(0).getPublications().get(0));
        assertEquals(1, response.getBody().getReferencedAuthors().get(0).getIndicators().size());
        assertEquals(List.of(Indicators.RECENTLYACCEPTEDAUTHORTHISJOURNAL), response.getBody().getReferencedAuthors().get(0).getIndicators());

        assertEquals(1, response.getBody().getReferencedAuthors().get(0).getReviewStatistics().size());
        assertEquals("ACR", response.getBody().getReferencedAuthors().get(0).getReviewStatistics().get(0).getEmJournalAcronym());
        assertEquals(1, response.getBody().getReferencedAuthors().get(0).getReviewStatistics().get(0).getInvitationCount());
        assertEquals(0, response.getBody().getReferencedAuthors().get(0).getReviewStatistics().get(0).getWorkInProgressCount());
        assertEquals(0, response.getBody().getReferencedAuthors().get(0).getReviewStatistics().get(0).getCompletedCount());
        assertNull(response.getBody().getReferencedAuthors().get(0).getReviewStatistics().get(0).getMostRecentCompleted());

        assertEquals("000000900", response.getBody().getReferencedAuthors().get(1).getScopusIds().get(0));
        assertEquals("wilma@bedrock.com", response.getBody().getReferencedAuthors().get(1).getEmails().get(0));
        assertEquals(2, response.getBody().getReferencedAuthors().get(1).getPublications().size());
        assertEquals("documentEid2", response.getBody().getReferencedAuthors().get(1).getPublications().get(0));
        assertEquals("documentEid", response.getBody().getReferencedAuthors().get(1).getPublications().get(1));
        assertNull(response.getBody().getReferencedAuthors().get(1).getIndicators());

        assertEquals("000000700", response.getBody().getReferencedAuthors().get(2).getScopusIds().get(0));
        assertEquals("barney@bedrock.com", response.getBody().getReferencedAuthors().get(2).getEmails().get(0));
        assertEquals(1, response.getBody().getReferencedAuthors().get(2).getPublications().size());
        assertEquals("documentEid", response.getBody().getReferencedAuthors().get(2).getPublications().get(0));
        assertNull(response.getBody().getReferencedAuthors().get(2).getIndicators());

        assertEquals("000000600", response.getBody().getReferencedAuthors().get(3).getScopusIds().get(0));
        assertEquals("betty@bedrock.com", response.getBody().getReferencedAuthors().get(3).getEmails().get(0));
        assertEquals(1, response.getBody().getReferencedAuthors().get(3).getPublications().size());
        assertEquals("documentEid2", response.getBody().getReferencedAuthors().get(3).getPublications().get(0));
        assertNull(response.getBody().getReferencedAuthors().get(3).getIndicators());
    }
}
