package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.enums.ProductType;
import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.generated.model.ManuscriptDetails;
import com.elsevier.find.reviewers.testutils.JdbcMockAnswer;
import com.elsevier.find.reviewers.testutils.TestBase;
import com.elsevier.find.reviewers.utils.CookieManager.SessionData;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.data.jdbc.JdbcRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.sql.SQLException;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, JdbcRepositoriesAutoConfiguration.class})
public class Manuscripts_getManuscriptTest extends TestBase {
    // Wire to the service that we want to test
    @Autowired
    private ManuscriptsService manuscriptsService;

    @MockBean(name = "emWebClient")
    private WebClient emWebClient;

    @BeforeEach
    void setup() {
        SessionContext.initialize(new SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", true, true));
    }

    @AfterEach
    void tearDown() {
        SessionContext.destroy();
    }

    @Test
    void testNoManuscript() throws SQLException {
        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(RowMapper.class))).thenAnswer(mockAnswer);

        ResponseEntity<ManuscriptDetails> response = manuscriptsService.getManuscript("ACR", 123L, null);

        assertEquals("ACR", mockAnswer.getParameter("emJournalAcronym", String.class));
        assertEquals(123L, mockAnswer.getParameter("documentId", Long.class));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNull(response.getBody().getManuscriptNumber(), "Manuscript number not valid");
        assertNull(response.getBody().getTitle(), "Title not valid");

        mockAnswer.addNullResultMap();
        response = manuscriptsService.getManuscript("ACR", 123L, null);
        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNull(response.getBody().getManuscriptNumber(), "Manuscript number not valid");
        assertNull(response.getBody().getTitle(), "Title not valid");
        assertNull(response.getBody().getAbstract(), "Abstract not valid");
    }

    @Test
    void testDatabaseException() {
        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(RowMapper.class))).thenThrow(new DataAccessException("Test Exception") {
        });

        assertThrows(DataAccessException.class, () -> manuscriptsService.getManuscript("ACR", 1L, null));
    }

    @Test
    void testInvalidInput() {
        assertThrows(InternalException.class, () -> manuscriptsService.getManuscript(null, null, null));
        assertThrows(InternalException.class, () -> manuscriptsService.getManuscript("", 1L, null));
        assertThrows(InternalException.class, () -> manuscriptsService.getManuscript(" ", 1L, null));
        assertThrows(InternalException.class, () -> manuscriptsService.getManuscript("NoDocId", null, null));
    }

    @Test
    void testManuscriptDataWithAuthors() throws SQLException {
        Map<String, Object> resultMapping1 = Map.ofEntries(
                Map.entry("pubd_number", "PUB-D-NUMBER"),
                Map.entry("manuscript_title", "My Manuscript Title"),
                Map.entry("corresponding_authors", "[{\"emails\" : [\"barney@bedrock.com\"], \"firstName\" : \"Barney\", \"lastName\" : \"Rubble\"}]"),
                Map.entry("co_authors", "[{\"emails\" : [\"{wilma}@bedrock.com\", null], \"firstName\" : \"Wilma\", \"lastName\" : \"Flintstone\"}, {\"emails\" : [\"- betty@bedrock.com\"], \"firstName\" : \"Betty\", \"lastName\" : \"Rubble\"}]"));

        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(resultMapping1);

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(RowMapper.class))).thenAnswer(mockAnswer);

        ResponseEntity<ManuscriptDetails> response = manuscriptsService.getManuscript("ACR", 123L, null);

        assertEquals("ACR", mockAnswer.getParameter("emJournalAcronym", String.class));
        assertEquals(123L, mockAnswer.getParameter("documentId", Long.class));

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Null body");
        assertEquals("PUB-D-NUMBER", response.getBody().getManuscriptNumber());
        assertEquals("My Manuscript Title", response.getBody().getTitle());

        assertEquals(1, response.getBody().getCorrespondingAuthors().size());
        assertEquals("barney@bedrock.com", response.getBody().getCorrespondingAuthors().get(0).getEmails().get(0));
        assertEquals("Barney", response.getBody().getCorrespondingAuthors().get(0).getFirstName());
        assertEquals("Rubble", response.getBody().getCorrespondingAuthors().get(0).getLastName());
        assertEquals("Barney Rubble", response.getBody().getCorrespondingAuthors().get(0).getDisplayName());

        assertEquals(2, response.getBody().getCoAuthors().size());
        assertEquals("wilma@bedrock.com", response.getBody().getCoAuthors().get(0).getEmails().get(0));
        assertEquals("Wilma", response.getBody().getCoAuthors().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getCoAuthors().get(0).getLastName());
        assertEquals("Wilma Flintstone", response.getBody().getCoAuthors().get(0).getDisplayName());
        assertEquals("betty@bedrock.com", response.getBody().getCoAuthors().get(1).getEmails().get(0));
        assertEquals("Betty", response.getBody().getCoAuthors().get(1).getFirstName());
        assertEquals("Rubble", response.getBody().getCoAuthors().get(1).getLastName());
        assertEquals("Betty Rubble", response.getBody().getCoAuthors().get(1).getDisplayName());
    }

    @Test
    void testNonUrsdbManuscript() {
        SessionContext.initialize(new SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", false, false));

        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(emWebClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just("{\"Response\": {" +
                        "\"result\": {\"e\": {" +
                        "\"submissionId\": \"ACR-D-12345\",\"submissionTitle\": \"Density of Rocks\"," +
                        " \"abstractText\": \"Rock stuff is special\"}}}}"));

        ResponseEntity<ManuscriptDetails> response = manuscriptsService.getManuscript("CANCER-CELL", 123L, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("ACR-D-12345", response.getBody().getManuscriptNumber());
        assertEquals("Density of Rocks", response.getBody().getTitle());
        assertEquals("Rock stuff is special", response.getBody().getAbstract());
    }

    @Test
    void testNonUrsdbManuscriptMissing() {
        SessionContext.initialize(new SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", false, false));

        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(emWebClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just("Invalid JSON"))
                .thenReturn(Mono.just(""))
                .thenReturn(null);

        ResponseEntity<ManuscriptDetails> response = manuscriptsService.getManuscript("THELANCETHAEMATOLOGY", 123L, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNull(response.getBody().getManuscriptNumber(), "Manuscript number not valid");
        assertNull(response.getBody().getTitle(), "Title not valid");
        assertNull(response.getBody().getAbstract(), "Abstract not valid");

        response = manuscriptsService.getManuscript("THELANCETHIV", 123L, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNull(response.getBody().getManuscriptNumber(), "Manuscript number not valid");
        assertNull(response.getBody().getTitle(), "Title not valid");
        assertNull(response.getBody().getAbstract(), "Abstract not valid");

        response = manuscriptsService.getManuscript("THELANCETMICROBE", 123L, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNull(response.getBody().getManuscriptNumber(), "Manuscript number not valid");
        assertNull(response.getBody().getTitle(), "Title not valid");
        assertNull(response.getBody().getAbstract(), "Abstract not valid");
    }
}
