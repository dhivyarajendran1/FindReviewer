package com.elsevier.find.reviewers;

import com.elsevier.find.reviewers.config.DigestAuthConfig.DigestAuthFilterFunction;
import me.vzhilin.auth.DigestAuthenticator;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.ExchangeFunction;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.net.URI;

import static org.junit.jupiter.api.Assertions.assertThrows;


public class DigestAuthConfigTest {
    @Test
    void testAuthenticatedFirstTime() {
        DigestAuthFilterFunction digestAuth = new DigestAuthFilterFunction(new DigestAuthenticator("username", "password"));

        ClientRequest clientRequest = Mockito.mock(ClientRequest.class);
        ExchangeFunction exchangeFunction = Mockito.mock(ExchangeFunction.class);
        ClientResponse clientResponse = Mockito.mock(ClientResponse.class);

        Mockito.when(clientRequest.method()).thenReturn(HttpMethod.GET);
        Mockito.when(clientRequest.url()).thenReturn(URI.create("http://localhost/api"));

        Mockito.when(exchangeFunction.exchange(clientRequest)).thenReturn(Mono.just(clientResponse));
        Mockito.when(clientResponse.statusCode()).thenReturn(HttpStatus.OK);

        StepVerifier.create(digestAuth.filter(clientRequest, exchangeFunction))
                .expectNext(clientResponse).verifyComplete();
    }

    @Test
    void testNotAuthenticatedFirstTime() {
        DigestAuthFilterFunction digestAuth = new DigestAuthFilterFunction(new DigestAuthenticator("username", "password"));

        ClientRequest clientRequest = Mockito.mock(ClientRequest.class);
        ExchangeFunction exchangeFunction = Mockito.mock(ExchangeFunction.class);
        ClientResponse clientResponse = Mockito.mock(ClientResponse.class);

        Mockito.when(clientRequest.method()).thenReturn(HttpMethod.GET);
        Mockito.when(clientRequest.url()).thenReturn(URI.create("http://localhost/api"));
        Mockito.when(clientRequest.headers()).thenReturn(HttpHeaders.EMPTY);
        Mockito.when(clientRequest.cookies()).thenReturn(HttpHeaders.EMPTY);

        Mockito.when(exchangeFunction.exchange(clientRequest)).thenReturn(Mono.just(clientResponse));
        Mockito.when(clientResponse.statusCode()).thenReturn(HttpStatus.UNAUTHORIZED);
        ClientResponse.Headers responseHeaders = Mockito.mock(ClientResponse.Headers.class);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add(HttpHeaders.WWW_AUTHENTICATE, "Digest realm=\"localhost.com\", nonce=\"f5d6eeccc66664731c72e3300d3dfadf\"");
        Mockito.when(responseHeaders.asHttpHeaders()).thenReturn(HttpHeaders.EMPTY).thenReturn(httpHeaders);

        Mockito.when(clientResponse.headers()).thenReturn(responseHeaders);

        StepVerifier.create(digestAuth.filter(clientRequest, exchangeFunction))
                .expectNext(clientResponse).verifyComplete();
    }


    @Test
    void testAuthenticatedSecondTime() {
        DigestAuthFilterFunction digestAuth = new DigestAuthFilterFunction(new DigestAuthenticator("username", "password"));

        ClientRequest clientRequest = Mockito.mock(ClientRequest.class);
        ExchangeFunction exchangeFunction = Mockito.mock(ExchangeFunction.class);
        ClientResponse clientResponse = Mockito.mock(ClientResponse.class);

        Mockito.when(clientRequest.method()).thenReturn(HttpMethod.GET);
        Mockito.when(clientRequest.url()).thenReturn(URI.create("http://localhost/api"));
        Mockito.when(clientRequest.headers()).thenReturn(HttpHeaders.EMPTY);
        Mockito.when(clientRequest.cookies()).thenReturn(HttpHeaders.EMPTY);

        Mockito.when(exchangeFunction.exchange(clientRequest)).thenReturn(Mono.just(clientResponse));
        Mockito.when(clientResponse.statusCode()).thenReturn(HttpStatus.UNAUTHORIZED).thenReturn(HttpStatus.OK);
        ClientResponse.Headers responseHeaders = Mockito.mock(ClientResponse.Headers.class);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add(HttpHeaders.WWW_AUTHENTICATE, "Digest realm=\"localhost.com\", nonce=\"f5d6eeccc66664731c72e3300d3dfadf\"");
        Mockito.when(responseHeaders.asHttpHeaders()).thenReturn(HttpHeaders.EMPTY).thenReturn(httpHeaders);

        Mockito.when(clientResponse.headers()).thenReturn(responseHeaders);

        StepVerifier.create(digestAuth.filter(clientRequest, exchangeFunction))
                .expectNext(clientResponse).verifyComplete();
    }

    @Test
    void testInvalidNonce() {
        DigestAuthFilterFunction digestAuth = new DigestAuthFilterFunction(new DigestAuthenticator("username", "password"));

        ClientRequest clientRequest = Mockito.mock(ClientRequest.class);
        ExchangeFunction exchangeFunction = Mockito.mock(ExchangeFunction.class);
        ClientResponse clientResponse = Mockito.mock(ClientResponse.class);

        Mockito.when(clientRequest.method()).thenReturn(HttpMethod.GET);
        Mockito.when(clientRequest.url()).thenReturn(URI.create("http://localhost/api"));
        Mockito.when(clientRequest.headers()).thenReturn(HttpHeaders.EMPTY);
        Mockito.when(clientRequest.cookies()).thenReturn(HttpHeaders.EMPTY);

        Mockito.when(exchangeFunction.exchange(clientRequest)).thenReturn(Mono.just(clientResponse));
        Mockito.when(clientResponse.statusCode()).thenReturn(HttpStatus.UNAUTHORIZED);
        ClientResponse.Headers responseHeaders = Mockito.mock(ClientResponse.Headers.class);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add(HttpHeaders.WWW_AUTHENTICATE, "Invalid nonce");
        Mockito.when(responseHeaders.asHttpHeaders()).thenReturn(HttpHeaders.EMPTY).thenReturn(httpHeaders);

        Mockito.when(clientResponse.headers()).thenReturn(responseHeaders);

        StepVerifier.create(digestAuth.filter(clientRequest, exchangeFunction)).expectError(RuntimeException.class).verify();
    }

    @Test
    void testAuthHeader() {
        DigestAuthenticator digestAuthenticator = Mockito.mock(DigestAuthenticator.class);
        Mockito.when(digestAuthenticator.authorizationHeader(Mockito.anyString(), Mockito.any()))
                .thenReturn("Digest realm=\"localhost.com\", nonce=\"f5d6eeccc66664731c72e3300d3dfadf\"");

        DigestAuthFilterFunction digestAuth = new DigestAuthFilterFunction(digestAuthenticator);

        ClientRequest clientRequest = Mockito.mock(ClientRequest.class);
        ExchangeFunction exchangeFunction = Mockito.mock(ExchangeFunction.class);
        ClientResponse clientResponse = Mockito.mock(ClientResponse.class);

        Mockito.when(clientRequest.method()).thenReturn(HttpMethod.GET);
        Mockito.when(clientRequest.url()).thenReturn(URI.create("http://localhost/api"));
        Mockito.when(clientRequest.headers()).thenReturn(HttpHeaders.EMPTY);
        Mockito.when(clientRequest.cookies()).thenReturn(HttpHeaders.EMPTY);

        Mockito.when(exchangeFunction.exchange(clientRequest)).thenReturn(Mono.just(clientResponse));

        assertThrows(RuntimeException.class, () -> digestAuth.filter(clientRequest, exchangeFunction));
    }
}
