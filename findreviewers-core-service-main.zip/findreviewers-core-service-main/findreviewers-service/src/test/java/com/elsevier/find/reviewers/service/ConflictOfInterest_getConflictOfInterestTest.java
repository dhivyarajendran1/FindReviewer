package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.generated.model.ConflictOfInterestResponse;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.generated.model.Indicators;
import com.elsevier.find.reviewers.testutils.TestBase;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.data.jdbc.JdbcRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, JdbcRepositoriesAutoConfiguration.class})
public class ConflictOfInterest_getConflictOfInterestTest extends TestBase {
    // Wire to the service that we want to test
    @Autowired
    private ConflictOfInterestService conflictOfInterestService;

    @MockBean(name = "personfinder")
    private WebClient personFinderWebClient;

    @Test
    void testNoConflicts404() {
        final WebClient.RequestHeadersUriSpec uriSpecMock = Mockito.mock(WebClient.RequestHeadersUriSpec.class);
        final WebClient.RequestHeadersSpec headersSpecMock = Mockito.mock(WebClient.RequestHeadersSpec.class);
        Mockito.when(personFinderWebClient.get()).thenReturn(uriSpecMock);
        Mockito.when(uriSpecMock.uri(Mockito.any(URI.class))).thenReturn(headersSpecMock);
        Mockito.when(headersSpecMock.header(Mockito.anyString(), Mockito.anyString())).thenReturn(headersSpecMock);
        Mockito.when(headersSpecMock.accept(Mockito.notNull())).thenReturn(headersSpecMock);
        Mockito.when(headersSpecMock.retrieve()).thenThrow(new WebClientResponseException(404, "Not Found", null, null, null));

        ResponseEntity<ConflictOfInterestResponse> response =
                conflictOfInterestService.getConflictOfInterest(List.of("6543"), List.of("1234"), null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(0, response.getBody().getReviewers().size());
    }

    @Test
    void testHttpErrorResponse() {
        final WebClient.RequestHeadersUriSpec uriSpecMock = Mockito.mock(WebClient.RequestHeadersUriSpec.class);
        final WebClient.RequestHeadersSpec headersSpecMock = Mockito.mock(WebClient.RequestHeadersSpec.class);
        Mockito.when(personFinderWebClient.get()).thenReturn(uriSpecMock);
        Mockito.when(uriSpecMock.uri(Mockito.any(URI.class))).thenReturn(headersSpecMock);
        Mockito.when(headersSpecMock.header(Mockito.anyString(), Mockito.anyString())).thenReturn(headersSpecMock);
        Mockito.when(headersSpecMock.accept(Mockito.notNull())).thenReturn(headersSpecMock);
        Mockito.when(headersSpecMock.retrieve())
                .thenThrow(new WebClientResponseException(500, "Internal Error", null, null, null))
                .thenThrow(new RuntimeException("Error Test"))
                .thenThrow(new WebClientResponseException(400, "Bad Request", null, null, null))
                .thenThrow(new WebClientResponseException(400, "Bad Request", null, "500 PF-02 : Too many authors".getBytes(), null));

        InternalException e = assertThrows(InternalException.class, () -> conflictOfInterestService.getConflictOfInterest(List.of("6543"), List.of("1234"), null));
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getHttpStatus(), "Invalid status");
        assertEquals(ErrorResponse.IdEnum.PERSONFINDERFAILURE, e.toErrorResponse().getId(), "Invalid error Id");

        e = assertThrows(InternalException.class, () -> conflictOfInterestService.getConflictOfInterest(List.of("6543"), List.of("1234"), null));
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getHttpStatus(), "Invalid status");
        assertEquals(ErrorResponse.IdEnum.PERSONFINDERFAILURE, e.toErrorResponse().getId(), "Invalid error Id");

        e = assertThrows(InternalException.class, () -> conflictOfInterestService.getConflictOfInterest(List.of("6543"), List.of("1234"), null));
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getHttpStatus(), "Invalid status");
        assertEquals(ErrorResponse.IdEnum.PERSONFINDERFAILURE, e.toErrorResponse().getId(), "Invalid error Id");

        e = assertThrows(InternalException.class, () -> conflictOfInterestService.getConflictOfInterest(List.of("6543"), List.of("1234"), null));
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getHttpStatus(), "Invalid status");
        assertEquals(ErrorResponse.IdEnum.LIMITEXCEEDED, e.toErrorResponse().getId(), "Invalid error Id");
    }

    @Test
    void testNoConflicts() {
        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(personFinderWebClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just("{\"conflictOfInterests\":[]}"))
                .thenReturn(Mono.just("{}"))
                .thenReturn(Mono.just(""))
                .thenReturn(Mono.just("{\"conflictOfInterests\":[{\"reviewerId\":\"1234\"}]}"))
                .thenReturn(Mono.just("{\"conflictOfInterests\":[{\"conflicts\": []}]}"))
                .thenReturn(Mono.just("{\"conflictOfInterests\":[{\"reviewerId\":\"1234\", \"conflicts\": []}]}"))
                .thenReturn(Mono.just("{\"conflictOfInterests\":[{\"reviewerId\":\"1234\", \"conflicts\": [{\"conflictTypes\": null}]}]}"));

        for (int i = 1; i <= 7; i++) {
            ResponseEntity<ConflictOfInterestResponse> response =
                    conflictOfInterestService.getConflictOfInterest(List.of("6543"), List.of("1234"), null);

            assertNotNull(response, "Null Response " + i);
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertNotNull(response.getBody(), "Body not valid " + i);
            assertEquals(0, response.getBody().getReviewers().size());
        }
    }

    @Test
    void testInvalidInput() {
        assertThrows(InternalException.class, () -> conflictOfInterestService.getConflictOfInterest(null, List.of("123"), null));
        assertThrows(InternalException.class, () -> conflictOfInterestService.getConflictOfInterest(Collections.emptyList(), List.of("123"), null));
        assertThrows(InternalException.class, () -> conflictOfInterestService.getConflictOfInterest(List.of("123"), null, null));
        assertThrows(InternalException.class, () -> conflictOfInterestService.getConflictOfInterest(List.of("123"), Collections.emptyList(), null));
    }

    @Test
    void testMessageProcessingError() {
        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(personFinderWebClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just("{ invalid json }"));

        InternalException e = assertThrows(InternalException.class, () -> conflictOfInterestService.getConflictOfInterest(List.of("6543"), List.of("1234"), null));
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getHttpStatus(), "Invalid status");
        assertEquals(ErrorResponse.IdEnum.PERSONFINDERFAILURE, e.toErrorResponse().getId(), "Invalid error Id");
    }

    @Test
    void testSingleConflict() {
        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(personFinderWebClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just("{\"conflictOfInterests\":[{\"reviewerId\":\"1234\", \"conflicts\": [{\"conflictTypes\": [\"CURRENT_COAFFILIATION\"]}]}]}"));

        ResponseEntity<ConflictOfInterestResponse> response =
                conflictOfInterestService.getConflictOfInterest(List.of("6543"), List.of("1234"), null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(1, response.getBody().getReviewers().size());
        assertEquals("1234", response.getBody().getReviewers().get(0).getScopusId());
        assertEquals(1, response.getBody().getReviewers().get(0).getIndicators().size());
        assertEquals(Indicators.SAMEINSTITUTION, response.getBody().getReviewers().get(0).getIndicators().get(0));
    }

    @Test
    void testMultipleConflict() {
        final WebClient.ResponseSpec responseSpecMock = createWebClientResponseSpecMock(personFinderWebClient);
        Mockito.when(responseSpecMock.bodyToMono(String.class))
                .thenReturn(Mono.just("{\"conflictOfInterests\":[{\"reviewerId\":\"1234\", \"conflicts\": [{\"conflictTypes\": [\"COAFFILIATION\", \"MANUSCRIPT_AUTHOR\"]}," +
                        "{\"conflictTypes\": [\"RECENT_COAUTHOR\", \"UNKNOWN\"]}]}," +
                        "{\"reviewerId\":\"1234\", \"conflicts\": [{\"conflictTypes\": [\"SAME_COUNTRY\", \"SAME_COUNTRY\"]} ]}]}"));

        ResponseEntity<ConflictOfInterestResponse> response =
                conflictOfInterestService.getConflictOfInterest(List.of("6543"), List.of("1234"), null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(1, response.getBody().getReviewers().size());
        assertEquals("1234", response.getBody().getReviewers().get(0).getScopusId());
        assertEquals(4, response.getBody().getReviewers().get(0).getIndicators().size());
        assertEquals(Indicators.SAMEINSTITUTION, response.getBody().getReviewers().get(0).getIndicators().get(0));
        assertEquals(Indicators.MANUSCRIPTAUTHOR, response.getBody().getReviewers().get(0).getIndicators().get(1));
        assertEquals(Indicators.COAUTHORLAST5YEARS, response.getBody().getReviewers().get(0).getIndicators().get(2));
        assertEquals(Indicators.SAMECOUNTRY, response.getBody().getReviewers().get(0).getIndicators().get(3));
    }
}
