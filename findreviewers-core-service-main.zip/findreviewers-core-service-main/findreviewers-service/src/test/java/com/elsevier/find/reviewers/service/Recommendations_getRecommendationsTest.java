package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.dao.RecommenderAuditDao;
import com.elsevier.find.reviewers.dao.RecommenderAuditDao.AdditionalInfoToMissingAttributeConverter;
import com.elsevier.find.reviewers.dao.RecommenderAuditDao.ManuscriptAudit;
import com.elsevier.find.reviewers.dao.impl.AdditionalInfoDaoImpl.AdditionalInfoResultsExtractor;
import com.elsevier.find.reviewers.enums.ProductType;
import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.exception.RecommendationException;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.generated.model.Indicators;
import com.elsevier.find.reviewers.generated.model.RecommendationsFailureResponse;
import com.elsevier.find.reviewers.generated.model.RecommendationsResponse;
import com.elsevier.find.reviewers.testutils.JdbcMockAnswer;
import com.elsevier.find.reviewers.testutils.TestBase;
import com.elsevier.find.reviewers.utils.CookieManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.data.jdbc.JdbcRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.util.ReflectionTestUtils;
import software.amazon.awssdk.core.pagination.sync.SdkIterable;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.EnhancedType;
import software.amazon.awssdk.enhanced.dynamodb.model.PageIterable;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryConditional;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.GetQueueUrlRequest;
import software.amazon.awssdk.services.sqs.model.GetQueueUrlResponse;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;
import software.amazon.awssdk.services.sqs.model.SendMessageResponse;

import java.io.IOException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.sql.SQLException;
import java.time.Instant;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@TestPropertySource(properties = {
        "recommender.base.url=https://localhost/api/",
        "spring.profiles.active=prod"
})
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, JdbcRepositoriesAutoConfiguration.class})
public class Recommendations_getRecommendationsTest extends TestBase {
    // Wire to the service that we want to test
    @Autowired
    private RecommendationsService recommendationsService;

    @MockBean(name = "httpClient")
    private HttpClient mockHttpClient;

    @MockBean
    private SqsClient sqsClient;

    @Autowired
    private RecommenderAuditDao recommenderAuditDao;

    @Captor
    private ArgumentCaptor<HttpRequest> requestCaptor;

    private DynamoDbTable<ManuscriptAudit> mockManuscriptAuditTable = Mockito.mock(DynamoDbTable.class);

    @BeforeEach
    void mockDynamoDbTable() {
        ReflectionTestUtils.setField(recommenderAuditDao, "manuscriptAuditTable", mockManuscriptAuditTable);
        SessionContext.initialize(new CookieManager.SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", true, true));
    }

    @Test
    void testNoRecommendations() throws IOException, InterruptedException {
        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(200).thenReturn(200).thenReturn(404).thenReturn(500);
        Mockito.when(mockTokenResponse.body()).thenReturn("{}").thenReturn(null);

        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        ResponseEntity<RecommendationsResponse> response = recommendationsService.getRecommendations("SUB-1", "ACR", null, null, 100);

        Mockito.verify(mockHttpClient, Mockito.times(1)).send(requestCaptor.capture(),
                Mockito.any(HttpResponse.BodyHandler.class));
        assertTrue(requestCaptor.getValue().uri().toString().endsWith("/recommendations/reviewers?manuscript_id=SUB-1&size=100"), "Incorrect URL");
        assertEquals("GET", requestCaptor.getValue().method());

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody(), "Body not valid");

        response = recommendationsService.getRecommendations("SUB-1", "ACR", null, null, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody(), "Body not valid");

        response = recommendationsService.getRecommendations("SUB-1", "ACR", null, null, 10);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody(), "Body not valid");

        response = recommendationsService.getRecommendations("SUB-1", "ACR", null, null, 10);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody(), "Body not valid");
    }

    @Test
    void testGetRecommendationsHttpError() throws IOException, InterruptedException {
        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(500);
        Mockito.when(mockTokenResponse.body()).thenReturn("{\"error\":\"Message\"}");

        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenThrow(new IOException()).thenThrow(new InterruptedException());

        ResponseEntity<RecommendationsResponse> response = recommendationsService.getRecommendations("SUB-1", "ACR", 123L, null, 100);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody(), "Body not valid");

        response = recommendationsService.getRecommendations("SUB-1", "ACR", 123L, null, 100);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody(), "Body not valid");
    }

    @Test
    void testInvalidInput() {
        assertThrows(InternalException.class, () -> recommendationsService.getRecommendations(null, null, null, null, null));
        assertThrows(InternalException.class, () -> recommendationsService.getRecommendations(null, "ACR", null, null, null));
        assertThrows(InternalException.class, () -> recommendationsService.getRecommendations("SUB-1", null, null, null, null));
        assertThrows(InternalException.class, () -> recommendationsService.getRecommendations("", "ACR", null, null, null));
        assertThrows(InternalException.class, () -> recommendationsService.getRecommendations("SUB-1", "", null, null, null));
    }

    @Test
    void testNonUrsdbJournal() {
        SessionContext.initialize(new CookieManager.SessionData(ProductType.FindReviewers, "code", "bearer", "ACR", true, false));

        ResponseEntity<RecommendationsResponse> response = recommendationsService.getRecommendations("SUB-1", "ACR", 123L, null, 100);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNull(response.getBody().getRecommendations(), "Body not valid");
    }

    @Test
    void testSingleRecommendations() throws IOException, InterruptedException, SQLException {
        final String reviewer = """
                {
                    "scopusId": "56421000000",
                    "email": "fred@bedrock.com",
                    "name": "Fred",
                    "surname": "Flintstone",
                    "subjectAreas": ["2501", "3101", "Invalid-Subject"],
                    "numPublications": 106,
                    "hIndex": 47,
                    "citationTotal": 10882,
                    "citationTotalLast5Years": 39,
                    "affiliations": [{"name": "Bedrock University", "country": "United States", "city": "New York"}],
                    "keywords": ["Brain","Forecasting"],
                    "numPubsLast5Year": 24,
                    "numReviewerPublishedInManuscriptJournal": 3,
                    "topContentMatch": [
                        {
                            "title": "Density of Rocks",
                            "year": 2017,
                            "journal": "Stone Age International",
                            "scopusUrl": "https://www.scopus.com/record/display.uri?eid=2-s2.0-123456789&origin=resultslist&sort=plf-f&src=s",
                            "nCitations": 5,
                            "authorsPreview": [
                                {"id": "57200111111", "givenName": "Barney", "surname": "Rubble"},
                                {"id": "57200222222", "surname": "Flintstone"}
                            ],
                            "numAuthors": 7
                        }
                    ],
                    "numberOfSimilarWorks": 1,
                    "recentPublications": [
                        {
                            "title": "Cavemen Weekly",
                            "year": 2000,
                            "journal": "Stone Age International",
                            "scopusUrl": "https://www.scopus.com/record/display.uri?eid=2-s2.0-987654321&origin=resultslist&sort=plf-f&src=s",
                            "nCitations": 1,
                            "authorsPreview": [
                                {"id": "57200333333","givenName": "Barney","surname": "Rubble"},
                                {"id": "57200444444","surname": "Flintstone"}
                            ],
                            "numAuthors": 2
                        }
                    ],
                    "isOpposedByAuthor": true,
                    "isSuggestedByAuthor": true,
                    "sameInstitutionAsAuthors": true,
                    "isInSameCountry": true,
                    "hasCitedManuscriptAuthors": true,
                    "yearsActive": 56
                }
                """;

        final String recommendations = "{\"generationTime\": 1666797249000, " +
                "\"recommendations\": [" + reviewer + "], " +
                "\"analyticsInfo\": {" +
                "  \"cohortIdentifier\": \"reranking_model_v2\", " +
                "  \"generationTimestamps\": [1666797249000], " +
                "  \"servingTimestamp\": 1666797342407" +
                " }}";

        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(200);
        Mockito.when(mockTokenResponse.body()).thenReturn(recommendations).thenReturn("[]");

        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        Map<String, Object> resultMapping1 = Map.ofEntries(
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("this_recently_accepted_author", false),
                Map.entry("other_recently_accepted_author", false));

        JdbcMockAnswer mockAnswer = new JdbcMockAnswer();
        mockAnswer.addResultMapping(resultMapping1);

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(AdditionalInfoResultsExtractor.class))).thenAnswer(mockAnswer);

        ResponseEntity<RecommendationsResponse> response = recommendationsService.getRecommendations("SUB-1", "ACR", null, null, 20);

        Mockito.verify(mockHttpClient, Mockito.times(2)).send(requestCaptor.capture(),
                Mockito.any(HttpResponse.BodyHandler.class));
        assertTrue(requestCaptor.getAllValues().get(0).uri().toString().endsWith("/recommendations/reviewers?manuscript_id=SUB-1&size=20"), "Incorrect URL");
        assertTrue(requestCaptor.getAllValues().get(1).uri().toString().endsWith("/blocked-reviewers?em-acronym=ACR&reviewers=fred%40bedrock.com"), "Incorrect URL");
        assertEquals("GET", requestCaptor.getValue().method());

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1666797249000L, response.getBody().getGenerationTime());
        assertEquals(1, response.getBody().getRecommendations().size());
        assertEquals(1, response.getBody().getRecommendations().get(0).getScopusIds().size());
        assertEquals("56421000000", response.getBody().getRecommendations().get(0).getScopusIds().get(0));
        assertEquals(1, response.getBody().getRecommendations().get(0).getScopusIds().size());
        assertEquals("56421000000", response.getBody().getRecommendations().get(0).getScopusIds().get(0));
        assertEquals("fred@bedrock.com", response.getBody().getRecommendations().get(0).getEmails().get(0));
        assertEquals("Fred", response.getBody().getRecommendations().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getRecommendations().get(0).getLastName());

        assertEquals(2, response.getBody().getRecommendations().get(0).getSubjectAreas().size());
        assertEquals("Materials Science (miscellaneous)", response.getBody().getRecommendations().get(0).getSubjectAreas().get(0));
        assertEquals("Physics and Astronomy (miscellaneous)", response.getBody().getRecommendations().get(0).getSubjectAreas().get(1));

        assertEquals(106, response.getBody().getRecommendations().get(0).getPublicationCount());
        assertEquals(10882, response.getBody().getRecommendations().get(0).getCitationCount());
        assertEquals(39, response.getBody().getRecommendations().get(0).getCitation5YearCount());
        assertEquals("Bedrock University", response.getBody().getRecommendations().get(0).getAffiliationName());
        assertEquals("New York", response.getBody().getRecommendations().get(0).getAffiliationCity());
        assertEquals("United States", response.getBody().getRecommendations().get(0).getAffiliationCountry());
        assertEquals(2, response.getBody().getRecommendations().get(0).getKeywords().size());
        assertEquals("Brain", response.getBody().getRecommendations().get(0).getKeywords().get(0));
        assertEquals("Forecasting", response.getBody().getRecommendations().get(0).getKeywords().get(1));

        assertEquals(24, response.getBody().getRecommendations().get(0).getPublication5YearCount());
        assertEquals(3, response.getBody().getRecommendations().get(0).getPublishedInJournalCount());

        assertEquals(1, response.getBody().getRecommendations().get(0).getSimilarPublications().size());
        assertEquals("Density of Rocks", response.getBody().getRecommendations().get(0).getSimilarPublications().get(0).getTitle());
        assertEquals(2017, response.getBody().getRecommendations().get(0).getSimilarPublications().get(0).getYear());
        assertEquals("Stone Age International", response.getBody().getRecommendations().get(0).getSimilarPublications().get(0).getJournalTitle());
        assertEquals("2-s2.0-123456789", response.getBody().getRecommendations().get(0).getSimilarPublications().get(0).getEid());
        assertEquals(5, response.getBody().getRecommendations().get(0).getSimilarPublications().get(0).getCitationCount());

        assertEquals(7, response.getBody().getRecommendations().get(0).getSimilarPublications().get(0).getAuthorCount());
        assertEquals(2, response.getBody().getRecommendations().get(0).getSimilarPublications().get(0).getAuthors().size());
        assertEquals("57200111111", response.getBody().getRecommendations().get(0).getSimilarPublications().get(0).getAuthors().get(0).getId());
        assertEquals("Rubble, B.", response.getBody().getRecommendations().get(0).getSimilarPublications().get(0).getAuthors().get(0).getName());
        assertEquals("57200222222", response.getBody().getRecommendations().get(0).getSimilarPublications().get(0).getAuthors().get(1).getId());
        assertEquals("Flintstone", response.getBody().getRecommendations().get(0).getSimilarPublications().get(0).getAuthors().get(1).getName());

        assertEquals(1, response.getBody().getRecommendations().get(0).getSimilarPublicationsCount());

        assertEquals(1, response.getBody().getRecommendations().get(0).getRecentPublications().size());
        assertEquals("Cavemen Weekly", response.getBody().getRecommendations().get(0).getRecentPublications().get(0).getTitle());
        assertEquals(2000, response.getBody().getRecommendations().get(0).getRecentPublications().get(0).getYear());
        assertEquals("Stone Age International", response.getBody().getRecommendations().get(0).getRecentPublications().get(0).getJournalTitle());
        assertEquals("2-s2.0-987654321", response.getBody().getRecommendations().get(0).getRecentPublications().get(0).getEid());
        assertEquals(1, response.getBody().getRecommendations().get(0).getRecentPublications().get(0).getCitationCount());

        assertEquals(2, response.getBody().getRecommendations().get(0).getRecentPublications().get(0).getAuthorCount());
        assertEquals(2, response.getBody().getRecommendations().get(0).getRecentPublications().get(0).getAuthors().size());
        assertEquals("57200333333", response.getBody().getRecommendations().get(0).getRecentPublications().get(0).getAuthors().get(0).getId());
        assertEquals("57200444444", response.getBody().getRecommendations().get(0).getRecentPublications().get(0).getAuthors().get(1).getId());

        assertEquals(5, response.getBody().getRecommendations().get(0).getIndicators().size());
        assertTrue(response.getBody().getRecommendations().get(0).getIndicators().contains(Indicators.OPPOSEDBYAUTHOR), "Missing OPPOSEDBYAUTHOR");
        assertTrue(response.getBody().getRecommendations().get(0).getIndicators().contains(Indicators.SUGGESTEDBYAUTHOR), "Missing SUGGESTEDBYAUTHOR");
        assertTrue(response.getBody().getRecommendations().get(0).getIndicators().contains(Indicators.SAMEINSTITUTION), "Missing SAMEINSTITUTION");
        assertTrue(response.getBody().getRecommendations().get(0).getIndicators().contains(Indicators.SAMECOUNTRY), "Missing SAMECOUNTRY");
        assertTrue(response.getBody().getRecommendations().get(0).getIndicators().contains(Indicators.CITEDMANUSCRIPTAUTHORS), "Missing CITEDMANUSCRIPTAUTHORS");

        assertEquals(56, response.getBody().getRecommendations().get(0).getYearsActive());
        assertNull(response.getBody().getRecommendations().get(0).getReviewStatistics());
        assertEquals(3, response.getBody().getAnalyticsInfo().size());
    }

    @Test
    void testMultiplePartialRecommendations() throws IOException, InterruptedException {
        final String reviewer1 = "{\"scopusId\": \"56421000000\"," +
                "\"email\": \"fred@bedrock.com\"," +
                "\"name\": \"Fred\"," +
                "\"surname\": \"Flintstone\"," +
                "\"subjectAreas\": []," +
                "\"affiliations\": [ ]," +
                "\"keywords\": [ ]," +
                "\"topContentMatch\": [{\"numAuthors\": 7}]" +
                "}";
        final String reviewer2 = "{\"scopusId\": \"56421000001\"," +
                "\"email\": \"wilma@bedrock.com\"," +
                "\"affiliations\": null," +
                "\"keywords\": null," +
                "\"topContentMatch\": [" +
                "  {\"scopusUrl\": \"not expected scopus url\"," +
                "   \"authorsPreview\": [{\"id\": \"57200111111\",\"givenName\": \"\",\"surname\": \"Rubble\"}," +
                "                        {\"id\": \"57200222222\",\"givenName\": \"Fred\"}]}]" +
                "}";
        final String reviewer3 = "{\"scopusId\": \"56421000002\"," +
                "\"email\": \"barney@bedrock.com\"," +
                "\"topContentMatch\": [" +
                "  {\"scopusUrl\": \"?eid=\"," +
                "   \"authorsPreview\": [{\"id\": \"57200111111\",\"surname\": \"\"}," +
                "                        {\"id\": \"57200222222\",\"givenName\": \"\",\"surname\": \"\"}]}]" +
                "}";
        final String reviewer4 = "{\"scopusId\": \"56421000003\"," +
                "\"email\": \"betty@bedrock.com\"," +
                "\"topContentMatch\": null" +
                "}";
        final String reviewer5 = "{\"scopusId\": \"56421000004\"," +
                "\"email\": \"Invalid - email - address\"," +
                "\"topContentMatch\": null" +
                "}";

        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(200);
        Mockito.when(mockTokenResponse.body())
                .thenReturn("{\"recommendations\": [" +
                        reviewer1 + "," + reviewer2 + "," + reviewer3 + "," + reviewer4 + "," + reviewer5 + "]}")
                .thenReturn("[]");

        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(AdditionalInfoResultsExtractor.class))).thenAnswer(new JdbcMockAnswer());

        ResponseEntity<RecommendationsResponse> response = recommendationsService.getRecommendations("SUB-1", "ACR", null, null, null);

        Mockito.verify(mockHttpClient, Mockito.times(2)).send(requestCaptor.capture(),
                Mockito.any(HttpResponse.BodyHandler.class));
        assertTrue(requestCaptor.getAllValues().get(0).uri().toString().endsWith("/recommendations/reviewers?manuscript_id=SUB-1&size=100"), "Incorrect URL");
        assertTrue(requestCaptor.getAllValues().get(1).uri().toString().endsWith("/blocked-reviewers?em-acronym=ACR&reviewers=fred%40bedrock.com%2Cwilma%40bedrock.com%2Cbarney%40bedrock.com%2Cbetty%40bedrock.com"), "Incorrect URL");
        assertEquals("GET", requestCaptor.getValue().method());

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(4, response.getBody().getRecommendations().size());
        assertEquals(1, response.getBody().getRecommendations().get(0).getScopusIds().size());
        assertEquals("56421000000", response.getBody().getRecommendations().get(0).getScopusIds().get(0));
        assertEquals("fred@bedrock.com", response.getBody().getRecommendations().get(0).getEmails().get(0));
        assertEquals("Fred", response.getBody().getRecommendations().get(0).getFirstName());
        assertEquals("Flintstone", response.getBody().getRecommendations().get(0).getLastName());
        assertNull(response.getBody().getRecommendations().get(0).getKeywords());
        assertNull(response.getBody().getRecommendations().get(0).getAffiliationName());
        assertEquals(1, response.getBody().getRecommendations().get(0).getSimilarPublications().size());
        assertNull(response.getBody().getRecommendations().get(0).getSimilarPublications().get(0).getEid());

        assertEquals(1, response.getBody().getRecommendations().get(1).getScopusIds().size());
        assertEquals("56421000001", response.getBody().getRecommendations().get(1).getScopusIds().get(0));
        assertEquals("wilma@bedrock.com", response.getBody().getRecommendations().get(1).getEmails().get(0));
        assertNull(response.getBody().getRecommendations().get(1).getKeywords());
        assertNull(response.getBody().getRecommendations().get(1).getAffiliationName());
        assertEquals(1, response.getBody().getRecommendations().get(1).getSimilarPublications().size());
        assertNull(response.getBody().getRecommendations().get(1).getSimilarPublications().get(0).getEid());
        assertEquals(2, response.getBody().getRecommendations().get(1).getSimilarPublications().get(0).getAuthors().size());
        assertEquals("Rubble", response.getBody().getRecommendations().get(1).getSimilarPublications().get(0).getAuthors().get(0).getName());
        assertEquals("Fred", response.getBody().getRecommendations().get(1).getSimilarPublications().get(0).getAuthors().get(1).getName());
        assertNull(response.getBody().getRecommendations().get(1).getReviewStatistics());

        assertEquals(1, response.getBody().getRecommendations().get(2).getScopusIds().size());
        assertEquals("56421000002", response.getBody().getRecommendations().get(2).getScopusIds().get(0));
        assertEquals("barney@bedrock.com", response.getBody().getRecommendations().get(2).getEmails().get(0));
        assertEquals(1, response.getBody().getRecommendations().get(2).getSimilarPublications().size());
        assertNull(response.getBody().getRecommendations().get(2).getSimilarPublications().get(0).getEid());
        assertNull(response.getBody().getRecommendations().get(2).getSimilarPublications().get(0).getAuthors());
        assertNull(response.getBody().getRecommendations().get(2).getReviewStatistics());

        assertEquals(1, response.getBody().getRecommendations().get(3).getScopusIds().size());
        assertEquals("56421000003", response.getBody().getRecommendations().get(3).getScopusIds().get(0));
        assertEquals("betty@bedrock.com", response.getBody().getRecommendations().get(3).getEmails().get(0));
        assertNull(response.getBody().getRecommendations().get(3).getReviewStatistics());
        assertNull(response.getBody().getRecommendations().get(3).getSimilarPublications());
    }

    @Test
    void testNoRecommendationsWithRecentReflow() throws IOException, InterruptedException {
        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(404);

        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        Mockito.when(coreDb.queryForObject(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.eq(Long.class))).thenReturn(5L);

        ManuscriptAudit testData1 = new ManuscriptAudit();
        testData1.setJournalAcronym("ACR");
        assertEquals("ACR", testData1.getJournalAcronym());
        testData1.setSortKey("123#123456789");
        assertEquals("123#123456789", testData1.getSortKey());
        testData1.setForced(false);
        testData1.setEventTime(Instant.now().toEpochMilli() - 2000);

        ManuscriptAudit testData2 = new ManuscriptAudit();
        testData2.setJournalAcronym("ACR");
        testData2.setSortKey("123#123456789");
        testData2.setForced(true);
        testData2.setEventTime(2000L);

        ManuscriptAudit testData3 = new ManuscriptAudit();
        testData3.setJournalAcronym("ACR");
        testData3.setSortKey("123#123456789");
        testData3.setForced(true);
        testData3.setEventTime(Instant.now().toEpochMilli() - 2000);

        PageIterable<ManuscriptAudit> mockPage = Mockito.mock(PageIterable.class);
        SdkIterable<ManuscriptAudit> sdkIter = Mockito.mock(SdkIterable.class);
        Mockito.when(sdkIter.stream()).thenReturn(List.of(testData1, testData2, testData3).stream());
        Mockito.when(mockPage.items()).thenReturn(sdkIter);

        Mockito.when(mockManuscriptAuditTable.query(Mockito.any(QueryConditional.class))).thenReturn(mockPage);

        ResponseEntity<RecommendationsResponse> response = recommendationsService.getRecommendations("SUB-1", "ACR", 123L, null, 100);

        Mockito.verify(mockHttpClient, Mockito.times(1)).send(requestCaptor.capture(),
                Mockito.any(HttpResponse.BodyHandler.class));
        assertTrue(requestCaptor.getValue().uri().toString().endsWith("/recommendations/reviewers?manuscript_id=SUB-1&size=100"), "Incorrect URL");
        assertEquals("GET", requestCaptor.getValue().method());

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody(), "Body not valid");
        assertEquals(0, getAnalyticsCounterValue("custom.manuscript.reflow", "recommendations"));
    }

    @Test
    void testNoRecommendationsWithReflow() throws IOException, InterruptedException {
        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(404);

        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        Mockito.when(coreDb.queryForObject(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.eq(Long.class))).thenReturn(5L);

        ManuscriptAudit testData1 = new ManuscriptAudit();
        testData1.setJournalAcronym("ACR");
        testData1.setSortKey("123#123456789");
        testData1.setForced(false);
        testData1.setEventTime(2000L);

        ManuscriptAudit testData2 = new ManuscriptAudit();
        testData2.setJournalAcronym("ACR");
        testData2.setSortKey("123#123456789");
        testData2.setForced(false);
        testData2.setEventTime(2000L);
        testData2.setMissingAttributes(Collections.emptyList());

        PageIterable<ManuscriptAudit> mockPage = Mockito.mock(PageIterable.class);
        SdkIterable<ManuscriptAudit> sdkIter = Mockito.mock(SdkIterable.class);
        Mockito.when(sdkIter.stream()).thenReturn(List.of(testData1).stream()).thenReturn(List.of(testData2).stream());
        Mockito.when(mockPage.items()).thenReturn(sdkIter);

        Mockito.when(mockManuscriptAuditTable.query(Mockito.any(QueryConditional.class))).thenReturn(mockPage);

        Mockito.when(sqsClient.getQueueUrl(Mockito.any(GetQueueUrlRequest.class))).thenReturn(GetQueueUrlResponse.builder().build());
        Mockito.when(sqsClient.sendMessage(Mockito.any(SendMessageRequest.class))).thenReturn(null)
                .thenReturn(SendMessageResponse.builder().build());
        ArgumentCaptor<SendMessageRequest> messageCaptor = ArgumentCaptor.forClass(SendMessageRequest.class);

        ResponseEntity<RecommendationsResponse> response = recommendationsService.getRecommendations("SUB-1", "ACR", 123L, null, 100);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody(), "Body not valid");
        assertEquals(1, getAnalyticsCounterValue("custom.manuscript.reflow", "recommendations"));

        Object recommenderClass = ReflectionTestUtils.getField(recommendationsService, "recommender");
        ReflectionTestUtils.setField(recommenderClass, "isCloudUrsdb", true);
        response = recommendationsService.getRecommendations("SUB-1", "ACR", 123L, null, 100);
        ReflectionTestUtils.setField(recommenderClass, "isCloudUrsdb", false);

        Mockito.verify(mockHttpClient, Mockito.times(2)).send(requestCaptor.capture(),
                Mockito.any(HttpResponse.BodyHandler.class));
        assertTrue(requestCaptor.getValue().uri().toString().endsWith("/recommendations/reviewers?manuscript_id=SUB-1&size=100"), "Incorrect URL");
        assertEquals("GET", requestCaptor.getValue().method());

        Mockito.verify(sqsClient, Mockito.times(2)).sendMessage(messageCaptor.capture());
        assertTrue(messageCaptor.getAllValues().get(0).messageBody().contains("\"operation\": \"UPSERT\""), "Failed to request operation");
        assertTrue(messageCaptor.getAllValues().get(0).messageBody().contains("\"force\": true"), "Message missing force");
        assertTrue(messageCaptor.getAllValues().get(0).messageBody().contains("\"journalId\": 5"), "Message missing journal id");
        assertTrue(messageCaptor.getAllValues().get(0).messageBody().contains("\"journalAcronym\": \"ACR\""), "Message missing journal");
        assertTrue(messageCaptor.getAllValues().get(0).messageBody().contains("\"documentId\": 123"), "Message missing document");

        assertTrue(messageCaptor.getAllValues().get(1).messageBody().contains("\"operation\": \"UPDATE\""), "Failed to request operation");
        assertTrue(messageCaptor.getAllValues().get(1).messageBody().contains("\"force\": true"), "Message missing force");
        assertTrue(messageCaptor.getAllValues().get(1).messageBody().contains("\"journal_id\": 5"), "Message missing journal id");
        assertTrue(messageCaptor.getAllValues().get(1).messageBody().contains("\"document_id\": 123"), "Message missing document");

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody(), "Body not valid");
    }

    @Test
    void testNoRecommendationsWithMissingData() throws IOException, InterruptedException {
        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(404);

        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        Mockito.when(coreDb.queryForObject(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.eq(Long.class))).thenReturn(5L);

        ManuscriptAudit testData1 = new ManuscriptAudit();
        testData1.setJournalAcronym("ACR");
        testData1.setSortKey("123#123456789");
        testData1.setForced(false);
        testData1.setEventTime(Instant.now().toEpochMilli());
        testData1.setMissingAttributes(List.of("abstract"));

        PageIterable<ManuscriptAudit> mockPage = Mockito.mock(PageIterable.class);
        SdkIterable<ManuscriptAudit> sdkIter = Mockito.mock(SdkIterable.class);
        Mockito.when(sdkIter.stream()).thenReturn(List.of(testData1).stream());
        Mockito.when(mockPage.items()).thenReturn(sdkIter);

        Mockito.when(mockManuscriptAuditTable.query(Mockito.any(QueryConditional.class))).thenReturn(mockPage);

        Mockito.when(sqsClient.getQueueUrl(Mockito.any(GetQueueUrlRequest.class))).thenReturn(GetQueueUrlResponse.builder().build());
        Mockito.when(sqsClient.sendMessage(Mockito.any(SendMessageRequest.class))).thenReturn(null)
                .thenReturn(SendMessageResponse.builder().build());

        RecommendationException e = assertThrows(RecommendationException.class, () -> recommendationsService.getRecommendations("SUB-1", "ACR", 123L, null, 100));

        assertEquals(HttpStatus.NOT_FOUND, e.getHttpStatus());
        assertNotNull(e.getResponse());
        assertEquals(List.of(RecommendationsFailureResponse.MissingManuscriptDataEnum.ABSTRACT), e.getResponse().getMissingManuscriptData());

        // There is a converter that we need to test directly as we mock the conversion above
        assertNull(new AdditionalInfoToMissingAttributeConverter().transformFrom(null));
        assertEquals(EnhancedType.listOf(String.class), new AdditionalInfoToMissingAttributeConverter().type());
        // {"Message":{"S":"Missing values abstract for Manuscript"},"MissingAttributes":{"L":[{"S":"abstract"}]}}
        AttributeValue dymnamoData = AttributeValue.fromM(Map.of(
                "Message", AttributeValue.fromS("Missing values abstract for Manuscript"),
                "MissingAttributes", AttributeValue.fromL(List.of(AttributeValue.fromS("abstract")))
        ));
        assertEquals(List.of("abstract"), new AdditionalInfoToMissingAttributeConverter().transformTo(dymnamoData));
        assertEquals(Collections.emptyList(), new AdditionalInfoToMissingAttributeConverter()
                .transformTo(AttributeValue.fromM(Collections.emptyMap())));
    }

    @Test
    void testNoRecommendationsWithReflowFailure() throws IOException, InterruptedException {
        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(404);

        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        Mockito.when(coreDb.queryForObject(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.eq(Long.class))).thenReturn(5L);

        PageIterable<ManuscriptAudit> mockPage = Mockito.mock(PageIterable.class);
        SdkIterable<ManuscriptAudit> sdkIter = Mockito.mock(SdkIterable.class);
        Mockito.when(sdkIter.stream()).thenReturn(Collections.EMPTY_LIST.stream());
        Mockito.when(mockPage.items()).thenReturn(sdkIter);

        Mockito.when(mockManuscriptAuditTable.query(Mockito.any(QueryConditional.class))).thenReturn(mockPage);

        Mockito.when(sqsClient.getQueueUrl(Mockito.any(GetQueueUrlRequest.class))).thenThrow(new RuntimeException());
        ArgumentCaptor<SendMessageRequest> messageCaptor = ArgumentCaptor.forClass(SendMessageRequest.class);

        ResponseEntity<RecommendationsResponse> response = recommendationsService.getRecommendations("SUB-1", "ACR", 123L, null, 100);

        Mockito.verify(mockHttpClient, Mockito.times(1)).send(requestCaptor.capture(),
                Mockito.any(HttpResponse.BodyHandler.class));
        assertTrue(requestCaptor.getValue().uri().toString().endsWith("/recommendations/reviewers?manuscript_id=SUB-1&size=100"), "Incorrect URL");
        assertEquals("GET", requestCaptor.getValue().method());

        Mockito.verify(sqsClient, Mockito.times(0)).sendMessage(messageCaptor.capture());

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody(), "Body not valid");
    }

    @Test
    void testNoRecommendationsWithReflowMissingJournal() throws IOException, InterruptedException {
        HttpResponse<String> mockTokenResponse = (HttpResponse<String>) Mockito.mock(HttpResponse.class);
        Mockito.when(mockTokenResponse.statusCode()).thenReturn(404);

        Mockito.when(mockHttpClient.send(Mockito.any(HttpRequest.class), Mockito.any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockTokenResponse);

        Mockito.when(coreDb.queryForObject(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.eq(Long.class))).thenReturn(null);

        ResponseEntity<RecommendationsResponse> response = recommendationsService.getRecommendations("SUB-1", "ACR", 123L, null, 100);

        Mockito.verify(mockHttpClient, Mockito.times(1)).send(requestCaptor.capture(),
                Mockito.any(HttpResponse.BodyHandler.class));
        assertTrue(requestCaptor.getValue().uri().toString().endsWith("/recommendations/reviewers?manuscript_id=SUB-1&size=100"), "Incorrect URL");
        assertEquals("GET", requestCaptor.getValue().method());

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody(), "Body not valid");

        response = recommendationsService.getRecommendations("SUB-1", "JOURNAL", 123L, null, 100);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody(), "Body not valid");

        Object recommenderClass = ReflectionTestUtils.getField(recommendationsService, "recommender");
        ReflectionTestUtils.setField(recommenderClass, "isNonProd", true);
        response = recommendationsService.getRecommendations("SUB-1", "ACR", 123L, null, 100);
        ReflectionTestUtils.setField(recommenderClass, "isNonProd", false);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody(), "Body not valid");
    }
}
