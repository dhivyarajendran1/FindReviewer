package com.elsevier.find.reviewers;

import com.elsevier.find.reviewers.exception.ControllerExceptionResponseHandler;
import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.exception.RecommendationException;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.generated.model.RecommendationsFailureResponse;
import com.elsevier.find.reviewers.generated.model.RecommendationsFailureResponse.MissingManuscriptDataEnum;
import com.elsevier.find.reviewers.service.base.BaseService;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.ConstraintViolationException;
import org.apache.catalina.connector.ClientAbortException;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.context.request.WebRequest;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutionException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * Tests the different type of exceptions - there are some that are covered by the main service tests,
 * this is designed to test those exceptions that are hard to test via service interface calls
 */
public class ExceptionHandlingTest {
    // All methods in the class are protected, so extend them, so they can be exposed for testing
    private static class TestableHandler extends ControllerExceptionResponseHandler {
        public ResponseEntity<ErrorResponse> handleInternalException(InternalException e, WebRequest request) {
            return super.handleInternalException(e, request);
        }

        public ResponseEntity<RecommendationsFailureResponse> handleRecommendationException(RecommendationException e, WebRequest request) {
            return super.handleRecommendationException(e, request);
        }

        public ResponseEntity<ErrorResponse> handleIllegalArgument(RuntimeException e, WebRequest request) {
            return super.handleIllegalArgument(e, request);
        }

        public ResponseEntity<Object> handleClientAbortException(ClientAbortException e, WebRequest request) {
            return super.handleClientAbortException(e, request);
        }

        protected ResponseEntity<ErrorResponse> handleConstraintViolationException(ConstraintViolationException e, WebRequest request) {
            return super.handleConstraintViolationException(e, request);
        }

        public ResponseEntity<ErrorResponse> handleOther(Exception e, WebRequest request) {
            return super.handleOther(e, request);
        }

        public ResponseEntity<Object> handleExceptionInternal(
                Exception ex, Object body, HttpHeaders headers, HttpStatus status, WebRequest request) {
            return super.handleExceptionInternal(ex, body, headers, status, request);
        }
    }

    private final TestableHandler testHandler = new TestableHandler();

    @Test
    void testHandleInternalException() {
        InternalException e = new InternalException(HttpStatus.BAD_GATEWAY);
        ResponseEntity<ErrorResponse> resp = testHandler.handleInternalException(e, null);

        assertEquals(HttpStatus.BAD_GATEWAY, resp.getStatusCode());
        assertNull(resp.getBody());

        e = new InternalException(ErrorResponse.IdEnum.INCOMPLETEDATA, HttpStatus.INSUFFICIENT_STORAGE);
        resp = testHandler.handleInternalException(e, null);

        assertEquals(HttpStatus.INSUFFICIENT_STORAGE, resp.getStatusCode());
        assertEquals(ErrorResponse.IdEnum.INCOMPLETEDATA, resp.getBody().getId());
        assertEquals(0, resp.getBody().getAttributes().size());

        e = new InternalException(ErrorResponse.IdEnum.INCOMPLETEDATA, HttpStatus.INSUFFICIENT_STORAGE, Map.of("attrib1", "value"));
        resp = testHandler.handleInternalException(e, null);

        assertEquals(HttpStatus.INSUFFICIENT_STORAGE, resp.getStatusCode());
        assertEquals(ErrorResponse.IdEnum.INCOMPLETEDATA, resp.getBody().getId());
        assertEquals(1, resp.getBody().getAttributes().size());

        e = new InternalException(ErrorResponse.IdEnum.INCOMPLETEDATA, HttpStatus.INSUFFICIENT_STORAGE);
        e.addAttribute("Attrib1", "value");
        resp = testHandler.handleInternalException(e, null);

        assertEquals(HttpStatus.INSUFFICIENT_STORAGE, resp.getStatusCode());
        assertEquals(ErrorResponse.IdEnum.INCOMPLETEDATA, resp.getBody().getId());
        assertEquals(1, resp.getBody().getAttributes().size());
    }

    @Test
    void testHandleRecommendationsException() {
        RecommendationException e = new RecommendationException(Collections.emptyList());
        ResponseEntity<RecommendationsFailureResponse> resp = testHandler.handleRecommendationException(e, null);

        assertEquals(HttpStatus.NOT_FOUND, resp.getStatusCode());
        assertNull(resp.getBody());

        e = new RecommendationException(List.of("Unknown Attribute"));
        resp = testHandler.handleRecommendationException(e, null);

        assertEquals(HttpStatus.NOT_FOUND, resp.getStatusCode());
        assertNull(resp.getBody());

        e = new RecommendationException(List.of("title"));
        resp = testHandler.handleRecommendationException(e, null);

        assertEquals(HttpStatus.NOT_FOUND, resp.getStatusCode());
        assertNotNull(resp.getBody());
        assertEquals(List.of(MissingManuscriptDataEnum.TITLE), resp.getBody().getMissingManuscriptData());

        e = new RecommendationException(List.of("status"));
        resp = testHandler.handleRecommendationException(e, null);

        assertEquals(HttpStatus.NOT_FOUND, resp.getStatusCode());
        assertNotNull(resp.getBody());
        assertEquals(List.of(MissingManuscriptDataEnum.STATUS), resp.getBody().getMissingManuscriptData());

        e = new RecommendationException(List.of("submissionDate"));
        resp = testHandler.handleRecommendationException(e, null);

        assertEquals(HttpStatus.NOT_FOUND, resp.getStatusCode());
        assertNotNull(resp.getBody());
        assertEquals(List.of(MissingManuscriptDataEnum.SUBMISSIONDATE), resp.getBody().getMissingManuscriptData());

        e = new RecommendationException(List.of("authors"));
        resp = testHandler.handleRecommendationException(e, null);

        assertEquals(HttpStatus.NOT_FOUND, resp.getStatusCode());
        assertNotNull(resp.getBody());
        assertEquals(List.of(MissingManuscriptDataEnum.AUTHORS), resp.getBody().getMissingManuscriptData());

        e = new RecommendationException(List.of("journal"));
        resp = testHandler.handleRecommendationException(e, null);

        assertEquals(HttpStatus.NOT_FOUND, resp.getStatusCode());
        assertNotNull(resp.getBody());
        assertEquals(List.of(MissingManuscriptDataEnum.JOURNAL), resp.getBody().getMissingManuscriptData());

        e = new RecommendationException(List.of("abstract"));
        resp = testHandler.handleRecommendationException(e, null);

        assertEquals(HttpStatus.NOT_FOUND, resp.getStatusCode());
        assertNotNull(resp.getBody());
        assertEquals(List.of(MissingManuscriptDataEnum.ABSTRACT), resp.getBody().getMissingManuscriptData());

        e = new RecommendationException(List.of("authors.corresponding"));
        resp = testHandler.handleRecommendationException(e, null);

        assertEquals(HttpStatus.NOT_FOUND, resp.getStatusCode());
        assertNotNull(resp.getBody());
        assertEquals(List.of(MissingManuscriptDataEnum.CORRESPONDINGAUTHOR), resp.getBody().getMissingManuscriptData());

        e = new RecommendationException(List.of("journal.acronym"));
        resp = testHandler.handleRecommendationException(e, null);

        assertEquals(HttpStatus.NOT_FOUND, resp.getStatusCode());
        assertNotNull(resp.getBody());
        assertEquals(List.of(MissingManuscriptDataEnum.JOURNALACRONYM), resp.getBody().getMissingManuscriptData());

        e = new RecommendationException(List.of("title", "status", "submissionDate", "authors", "journal", "abstract",
                "authors.corresponding", "journal.acronym"));
        resp = testHandler.handleRecommendationException(e, null);

        assertEquals(HttpStatus.NOT_FOUND, resp.getStatusCode());
        assertNotNull(resp.getBody());
        assertEquals(List.of(MissingManuscriptDataEnum.TITLE,
                MissingManuscriptDataEnum.STATUS,
                MissingManuscriptDataEnum.SUBMISSIONDATE,
                MissingManuscriptDataEnum.AUTHORS,
                MissingManuscriptDataEnum.JOURNAL,
                MissingManuscriptDataEnum.ABSTRACT,
                MissingManuscriptDataEnum.CORRESPONDINGAUTHOR,
                MissingManuscriptDataEnum.JOURNALACRONYM), resp.getBody().getMissingManuscriptData());
    }

    @Test
    void testHandleIllegalArgument() {
        RuntimeException e = new RuntimeException();
        ResponseEntity<ErrorResponse> resp = testHandler.handleIllegalArgument(e, null);

        assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode());
        assertEquals(ErrorResponse.IdEnum.INVALIDARGUMENT, resp.getBody().getId());
        assertNull(resp.getBody().getAttributes());

        e = new RuntimeException("JSON parse error: Cannot deserialize instance of `com.elsevier.reviewer.hub.generated.model.VolunteerAdditionalDetails`");
        resp = testHandler.handleIllegalArgument(e, null);

        assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode());
        assertEquals(ErrorResponse.IdEnum.INVALIDARGUMENT, resp.getBody().getId());
        assertEquals(1, resp.getBody().getAttributes().size());
        assertEquals("JSON parse error", resp.getBody().getAttributes().get("Message"));
    }

    @Test
    void testHandleConstraintViolation() {
        ConstraintViolationException e = new ConstraintViolationException(Collections.emptySet());
        ResponseEntity<ErrorResponse> resp = testHandler.handleConstraintViolationException(e, null);

        assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode());
        assertEquals(ErrorResponse.IdEnum.INVALIDARGUMENT, resp.getBody().getId());
        assertNull(resp.getBody().getAttributes());

        e = new ConstraintViolationException("JSON parse error: Cannot deserialize instance of", Collections.emptySet());
        resp = testHandler.handleConstraintViolationException(e, null);

        assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode());
        assertEquals(ErrorResponse.IdEnum.INVALIDARGUMENT, resp.getBody().getId());
        assertEquals(1, resp.getBody().getAttributes().size());
        assertEquals("JSON parse error", resp.getBody().getAttributes().get("Message"));
    }

    @Test
    void testClientAbortException() {
        ClientAbortException e = new ClientAbortException();
        ResponseEntity<Object> resp = testHandler.handleClientAbortException(e, null);

        assertNull(resp, "ClientAbortException in non null response");
    }

    @Test
    void testHandleOther() {
        Exception e = new Exception();
        ResponseEntity<ErrorResponse> resp = testHandler.handleOther(e, null);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, resp.getStatusCode());
        assertEquals(ErrorResponse.IdEnum.UNKNOWN, resp.getBody().getId());
        assertEquals(1, resp.getBody().getAttributes().size());
        assertEquals("Unexpected error, see log for more details", resp.getBody().getAttributes().get("Message"));
    }

    @Test
    void testHandleExceptionInternal() {
        Exception e = new Exception();
        ResponseEntity<Object> resp = testHandler.handleExceptionInternal(e, null, null, null, null);

        assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode());
        assertEquals(ErrorResponse.IdEnum.INVALIDARGUMENT, ((ErrorResponse) resp.getBody()).getId());
        assertNull(((ErrorResponse) resp.getBody()).getAttributes());

        e = new Exception(":");
        resp = testHandler.handleExceptionInternal(e, null, null, HttpStatus.EXPECTATION_FAILED, null);

        assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode());
        assertEquals(ErrorResponse.IdEnum.INVALIDARGUMENT, ((ErrorResponse) resp.getBody()).getId());
        assertEquals(1, ((ErrorResponse) resp.getBody()).getAttributes().size());
        assertEquals("417 EXPECTATION_FAILED", ((ErrorResponse) resp.getBody()).getAttributes().get("SpringHttpStatus"));

        e = new Exception("Exception Message");
        resp = testHandler.handleExceptionInternal(e, null, null, HttpStatus.BANDWIDTH_LIMIT_EXCEEDED, null);

        assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode());
        assertEquals(ErrorResponse.IdEnum.INVALIDARGUMENT, ((ErrorResponse) resp.getBody()).getId());
        assertEquals(2, ((ErrorResponse) resp.getBody()).getAttributes().size());
        assertEquals("509 BANDWIDTH_LIMIT_EXCEEDED", ((ErrorResponse) resp.getBody()).getAttributes().get("SpringHttpStatus"));
        assertEquals("Exception Message", ((ErrorResponse) resp.getBody()).getAttributes().get("Message"));

        resp = testHandler.handleExceptionInternal(null, null, null, null, null);

        assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode());
        assertEquals(ErrorResponse.IdEnum.INVALIDARGUMENT, ((ErrorResponse) resp.getBody()).getId());
        assertNull(((ErrorResponse) resp.getBody()).getAttributes());
    }

    @Test
    void testFuturesExceptions() throws ExecutionException, InterruptedException {
        CompletableFuture mockFuture = Mockito.mock(CompletableFuture.class);
        List<CompletableFuture<Void>> mockFutures = List.of(mockFuture);

        // Hack to the base object to be able to call the Futures method so exceptions can be tested
        BaseService testBase = new BaseService(null) {
            // Trigger waitAndGetFutureContent when getRequest is called
            public Optional<HttpServletRequest> getRequest() {
                this.waitAndGetFutureContent(mockFuture);
                return Optional.empty();
            }

            // Trigger waitAndJoinFutures when getObjectMapper is called
            public Optional<ObjectMapper> getObjectMapper() {
                this.waitAndJoinFutures(mockFutures);
                return Optional.empty();
            }
        };

        Mockito.when(mockFuture.get())
                .thenThrow(new ExecutionException() {
                })
                .thenThrow(new InterruptedException());

        Mockito.when(mockFuture.join())
                .thenThrow(new CompletionException() {
                });

        assertThrows(InternalException.class, testBase::getRequest);
        assertThrows(InternalException.class, testBase::getRequest);
        assertThrows(InternalException.class, testBase::getObjectMapper);
    }
}
