package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.enums.ProductType;
import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.generated.model.CandidatesResponse;
import com.elsevier.find.reviewers.generated.model.EditorialHistory.ClassificationEnum;
import com.elsevier.find.reviewers.generated.model.ReviewHistory.StateEnum;
import com.elsevier.find.reviewers.testutils.JdbcMockAnswer;
import com.elsevier.find.reviewers.testutils.TestBase;
import com.elsevier.find.reviewers.utils.CookieManager;
import org.apache.logging.log4j.ThreadContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.data.jdbc.JdbcRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.sql.SQLException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.OptionalLong;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, JdbcRepositoriesAutoConfiguration.class})
public class Candidates_getCandidateDetailsTest extends TestBase {
    // Wire to the service that we want to test
    @Autowired
    private CandidatesService candidatesService;

    @BeforeEach
    void setup() {
        SessionContext.initialize(new CookieManager.SessionData(ProductType.FindReviewers, "code", "bearer", "CELL", true, false));
    }

    @Test
    void testNoCandidateDetails() {
        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(ResultSetExtractor.class))).thenAnswer(new JdbcMockAnswer());

        ResponseEntity<CandidatesResponse> response = candidatesService.getCandidateDetails(List.of("fred@bedrock.com"), null, null);

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(0, response.getBody().getCandidates().size());
    }

    @Test
    void testInvalidInput() {
        assertThrows(InternalException.class, () -> candidatesService.getCandidateDetails(null, null, null));
        assertThrows(InternalException.class, () -> candidatesService.getCandidateDetails(Collections.emptyList(), null, "ACR"));
    }

    @Test
    void testNonElsevierCandidateDetails() {
        SessionContext.initialize(new CookieManager.SessionData(ProductType.FindReviewers, "code", "bearer", "NON-ELS", true, false));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(ResultSetExtractor.class))).thenAnswer(new JdbcMockAnswer());

        ResponseEntity<CandidatesResponse> response = candidatesService.getCandidateDetails(List.of("fred@bedrock.com"), null, "NON-ELS");

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(0, response.getBody().getCandidates().size());
    }

    @Test
    void testCandidateDetailsNotes() throws SQLException {
        JdbcMockAnswer mockEmAnswer = new JdbcMockAnswer();
        mockEmAnswer.addResultMapping(Map.ofEntries(
                        Map.entry("email", "wilma@bedrock.com"),
                        Map.entry("notes", """
                                [{"postedBy":"Barney Rubble","postedDate":1589808527843,"note":"Great reviewer"},
                                 {"postedBy":"Fred Flinstone","postedDate":1599808527843,"note":"Am I biased?"}]
                                """)),
                Map.ofEntries(
                        Map.entry("email", "fred@bedrock.com"),
                        Map.entry("notes", """
                                [{"postedBy":"Betty Rubble","postedDate":1689808527843,"note":"Average reviewer"}]
                                """)));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(ResultSetExtractor.class))).thenAnswer(mockEmAnswer);

        ResponseEntity<CandidatesResponse> response = candidatesService.getCandidateDetails(List.of("fred@bedrock.com", "wilma@bedrock.com"), null, "ACR");

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(2, response.getBody().getCandidates().size());
        assertEquals("fred@bedrock.com", response.getBody().getCandidates().get(0).getEmail());
        assertEquals(1, response.getBody().getCandidates().get(0).getNotes().size());
        assertEquals("Betty Rubble", response.getBody().getCandidates().get(0).getNotes().get(0).getPostedBy());
        assertEquals(1689808527843L, response.getBody().getCandidates().get(0).getNotes().get(0).getPostedDate());
        assertEquals("Average reviewer", response.getBody().getCandidates().get(0).getNotes().get(0).getNote());
        assertEquals("wilma@bedrock.com", response.getBody().getCandidates().get(1).getEmail());
        assertEquals(2, response.getBody().getCandidates().get(1).getNotes().size());
        assertEquals("Barney Rubble", response.getBody().getCandidates().get(1).getNotes().get(0).getPostedBy());
        assertEquals(1589808527843L, response.getBody().getCandidates().get(1).getNotes().get(0).getPostedDate());
        assertEquals("Great reviewer", response.getBody().getCandidates().get(1).getNotes().get(0).getNote());
        assertEquals("Fred Flinstone", response.getBody().getCandidates().get(1).getNotes().get(1).getPostedBy());
        assertEquals(1599808527843L, response.getBody().getCandidates().get(1).getNotes().get(1).getPostedDate());
        assertEquals("Am I biased?", response.getBody().getCandidates().get(1).getNotes().get(1).getNote());
        assertNull(response.getBody().getCandidates().get(0).getReviewHistory());
        assertNull(response.getBody().getCandidates().get(1).getReviewHistory());
    }

    @Test
    void testCandidateDetailsEditorHistory() throws SQLException {
        JdbcMockAnswer mockEmAnswer = new JdbcMockAnswer();
        mockEmAnswer.addResultMapping(Map.ofEntries(
                        Map.entry("email", "wilma@bedrock.com"),
                        Map.entry("editorial_history", """
                                [{"emJournalAcronym":"OTHER","journalTitle":"OTHER Title",
                                "classification":"editorialBoardMember","role":"EBM","startDate":1324512000000},
                                {"emJournalAcronym":"ACR","journalTitle":"ACR Title",
                                "classification":"editorialBoardMember","role":"EBM","startDate":1324512000000}]
                                """)),
                Map.ofEntries(
                        Map.entry("email", "fred@bedrock.com"),
                        Map.entry("editorial_history", """
                                [{"emJournalAcronym":"ARC1","journalTitle":"ARC1 Title",
                                "classification":"editorialBoardMember","role":"EBM",
                                "endDate":2238684704000}]
                                """)));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(ResultSetExtractor.class))).thenAnswer(mockEmAnswer);

        ResponseEntity<CandidatesResponse> response = candidatesService.getCandidateDetails(List.of("fred@bedrock.com", "wilma@bedrock.com"), null, "ACR");

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(2, response.getBody().getCandidates().size());

        assertEquals("fred@bedrock.com", response.getBody().getCandidates().get(0).getEmail());
        assertEquals(1, response.getBody().getCandidates().get(0).getEditorialHistory().size());
        assertEquals("ARC1", response.getBody().getCandidates().get(0).getEditorialHistory().get(0).getEmJournalAcronym());
        assertEquals("ARC1 Title", response.getBody().getCandidates().get(0).getEditorialHistory().get(0).getJournalTitle());
        assertEquals(ClassificationEnum.EDITORIALBOARDMEMBER, response.getBody().getCandidates().get(0).getEditorialHistory().get(0).getClassification());
        assertEquals("EBM", response.getBody().getCandidates().get(0).getEditorialHistory().get(0).getRole());
        assertNull(response.getBody().getCandidates().get(0).getEditorialHistory().get(0).getStartDate());
        assertEquals(2238684704000L, response.getBody().getCandidates().get(0).getEditorialHistory().get(0).getEndDate());

        assertEquals(2, response.getBody().getCandidates().get(1).getEditorialHistory().size());
        assertEquals("OTHER", response.getBody().getCandidates().get(1).getEditorialHistory().get(0).getEmJournalAcronym());
        assertEquals("OTHER Title", response.getBody().getCandidates().get(1).getEditorialHistory().get(0).getJournalTitle());
        assertEquals(ClassificationEnum.EDITORIALBOARDMEMBER, response.getBody().getCandidates().get(1).getEditorialHistory().get(0).getClassification());
        assertEquals("EBM", response.getBody().getCandidates().get(1).getEditorialHistory().get(0).getRole());
        assertEquals(1324512000000L, response.getBody().getCandidates().get(1).getEditorialHistory().get(0).getStartDate());
        assertNull(response.getBody().getCandidates().get(1).getEditorialHistory().get(0).getEndDate());

        assertNull(response.getBody().getCandidates().get(0).getNotes());
        assertNull(response.getBody().getCandidates().get(1).getNotes());
        assertNull(response.getBody().getCandidates().get(0).getReviewHistory());
        assertNull(response.getBody().getCandidates().get(1).getReviewHistory());
    }

    @Test
    void testCandidateDetailsReviewHistory() throws SQLException {
        JdbcMockAnswer mockEmAnswer = new JdbcMockAnswer();
        mockEmAnswer.addResultMapping(Map.ofEntries(
                        Map.entry("email", "fred@bedrock.com"),
                        Map.entry("notes", "-null-"),
                        Map.entry("editorial_history", "-null-"),
                        Map.entry("journal_acronym", "ACR2"),
                        Map.entry("document_id", 123L),
                        Map.entry("revision", 1),
                        Map.entry("rstart", OptionalLong.of(1589808527843L)),
                        Map.entry("rstop", OptionalLong.of(1589809511783L)),
                        Map.entry("work_in_progress", false),
                        Map.entry("has_not_responded", false),
                        Map.entry("declined", false),
                        Map.entry("terminated", false),
                        Map.entry("completed", false),
                        Map.entry("alternate", false),
                        Map.entry("promoted", false),
                        Map.entry("uninvited", false),
                        Map.entry("assigned_not_invited", true),
                        Map.entry("accepted_date", OptionalLong.of(1589998527843L)),
                        Map.entry("due_date", OptionalLong.of(1589999511783L)),
                        Map.entry("reviewer_decision", "Accept"),
                        Map.entry("editor_decision", "Acceptance")),
                Map.ofEntries(
                        Map.entry("email", "fred@bedrock.com"),
                        Map.entry("notes", "-null-"),
                        Map.entry("editorial_history", "-null-"),
                        Map.entry("journal_acronym", "ACR2"),
                        Map.entry("document_id", 124L),
                        Map.entry("revision", 0),
                        Map.entry("rstart", OptionalLong.of(2589808527843L)),
                        Map.entry("rstop", OptionalLong.of(2589809511783L)),
                        Map.entry("work_in_progress", true),
                        Map.entry("has_not_responded", true),
                        Map.entry("declined", false),
                        Map.entry("terminated", true),
                        Map.entry("completed", false),
                        Map.entry("alternate", true),
                        Map.entry("promoted", true),
                        Map.entry("uninvited", true),
                        Map.entry("assigned_not_invited", false),
                        Map.entry("accepted_date", OptionalLong.of(2589998527843L)),
                        Map.entry("due_date", OptionalLong.of(2589999511783L)),
                        Map.entry("reviewer_decision", "Reject"),
                        Map.entry("editor_decision", "Rejecting")),
                Map.ofEntries(
                        Map.entry("email", "fred@bedrock.com"),
                        Map.entry("notes", "-null-"),
                        Map.entry("editorial_history", "-null-"),
                        Map.entry("journal_acronym", "ACR3"),
                        Map.entry("document_id", 125L),
                        Map.entry("revision", 0),
                        Map.entry("rstart", OptionalLong.of(2689808527843L)),
                        Map.entry("rstop", OptionalLong.of(2689809511783L)),
                        Map.entry("work_in_progress", false),
                        Map.entry("has_not_responded", false),
                        Map.entry("declined", false),
                        Map.entry("terminated", false),
                        Map.entry("completed", true),
                        Map.entry("alternate", false),
                        Map.entry("promoted", true),
                        Map.entry("uninvited", false),
                        Map.entry("assigned_not_invited", false),
                        Map.entry("accepted_date", OptionalLong.of(2689998527843L)),
                        Map.entry("due_date", OptionalLong.of(2689999511783L)),
                        Map.entry("reviewer_decision", "Undecided"),
                        Map.entry("editor_decision", "Delayed")));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(ResultSetExtractor.class))).thenAnswer(mockEmAnswer);

        ResponseEntity<CandidatesResponse> response = candidatesService.getCandidateDetails(List.of("fred@bedrock.com"), null, "ACR");

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(1, response.getBody().getCandidates().size());
        assertEquals("fred@bedrock.com", response.getBody().getCandidates().get(0).getEmail());
        assertNull(response.getBody().getCandidates().get(0).getNotes());
        assertEquals(3, response.getBody().getCandidates().get(0).getReviewHistory().size());

        assertEquals("ACR2", response.getBody().getCandidates().get(0).getReviewHistory().get(0).getEmJournalAcronym());
        assertEquals(123L, response.getBody().getCandidates().get(0).getReviewHistory().get(0).getDocumentId());
        assertEquals(1, response.getBody().getCandidates().get(0).getReviewHistory().get(0).getRevision());
        assertEquals(1589808527843L, response.getBody().getCandidates().get(0).getReviewHistory().get(0).getStartDate());
        assertEquals(1589809511783L, response.getBody().getCandidates().get(0).getReviewHistory().get(0).getStopDate());
        assertEquals(StateEnum.ASSIGNEDNOTINVITED, response.getBody().getCandidates().get(0).getReviewHistory().get(0).getState());
        assertEquals(1589998527843L, response.getBody().getCandidates().get(0).getReviewHistory().get(0).getAcceptDate());
        assertEquals(1589999511783L, response.getBody().getCandidates().get(0).getReviewHistory().get(0).getDueDate());
        assertEquals("Accept", response.getBody().getCandidates().get(0).getReviewHistory().get(0).getReviewerDecision());
        assertEquals("Acceptance", response.getBody().getCandidates().get(0).getReviewHistory().get(0).getEditorDecision());

        assertEquals("ACR2", response.getBody().getCandidates().get(0).getReviewHistory().get(1).getEmJournalAcronym());
        assertEquals(124L, response.getBody().getCandidates().get(0).getReviewHistory().get(1).getDocumentId());
        assertEquals(0, response.getBody().getCandidates().get(0).getReviewHistory().get(1).getRevision());
        assertEquals(2589808527843L, response.getBody().getCandidates().get(0).getReviewHistory().get(1).getStartDate());
        assertEquals(2589809511783L, response.getBody().getCandidates().get(0).getReviewHistory().get(1).getStopDate());
        assertEquals(StateEnum.TERMINATED, response.getBody().getCandidates().get(0).getReviewHistory().get(1).getState());
        assertEquals(2589998527843L, response.getBody().getCandidates().get(0).getReviewHistory().get(1).getAcceptDate());
        assertEquals(2589999511783L, response.getBody().getCandidates().get(0).getReviewHistory().get(1).getDueDate());
        assertEquals("Reject", response.getBody().getCandidates().get(0).getReviewHistory().get(1).getReviewerDecision());
        assertEquals("Rejecting", response.getBody().getCandidates().get(0).getReviewHistory().get(1).getEditorDecision());

        assertEquals("ACR3", response.getBody().getCandidates().get(0).getReviewHistory().get(2).getEmJournalAcronym());
        assertEquals(125L, response.getBody().getCandidates().get(0).getReviewHistory().get(2).getDocumentId());
        assertEquals(0, response.getBody().getCandidates().get(0).getReviewHistory().get(2).getRevision());
        assertEquals(2689808527843L, response.getBody().getCandidates().get(0).getReviewHistory().get(2).getStartDate());
        assertEquals(2689809511783L, response.getBody().getCandidates().get(0).getReviewHistory().get(2).getStopDate());
        assertEquals(StateEnum.COMPLETED, response.getBody().getCandidates().get(0).getReviewHistory().get(2).getState());
        assertEquals(2689998527843L, response.getBody().getCandidates().get(0).getReviewHistory().get(2).getAcceptDate());
        assertEquals(2689999511783L, response.getBody().getCandidates().get(0).getReviewHistory().get(2).getDueDate());
        assertEquals("Undecided", response.getBody().getCandidates().get(0).getReviewHistory().get(2).getReviewerDecision());
        assertEquals("Delayed", response.getBody().getCandidates().get(0).getReviewHistory().get(2).getEditorDecision());
    }

    @Test
    void testCandidateDetailsReviewHistoryMoreStates() throws SQLException {
        Map<String, Object> dbReturnBase = Map.ofEntries(
                Map.entry("email", "fred@bedrock.com"),
                Map.entry("notes", "-null-"),
                Map.entry("editorial_history", "-null-"),
                Map.entry("journal_acronym", "ACR2"),
                Map.entry("document_id", 123L),
                Map.entry("revision", 1),
                Map.entry("rstart", OptionalLong.empty()),
                Map.entry("rstop", OptionalLong.empty()),
                Map.entry("work_in_progress", false),
                Map.entry("has_not_responded", false),
                Map.entry("declined", false),
                Map.entry("terminated", false),
                Map.entry("completed", false),
                Map.entry("alternate", false),
                Map.entry("promoted", false),
                Map.entry("uninvited", false),
                Map.entry("assigned_not_invited", false),
                Map.entry("accepted_date", OptionalLong.empty()),
                Map.entry("due_date", OptionalLong.empty()),
                Map.entry("reviewer_decision", "-null-"),
                Map.entry("editor_decision", "-null-"));

        JdbcMockAnswer mockEmAnswer1 = new JdbcMockAnswer();
        Map<String, Object> dbReturn1 = new HashMap<>();
        dbReturn1.putAll(dbReturnBase);
        dbReturn1.put("declined", true);
        mockEmAnswer1.addResultMapping(dbReturn1);

        JdbcMockAnswer mockEmAnswer2 = new JdbcMockAnswer();
        Map<String, Object> dbReturn2 = new HashMap<>();
        dbReturn2.putAll(dbReturnBase);
        dbReturn2.put("uninvited", true);
        mockEmAnswer2.addResultMapping(dbReturn2);

        JdbcMockAnswer mockEmAnswer3 = new JdbcMockAnswer();
        Map<String, Object> dbReturn3 = new HashMap<>();
        dbReturn3.putAll(dbReturnBase);
        dbReturn3.put("work_in_progress", true);
        mockEmAnswer3.addResultMapping(dbReturn3);

        JdbcMockAnswer mockEmAnswer4 = new JdbcMockAnswer();
        Map<String, Object> dbReturn4 = new HashMap<>();
        dbReturn4.putAll(dbReturnBase);
        mockEmAnswer4.addResultMapping(dbReturn4);

        Mockito.when(coreDb.query(Mockito.anyString(),
                        Mockito.any(SqlParameterSource.class),
                        Mockito.any(ResultSetExtractor.class)))
                .thenAnswer(mockEmAnswer1).thenAnswer(mockEmAnswer2).thenAnswer(mockEmAnswer3).thenAnswer(mockEmAnswer4);

        ResponseEntity<CandidatesResponse> response = candidatesService.getCandidateDetails(List.of("fred@bedrock.com"), null, "ACR");

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(1, response.getBody().getCandidates().size());
        assertEquals("fred@bedrock.com", response.getBody().getCandidates().get(0).getEmail());
        assertNull(response.getBody().getCandidates().get(0).getNotes());
        assertEquals(1, response.getBody().getCandidates().get(0).getReviewHistory().size());

        assertEquals("ACR2", response.getBody().getCandidates().get(0).getReviewHistory().get(0).getEmJournalAcronym());
        assertEquals(123L, response.getBody().getCandidates().get(0).getReviewHistory().get(0).getDocumentId());
        assertEquals(1, response.getBody().getCandidates().get(0).getReviewHistory().get(0).getRevision());
        assertNull(response.getBody().getCandidates().get(0).getReviewHistory().get(0).getStartDate());
        assertNull(response.getBody().getCandidates().get(0).getReviewHistory().get(0).getStopDate());
        assertEquals(StateEnum.DECLINED, response.getBody().getCandidates().get(0).getReviewHistory().get(0).getState());
        assertNull(response.getBody().getCandidates().get(0).getReviewHistory().get(0).getAcceptDate());
        assertNull(response.getBody().getCandidates().get(0).getReviewHistory().get(0).getDueDate());
        assertNull(response.getBody().getCandidates().get(0).getReviewHistory().get(0).getReviewerDecision());
        assertNull(response.getBody().getCandidates().get(0).getReviewHistory().get(0).getEditorDecision());

        response = candidatesService.getCandidateDetails(List.of("fred@bedrock.com"), null, "ACR");

        assertEquals(StateEnum.UNINVITED, response.getBody().getCandidates().get(0).getReviewHistory().get(0).getState());

        response = candidatesService.getCandidateDetails(List.of("fred@bedrock.com"), null, "ACR");

        assertEquals(StateEnum.WORKINPROGRESS, response.getBody().getCandidates().get(0).getReviewHistory().get(0).getState());

        response = candidatesService.getCandidateDetails(List.of("fred@bedrock.com"), null, "ACR");

        assertNull(response.getBody().getCandidates().get(0).getReviewHistory().get(0).getState());
    }

    @Test
    void testCandidateDetailsInvalidNotes() throws SQLException {
        // TESTING NOTE: Because of the way the DAO may not read all the boolean values for the states
        // when testing multiple review history records for one reviewer they need to be ordered so that the
        // one that is the last state checked in the DAO is the first in the review records
        JdbcMockAnswer mockEmAnswer = new JdbcMockAnswer();
        mockEmAnswer.addResultMapping(Map.ofEntries(
                        Map.entry("email", "wilma@bedrock.com"),
                        Map.entry("notes", "{Not JSON}"),
                        Map.entry("editorial_history", "{Not JSON}"),
                        Map.entry("journal_acronym", "ACR1"),
                        Map.entry("document_id", 123L),
                        Map.entry("revision", 1),
                        Map.entry("rstart", OptionalLong.of(1589808527843L)),
                        Map.entry("rstop", OptionalLong.of(1589809511783L)),
                        Map.entry("work_in_progress", false),
                        Map.entry("has_not_responded", false),
                        Map.entry("declined", false),
                        Map.entry("terminated", false),
                        Map.entry("completed", false),
                        Map.entry("alternate", false),
                        Map.entry("promoted", true),
                        Map.entry("uninvited", false),
                        Map.entry("assigned_not_invited", false),
                        Map.entry("accepted_date", OptionalLong.of(1589998527843L)),
                        Map.entry("due_date", OptionalLong.of(1589999511783L)),
                        Map.entry("reviewer_decision", "-null-"),
                        Map.entry("editor_decision", "-null-")),
                Map.ofEntries(
                        Map.entry("email", "wilma@bedrock.com"),
                        Map.entry("notes", "{Not JSON}"),
                        Map.entry("editorial_history", "{Not JSON}"),
                        Map.entry("journal_acronym", "ACR1"),
                        Map.entry("document_id", 124L),
                        Map.entry("revision", 0),
                        Map.entry("rstart", OptionalLong.of(2589808527843L)),
                        Map.entry("rstop", OptionalLong.of(1589809511783L)),
                        Map.entry("work_in_progress", false),
                        Map.entry("has_not_responded", true),
                        Map.entry("declined", false),
                        Map.entry("terminated", false),
                        Map.entry("completed", false),
                        Map.entry("alternate", false),
                        Map.entry("promoted", false),
                        Map.entry("uninvited", false),
                        Map.entry("assigned_not_invited", false),
                        Map.entry("accepted_date", OptionalLong.of(1589998527843L)),
                        Map.entry("due_date", OptionalLong.of(1589999511783L)),
                        Map.entry("reviewer_decision", "-null-"),
                        Map.entry("editor_decision", "-null-")),
                Map.ofEntries(
                        Map.entry("email", "wilma@bedrock.com"),
                        Map.entry("notes", "{Not JSON}"),
                        Map.entry("editorial_history", "{Not JSON}"),
                        Map.entry("journal_acronym", "ACR1"),
                        Map.entry("document_id", 125L),
                        Map.entry("revision", 0),
                        Map.entry("rstart", OptionalLong.of(2589808527843L)),
                        Map.entry("rstop", OptionalLong.empty()),
                        Map.entry("work_in_progress", false),
                        Map.entry("has_not_responded", false),
                        Map.entry("declined", false),
                        Map.entry("terminated", false),
                        Map.entry("completed", false),
                        Map.entry("alternate", true),
                        Map.entry("promoted", false),
                        Map.entry("uninvited", false),
                        Map.entry("assigned_not_invited", false),
                        Map.entry("accepted_date", OptionalLong.of(1589998527843L)),
                        Map.entry("due_date", OptionalLong.of(1589999511783L)),
                        Map.entry("reviewer_decision", "-null-"),
                        Map.entry("editor_decision", "-null-")));

        Mockito.when(coreDb.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class),
                Mockito.any(ResultSetExtractor.class))).thenAnswer(mockEmAnswer);

        ResponseEntity<CandidatesResponse> response = candidatesService.getCandidateDetails(List.of("wilma@bedrock.com"), null, "ACR");

        assertNotNull(response, "Null Response");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody(), "Body not valid");
        assertEquals(1, response.getBody().getCandidates().size());
        assertEquals("wilma@bedrock.com", response.getBody().getCandidates().get(0).getEmail());
        assertNull(response.getBody().getCandidates().get(0).getNotes());

        assertEquals(3, response.getBody().getCandidates().get(0).getReviewHistory().size());

        assertEquals("ACR1", response.getBody().getCandidates().get(0).getReviewHistory().get(0).getEmJournalAcronym());
        assertEquals(123L, response.getBody().getCandidates().get(0).getReviewHistory().get(0).getDocumentId());
        assertEquals(1, response.getBody().getCandidates().get(0).getReviewHistory().get(0).getRevision());
        assertEquals(1589808527843L, response.getBody().getCandidates().get(0).getReviewHistory().get(0).getStartDate());
        assertEquals(StateEnum.PROMOTED, response.getBody().getCandidates().get(0).getReviewHistory().get(0).getState());
        assertNull(response.getBody().getCandidates().get(0).getReviewHistory().get(0).getReviewerDecision());
        assertNull(response.getBody().getCandidates().get(0).getReviewHistory().get(0).getEditorDecision());

        assertEquals("ACR1", response.getBody().getCandidates().get(0).getReviewHistory().get(1).getEmJournalAcronym());
        assertEquals(124L, response.getBody().getCandidates().get(0).getReviewHistory().get(1).getDocumentId());
        assertEquals(0, response.getBody().getCandidates().get(0).getReviewHistory().get(1).getRevision());
        assertEquals(2589808527843L, response.getBody().getCandidates().get(0).getReviewHistory().get(1).getStartDate());
        assertEquals(StateEnum.HASNOTRESPONDED, response.getBody().getCandidates().get(0).getReviewHistory().get(1).getState());

        assertEquals("ACR1", response.getBody().getCandidates().get(0).getReviewHistory().get(1).getEmJournalAcronym());
        assertEquals(125L, response.getBody().getCandidates().get(0).getReviewHistory().get(2).getDocumentId());
        assertEquals(0, response.getBody().getCandidates().get(0).getReviewHistory().get(2).getRevision());
        assertEquals(2589808527843L, response.getBody().getCandidates().get(0).getReviewHistory().get(2).getStartDate());
        assertEquals(StateEnum.ALTERNATE, response.getBody().getCandidates().get(0).getReviewHistory().get(2).getState());
    }
}
