package com.elsevier.find.reviewers.dao;

import com.elsevier.find.reviewers.generated.model.CandidateDetails;
import com.elsevier.find.reviewers.generated.model.PersonDetailsReviewStatistics;

import java.util.List;
import java.util.Map;

/**
 * Interface that supports operations on Review History
 */
public interface CandidateInfoDao {
    interface ReviewStatistics {
        List<PersonDetailsReviewStatistics> getStatistics();

        boolean toRemove();
    }

    /**
     * Gets the review statistics for a list of users
     *
     * @param emails List of emails the review statistics is required for
     * @return list of review statistics mapped for each email
     */
    Map<String, ReviewStatistics> getReviewStatistics(List<String> emails);

    /**
     * Gets the details for a list of users
     *
     * @param emJournalAcronym EM Journal Acronym to get details for
     * @param emails           List of emails the details are required for
     * @return list of candidates details
     */
    List<CandidateDetails> getCandidateDetails(String emJournalAcronym, List<String> emails);
}
