package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.dao.EditorDao;
import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.generated.api.EditorsApiDelegate;
import com.elsevier.find.reviewers.generated.model.Editor;
import com.elsevier.find.reviewers.generated.model.EditorsResponse;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.generated.model.KeywordSearchLogic;
import com.elsevier.find.reviewers.service.base.BaseService;
import com.elsevier.find.reviewers.service.base.DataGatherRules;
import com.elsevier.find.reviewers.service.base.PersonDetailsSupportService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

/**
 * Class to handle all requests on the volunteer endpoint
 */
@Slf4j
@Service
public class EditorsService extends BaseService implements EditorsApiDelegate {

    private final EditorDao editorDao;

    private final PersonDetailsSupportService personDetailsSupportService;

    public EditorsService(ObjectMapper objectMapper,
                          EditorDao editorDao,
                          PersonDetailsSupportService personDetailsSupportService) {
        super(objectMapper);
        this.editorDao = editorDao;
        this.personDetailsSupportService = personDetailsSupportService;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class, readOnly = true)
    public ResponseEntity<EditorsResponse> getEditors(String emJournalAcronym,
                                                      String xScope,
                                                      String keywords,
                                                      KeywordSearchLogic searchLogic,
                                                      Integer offset,
                                                      Integer limit) {
        // We only have editor information for Elsevier journals
        if (!SessionContext.isElsevierJournal()) {
            return ResponseEntity.ok().body(new EditorsResponse());
        }

        if (emJournalAcronym == null || emJournalAcronym.isBlank()) {
            log.error("Editor request made without EM Journal Acronym");
            throw new InternalException(ErrorResponse.IdEnum.INVALIDARGUMENT,
                    HttpStatus.BAD_REQUEST, Map.of("emJournalAcronym", "null"));
        }

        List<Editor> editors = editorDao.getEditorialBoardMembersByEmJournalAcronym(emJournalAcronym, offset, limit);

        // If the request was to limit the records, and we found fewer records than the limit, then there is no more
        // records available
        EditorsResponse response = new EditorsResponse();
        response.setMore(limit != null && editors.size() >= limit);

        DataGatherRules<Editor> rules = new DataGatherRules<>(editors)
                .addInternalDbData().addReviewStatistics(false).addScopusData().addContentMatch(keywords, searchLogic);

        editors = personDetailsSupportService.gatherAdditionalData(emJournalAcronym, rules);

        response.setEditors(editors);

        log.info("Returning {} editors for journal {}", editors.size(), emJournalAcronym);

        return ResponseEntity.ok().body(response);
    }
}
