package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.dao.JournalDao;
import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.generated.api.JournalReviewersApiDelegate;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.generated.model.JournalReviewersResponse;
import com.elsevier.find.reviewers.generated.model.KeywordSearchLogic;
import com.elsevier.find.reviewers.generated.model.PersonDetails;
import com.elsevier.find.reviewers.generated.model.PersonDetailsReviewStatistics;
import com.elsevier.find.reviewers.generated.model.ScopusSearchAuthor;
import com.elsevier.find.reviewers.service.base.BaseService;
import com.elsevier.find.reviewers.service.base.DataGatherRules;
import com.elsevier.find.reviewers.service.base.PersonDetailsSupportService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
public class JournalReviewerService extends BaseService implements JournalReviewersApiDelegate {

    private final JournalDao journalDao;

    private final PersonDetailsSupportService personDetailsSupportService;

    public JournalReviewerService(ObjectMapper objectMapper,
                                  JournalDao journalDao,
                                  PersonDetailsSupportService personDetailsSupportService) {
        super(objectMapper);
        this.journalDao = journalDao;
        this.personDetailsSupportService = personDetailsSupportService;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class, readOnly = true)
    public ResponseEntity<JournalReviewersResponse> getJournalReviewers(String emJournalAcronym,
                                                                        String keywords,
                                                                        String xScope,
                                                                        KeywordSearchLogic searchLogic,
                                                                        Integer offset,
                                                                        Integer limit) {
        if (!SessionContext.isUrsdbJournal()) {
            return ResponseEntity.ok().body(new JournalReviewersResponse());
        }

        if (emJournalAcronym == null || emJournalAcronym.isBlank() || keywords == null || keywords.trim().length() < 3 ||
                limit == null || limit > 200) {
            final Map<String, String> args = Map.of("emJournalAcronym", String.valueOf(emJournalAcronym),
                    "keywords", String.valueOf(keywords),
                    "limit", String.valueOf(limit));
            log.error("Invalid request for Journal Reviewers, no journal acronym, no limit under 201 or without at least 3 character keyword {}",
                    args);
            throw new InternalException(ErrorResponse.IdEnum.INVALIDARGUMENT, HttpStatus.BAD_REQUEST, args);
        }

        List<ScopusSearchAuthor> reviewers = journalDao.getJournalReviewers(emJournalAcronym, offset, limit);

        log.debug("Read {} Journal reviewers from the database for {}", reviewers, emJournalAcronym);

        // If the request was to limit the records, and we found fewer records than the limit, then there is no more
        // records available
        JournalReviewersResponse response = new JournalReviewersResponse();
        response.setMore(reviewers.size() >= limit);

        if (!reviewers.isEmpty()) {
            DataGatherRules<ScopusSearchAuthor> rules = new DataGatherRules<>(reviewers)
                    .addBlockList().addInternalDbData().addReviewStatistics(true).addScopusData().addContentMatch(keywords, searchLogic);

            List<ScopusSearchAuthor> reviewersWithDetails = personDetailsSupportService.gatherAdditionalData(emJournalAcronym, rules);

            List<ScopusSearchAuthor> cleanedReviewers = reviewersWithDetails.stream()
                    .filter(r -> (r.getKeywordMatchCount() != null &&
                            r.getKeywordMatchCount() > 1) &&
                            getActiveReviewCount(r) < 3)
                    .collect(Collectors.toList());

            response.setReviewers(cleanedReviewers);

            log.info("Journal reviewers cleaned search returned {} results for {}", cleanedReviewers.size(), emJournalAcronym);
        }

        return ResponseEntity.ok().body(response);
    }

    private long getActiveReviewCount(PersonDetails person) {
        List<PersonDetailsReviewStatistics> reviewStatistics = person.getReviewStatistics();

        long activeReviewCount = 0;
        if (reviewStatistics != null) {
            for (PersonDetailsReviewStatistics stats : reviewStatistics) {
                activeReviewCount += stats.getWorkInProgressCount();
            }
        }
        return activeReviewCount;
    }
}
