package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.CandidateDetails;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * The response for a list of candidates details
 */
@Schema(description = "The response for a list of candidates details")
@Validated



public class CandidatesResponse   {
  @JsonProperty("candidates")
  @Valid
  private List<CandidateDetails> candidates = new ArrayList<>();

  public CandidatesResponse candidates(List<CandidateDetails> candidates) {
    this.candidates = candidates;
    return this;
  }

  public CandidatesResponse addCandidatesItem(CandidateDetails candidatesItem) {
    this.candidates.add(candidatesItem);
    return this;
  }

  /**
   * Get candidates
   * @return candidates
   **/
  @Schema(required = true, description = "")
      @NotNull
    @Valid
    public List<CandidateDetails> getCandidates() {
    return candidates;
  }

  public void setCandidates(List<CandidateDetails> candidates) {
    this.candidates = candidates;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CandidatesResponse candidatesResponse = (CandidatesResponse) o;
    return Objects.equals(this.candidates, candidatesResponse.candidates);
  }

  @Override
  public int hashCode() {
    return Objects.hash(candidates);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CandidatesResponse {\n");
    
    sb.append("    candidates: ").append(toIndentedString(candidates)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
