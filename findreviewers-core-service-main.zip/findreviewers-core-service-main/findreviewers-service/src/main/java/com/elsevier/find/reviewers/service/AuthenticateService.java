package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.dao.EditorDao;
import com.elsevier.find.reviewers.dao.JournalDao;
import com.elsevier.find.reviewers.dao.UserDao;
import com.elsevier.find.reviewers.enums.ProductType;
import com.elsevier.find.reviewers.external.EditorialManager;
import com.elsevier.find.reviewers.external.EditorialManager.AuthResponse;
import com.elsevier.find.reviewers.external.ReviewerHub;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.generated.api.AuthenticateApiDelegate;
import com.elsevier.find.reviewers.generated.model.AuthenticateBody;
import com.elsevier.find.reviewers.generated.model.AuthenticateResponse;
import com.elsevier.find.reviewers.service.base.BaseService;
import com.elsevier.find.reviewers.utils.Constants;
import com.elsevier.find.reviewers.utils.CookieManager;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * Class to handle all requests on the authenticate endpoint
 */
@Slf4j
@Service
public class AuthenticateService extends BaseService implements AuthenticateApiDelegate {
    private static final long MAXIMUM_SESSION_DURATION = 36000;

    private final EditorialManager editorialManager;
    private final ReviewerHub reviewerHub;
    private final JournalDao journalDao;
    private final EditorDao editorDao;
    private final UserDao userDao;
    private final CookieManager cookieManager;
    private final String readOnlyAuthCode;

    // Stop SonarQube complaining about the number of constructor arguments
    @SuppressWarnings("java:S107")
    public AuthenticateService(ObjectMapper objectMapper,
                               EditorialManager editorialManager,
                               ReviewerHub reviewerHub,
                               JournalDao journalDao,
                               EditorDao editorDao,
                               UserDao userDao,
                               CookieManager cookieManager,
                               @Value("${read.only.authentication.code}") String readOnlyAuthCode) {
        super(objectMapper);
        this.editorialManager = editorialManager;
        this.reviewerHub = reviewerHub;
        this.journalDao = journalDao;
        this.editorDao = editorDao;
        this.userDao = userDao;
        this.cookieManager = cookieManager;
        this.readOnlyAuthCode = readOnlyAuthCode;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class, readOnly = true)
    public ResponseEntity<AuthenticateResponse> authenticate(String xScope,
                                                             AuthenticateBody body,
                                                             String findReviewersSession) {
        if (xScope == null || xScope.isBlank()) {
            log.error("Authentication failed due to invalid X-Scope in request");
            return getUnauthorisedResponse(xScope);
        }

        if ("FE-IDP".equals(xScope)) {
            return findEditorAuthentication(xScope);
        }

        // Find Reviewers (regardless of launch location) requires a Journal Acronym
        if (body == null || body.getEmJournalAcronym() == null || body.getEmJournalAcronym().isBlank()) {
            log.warn("Authentication failed due to invalid request for journal {}",
                    body == null || body.getEmJournalAcronym() == null ? "null" : body.getEmJournalAcronym());
            return getUnauthorisedResponse(xScope);
        }

        if (xScope.startsWith("FR-IDP-")) {
            return findReviewersIdpAuthentication(xScope, body);
        }

        return findReviewersEmAuthentication(xScope, body, findReviewersSession);
    }

    private ResponseEntity<AuthenticateResponse> findEditorAuthentication(String xScope) {
        // Find Editors currently matches against a hard coded list of user email addresses
        final List<String> usersEmails = SessionContext.getAllEmails();
        if (usersEmails.isEmpty()) {
            log.warn("Authentication failed for Find Editors {} for user without emails, WebUserId {}, name {}", xScope,
                    SessionContext.getWebUserId(), SessionContext.getDisplayName());
            return getUnauthorisedResponse(xScope);
        }

        // Check the superuser and then look at the users role
        if (Collections.disjoint(usersEmails, Constants.findEditorsSuperUserEmails)) {
            log.debug("Find Editors user not Superuser {}", usersEmails);
            if (!userDao.isAllowedFindEditorAccess(usersEmails)) {
                log.debug("Find Editors user not a supported default role {}", usersEmails);
                if (!reviewerHub.checkFindEditorsAccess(usersEmails)) {
                    log.warn("Authentication failed for Find Editors {} for user {}", xScope, usersEmails);
                    return getUnauthorisedResponse(xScope);
                }
            }
        }

        log.info("Detected login to Find Editors for {}", usersEmails);

        ResponseCookie cookie = cookieManager.createCookie(ProductType.FindEditors, null, null,
                MAXIMUM_SESSION_DURATION, null, true, true, xScope);

        AuthenticateResponse response = new AuthenticateResponse();
        response.setAnalyticsInfo(SessionContext.getAnalyticsInfo());
        response.setExpires(Instant.now().toEpochMilli() + (MAXIMUM_SESSION_DURATION * 1000));
        response.setEmails(usersEmails);
        response.setDisplayName(SessionContext.getDisplayName());

        return ResponseEntity.ok().header(HttpHeaders.SET_COOKIE, cookie.toString()).body(response);
    }

    private ResponseEntity<AuthenticateResponse> findReviewersIdpAuthentication(String xScope, AuthenticateBody body) {
        final List<String> emails = SessionContext.getAllEmails();
        if (emails.isEmpty()) {
            log.warn("Find Reviewers authentication request made without emails, WebUserId {}, name {}",
                    SessionContext.getWebUserId(), SessionContext.getDisplayName());
            return getUnauthorisedResponse(xScope);
        }

        log.info("Authentication request made for code {}, ID+ user {}", body.getAuthenticationCode(), emails);

        final boolean isReadOnlySession = readOnlyAuthCode.equals(body.getAuthenticationCode());

        // When logging in from ID+ we need to check that the user is a valid editor for the journal
        CompletableFuture<Boolean> isEditorFuture = createAsyncFuture(() ->
                editorDao.isEditor(body.getEmJournalAcronym(), emails));

        CompletableFuture<Boolean> isUrsdbJournalFuture = createAsyncFuture(() ->
                journalDao.isUrsdbJournal(body.getEmJournalAcronym()));

        final boolean isEditor = waitAndGetFutureContent(isEditorFuture);
        if (!isEditor && !isReadOnlySession) {
            log.warn("Authentication failed due to invalid editor user {} for journal {}", SessionContext.getAllEmails(),
                    body.getEmJournalAcronym());
            return getUnauthorisedResponse(xScope);
        }

        final boolean isUrsdbJournal = waitAndGetFutureContent(isUrsdbJournalFuture);

        final long expiry = MAXIMUM_SESSION_DURATION;
        log.debug("Authorisation complete with expire in {} and URSDB support {}", expiry, isUrsdbJournal);

        ResponseCookie cookie = cookieManager.createCookie(ProductType.FindReviewers, body.getAuthenticationCode(),
                readOnlyAuthCode, expiry, body.getEmJournalAcronym(), isReadOnlySession, isUrsdbJournal, xScope);

        AuthenticateResponse idpResponse = new AuthenticateResponse();
        idpResponse.setEmails(emails);
        idpResponse.setDisplayName(SessionContext.getDisplayName());
        idpResponse.setAnalyticsInfo(SessionContext.getAnalyticsInfo());
        idpResponse.setExpires(Instant.now().toEpochMilli() + (expiry * 1000));
        idpResponse.setAnalyticsEnabled(isUrsdbJournal ||
                Constants.nonUrsdbElsevierJournals.containsKey(body.getEmJournalAcronym().toUpperCase()));

        return ResponseEntity.ok().header(HttpHeaders.SET_COOKIE, cookie.toString()).body(idpResponse);
    }

    private ResponseEntity<AuthenticateResponse> findReviewersEmAuthentication(String xScope, AuthenticateBody body, String findReviewersSession) {
        // There is a case where the user can refresh the browser, and it will initiate another authentication request
        // We can check for this if there is an existing cookie that was generated using the same code.
        // We stop the re-authentication as that will fail as the code will have expired in EM, and instead we
        // continue using the existing cookie
        if (cookieManager.isSameSession(body.getAuthenticationCode(), findReviewersSession)) {
            log.info("Duplicate request to authenticate with same code as existing code {} session {}",
                    body.getAuthenticationCode(), findReviewersSession);
            return ResponseEntity.ok().build();
        }

        log.info("Editorial Manager authentication request made for code {}", body.getAuthenticationCode());

        final boolean isReadOnlySession = readOnlyAuthCode.equals(body.getAuthenticationCode());

        CompletableFuture<Boolean> isUrsdbJournalFuture =
                createAsyncFuture(() -> journalDao.isUrsdbJournal(body.getEmJournalAcronym()));

        CompletableFuture<AuthResponse> authFuture = createAsyncFuture(() -> {
            AuthResponse auth = null;
            // Check for the case where we have the special Read Only code. This code does not need to be verified
            // with EM, but at the same time will not allow any data to be saved
            if (isReadOnlySession) {
                auth = new AuthResponse();
                auth.setAccessToken(readOnlyAuthCode);
                auth.setExpiresIn(String.valueOf(MAXIMUM_SESSION_DURATION));
            } else if (body.getAuthenticationCode() != null) {
                auth = editorialManager.getBearerToken(body.getAuthenticationCode());
            }
            return auth;
        });

        AuthResponse auth = waitAndGetFutureContent(authFuture);
        if (auth == null) {
            return getUnauthorisedResponse(xScope);
        }

        final boolean isUrsdbJournal = waitAndGetFutureContent(isUrsdbJournalFuture);

        final long expiry = Math.min(MAXIMUM_SESSION_DURATION, Long.parseLong(auth.getExpiresIn()));
        log.debug("Authorisation complete with {} to expire in {} with URSDB support - {}", auth, expiry, isUrsdbJournal);

        ResponseCookie cookie = cookieManager.createCookie(ProductType.FindReviewers, body.getAuthenticationCode(),
                auth.getAccessToken(), expiry, body.getEmJournalAcronym(), isReadOnlySession, isUrsdbJournal, xScope);

        AuthenticateResponse response = new AuthenticateResponse();
        response.setAnalyticsInfo(SessionContext.getAnalyticsInfo());
        response.setExpires(Instant.now().toEpochMilli() + (expiry * 1000));
        response.setAnalyticsEnabled(isUrsdbJournal ||
                Constants.nonUrsdbElsevierJournals.containsKey(body.getEmJournalAcronym().toUpperCase()));

        return ResponseEntity.ok().header(HttpHeaders.SET_COOKIE, cookie.toString()).body(response);
    }

    private ResponseEntity<AuthenticateResponse> getUnauthorisedResponse(String xScope) {
        if (xScope == null || xScope.isBlank()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .header(HttpHeaders.SET_COOKIE, cookieManager.deleteCookie(xScope).toString()).build();
    }
}
