package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.FundingAward;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * The response for a list of Funding Awards
 */
@Schema(description = "The response for a list of Funding Awards")
@Validated



public class FundingResponse   {
  @JsonProperty("fundingAwards")
  @Valid
  private List<FundingAward> fundingAwards = null;

  public FundingResponse fundingAwards(List<FundingAward> fundingAwards) {
    this.fundingAwards = fundingAwards;
    return this;
  }

  public FundingResponse addFundingAwardsItem(FundingAward fundingAwardsItem) {
    if (this.fundingAwards == null) {
      this.fundingAwards = new ArrayList<>();
    }
    this.fundingAwards.add(fundingAwardsItem);
    return this;
  }

  /**
   * Get fundingAwards
   * @return fundingAwards
   **/
  @Schema(description = "")
      @Valid
    public List<FundingAward> getFundingAwards() {
    return fundingAwards;
  }

  public void setFundingAwards(List<FundingAward> fundingAwards) {
    this.fundingAwards = fundingAwards;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    FundingResponse fundingResponse = (FundingResponse) o;
    return Objects.equals(this.fundingAwards, fundingResponse.fundingAwards);
  }

  @Override
  public int hashCode() {
    return Objects.hash(fundingAwards);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class FundingResponse {\n");
    
    sb.append("    fundingAwards: ").append(toIndentedString(fundingAwards)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
