package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * The response from an authenticate request
 */
@Schema(description = "The response from an authenticate request")
@Validated



public class AuthenticateResponse   {
  @JsonProperty("displayName")
  private String displayName = null;

  @JsonProperty("emails")
  @Valid
  private List<String> emails = null;

  @JsonProperty("expires")
  private Long expires = null;

  @JsonProperty("analyticsEnabled")
  private Boolean analyticsEnabled = true;

  @JsonProperty("analyticsInfo")
  @Valid
  private Map<String, String> analyticsInfo = null;

  public AuthenticateResponse displayName(String displayName) {
    this.displayName = displayName;
    return this;
  }

  /**
   * The display format of the users name
   * @return displayName
   **/
  @Schema(example = "John Smith", description = "The display format of the users name")
  
    public String getDisplayName() {
    return displayName;
  }

  public void setDisplayName(String displayName) {
    this.displayName = displayName;
  }

  public AuthenticateResponse emails(List<String> emails) {
    this.emails = emails;
    return this;
  }

  public AuthenticateResponse addEmailsItem(String emailsItem) {
    if (this.emails == null) {
      this.emails = new ArrayList<>();
    }
    this.emails.add(emailsItem);
    return this;
  }

  /**
   * The users email addresses in priority order (primary email first)
   * @return emails
   **/
  @Schema(description = "The users email addresses in priority order (primary email first)")
  
    public List<String> getEmails() {
    return emails;
  }

  public void setEmails(List<String> emails) {
    this.emails = emails;
  }

  public AuthenticateResponse expires(Long expires) {
    this.expires = expires;
    return this;
  }

  /**
   * When the authenticated session expires (EPOCH - milliseconds)
   * minimum: 0
   * @return expires
   **/
  @Schema(example = "1579866980000", required = true, description = "When the authenticated session expires (EPOCH - milliseconds)")
      @NotNull

  @Min(0L)  public Long getExpires() {
    return expires;
  }

  public void setExpires(Long expires) {
    this.expires = expires;
  }

  public AuthenticateResponse analyticsEnabled(Boolean analyticsEnabled) {
    this.analyticsEnabled = analyticsEnabled;
    return this;
  }

  /**
   * If analytics are to be recorded for this session
   * @return analyticsEnabled
   **/
  @Schema(required = true, description = "If analytics are to be recorded for this session")
      @NotNull

    public Boolean isAnalyticsEnabled() {
    return analyticsEnabled;
  }

  public void setAnalyticsEnabled(Boolean analyticsEnabled) {
    this.analyticsEnabled = analyticsEnabled;
  }

  public AuthenticateResponse analyticsInfo(Map<String, String> analyticsInfo) {
    this.analyticsInfo = analyticsInfo;
    return this;
  }

  public AuthenticateResponse putAnalyticsInfoItem(String key, String analyticsInfoItem) {
    if (this.analyticsInfo == null) {
      this.analyticsInfo = new HashMap<>();
    }
    this.analyticsInfo.put(key, analyticsInfoItem);
    return this;
  }

  /**
   * The analytics info that can be used to track the users operations
   * @return analyticsInfo
   **/
  @Schema(description = "The analytics info that can be used to track the users operations")
  
    public Map<String, String> getAnalyticsInfo() {
    return analyticsInfo;
  }

  public void setAnalyticsInfo(Map<String, String> analyticsInfo) {
    this.analyticsInfo = analyticsInfo;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AuthenticateResponse authenticateResponse = (AuthenticateResponse) o;
    return Objects.equals(this.displayName, authenticateResponse.displayName) &&
        Objects.equals(this.emails, authenticateResponse.emails) &&
        Objects.equals(this.expires, authenticateResponse.expires) &&
        Objects.equals(this.analyticsEnabled, authenticateResponse.analyticsEnabled) &&
        Objects.equals(this.analyticsInfo, authenticateResponse.analyticsInfo);
  }

  @Override
  public int hashCode() {
    return Objects.hash(displayName, emails, expires, analyticsEnabled, analyticsInfo);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AuthenticateResponse {\n");
    
    sb.append("    displayName: ").append(toIndentedString(displayName)).append("\n");
    sb.append("    emails: ").append(toIndentedString(emails)).append("\n");
    sb.append("    expires: ").append(toIndentedString(expires)).append("\n");
    sb.append("    analyticsEnabled: ").append(toIndentedString(analyticsEnabled)).append("\n");
    sb.append("    analyticsInfo: ").append(toIndentedString(analyticsInfo)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
