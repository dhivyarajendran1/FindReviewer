package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.external.ScopusSharedSearchPeople;
import com.elsevier.find.reviewers.external.ScopusSharedSearchPeople.ScopusSharedSearchAuthor;
import com.elsevier.find.reviewers.generated.api.AuthorsApiDelegate;
import com.elsevier.find.reviewers.generated.model.AuthorsResponse;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.generated.model.KeywordSearchLogic;
import com.elsevier.find.reviewers.generated.model.ScopusSearchAuthor;
import com.elsevier.find.reviewers.service.base.BaseService;
import com.elsevier.find.reviewers.service.base.DataGatherRules;
import com.elsevier.find.reviewers.service.base.PersonDetailsSupportService;
import com.elsevier.find.reviewers.utils.PersonDetailsUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
public class AuthorsService extends BaseService implements AuthorsApiDelegate {

    private final ScopusSharedSearchPeople scopusSharedSearchPeople;

    private final PersonDetailsSupportService personDetailsSupportService;

    protected AuthorsService(ObjectMapper objectMapper,
                             ScopusSharedSearchPeople scopusSharedSearchPeople,
                             PersonDetailsSupportService personDetailsSupportService) {
        super(objectMapper);
        this.scopusSharedSearchPeople = scopusSharedSearchPeople;
        this.personDetailsSupportService = personDetailsSupportService;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class, readOnly = true)
    public ResponseEntity<AuthorsResponse> authorSearch(String xScope,
                                                        String emJournalAcronym,
                                                        String firstName,
                                                        String lastName,
                                                        String affiliation,
                                                        String email,
                                                        String keywords,
                                                        KeywordSearchLogic searchLogic) {
        if (!isValidSearchArgs(firstName, lastName, affiliation, email)) {
            final Map<String, String> args = Map.of("firstName", String.valueOf(firstName),
                    "lastName", String.valueOf(lastName),
                    "affiliation", String.valueOf(affiliation),
                    "email", String.valueOf(email));
            log.error("Invalid request for Author search, no journal acronym or no/invalid search parameters {}", args);
            throw new InternalException(ErrorResponse.IdEnum.INVALIDARGUMENT, HttpStatus.BAD_REQUEST, args);
        }

        List<ScopusSharedSearchAuthor> authors = scopusSharedSearchPeople.getAuthors(firstName, lastName, affiliation, email);

        log.info("Scopus author search for {} returned {} results", emJournalAcronym, authors.size());

        AuthorsResponse response = new AuthorsResponse();
        if (!authors.isEmpty()) {
            List<ScopusSearchAuthor> scopusAuthors = authors.stream().map(PersonDetailsUtils::convertAuthor).collect(Collectors.toList());
            DataGatherRules<ScopusSearchAuthor> rules = new DataGatherRules<>(scopusAuthors)
                    .addBlockList().addInternalDbData().addReviewStatistics(false).addContentMatch(keywords, searchLogic);

            response.setAuthors(personDetailsSupportService.gatherAdditionalData(emJournalAcronym, rules));

            log.info("Scopus author cleaned search returned {} results for journal {}", response.getAuthors().size(), emJournalAcronym);
        }

        return ResponseEntity.ok().body(response);
    }

    private boolean isValidSearchArgs(String... searchArgs) {
        List<String> setArgs = Arrays.stream(searchArgs).filter(a -> a != null && !a.isBlank()).collect(Collectors.toList());
        // Valid is having at least one argument set and arguments can not start and end in a wild card
        // as the search service we use does not support that
        return !setArgs.isEmpty() && setArgs.stream().noneMatch(a -> a.startsWith("*") && a.endsWith("*"));
    }
}
