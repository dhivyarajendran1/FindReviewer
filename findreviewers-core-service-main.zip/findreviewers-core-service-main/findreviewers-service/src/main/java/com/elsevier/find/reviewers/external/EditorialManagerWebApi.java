package com.elsevier.find.reviewers.external;

import com.elsevier.find.reviewers.enums.ReviewerStatusType;
import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.exception.RetryableException;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.utils.PersonDetailsUtils;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.retry.backoff.FixedBackOffPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.util.DefaultUriBuilderFactory;

import java.io.IOException;
import java.net.URI;
import java.time.Duration;
import java.util.Collections;
import java.util.List;

@Slf4j
@Service
public class EditorialManagerWebApi {
    private static final String SITE_NAME = "site_name";
    private static final String MSG_TYPE = "_type";
    private static final String DOC_IDS = "ids";

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class EmWebApiAuthor {
        @JsonProperty("authorFullName")
        private String authorFullName;
        @JsonProperty("authorFirstName")
        private String authorFirstName;
        @JsonProperty("authorLastName")
        private String authorLastName;
        @JsonProperty("authorPrimaryEmailAddress")
        private String authorPrimaryEmailAddress;
        @JsonProperty("isCorresponding")
        private String isCorresponding; // Boolean - "true" or "false"

        @JsonIgnore
        public boolean isCorrespondingAuthor() {
            return "true".equalsIgnoreCase(isCorresponding);
        }

        public List<String> getEmailAddresses() {
            return authorPrimaryEmailAddress == null ? null : PersonDetailsUtils.processEmEmails(List.of(authorPrimaryEmailAddress));
        }
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class EmWebApiManuscript {
        @Data
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class EmWebApiManuscriptKeywords {
            @JsonProperty("word")
            private String word;
        }

        @Data
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class EmWebApiManuscriptClassifications {
            @JsonProperty("description")
            private String description;
        }

        @JsonProperty("journalName")
        private String journalName;
        @JsonProperty("submissionId")
        private String submissionId;
        @JsonProperty("submissionTitle")
        private String submissionTitle;
        @JsonProperty("abstractText")
        private String abstractText;
        @JsonProperty("keywords")
        private List<EmWebApiManuscriptKeywords> keywords;
        @JsonProperty("classifications")
        private List<EmWebApiManuscriptClassifications> classifications;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class EmWebApiReviewer {
        @JsonProperty("reviewerFullName")
        private String reviewerFullName;
        @JsonProperty("reviewerFirstName")
        private String reviewerFirstName;
        @JsonProperty("reviewerLastName")
        private String reviewerLastName;
        @JsonProperty("reviewerPrimaryEmailAddress")
        private String reviewerPrimaryEmailAddress;
        @JsonProperty("reviewerAssignmentStatus")
        private ReviewerStatusType reviewerAssignmentStatus;
        @JsonProperty("ReviewerInvitationResponse")
        private ReviewerStatusType reviewerInvitationResponse;

        public ReviewerStatusType getStatus() {
            // There is a case where the user has declined the invitation, they are not shown as that in the
            // status field, so we need to overwrite that value with the correct Decline value
            return ReviewerStatusType.Declined.equals(reviewerInvitationResponse) ?
                    ReviewerStatusType.Declined : reviewerAssignmentStatus;
        }

        public String getEmailAddress() {
            return reviewerPrimaryEmailAddress == null ? null : reviewerPrimaryEmailAddress.trim().toLowerCase();
        }
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class EmWebApiResponse<T> {
        @Data
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class EmWebApiResultE<T> {
            @JsonProperty("e")
            @JsonFormat(with = JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
            private T e;
        }

        @Data
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class EmWebApiResult<T> {
            @JsonProperty("result")
            private EmWebApiResultE<T> result;
        }

        @JsonProperty("Response")
        private EmWebApiResult<T> response;

        @JsonIgnore
        public T getElement() {
            if (response == null || response.getResult() == null || response.getResult().getE() == null) {
                return null;
            }
            return response.getResult().getE();
        }
    }

    private final WebClient webClient;

    private final DefaultUriBuilderFactory uriBuilderFactory;

    private final ObjectMapper objectMapper;

    private final RetryTemplate emRetry;

    public EditorialManagerWebApi(@Qualifier("emWebClient") WebClient webClient,
                                  ObjectMapper objectMapper,
                                  @Value("${em.web.api.client.host}") String emWebApiBaseUrl) {
        this.webClient = webClient;
        this.objectMapper = objectMapper;
        uriBuilderFactory = new DefaultUriBuilderFactory(emWebApiBaseUrl.endsWith("/") ?
                emWebApiBaseUrl.substring(0, emWebApiBaseUrl.length() - 1) : emWebApiBaseUrl);

        emRetry = new RetryTemplate();
        FixedBackOffPolicy fixedBackOffPolicy = new FixedBackOffPolicy();
        fixedBackOffPolicy.setBackOffPeriod(500L);
        emRetry.setBackOffPolicy(fixedBackOffPolicy);
        emRetry.setRetryPolicy(new SimpleRetryPolicy(3));
    }

    public List<EmWebApiAuthor> getAuthors(String emJournalAcronym, long documentId) {
        String rawResponse = null;
        EmWebApiResponse<List<EmWebApiAuthor>> authorResponse = null;
        try {
            URI uri = uriBuilderFactory.builder().path("/submissions/full/contributors/authors/documentids")
                    .queryParam(DOC_IDS, documentId)
                    .queryParam(SITE_NAME, emJournalAcronym)
                    .queryParam(MSG_TYPE, "json")
                    .build();

            rawResponse = makeEmWebApiCall(uri);

            if (rawResponse != null && !rawResponse.isBlank()) {
                authorResponse = objectMapper.readValue(rawResponse, new TypeReference<>() {
                });
            }
        } catch (IOException e) {
            log.error("EM Web API response for authors for journal {} document {} unexpected format {}",
                    emJournalAcronym, documentId, rawResponse, e);
        }

        return authorResponse == null || authorResponse.getElement() == null ? Collections.emptyList() : authorResponse.getElement();
    }

    public EmWebApiManuscript getManuscript(String emJournalAcronym, long documentId) {
        String rawResponse = null;
        EmWebApiResponse<EmWebApiManuscript> manuscriptResponse = null;
        try {
            URI uri = uriBuilderFactory.builder().path("/submissions/full/metadata/documentids")
                    .queryParam(DOC_IDS, documentId)
                    .queryParam(SITE_NAME, emJournalAcronym)
                    .queryParam(MSG_TYPE, "json")
                    .build();

            rawResponse = makeEmWebApiCall(uri);

            if (rawResponse != null && !rawResponse.isBlank()) {
                manuscriptResponse = objectMapper.readValue(rawResponse, new TypeReference<>() {
                });
            }
        } catch (IOException e) {
            log.error("EM Web API response for manuscript for journal {} document {} unexpected format {}",
                    emJournalAcronym, documentId, rawResponse, e);
        }

        return manuscriptResponse == null ? null : manuscriptResponse.getElement();
    }

    public List<EmWebApiReviewer> getReviewers(String emJournalAcronym, long documentId) {
        String rawResponse = null;
        EmWebApiResponse<List<EmWebApiReviewer>> reviewerResponse = null;
        try {
            URI uri = uriBuilderFactory.builder().path("/submissions/full/reviewer/documentids")
                    .queryParam(DOC_IDS, documentId)
                    .queryParam(SITE_NAME, emJournalAcronym)
                    .queryParam(MSG_TYPE, "json")
                    .build();

            rawResponse = makeEmWebApiCall(uri);

            if (rawResponse != null && !rawResponse.isBlank()) {
                reviewerResponse = objectMapper.readValue(rawResponse, new TypeReference<>() {
                });
            }
        } catch (IOException e) {
            log.error("EM Web API response for reviewers for journal {} document {} unexpected format {}",
                    emJournalAcronym, documentId, rawResponse, e);
        }

        return reviewerResponse == null ? null : reviewerResponse.getElement();
    }

    /**
     * Makes the API request to the EM Web API with all the correct authentication
     *
     * @param url The URL specifics to be called (with all parameters)
     */
    private String makeEmWebApiCall(URI url) {
        log.info("EM Web API {} request", url);

        String response = null;
        try {
            response = emRetry.execute(context -> {
                try {
                    return webClient.get().uri(url)
                            .accept(MediaType.APPLICATION_JSON)
                            .retrieve()
                            .bodyToMono(String.class)
                            // Subscribe to this Mono and block until a next signal is received or a timeout expires.
                            // Returns that value, or null if the Mono completes empty.
                            .block(Duration.ofSeconds(20));
                } catch (WebClientResponseException e) {
                    if (e.getStatusCode() == HttpStatus.NOT_FOUND) {
                        log.error("Entry not found for EM Web API {} HttpStatusCode = {}, HttpHeaders = {}, ResponseBody = {}",
                                url, e.getStatusCode(), e.getHeaders(), e.getResponseBodyAsString(), e);
                        return null;
                    } else {
                        throw new RetryableException(new InternalException(ErrorResponse.IdEnum.EMFAILURE, HttpStatus.INTERNAL_SERVER_ERROR),
                                "Error calling EM Web API {} HttpStatusCode = {}, HttpHeaders = {}, ResponseBody = {}",
                                url, e.getStatusCode(), e.getHeaders(), e.getResponseBodyAsString(), e).logWarn();
                    }
                } catch (Exception e) {
                    throw new RetryableException(new InternalException(ErrorResponse.IdEnum.EMFAILURE, HttpStatus.INTERNAL_SERVER_ERROR),
                            "Exception calling EM Web API {}", url, e).logWarn();
                }
            });
        } catch (RetryableException e) {
            e.logError();
        }

        log.info("EM Web API {} completed {}", url, response);
        return response;
    }
}
