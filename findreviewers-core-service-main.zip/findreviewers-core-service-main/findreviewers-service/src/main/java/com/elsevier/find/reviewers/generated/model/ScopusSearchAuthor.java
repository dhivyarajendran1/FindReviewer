package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.Indicators;
import com.elsevier.find.reviewers.generated.model.PersonDetails;
import com.elsevier.find.reviewers.generated.model.PersonDetailsReviewStatistics;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * ScopusSearchAuthor
 */
@Validated



public class ScopusSearchAuthor extends PersonDetails  {
  @JsonProperty("keywordMatchCount")
  private Integer keywordMatchCount = null;

  public ScopusSearchAuthor keywordMatchCount(Integer keywordMatchCount) {
    this.keywordMatchCount = keywordMatchCount;
    return this;
  }

  /**
   * The number of publication this author has that matches the search terms
   * @return keywordMatchCount
   **/
  @Schema(example = "3", description = "The number of publication this author has that matches the search terms")
  
    public Integer getKeywordMatchCount() {
    return keywordMatchCount;
  }

  public void setKeywordMatchCount(Integer keywordMatchCount) {
    this.keywordMatchCount = keywordMatchCount;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ScopusSearchAuthor scopusSearchAuthor = (ScopusSearchAuthor) o;
    return Objects.equals(this.keywordMatchCount, scopusSearchAuthor.keywordMatchCount) &&
        super.equals(o);
  }

  @Override
  public int hashCode() {
    return Objects.hash(keywordMatchCount, super.hashCode());
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ScopusSearchAuthor {\n");
    sb.append("    ").append(toIndentedString(super.toString())).append("\n");
    sb.append("    keywordMatchCount: ").append(toIndentedString(keywordMatchCount)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
