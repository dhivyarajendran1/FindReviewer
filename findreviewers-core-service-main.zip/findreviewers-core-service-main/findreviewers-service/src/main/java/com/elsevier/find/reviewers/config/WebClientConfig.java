package com.elsevier.find.reviewers.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.client.AuthorizedClientServiceReactiveOAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.InMemoryReactiveOAuth2AuthorizedClientService;
import org.springframework.security.oauth2.client.registration.ClientRegistration;
import org.springframework.security.oauth2.client.registration.InMemoryReactiveClientRegistrationRepository;
import org.springframework.security.oauth2.client.registration.ReactiveClientRegistrationRepository;
import org.springframework.security.oauth2.client.web.reactive.function.client.ServerOAuth2AuthorizedClientExchangeFilterFunction;
import org.springframework.security.oauth2.core.AuthorizationGrantType;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientConfig {

    private static final String OAUTH_PATH = "%s/oauth2/token";

    /*
     * PERSON FINDER
     */
    @Bean(name = "personfinderRegistration")
    ReactiveClientRegistrationRepository personFinderRegistration(
            @Value("${personfinder.client.base.url}") String baseUrl,
            @Value("${personfinder.client.id}") String clientId,
            @Value("${personfinder.client.secret}") String clientSecret) {
        final String personFinderBaseUrl = baseUrl.endsWith("/") ? baseUrl.substring(0, baseUrl.length() - 1) : baseUrl;
        ClientRegistration registration = ClientRegistration
                .withRegistrationId("personfinder")
                .tokenUri(String.format(OAUTH_PATH, personFinderBaseUrl))
                .clientId(clientId)
                .clientSecret(clientSecret)
                .authorizationGrantType(AuthorizationGrantType.CLIENT_CREDENTIALS)
                .build();
        return new InMemoryReactiveClientRegistrationRepository(registration);
    }

    @Bean(name = "personfinder")
    WebClient personFinderWebClient(@Qualifier("personfinderRegistration") ReactiveClientRegistrationRepository clientRegistrations) {

        InMemoryReactiveOAuth2AuthorizedClientService authorizedClientService =
                new InMemoryReactiveOAuth2AuthorizedClientService(clientRegistrations);
        ServerOAuth2AuthorizedClientExchangeFilterFunction oauth = new ServerOAuth2AuthorizedClientExchangeFilterFunction(
                new AuthorizedClientServiceReactiveOAuth2AuthorizedClientManager(clientRegistrations, authorizedClientService)
        );

        oauth.setDefaultClientRegistrationId("personfinder");
        return WebClient.builder().exchangeStrategies(ExchangeStrategies.builder()
                        .codecs(configurer -> configurer
                                .defaultCodecs()
                                .maxInMemorySize(-1))
                        .build())
                .filter(oauth)
                .build();
    }

    /*
     * SCOPUS SHARED SEARCH
     */
    @Bean(name = "scopussharedsearchRegistration")
    ReactiveClientRegistrationRepository scopusSharedSearchRegistration(
            @Value("${scopussharedsearch.client.base.url}") String baseUrl,
            @Value("${scopussharedsearch.client.id}") String clientId,
            @Value("${scopussharedsearch.client.secret}") String clientSecret) {
        final String scopusSharedSearchBaseUrl = baseUrl.endsWith("/") ? baseUrl.substring(0, baseUrl.length() - 1) : baseUrl;
        ClientRegistration registration = ClientRegistration
                .withRegistrationId("scopussharedsearch")
                .tokenUri(String.format(OAUTH_PATH, scopusSharedSearchBaseUrl))
                .clientId(clientId)
                .clientSecret(clientSecret)
                .authorizationGrantType(AuthorizationGrantType.CLIENT_CREDENTIALS)
                .build();
        return new InMemoryReactiveClientRegistrationRepository(registration);
    }

    @Bean(name = "scopussharedsearch")
    WebClient scopusSharedSearchwebClient(@Qualifier("scopussharedsearchRegistration") ReactiveClientRegistrationRepository clientRegistrations) {

        InMemoryReactiveOAuth2AuthorizedClientService authorizedClientService =
                new InMemoryReactiveOAuth2AuthorizedClientService(clientRegistrations);
        ServerOAuth2AuthorizedClientExchangeFilterFunction oauth = new ServerOAuth2AuthorizedClientExchangeFilterFunction(
                new AuthorizedClientServiceReactiveOAuth2AuthorizedClientManager(clientRegistrations, authorizedClientService)
        );

        oauth.setDefaultClientRegistrationId("scopussharedsearch");
        return WebClient.builder().defaultHeader("x-els-product", "find-reviewers")
                .exchangeStrategies(ExchangeStrategies.builder()
                        .codecs(configurer -> configurer
                                .defaultCodecs()
                                .maxInMemorySize(-1))
                        .build())
                .filter(oauth)
                .build();
    }

    /*
     * SCOPUS GRAPH
     */
    @Bean(name = "scopusgraphRegistration")
    ReactiveClientRegistrationRepository scopusGraphRegistration(
            @Value("${scopusgraph.client.base.url}") String baseUrl,
            @Value("${scopusgraph.client.id}") String clientId,
            @Value("${scopusgraph.client.secret}") String clientSecret) {
        final String scopusSharedSearchBaseUrl = baseUrl.endsWith("/") ? baseUrl.substring(0, baseUrl.length() - 1) : baseUrl;
        ClientRegistration registration = ClientRegistration
                .withRegistrationId("scopusgraph")
                .tokenUri(String.format(OAUTH_PATH, scopusSharedSearchBaseUrl))
                .clientId(clientId)
                .clientSecret(clientSecret)
                .authorizationGrantType(AuthorizationGrantType.CLIENT_CREDENTIALS)
                .build();
        return new InMemoryReactiveClientRegistrationRepository(registration);
    }

    @Bean(name = "scopusgraph")
    WebClient scopusGraphwebClient(@Qualifier("scopusgraphRegistration") ReactiveClientRegistrationRepository clientRegistrations) {

        InMemoryReactiveOAuth2AuthorizedClientService authorizedClientService =
                new InMemoryReactiveOAuth2AuthorizedClientService(clientRegistrations);
        ServerOAuth2AuthorizedClientExchangeFilterFunction oauth = new ServerOAuth2AuthorizedClientExchangeFilterFunction(
                new AuthorizedClientServiceReactiveOAuth2AuthorizedClientManager(clientRegistrations, authorizedClientService)
        );

        oauth.setDefaultClientRegistrationId("scopusgraph");
        return WebClient.builder().exchangeStrategies(ExchangeStrategies.builder()
                        .codecs(configurer -> configurer
                                .defaultCodecs()
                                .maxInMemorySize(-1))
                        .build())
                .filter(oauth)
                .build();
    }

    /*
     * SCOPUS AUTOCOMPLETE
     */
    @Bean(name = "scopusAutocompleteRegistration")
    ReactiveClientRegistrationRepository scopusAutocompleteRegistration(
            @Value("${scopusautocomplete.client.base.url}") String baseUrl,
            @Value("${scopusautocomplete.client.id}") String clientId,
            @Value("${scopusautocomplete.client.secret}") String clientSecret) {
        final String scopusAutocompleteBaseUrl = baseUrl.endsWith("/") ? baseUrl.substring(0, baseUrl.length() - 1) : baseUrl;
        ClientRegistration registration = ClientRegistration
                .withRegistrationId("scopusautocomplete")
                .tokenUri(String.format(OAUTH_PATH, scopusAutocompleteBaseUrl))
                .clientId(clientId)
                .clientSecret(clientSecret)
                .authorizationGrantType(AuthorizationGrantType.CLIENT_CREDENTIALS)
                .build();
        return new InMemoryReactiveClientRegistrationRepository(registration);
    }

    @Bean(name = "scopusautocomplete")
    WebClient scopusAutocompletewebClient(@Qualifier("scopusAutocompleteRegistration") ReactiveClientRegistrationRepository clientRegistrations) {

        InMemoryReactiveOAuth2AuthorizedClientService authorizedClientService =
                new InMemoryReactiveOAuth2AuthorizedClientService(clientRegistrations);
        ServerOAuth2AuthorizedClientExchangeFilterFunction oauth = new ServerOAuth2AuthorizedClientExchangeFilterFunction(
                new AuthorizedClientServiceReactiveOAuth2AuthorizedClientManager(clientRegistrations, authorizedClientService)
        );

        oauth.setDefaultClientRegistrationId("scopusautocomplete");
        return WebClient.builder().defaultHeader("x-els-product", "find-reviewer")
                .exchangeStrategies(ExchangeStrategies.builder()
                        .codecs(configurer -> configurer
                                .defaultCodecs()
                                .maxInMemorySize(-1))
                        .build())
                .filter(oauth)
                .build();
    }
}
