package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.external.ScopusAutocomplete;
import com.elsevier.find.reviewers.generated.api.AutocompleteApiDelegate;
import com.elsevier.find.reviewers.generated.model.*;
import com.elsevier.find.reviewers.service.base.BaseService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Class to handle requests for Scopus Autocomplete suggestions
 */
@Slf4j
@Service
public class AutocompleteService extends BaseService implements AutocompleteApiDelegate {

    private final ScopusAutocomplete scopusAutocomplete;


    public AutocompleteService(ObjectMapper objectMapper,
                               ScopusAutocomplete scopusAutocomplete) {
        super(objectMapper);
        this.scopusAutocomplete = scopusAutocomplete;
    }

    @Override
    public ResponseEntity<AutocompleteResponse> scopusAutocomplete(String query, String xScope) {
        if (query == null || query.length() < 3) {
            final Map<String, String> arg = Map.of("query", String.valueOf(query));
            log.error("Invalid request for scopus autocomplete, mandatory parameter query not set correctly: {}", arg);
            throw new InternalException(ErrorResponse.IdEnum.INVALIDARGUMENT, HttpStatus.BAD_REQUEST, arg);
        }

        log.info("Autocomplete suggestions for keyword search query {}", query);

        List<String> suggestions = scopusAutocomplete.getAutocompleteSuggestions(query);

        AutocompleteResponse response = new AutocompleteResponse();
        response.setSuggestions(suggestions);

        return ResponseEntity.ok().body(response);
    }
}
