package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.ClassificationDetails;
import com.elsevier.find.reviewers.generated.model.ClassificationTree;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * ClassificationTree
 */
@Validated



public class ClassificationTree extends ClassificationDetails  {
  @JsonProperty("children")
  @Valid
  private List<ClassificationTree> children = null;

  public ClassificationTree children(List<ClassificationTree> children) {
    this.children = children;
    return this;
  }

  public ClassificationTree addChildrenItem(ClassificationTree childrenItem) {
    if (this.children == null) {
      this.children = new ArrayList<>();
    }
    this.children.add(childrenItem);
    return this;
  }

  /**
   * Any classifications that are a child of this classification
   * @return children
   **/
  @Schema(description = "Any classifications that are a child of this classification")
      @Valid
    public List<ClassificationTree> getChildren() {
    return children;
  }

  public void setChildren(List<ClassificationTree> children) {
    this.children = children;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ClassificationTree classificationTree = (ClassificationTree) o;
    return Objects.equals(this.children, classificationTree.children) &&
        super.equals(o);
  }

  @Override
  public int hashCode() {
    return Objects.hash(children, super.hashCode());
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ClassificationTree {\n");
    sb.append("    ").append(toIndentedString(super.toString())).append("\n");
    sb.append("    children: ").append(toIndentedString(children)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
