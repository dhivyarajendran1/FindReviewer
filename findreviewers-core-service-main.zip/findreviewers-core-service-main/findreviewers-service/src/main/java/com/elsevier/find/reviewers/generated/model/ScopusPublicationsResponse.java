package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.ScopusPublication;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * The response for a list of Scopus publications
 */
@Schema(description = "The response for a list of Scopus publications")
@Validated



public class ScopusPublicationsResponse   {
  @JsonProperty("publications")
  @Valid
  private List<ScopusPublication> publications = new ArrayList<>();

  public ScopusPublicationsResponse publications(List<ScopusPublication> publications) {
    this.publications = publications;
    return this;
  }

  public ScopusPublicationsResponse addPublicationsItem(ScopusPublication publicationsItem) {
    this.publications.add(publicationsItem);
    return this;
  }

  /**
   * Get publications
   * @return publications
   **/
  @Schema(required = true, description = "")
      @NotNull
    @Valid
    public List<ScopusPublication> getPublications() {
    return publications;
  }

  public void setPublications(List<ScopusPublication> publications) {
    this.publications = publications;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ScopusPublicationsResponse scopusPublicationsResponse = (ScopusPublicationsResponse) o;
    return Objects.equals(this.publications, scopusPublicationsResponse.publications);
  }

  @Override
  public int hashCode() {
    return Objects.hash(publications);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ScopusPublicationsResponse {\n");
    
    sb.append("    publications: ").append(toIndentedString(publications)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
