package com.elsevier.find.reviewers.external;

import com.elsevier.find.reviewers.enums.ReviewerStatusType;
import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.exception.RetryableException;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.retry.backoff.FixedBackOffPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

@SuppressWarnings("squid:S1192")
@Slf4j
@Service
public class EditorialManager {
    @JsonIgnoreProperties(ignoreUnknown = true)
    @Data
    public static class AuthResponse {
        @JsonProperty("access_token")
        private String accessToken;
        @JsonProperty("token_type")
        private String tokenType;
        @JsonProperty("expires_in")
        private String expiresIn;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Address {
        @JsonProperty("affiliation")
        private String affiliation;
    }

    // Stop SonarQube complaining about the class name and a member variable having the same name
    @SuppressWarnings("squid:S1700")
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Identifier {
        @JsonProperty("system")
        private String system;
        @JsonProperty("identifier")
        private String identifier;
        @JsonProperty("url")
        private String url;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Reviewer {
        @JsonProperty("status")
        private ReviewerStatusType status;
        @JsonProperty("journal-code")
        private String journalCode;
        @JsonProperty("given-name")
        private String givenName;
        @JsonProperty("family-name")
        private String familyName;
        @JsonProperty("address")
        private Address address;
        @JsonProperty("email-addresses")
        private List<String> emailAddresses;
        @JsonProperty("identifiers")
        private List<Identifier> identifiers;
        @JsonProperty("keywords")
        private List<String> keywords;

        public void addScopusIdentifier(String scopusId) {
            Identifier identifier = new Identifier();
            identifier.setSystem("scopus");
            identifier.setIdentifier(scopusId);
            identifier.setUrl(String.format("https://www.scopus.com/authid/detail.uri?authorId=%s", scopusId));
            if (identifiers == null) {
                identifiers = new ArrayList<>();
            }
            identifiers.add(identifier);
        }

        // SonarQube does not want null returned, but that is exactly what we want as it will prevent an empty
        // array in the JSON that is returned from the interface
        @SuppressWarnings("squid:S1168")
        @JsonIgnore
        public List<String> getScopusIdentifiers() {
            if (identifiers == null) {
                return null;
            }
            List<String> scopusIds = identifiers.stream()
                    .filter(i -> "scopus".equalsIgnoreCase(i.getSystem()) && i.getIdentifier() != null)
                    .map(Identifier::getIdentifier).collect(Collectors.toList());
            return scopusIds.isEmpty() ? null : scopusIds;
        }

        public void addAffiliation(String affiliation) {
            address = new Address();
            address.setAffiliation(affiliation);
        }
    }

    // Stop SonarQube complaining about the class name and a member variable having the same name
    @SuppressWarnings("squid:S1700")
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    private static class Reviewers {
        @JsonProperty("reviewers")
        private List<Reviewer> reviewers;

        public List<Reviewer> cleanReviewers() {
            if (reviewers == null) {
                return Collections.emptyList();
            }
            // Reviewers without email addresses are of no use
            reviewers.removeIf(r -> r.getEmailAddresses() == null || r.getEmailAddresses().isEmpty());
            reviewers.forEach(r -> r.getEmailAddresses().replaceAll(String::toLowerCase));
            return reviewers;
        }
    }

    private final ObjectMapper objectMapper;
    private final HttpClient httpClient;
    private final String emClientId;
    private final String emApiUrl;
    private final String emClientSecret;
    private final RetryTemplate emRetry;
    // Although we do not require the redirect URL to redirect to further authentication it is required
    // to match the Client configuration in EM
    private final String emApiRedirectUrl;

    public EditorialManager(ObjectMapper objectMapper,
                            HttpClient httpClient,
                            @Value("${em.client.id}") String emClientId,
                            @Value("${em.client.secret}") String emClientSecret,
                            @Value("${em.client.api.host}") String emApiUrl,
                            @Value("${em.client.redirect.url}") String emApiRedirectUrl) {
        this.objectMapper = objectMapper;
        this.httpClient = httpClient;
        this.emClientId = emClientId;
        this.emClientSecret = emClientSecret;
        this.emApiUrl = emApiUrl.endsWith("/") ? emApiUrl.substring(0, emApiUrl.length() - 1) : emApiUrl;
        this.emApiRedirectUrl = emApiRedirectUrl;

        emRetry = new RetryTemplate();
        FixedBackOffPolicy fixedBackOffPolicy = new FixedBackOffPolicy();
        fixedBackOffPolicy.setBackOffPeriod(500L);
        emRetry.setBackOffPolicy(fixedBackOffPolicy);
        emRetry.setRetryPolicy(new SimpleRetryPolicy(3));
    }

    @SuppressWarnings("squid:S3776")
    public AuthResponse getBearerToken(String code) {
        AuthResponse authResponse = null;
        final String payload = String.format("{\"client_id\": \"%s\",\"client_secret\": \"%s\"," +
                        "\"grant_type\": \"authorization_code\",\"code\": \"%s\",\"redirect_uri\": \"%s\"}",
                emClientId, emClientSecret, code, emApiRedirectUrl);
        final String emURL = String.format("%s/oauth2/token", emApiUrl);

        try {
            authResponse = emRetry.execute(context -> {
                AuthResponse response = null;
                try {
                    HttpRequest request = HttpRequest.newBuilder(new URI(emURL))
                            .header("Content-Type", "application/json")
                            .timeout(Duration.ofSeconds(7L))
                            .POST(HttpRequest.BodyPublishers.ofString(payload)).build();

                    HttpResponse<String> httpResponse = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

                    if (httpResponse.statusCode() == HttpStatus.OK.value()) {
                        log.debug("Authentication for bearer token successful with status {}", httpResponse.statusCode());
                        if (httpResponse.body() != null) {
                            response = objectMapper.readValue(httpResponse.body(), AuthResponse.class);
                        }
                        if (response == null || response.accessToken == null || response.expiresIn == null) {
                            final String errorBody = httpResponse.body();
                            log.error("Authentication failed (empty response) for code {} and response {}", code, errorBody);
                            response = null;
                        }
                    } else if (httpResponse.statusCode() == HttpStatus.SERVICE_UNAVAILABLE.value()) {
                        throw new RetryableException(new InternalException(ErrorResponse.IdEnum.EMFAILURE, INTERNAL_SERVER_ERROR),
                                "Service Unavailable {} while getting bearer token for code {}", httpResponse.statusCode(), code).logWarn();
                    } else {
                        final String errorBody = httpResponse.body();
                        log.error("Failed to get Bearer Token for status {}, code {}, error {}", httpResponse.statusCode(),
                                code, errorBody);
                    }
                } catch (RetryableException e) {
                    throw e;
                } catch (HttpTimeoutException e) {
                    // Several EM authentication requests get a timeout exception then work on a retry
                    throw new RetryableException(new InternalException(ErrorResponse.IdEnum.EMFAILURE, INTERNAL_SERVER_ERROR),
                            "HttpTimeoutException while getting bearer token {}", code, e).logWarn();
                } catch (IOException e) {
                    // There are some occasional errors where we get: java.io.IOException: HTTP/1.1 header parser received no bytes
                    // with these there is no record on the EM side that any authentication data is consumed, so do a retry
                    throw new RetryableException(new InternalException(ErrorResponse.IdEnum.EMFAILURE, INTERNAL_SERVER_ERROR),
                            "IOException while getting bearer token {}", code, e).logWarn();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    log.error("Interrupted while getting bearer token {}", code, e);
                } catch (Exception e) {
                    log.error("Failed to get Bearer Token for code {}", code, e);
                }
                return response;
            });
        } catch (RetryableException e) {
            e.logError();
        }

        return authResponse;
    }

    public void updateReviewers(String emJournalAcronym, long documentId, List<Reviewer> reviewers) {
        final String emURL = String.format("%s/journals/%s/document/%d/reviewers", emApiUrl, emJournalAcronym, documentId);
        Reviewers reviewersPayload = new Reviewers();
        reviewersPayload.setReviewers(reviewers);

        log.info("Making EM update reviewers request {} with reviewers {}", emURL, reviewers);

        try {
            final String payload = objectMapper.writeValueAsString(reviewersPayload);

            final HttpRequest request = HttpRequest.newBuilder(new URI(emURL))
                    .header("Authorization", String.format("Bearer %s", SessionContext.getBearerToken()))
                    .header("Content-Type", "application/json")
                    .header("Accept", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(payload))
                    .build();

            emRetry.execute(context -> {
                try {
                    HttpResponse<String> httpResponse = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
                    final int statusCode = httpResponse.statusCode();

                    if (statusCode == HttpStatus.OK.value() || statusCode == HttpStatus.CREATED.value()) {
                        log.info("Successfully added reviewers for journal {} documentId {} payload {} with response status {}",
                                emJournalAcronym, documentId, payload, statusCode);
                    } else {
                        if (statusCode == HttpStatus.UNAUTHORIZED.value()) {
                            log.warn("Unauthorized failure when adding reviewers for journal {} documentId {} with session token {} and age {}",
                                    emJournalAcronym, documentId, SessionContext.getBearerToken(), SessionContext.getMaxAge());
                        }

                        final String errorBody = httpResponse.body();
                        // At the moment the interface document only detail the following status codes and no information about
                        // an error payload
                        //        400: "Bad Request"
                        //        401: "Unauthorized"
                        //        403: "Forbidden"
                        //        405: "Invalid input"
                        // so at the moment we just return a generic error message and as we get specific details reported we
                        // will refine the error handling. In fact, we know there are also cases where a 500 is returned.
                        InternalException e = new InternalException(ErrorResponse.IdEnum.EMFAILURE, HttpStatus.INTERNAL_SERVER_ERROR,
                                Map.of("message", errorBody));
                        throw new RetryableException(e, "Failed to add reviewers for journal {} documentId {} payload {} with response status {} and value {}",
                                emJournalAcronym, documentId, payload, statusCode, errorBody);
                    }
                } catch (RetryableException e) {
                    throw e.logWarn();
                } catch (IOException e) {
                    throw new RetryableException(new InternalException(ErrorResponse.IdEnum.EMFAILURE, HttpStatus.INTERNAL_SERVER_ERROR),
                            "Failed to add reviewers for journal {} documentId {} payload {}",
                            emJournalAcronym, documentId, payload, e).logWarn();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    throw new RetryableException(new InternalException(ErrorResponse.IdEnum.EMFAILURE, HttpStatus.INTERNAL_SERVER_ERROR),
                            "Interrupted while updating reviewers in EM", e).logWarn();
                }
                return HttpStatus.OK;
            });
        } catch (
                RetryableException e) {
            throw e.logError().getInternalException();
        } catch (URISyntaxException |
                 IOException e) {
            log.error("Failed to add reviewers for journal {} documentId {}", emJournalAcronym, documentId, e);
            throw new InternalException(ErrorResponse.IdEnum.EMFAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    public List<Reviewer> getReviewers(String emJournalAcronym, long documentId) {
        Reviewers reviewersResponse = null;
        final String emURL = String.format("%s/journals/%s/document/%d/reviewers", emApiUrl, emJournalAcronym, documentId);

        log.info("Making EM get reviewers request {}", emURL);

        try {
            final HttpRequest request = HttpRequest.newBuilder(new URI(emURL))
                    .header("Authorization", String.format("Bearer %s", SessionContext.getBearerToken()))
                    .header("Content-Type", "application/json")
                    .header("Accept", "application/json")
                    .GET()
                    .build();

            reviewersResponse = emRetry.execute(context -> {
                try {
                    HttpResponse<String> httpResponse = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
                    final int statusCode = httpResponse.statusCode();

                    if (statusCode == HttpStatus.OK.value()) {
                        final String body = httpResponse.body();
                        log.info("Successfully retrieved reviewers for journal {} documentId {} response status {} and body {}",
                                emJournalAcronym, documentId, statusCode, body);

                        return objectMapper.readValue(body, Reviewers.class);
                    } else {
                        if (statusCode == HttpStatus.UNAUTHORIZED.value()) {
                            log.warn("Unauthorized failure when getting reviewers for journal {} documentId {} with session token {}",
                                    emJournalAcronym, documentId, SessionContext.getBearerToken());
                        }

                        final String errorBody = httpResponse.body();
                        InternalException e = new InternalException(ErrorResponse.IdEnum.EMFAILURE, HttpStatus.INTERNAL_SERVER_ERROR,
                                Map.of("message", errorBody));
                        throw new RetryableException(e, "Failed to retrieve reviewers for journal {} documentId {} with response status {} and value {}",
                                emJournalAcronym, documentId, statusCode, errorBody);
                    }
                } catch (RetryableException e) {
                    throw e.logWarn();
                } catch (IOException e) {
                    throw new RetryableException(new InternalException(ErrorResponse.IdEnum.EMFAILURE, HttpStatus.INTERNAL_SERVER_ERROR),
                            "Failed to retrieve reviewers for journal {} documentId {}",
                            emJournalAcronym, documentId, e).logWarn();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    throw new RetryableException(new InternalException(ErrorResponse.IdEnum.EMFAILURE, HttpStatus.INTERNAL_SERVER_ERROR),
                            "Interrupted while updating reviewers in EM", e).logWarn();
                }
            });
        } catch (RetryableException e) {
            e.logError();
        } catch (Exception e) {
            log.error("Failed to retrieve reviewers for journal {} documentId {}", emJournalAcronym, documentId, e);
        }

        if (reviewersResponse == null) {
            log.info("No reviewers retrieved for journal {} documentId {}", emJournalAcronym, documentId);
            return Collections.emptyList();
        }

        return reviewersResponse.cleanReviewers();
    }
}
