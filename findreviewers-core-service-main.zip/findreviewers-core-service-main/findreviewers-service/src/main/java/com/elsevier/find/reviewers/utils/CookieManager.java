package com.elsevier.find.reviewers.utils;

import com.elsevier.find.reviewers.enums.ProductType;
import com.elsevier.find.reviewers.exception.InternalException;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.Cookie;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.stereotype.Service;

import java.util.Base64;

@Slf4j
@Service
public class CookieManager {
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class SessionData {
        @JsonProperty("p")
        private ProductType productType;
        @JsonProperty("c")
        private String authenticationCode;
        @JsonProperty("b")
        private String bearerToken;
        @JsonProperty("j")
        private String emJournalAcronym;
        @JsonProperty("r")
        private boolean readOnly;
        @JsonProperty("u")
        private boolean ursdbJournal;
        @JsonIgnore
        private int maxAge;

        public SessionData(ProductType productType,
                           String authenticationCode,
                           String accessToken,
                           String emJournalAcronym,
                           boolean isReadOnlySession,
                           boolean isUrsdbJournal) {
            this.productType = productType;
            this.authenticationCode = authenticationCode;
            this.bearerToken = accessToken;
            this.emJournalAcronym = emJournalAcronym == null ? null : emJournalAcronym.toUpperCase();
            this.readOnly = isReadOnlySession;
            this.ursdbJournal = isUrsdbJournal;
        }

        public SessionData() {
        }
    }

    private final ObjectMapper objectMapper;

    public CookieManager(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    // SonarQube does not like the number of arguments
    @SuppressWarnings("java:S107")
    public ResponseCookie createCookie(ProductType productType,
                                       String authenticationCode,
                                       String accessToken,
                                       long expiresIn,
                                       String emJournalAcronym,
                                       boolean isReadOnlySession,
                                       boolean isUrsdbJournal,
                                       String xScope) {
        SessionData sessionData = new SessionData(productType, authenticationCode, accessToken, emJournalAcronym,
                isReadOnlySession, isUrsdbJournal);

        String encodedCookieData;
        try {
            encodedCookieData = Base64.getEncoder().encodeToString(
                    objectMapper.writeValueAsString(sessionData).getBytes());
        } catch (Exception e) {
            log.error("Failed to encode cookie for session {}", sessionData, e);
            throw new InternalException(HttpStatus.UNAUTHORIZED);
        }

        return ResponseCookie.from(xScope.toUpperCase(), encodedCookieData)
                .secure(true)
                .maxAge(expiresIn)
                .path("/")
                .build();
    }

    // Prevent SonarQube complaining about creating a null cookie
    @SuppressWarnings("java:S4449")
    public ResponseCookie deleteCookie(String xScope) {
        return ResponseCookie.from(xScope.toUpperCase(), null).maxAge(0).path("/").build();
    }

    public boolean isSessionCookie(String xScope, Cookie cookie) {
        return xScope != null && xScope.toUpperCase().equals(cookie.getName());
    }

    public SessionData getSessionData(Cookie cookie) {
        SessionData sessionData = null;
        try {
            sessionData = objectMapper.readValue(Base64.getDecoder().decode(cookie.getValue().getBytes()),
                    SessionData.class);
            sessionData.setMaxAge(cookie.getMaxAge());
        } catch (Exception e) {
            log.error("Invalid Session Cookie detected during decoding", e);
        }

        return sessionData;
    }

    public boolean isSameSession(String authenticationCode, String existingSession) {
        if (existingSession != null && authenticationCode != null) {
            try {
                SessionData sessionData = objectMapper.readValue(Base64.getDecoder().decode(existingSession), SessionData.class);
                return authenticationCode.equals(sessionData.getAuthenticationCode());
            } catch (Exception e) {
                log.error("Invalid Session detected during decoding for session match", e);
            }
        }
        return false;
    }
}
