package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.ScopusAuthor;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * Details about a Funding Award
 */
@Schema(description = "Details about a Funding Award")
@Validated



public class FundingAward   {
  @JsonProperty("awardId")
  private String awardId = null;

  @JsonProperty("title")
  private String title = null;

  @JsonProperty("funderName")
  private String funderName = null;

  @JsonProperty("startDate")
  private Long startDate = null;

  @JsonProperty("endDate")
  private Long endDate = null;

  @JsonProperty("abstract")
  private String _abstract = null;

  @JsonProperty("awardees")
  @Valid
  private List<ScopusAuthor> awardees = null;

  public FundingAward awardId(String awardId) {
    this.awardId = awardId;
    return this;
  }

  /**
   * Unique Funding identifier
   * @return awardId
   **/
  @Schema(example = "1000010483320", description = "Unique Funding identifier")
  
    public String getAwardId() {
    return awardId;
  }

  public void setAwardId(String awardId) {
    this.awardId = awardId;
  }

  public FundingAward title(String title) {
    this.title = title;
    return this;
  }

  /**
   * The title of the funding award
   * @return title
   **/
  @Schema(example = "Analysis of Exhaled Volatiles for the Diagnosis", description = "The title of the funding award")
  
    public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public FundingAward funderName(String funderName) {
    this.funderName = funderName;
    return this;
  }

  /**
   * The name of the funder
   * @return funderName
   **/
  @Schema(example = "National Institute of Allergy and Infectious Diseases", description = "The name of the funder")
  
    public String getFunderName() {
    return funderName;
  }

  public void setFunderName(String funderName) {
    this.funderName = funderName;
  }

  public FundingAward startDate(Long startDate) {
    this.startDate = startDate;
    return this;
  }

  /**
   * The date the award started (EPOCH - milliseconds)
   * minimum: 0
   * @return startDate
   **/
  @Schema(example = "1666797249000", description = "The date the award started (EPOCH - milliseconds)")
  
  @Min(0L)  public Long getStartDate() {
    return startDate;
  }

  public void setStartDate(Long startDate) {
    this.startDate = startDate;
  }

  public FundingAward endDate(Long endDate) {
    this.endDate = endDate;
    return this;
  }

  /**
   * The date the award ended (EPOCH - milliseconds)
   * minimum: 0
   * @return endDate
   **/
  @Schema(example = "1686797249000", description = "The date the award ended (EPOCH - milliseconds)")
  
  @Min(0L)  public Long getEndDate() {
    return endDate;
  }

  public void setEndDate(Long endDate) {
    this.endDate = endDate;
  }

  public FundingAward _abstract(String _abstract) {
    this._abstract = _abstract;
    return this;
  }

  /**
   * The description of the award
   * @return _abstract
   **/
  @Schema(example = "Aspergillus is a fungus that can commonly infect ...", description = "The description of the award")
  
    public String getAbstract() {
    return _abstract;
  }

  public void setAbstract(String _abstract) {
    this._abstract = _abstract;
  }

  public FundingAward awardees(List<ScopusAuthor> awardees) {
    this.awardees = awardees;
    return this;
  }

  public FundingAward addAwardeesItem(ScopusAuthor awardeesItem) {
    if (this.awardees == null) {
      this.awardees = new ArrayList<>();
    }
    this.awardees.add(awardeesItem);
    return this;
  }

  /**
   * The list of awardees
   * @return awardees
   **/
  @Schema(description = "The list of awardees")
      @Valid
    public List<ScopusAuthor> getAwardees() {
    return awardees;
  }

  public void setAwardees(List<ScopusAuthor> awardees) {
    this.awardees = awardees;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    FundingAward fundingAward = (FundingAward) o;
    return Objects.equals(this.awardId, fundingAward.awardId) &&
        Objects.equals(this.title, fundingAward.title) &&
        Objects.equals(this.funderName, fundingAward.funderName) &&
        Objects.equals(this.startDate, fundingAward.startDate) &&
        Objects.equals(this.endDate, fundingAward.endDate) &&
        Objects.equals(this._abstract, fundingAward._abstract) &&
        Objects.equals(this.awardees, fundingAward.awardees);
  }

  @Override
  public int hashCode() {
    return Objects.hash(awardId, title, funderName, startDate, endDate, _abstract, awardees);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class FundingAward {\n");
    
    sb.append("    awardId: ").append(toIndentedString(awardId)).append("\n");
    sb.append("    title: ").append(toIndentedString(title)).append("\n");
    sb.append("    funderName: ").append(toIndentedString(funderName)).append("\n");
    sb.append("    startDate: ").append(toIndentedString(startDate)).append("\n");
    sb.append("    endDate: ").append(toIndentedString(endDate)).append("\n");
    sb.append("    _abstract: ").append(toIndentedString(_abstract)).append("\n");
    sb.append("    awardees: ").append(toIndentedString(awardees)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
