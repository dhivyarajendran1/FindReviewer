package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import io.swagger.v3.oas.annotations.media.Schema;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * The status of a reviewer for a manuscript
 */
public enum ReviewerStatus {
  INVITED("Invited"),
    INPROGRESS("InProgress"),
    DECLINED("Declined"),
    TERMINATED("Terminated"),
    COMPLETED("Completed"),
    ALTERNATE("Alternate"),
    UNINVITED("Uninvited"),
    ASSIGNED("Assigned"),
    PROPOSED("Proposed");

  private String value;

  ReviewerStatus(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static ReviewerStatus fromValue(String text) {
    for (ReviewerStatus b : ReviewerStatus.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
