package com.elsevier.find.reviewers.dao.impl;

import com.elsevier.find.reviewers.dao.JournalDao;
import com.elsevier.find.reviewers.generated.model.JournalDetails;
import com.elsevier.find.reviewers.generated.model.ScopusSearchAuthor;
import com.elsevier.find.reviewers.utils.PersonDetailsUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

/**
 * Implementation for the data access to journals
 */
// Suppress SonarQube 'String literals should not be duplicated' flagged against the inline sql
@SuppressWarnings("squid:S1192")
@Slf4j
@Repository
public class JournalDaoImpl extends BaseDaoImpl implements JournalDao {
    public JournalDaoImpl(NamedParameterJdbcTemplate dbSource, ObjectMapper objectMapper,
                          @Value("${findreviewers.cloud.ursdb:false}") String cloudUrsdbEnabled) {
        super(dbSource, objectMapper, cloudUrsdbEnabled);
    }

    class JournalDetailsRowMapper extends BaseRowMapper implements RowMapper<JournalDetails> {
        @Override
        public JournalDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
            JournalDetails journal = new JournalDetails();
            journal.setEmJournalAcronym(rs.getString("acronym"));
            journal.setTitle(rs.getString("title"));
            journal.setIssnl(rs.getString("issn"));
            return journal;
        }
    }

    class ScopusSearchAuthorRowMapper extends BaseRowMapper implements RowMapper<ScopusSearchAuthor> {
        @Override
        public ScopusSearchAuthor mapRow(ResultSet rs, int rowNum) throws SQLException {
            ScopusSearchAuthor reviewer = new ScopusSearchAuthor();

            reviewer.setFirstName(getOptionalString(rs, "first_name"));
            reviewer.setLastName(getOptionalString(rs, "last_name"));
            PersonDetailsUtils.setDisplayName(reviewer);

            String scopusId = rs.getString("scopus_id");
            if (scopusId != null && !scopusId.isEmpty()) {
                reviewer.addScopusIdsItem(scopusId);
            }

            final String emailJson = rs.getString("emails");
            if (emailJson != null && !emailJson.isBlank()) {
                try {
                    Arrays.stream(objectMapper.readValue(emailJson, String[].class)).forEach(reviewer::addEmailsItem);
                } catch (JsonProcessingException e) {
                    log.error("Failed to load emails from database for scopus Id {} and name {}, error {}",
                            reviewer.getScopusIds(), reviewer.getDisplayName(), e.getMessage());
                }
            }

            return reviewer;
        }
    }

    @Override
    public boolean isUrsdbJournal(String emJournalAcronym) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("emJournalAcronym", emJournalAcronym.toUpperCase());

        String sql = """
                select exists(select 1 from rr_ursdb."JOURNAL_INFO" where "JOURNAL__upper" = :emJournalAcronym)
                """;

        if (isCloudUrsdb) {
            sql = "select exists(select 1 from fr_ursdb.journal_info where journal__upper = :emJournalAcronym)";
        }

        return dbSource.queryForObject(sql, params, Boolean.class);
    }

    @Override
    public Long getEmJournalId(String emJournalAcronym) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("emJournalAcronym", emJournalAcronym.toUpperCase());

        String sql = """
                select "JOURNAL_ID" from rr_ursdb."JOURNAL_INFO" where "JOURNAL__upper" = :emJournalAcronym
                """;

        if (isCloudUrsdb) {
            sql = "select journal_id from fr_ursdb.journal_info where journal__upper = :emJournalAcronym";
        }

        return dbSource.queryForObject(sql, params, Long.class);
    }

    @Override
    public List<JournalDetails> getJournals() {
        MapSqlParameterSource params = new MapSqlParameterSource();
        // Only include Launched journals, that is a status of 1
        params.addValue("status", 1);

        String sql = """
                select e."JOURNAL__upper" as acronym, j.title as title, j.issn_l as issn
                from find_reviewers.eph_journal j
                inner join rr_ursdb."JOURNAL_INFO" e on e.pts_code = j.acronym
                where j.status = :status
                order by j.title
                """;

        if (isCloudUrsdb) {
            sql = """
                    select e.journal__upper as acronym, j.title as title, j.issn_l as issn
                    from find_reviewers.eph_journal j
                    inner join fr_ursdb.journal_info e on e.pts_code = j.acronym
                    where j.status = :status
                    order by j.title
                    """;
        }

        return dbSource.query(sql, params, new JournalDetailsRowMapper());
    }

    @Override
    public List<ScopusSearchAuthor> getJournalReviewers(String emJournalAcronym, Integer offset, Integer limit) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("emJournalAcronym", emJournalAcronym.toUpperCase());

        // EM can have invalid data for ScopusId, ones with spaces cause issues, so exclude them
        String sql = """
                with potential_reviewers as (
                  select distinct p."JOURNAL_ID" as journal_id,
                    p."PEOPLEID" as people_id,
                    p."FIRSTNAME" as first_name,
                    p."LASTNAME" as last_name,
                    i."SCOPUSAUTHORID" as scopus_id,
                    count(case when r."WORKINPROGRESS" or r."ASSIGNED_NOT_INVITED"
                      or not (r."DECLINED" or r."TERMINATED" or r."COMPLETED" or r."UNINVITED") then 1 end) as pending_reviews,
                    count(case when r."COMPLETED" then 1 end) as number_completed,
                    max(r."ACCEPTDATE") as last_accepted
                  from rr_ursdb."PEOPLE" p
                  inner join rr_ursdb."JOURNAL_INFO" j on j."JOURNAL_ID" = p."JOURNAL_ID"
                  inner join rr_ursdb."PERSONAL_IDENTIFIERS" i on i."JOURNAL_ID" = p."JOURNAL_ID" and i."PERSONAL_IDENTIFIERS_ID" = p."PERSONAL_IDENTIFIERS_ID"
                  inner join rr_ursdb."ROLEREVU" r on r."JOURNAL_ID" = p."JOURNAL_ID" and r."PEOPLEID" = p."PEOPLEID"
                  where j."JOURNAL__upper" = :emJournalAcronym
                  and i."SCOPUSAUTHORID" is not null and i."SCOPUSAUTHORID" != ''
                  and i."SCOPUSAUTHORID" not like '% %'
                  and r."ACCEPTDATE" is not null
                  and r."ACCEPTDATE" > (current_date - INTERVAL '2 years')
                  group by p."JOURNAL_ID", p."PEOPLEID", p."FIRSTNAME", p."LASTNAME", i."SCOPUSAUTHORID"
                )
                select p.first_name as first_name, p.last_name as last_name, p.scopus_id as scopus_id,
                  json_agg(a."Email__lower") as emails
                from potential_reviewers p
                inner join rr_ursdb."ADDRESS_EMAIL" a on a."JOURNAL_ID" = p.journal_id and a."PeopleID" = p.people_id
                left join find_reviewers.inoperative_email io on io.email = a."Email__lower"
                where p.number_completed > 0 and p.pending_reviews < 3 and io.email is null
                group by p.first_name, p.last_name, p.scopus_id, p.pending_reviews, p.last_accepted
                order by pending_reviews asc, last_accepted desc
                """ + toSqlPaging(offset, limit, params);

        if (isCloudUrsdb) {
            sql = """
                    with potential_reviewers as (
                      select distinct p.journal_id as journal_id,
                        p.peopleid as people_id,
                        p.firstname as first_name,
                        p.lastname as last_name,
                        i.scopusauthorid as scopus_id,
                        count(case when r.workinprogress or r.assigned_not_invited
                          or not (r.declined or r.terminated or r.completed or r.uninvited) then 1 end) as pending_reviews,
                        count(case when r.completed then 1 end) as number_completed,
                        max(r.acceptdate) as last_accepted
                      from fr_ursdb.people p
                      inner join fr_ursdb.journal_info j on j.journal_id = p.journal_id
                      inner join fr_ursdb.personal_identifiers i on i.journal_id = p.journal_id and i.personal_identifiers_id = p.personal_identifiers_id
                      inner join fr_ursdb.rolerevu r on r.journal_id = p.journal_id and r.peopleid = p.peopleid
                      where j.journal__upper = :emJournalAcronym
                      and i.scopusauthorid is not null and i.scopusauthorid != ''
                      and i.scopusauthorid not like '% %'
                      and r.acceptdate is not null
                      and r.acceptdate > (current_date - INTERVAL '2 years')
                      group by p.journal_id, p.peopleid, p.firstname, p.lastname, i.scopusauthorid
                    )
                    select p.first_name as first_name, p.last_name as last_name, p.scopus_id as scopus_id,
                      json_agg(a.email__lower) as emails
                    from potential_reviewers p
                    inner join fr_ursdb.address_email a on a.journal_id = p.journal_id and a.peopleid = p.people_id
                    left join find_reviewers.inoperative_email io on io.email = a.email__lower
                    where p.number_completed > 0 and p.pending_reviews < 3 and io.email is null
                    group by p.first_name, p.last_name, p.scopus_id, p.pending_reviews, p.last_accepted
                    order by pending_reviews asc, last_accepted desc
                    """ + toSqlPaging(offset, limit, params);
        }

        return dbSource.query(sql, params, new ScopusSearchAuthorRowMapper());
    }
}
