package com.elsevier.find.reviewers.external;

import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.exception.RetryableException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.retry.backoff.FixedBackOffPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Base64;
import java.util.Collections;
import java.util.List;

@Slf4j
@Service
public class EmSupport {

    private final ObjectMapper objectMapper;
    private final HttpClient httpClient;
    private final String emSupportApiUrl;
    private final String emSupportAuth;

    private final RetryTemplate emSupportRetry;

    public EmSupport(ObjectMapper objectMapper, HttpClient httpClient,
                     @Value("${emsupport.client.base.url}") String emSupportApiUrl,
                     @Value("${emsupport.client.username}") String emSupportUsername,
                     @Value("${emsupport.client.password}") String emSupportPassword) {
        this.objectMapper = objectMapper;
        this.httpClient = httpClient;
        this.emSupportApiUrl = emSupportApiUrl.endsWith("/") ? emSupportApiUrl.substring(0, emSupportApiUrl.length() - 1) : emSupportApiUrl;
        this.emSupportAuth = String.format("Basic %s", Base64.getEncoder().encodeToString(
                String.format("%s:%s", emSupportUsername, emSupportPassword).getBytes()));

        emSupportRetry = new RetryTemplate();
        FixedBackOffPolicy fixedBackOffPolicy = new FixedBackOffPolicy();
        fixedBackOffPolicy.setBackOffPeriod(500L);
        emSupportRetry.setBackOffPolicy(fixedBackOffPolicy);
        emSupportRetry.setRetryPolicy(new SimpleRetryPolicy(2));
    }

    @SuppressWarnings("squid:S3776")
    public List<String> getBlockedEmails(String emJournalAcronym, List<String> emails) {
        final String emailParam = String.join(",", emails);

        List<String> blockedEmails = null;
        try {
            // There is a case where we do not have a Journal, for this we create a dummy entry
            // as that will pick up users that have requested to be blocked across all journals
            final String url = String.format("%s/blocked-reviewers?em-acronym=%s&reviewers=%s", emSupportApiUrl,
                    emJournalAcronym != null ? emJournalAcronym : "DUMMY",
                    URLEncoder.encode(emailParam, StandardCharsets.UTF_8));

            log.info("Making EM Support request for {}", url);

            final HttpRequest request = HttpRequest.newBuilder(new URI(url))
                    .header("Authorization", emSupportAuth)
                    .header("Content-Type", "application/json")
                    .header("Accept", "application/json")
                    .timeout(Duration.ofSeconds(5L))
                    .GET()
                    .build();

            blockedEmails = emSupportRetry.execute(context -> {
                try {
                    HttpResponse<String> httpResponse = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

                    List<String> emSupportBlockedEmails = null;
                    if (httpResponse.statusCode() == HttpStatus.OK.value()) {
                        final String rawResponse = httpResponse.body();
                        if (rawResponse != null) {
                            emSupportBlockedEmails = objectMapper.readValue(rawResponse, new TypeReference<>() {
                            });
                            if (!emSupportBlockedEmails.isEmpty()) {
                                emSupportBlockedEmails.replaceAll(String::toLowerCase);
                                // The following logging is in a specific format allowing it to be searched for in the logs
                                log.info("BLOCKED REVIEWERS: {} reviewers blocked for journal {}", emSupportBlockedEmails.size(), emJournalAcronym);
                            } else {
                                log.debug("No blocked reviewers returned for journal {}", emJournalAcronym);
                            }
                        }
                    } else {
                        final String errorBody = httpResponse.body();
                        throw new RetryableException(new InternalException(HttpStatus.INTERNAL_SERVER_ERROR),
                                "Call to check blocked reviewers for {} failed with error {} and response {}",
                                emJournalAcronym, httpResponse.statusCode(), errorBody);
                    }
                    return emSupportBlockedEmails;
                } catch (RetryableException e) {
                    throw e.logWarn();
                } catch (IOException e) {
                    throw new RetryableException(new InternalException(HttpStatus.INTERNAL_SERVER_ERROR),
                            "Failed to get blocked users for journal {}", emJournalAcronym, e).logWarn();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    throw new RetryableException(new InternalException(HttpStatus.INTERNAL_SERVER_ERROR),
                            "Interrupted while getting blocked users for journal {}", emJournalAcronym, e).logWarn();
                }
            });
        } catch (RetryableException e) {
            e.logError();
        } catch (Exception e) {
            log.error("Failed to retrieve blocked users for journal {}", emJournalAcronym, e);
        }

        return blockedEmails == null ? Collections.emptyList() : blockedEmails;
    }
}
