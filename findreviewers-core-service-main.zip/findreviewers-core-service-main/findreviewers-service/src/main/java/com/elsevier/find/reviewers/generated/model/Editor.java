package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.ScopusSearchAuthor;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * Editor
 */
@Validated



public class Editor extends ScopusSearchAuthor  {
  @JsonProperty("startDate")
  private Long startDate = null;

  @JsonProperty("accreditation")
  private String accreditation = null;

  @JsonProperty("jobTitle")
  private String jobTitle = null;

  @JsonProperty("fieldsOfInterest")
  @Valid
  private List<String> fieldsOfInterest = null;

  @JsonProperty("personalWebsite")
  private String personalWebsite = null;

  public Editor startDate(Long startDate) {
    this.startDate = startDate;
    return this;
  }

  /**
   * The date the editor started (EPOCH - milliseconds)
   * minimum: 0
   * @return startDate
   **/
  @Schema(example = "1579866980000", description = "The date the editor started (EPOCH - milliseconds)")
  
  @Min(0L)  public Long getStartDate() {
    return startDate;
  }

  public void setStartDate(Long startDate) {
    this.startDate = startDate;
  }

  public Editor accreditation(String accreditation) {
    this.accreditation = accreditation;
    return this;
  }

  /**
   * The accreditation of the editor
   * @return accreditation
   **/
  @Schema(example = "PhD", description = "The accreditation of the editor")
  
    public String getAccreditation() {
    return accreditation;
  }

  public void setAccreditation(String accreditation) {
    this.accreditation = accreditation;
  }

  public Editor jobTitle(String jobTitle) {
    this.jobTitle = jobTitle;
    return this;
  }

  /**
   * The job title of the editor
   * @return jobTitle
   **/
  @Schema(description = "The job title of the editor")
  
    public String getJobTitle() {
    return jobTitle;
  }

  public void setJobTitle(String jobTitle) {
    this.jobTitle = jobTitle;
  }

  public Editor fieldsOfInterest(List<String> fieldsOfInterest) {
    this.fieldsOfInterest = fieldsOfInterest;
    return this;
  }

  public Editor addFieldsOfInterestItem(String fieldsOfInterestItem) {
    if (this.fieldsOfInterest == null) {
      this.fieldsOfInterest = new ArrayList<>();
    }
    this.fieldsOfInterest.add(fieldsOfInterestItem);
    return this;
  }

  /**
   * The editors fields of interest
   * @return fieldsOfInterest
   **/
  @Schema(description = "The editors fields of interest")
  
    public List<String> getFieldsOfInterest() {
    return fieldsOfInterest;
  }

  public void setFieldsOfInterest(List<String> fieldsOfInterest) {
    this.fieldsOfInterest = fieldsOfInterest;
  }

  public Editor personalWebsite(String personalWebsite) {
    this.personalWebsite = personalWebsite;
    return this;
  }

  /**
   * The personal website of the editor
   * @return personalWebsite
   **/
  @Schema(description = "The personal website of the editor")
  
    public String getPersonalWebsite() {
    return personalWebsite;
  }

  public void setPersonalWebsite(String personalWebsite) {
    this.personalWebsite = personalWebsite;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Editor editor = (Editor) o;
    return Objects.equals(this.startDate, editor.startDate) &&
        Objects.equals(this.accreditation, editor.accreditation) &&
        Objects.equals(this.jobTitle, editor.jobTitle) &&
        Objects.equals(this.fieldsOfInterest, editor.fieldsOfInterest) &&
        Objects.equals(this.personalWebsite, editor.personalWebsite) &&
        super.equals(o);
  }

  @Override
  public int hashCode() {
    return Objects.hash(startDate, accreditation, jobTitle, fieldsOfInterest, personalWebsite, super.hashCode());
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Editor {\n");
    sb.append("    ").append(toIndentedString(super.toString())).append("\n");
    sb.append("    startDate: ").append(toIndentedString(startDate)).append("\n");
    sb.append("    accreditation: ").append(toIndentedString(accreditation)).append("\n");
    sb.append("    jobTitle: ").append(toIndentedString(jobTitle)).append("\n");
    sb.append("    fieldsOfInterest: ").append(toIndentedString(fieldsOfInterest)).append("\n");
    sb.append("    personalWebsite: ").append(toIndentedString(personalWebsite)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
