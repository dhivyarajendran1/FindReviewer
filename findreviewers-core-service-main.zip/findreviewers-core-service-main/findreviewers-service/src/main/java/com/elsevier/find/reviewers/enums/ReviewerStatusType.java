package com.elsevier.find.reviewers.enums;

import com.elsevier.find.reviewers.generated.model.ReviewerStatus;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

@SuppressWarnings("squid:S00115")
public enum ReviewerStatusType {
    Selected("selected"),
    Invited("invited"),
    Assigned("assigned"),
    Proposed("proposed"),
    Alternate("alternate"),
    Agreed("agreed"),
    Uninvited("uninvited"),
    Unassigned("unassigned"),
    Complete("complete"),
    Declined("declined");

    private final String value;

    ReviewerStatusType(String value) {
        this.value = value;
    }

    @JsonValue
    public String getValue() {
        return value;
    }

    // We need to manually handle the mapping as there are reports of the EM interface for the enumerations
    // returning not only expected strings, but sometimes numeric values - so we handle both when we read in
    // responses from EM. There is also the situation where the case might change between the APIs
    @JsonCreator
    public static ReviewerStatusType getEnumFromValue(Object jsonValue) {
        ReviewerStatusType enumValue = null;
        if (jsonValue instanceof String) {
            for (ReviewerStatusType enumElement : ReviewerStatusType.values()) {
                if (enumElement.getValue().equalsIgnoreCase((String) jsonValue)) {
                    enumValue = enumElement;
                    break;
                }
            }
        } else if (jsonValue instanceof Number) {
            int intValue = ((Number) jsonValue).intValue();
            if (intValue == 1) {
                enumValue = Selected;
            } else if (intValue == 2) {
                enumValue = Invited;
            } else if (intValue == 3) {
                enumValue = Assigned;
            } else if (intValue == 4) {
                enumValue = Proposed;
            } else if (intValue == 5) {
                enumValue = Alternate;
            }
        }
        return enumValue;
    }

    public static ReviewerStatusType fromInterface(ReviewerStatus status) {
        ReviewerStatusType emStatus = Selected;
        if (status != null) {
            switch (status) {
                case ALTERNATE:
                    emStatus = Alternate;
                    break;
                case INVITED:
                    emStatus = Invited;
                    break;
                case ASSIGNED:
                    emStatus = Assigned;
                    break;
                case PROPOSED:
                    emStatus = Proposed;
                    break;
                default:
                    break;
            }
        }
        return emStatus;
    }

    public static ReviewerStatus toInterface(ReviewerStatusType statusType) {
        // Default proposed, which is also what selected maps to
        ReviewerStatus status = ReviewerStatus.PROPOSED;
        if (statusType != null) {
            switch (statusType) {
                case Alternate:
                    status = ReviewerStatus.ALTERNATE;
                    break;
                case Invited:
                    status = ReviewerStatus.INVITED;
                    break;
                case Assigned:
                    status = ReviewerStatus.ASSIGNED;
                    break;
                case Agreed:
                    status = ReviewerStatus.INPROGRESS;
                    break;
                case Uninvited:
                    status = ReviewerStatus.UNINVITED;
                    break;
                case Unassigned:
                    status = ReviewerStatus.TERMINATED;
                    break;
                case Complete:
                    status = ReviewerStatus.COMPLETED;
                    break;
                case Declined:
                    status = ReviewerStatus.DECLINED;
                    break;
                default:
                    break;
            }
        }
        return status;
    }
}
