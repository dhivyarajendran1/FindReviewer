package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.external.Recommender;
import com.elsevier.find.reviewers.external.Recommender.RecommendedAffiliation;
import com.elsevier.find.reviewers.external.Recommender.RecommendedAuthor;
import com.elsevier.find.reviewers.external.Recommender.RecommendedReviewer;
import com.elsevier.find.reviewers.external.Recommender.RecommenderPublication;
import com.elsevier.find.reviewers.external.Recommender.RecommenderResponse;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.generated.api.RecommendationsApiDelegate;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.generated.model.Indicators;
import com.elsevier.find.reviewers.generated.model.RecommendationsResponse;
import com.elsevier.find.reviewers.generated.model.RecommendationsReviewer;
import com.elsevier.find.reviewers.generated.model.ScopusAuthor;
import com.elsevier.find.reviewers.generated.model.ScopusPublication;
import com.elsevier.find.reviewers.service.base.BaseService;
import com.elsevier.find.reviewers.service.base.DataGatherRules;
import com.elsevier.find.reviewers.service.base.PersonDetailsSupportService;
import com.elsevier.find.reviewers.utils.Constants;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
public class RecommendationsService extends BaseService implements RecommendationsApiDelegate {
    private static final int DEFAULT_LIMIT = 100;
    private final Recommender recommender;

    private final PersonDetailsSupportService personDetailsSupportService;

    public RecommendationsService(ObjectMapper objectMapper,
                                  Recommender recommender,
                                  PersonDetailsSupportService personDetailsSupportService) {
        super(objectMapper);
        this.recommender = recommender;
        this.personDetailsSupportService = personDetailsSupportService;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class, readOnly = true)
    public ResponseEntity<RecommendationsResponse> getRecommendations(String submissionNumber,
                                                                      String emJournalAcronym,
                                                                      Long documentId,
                                                                      String xScope,
                                                                      Integer limit) {
        if (!SessionContext.isUrsdbJournal()) {
            return ResponseEntity.ok().body(new RecommendationsResponse());
        }

        if (emJournalAcronym == null || emJournalAcronym.isBlank() || submissionNumber == null ||
                submissionNumber.isBlank()) {
            final Map<String, String> args = Map.of("emJournalAcronym", String.valueOf(emJournalAcronym),
                    "submissionNumber", String.valueOf(submissionNumber));
            log.error("Recommendations request made without EM Journal Acronym or Submission Number {}", args);
            throw new InternalException(ErrorResponse.IdEnum.INVALIDARGUMENT, HttpStatus.BAD_REQUEST, args);
        }

        log.info("Making Recommendations request for manuscript {} for journal {}", submissionNumber, emJournalAcronym);

        RecommenderResponse recommenderResponse = recommender.getRecommendations(emJournalAcronym, submissionNumber,
                documentId, limit == null ? DEFAULT_LIMIT : limit);

        RecommendationsResponse response = new RecommendationsResponse();

        List<RecommendationsReviewer> recommendedReviewers = Collections.emptyList();
        if (recommenderResponse != null) {
            response.setGenerationTime(recommenderResponse.getGenerationTime());
            response.setAnalyticsInfo(recommenderResponse.getAnalyticsInfo());

            recommendedReviewers = recommenderResponse.getRecommendedReviewers().stream().map(this::convertRecommendation)
                    .collect(Collectors.toList());
        }

        if (recommendedReviewers.isEmpty()) {
            log.info("No entries returned from Recommendations request for {}", submissionNumber);
            return ResponseEntity.notFound().build();
        }

        log.info("Recommendations for {} journal {} returned {} results", submissionNumber, emJournalAcronym, recommendedReviewers.size());

        DataGatherRules<RecommendationsReviewer> rules = new DataGatherRules<>(recommendedReviewers)
                .addBlockList().addInternalDbData().addReviewStatistics(true);

        recommendedReviewers = personDetailsSupportService.gatherAdditionalData(emJournalAcronym, rules);

        log.info("Recommendations for {} journal {} cleaned search returned {} results", submissionNumber, emJournalAcronym,
                recommendedReviewers.size());

        response.setRecommendations(recommendedReviewers);

        return ResponseEntity.ok().body(response);
    }

    @SuppressWarnings("squid:S3776")
    private RecommendationsReviewer convertRecommendation(RecommendedReviewer reviewer) {
        RecommendationsReviewer recommendation = new RecommendationsReviewer();
        recommendation.addEmailsItem(reviewer.getEmail().trim().toLowerCase());
        recommendation.addScopusIdsItem(reviewer.getScopusId());
        recommendation.setHindex(reviewer.getHIndex());
        recommendation.setFirstName(reviewer.getName());
        recommendation.setLastName(reviewer.getSurname());

        // Only need the first affiliation
        if (reviewer.getAffiliations() != null && !reviewer.getAffiliations().isEmpty()) {
            RecommendedAffiliation affiliation = reviewer.getAffiliations().get(0);
            recommendation.setAffiliationName(affiliation.getName());
            recommendation.setAffiliationCity(affiliation.getCity());
            recommendation.setAffiliationCountry(affiliation.getCountry());
        }

        recommendation.setPublicationCount(reviewer.getNumPublications());
        recommendation.setCitationCount(reviewer.getCitationTotal());
        recommendation.setPublication5YearCount(reviewer.getNumPubsLast5Year());
        recommendation.setCitation5YearCount(reviewer.getCitationTotalLast5Years());
        recommendation.setYearsActive(reviewer.getYearsActive());
        recommendation.setPublishedInJournalCount(reviewer.getNumReviewerPublishedInManuscriptJournal());
        recommendation.setSimilarPublicationsCount(reviewer.getNumberOfSimilarWorks());

        if (reviewer.getKeywords() != null && !reviewer.getKeywords().isEmpty()) {
            recommendation.setKeywords(reviewer.getKeywords());
        }
        if (Boolean.TRUE.equals(reviewer.getIsSuggestedByAuthor())) {
            recommendation.addIndicatorsItem(Indicators.SUGGESTEDBYAUTHOR);
        }
        if (Boolean.TRUE.equals(reviewer.getHasCitedManuscriptAuthors())) {
            recommendation.addIndicatorsItem(Indicators.CITEDMANUSCRIPTAUTHORS);
        }
        if (Boolean.TRUE.equals(reviewer.getIsOpposedByAuthor())) {
            recommendation.addIndicatorsItem(Indicators.OPPOSEDBYAUTHOR);
        }
        if (Boolean.TRUE.equals(reviewer.getSameInstitutionAsAuthors())) {
            recommendation.addIndicatorsItem(Indicators.SAMEINSTITUTION);
        }
        if (Boolean.TRUE.equals(reviewer.getIsInSameCountry())) {
            recommendation.addIndicatorsItem(Indicators.SAMECOUNTRY);
        }

        recommendation.setSubjectAreas(Constants.getScopusSubjectAreaDescriptions(reviewer.getSubjectAreas()));

        if (reviewer.getTopContentMatch() != null) {
            reviewer.getTopContentMatch().forEach(p -> recommendation.addSimilarPublicationsItem(convertPublications(p)));
        }

        if (reviewer.getRecentPublications() != null) {
            reviewer.getRecentPublications().forEach(p -> recommendation.addRecentPublicationsItem(convertPublications(p)));
        }

        return recommendation;
    }

    private ScopusPublication convertPublications(RecommenderPublication publication) {
        ScopusPublication pub = new ScopusPublication();
        pub.setEid(publication.getScopusEid());
        pub.setTitle(publication.getTitle());
        pub.setJournalTitle(publication.getJournal());
        pub.setYear(publication.getYear());
        pub.setCitationCount(publication.getNCitations());
        pub.setAuthorCount(publication.getNumAuthors());

        if (publication.getAuthorsPreview() != null) {
            for (RecommendedAuthor author : publication.getAuthorsPreview()) {
                final String name = author.getName();
                if (name != null) {
                    ScopusAuthor scopusAuthor = new ScopusAuthor();
                    scopusAuthor.setId(author.getId());
                    scopusAuthor.setName(name);
                    pub.addAuthorsItem(scopusAuthor);
                }
            }
        }

        return pub;
    }
}
