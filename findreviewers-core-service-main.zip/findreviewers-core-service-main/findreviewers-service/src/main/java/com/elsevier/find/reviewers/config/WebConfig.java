package com.elsevier.find.reviewers.config;

import com.elsevier.find.reviewers.generated.model.KeywordSearchLogic;
import com.elsevier.find.reviewers.generated.model.SortOrder;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.format.FormatterRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * This class supplies all the custom rules required to support the REST interface via Spring
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {
    @Override
    // SonarQube: Complains about anonymous classes rather than lambda. It would be nice to change the anonymous
    // classes to lambdas, but unfortunately Spring does not like it and will error on startup
    @SuppressWarnings("squid:S1604")
    public void addFormatters(FormatterRegistry registry) {
        // Map the Enumerations from the String format to the internal Enumeration type
        registry.addConverter(new Converter<String, SortOrder>() {
            public SortOrder convert(String s) {
                return s == null ? null : SortOrder.valueOf(s.toUpperCase());
            }
        });
        registry.addConverter(new Converter<String, KeywordSearchLogic>() {
            public KeywordSearchLogic convert(String s) {
                return s == null ? null : KeywordSearchLogic.valueOf(s.toUpperCase());
            }
        });
    }
}
