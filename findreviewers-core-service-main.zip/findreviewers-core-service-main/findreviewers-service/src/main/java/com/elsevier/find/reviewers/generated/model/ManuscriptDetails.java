package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.PersonBase;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * The details for a manuscript
 */
@Schema(description = "The details for a manuscript")
@Validated



public class ManuscriptDetails   {
  @JsonProperty("manuscriptNumber")
  private String manuscriptNumber = null;

  @JsonProperty("title")
  private String title = null;

  @JsonProperty("abstract")
  private String _abstract = null;

  @JsonProperty("correspondingAuthors")
  @Valid
  private List<PersonBase> correspondingAuthors = null;

  @JsonProperty("coAuthors")
  @Valid
  private List<PersonBase> coAuthors = null;

  public ManuscriptDetails manuscriptNumber(String manuscriptNumber) {
    this.manuscriptNumber = manuscriptNumber;
    return this;
  }

  /**
   * The manuscript number
   * @return manuscriptNumber
   **/
  @Schema(description = "The manuscript number")
  
    public String getManuscriptNumber() {
    return manuscriptNumber;
  }

  public void setManuscriptNumber(String manuscriptNumber) {
    this.manuscriptNumber = manuscriptNumber;
  }

  public ManuscriptDetails title(String title) {
    this.title = title;
    return this;
  }

  /**
   * The title of the manuscript
   * @return title
   **/
  @Schema(description = "The title of the manuscript")
  
    public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public ManuscriptDetails _abstract(String _abstract) {
    this._abstract = _abstract;
    return this;
  }

  /**
   * The abstract of the manuscript
   * @return _abstract
   **/
  @Schema(example = "To study patterns of oral tranexamic acid use among pre- and perimenopausal Danish women following the introduction of the levonorgestrel-releasing intrauterine system...", description = "The abstract of the manuscript")
  
    public String getAbstract() {
    return _abstract;
  }

  public void setAbstract(String _abstract) {
    this._abstract = _abstract;
  }

  public ManuscriptDetails correspondingAuthors(List<PersonBase> correspondingAuthors) {
    this.correspondingAuthors = correspondingAuthors;
    return this;
  }

  public ManuscriptDetails addCorrespondingAuthorsItem(PersonBase correspondingAuthorsItem) {
    if (this.correspondingAuthors == null) {
      this.correspondingAuthors = new ArrayList<>();
    }
    this.correspondingAuthors.add(correspondingAuthorsItem);
    return this;
  }

  /**
   * Get correspondingAuthors
   * @return correspondingAuthors
   **/
  @Schema(description = "")
      @Valid
    public List<PersonBase> getCorrespondingAuthors() {
    return correspondingAuthors;
  }

  public void setCorrespondingAuthors(List<PersonBase> correspondingAuthors) {
    this.correspondingAuthors = correspondingAuthors;
  }

  public ManuscriptDetails coAuthors(List<PersonBase> coAuthors) {
    this.coAuthors = coAuthors;
    return this;
  }

  public ManuscriptDetails addCoAuthorsItem(PersonBase coAuthorsItem) {
    if (this.coAuthors == null) {
      this.coAuthors = new ArrayList<>();
    }
    this.coAuthors.add(coAuthorsItem);
    return this;
  }

  /**
   * Get coAuthors
   * @return coAuthors
   **/
  @Schema(description = "")
      @Valid
    public List<PersonBase> getCoAuthors() {
    return coAuthors;
  }

  public void setCoAuthors(List<PersonBase> coAuthors) {
    this.coAuthors = coAuthors;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ManuscriptDetails manuscriptDetails = (ManuscriptDetails) o;
    return Objects.equals(this.manuscriptNumber, manuscriptDetails.manuscriptNumber) &&
        Objects.equals(this.title, manuscriptDetails.title) &&
        Objects.equals(this._abstract, manuscriptDetails._abstract) &&
        Objects.equals(this.correspondingAuthors, manuscriptDetails.correspondingAuthors) &&
        Objects.equals(this.coAuthors, manuscriptDetails.coAuthors);
  }

  @Override
  public int hashCode() {
    return Objects.hash(manuscriptNumber, title, _abstract, correspondingAuthors, coAuthors);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ManuscriptDetails {\n");
    
    sb.append("    manuscriptNumber: ").append(toIndentedString(manuscriptNumber)).append("\n");
    sb.append("    title: ").append(toIndentedString(title)).append("\n");
    sb.append("    _abstract: ").append(toIndentedString(_abstract)).append("\n");
    sb.append("    correspondingAuthors: ").append(toIndentedString(correspondingAuthors)).append("\n");
    sb.append("    coAuthors: ").append(toIndentedString(coAuthors)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
