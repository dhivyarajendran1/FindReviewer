package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.ScopusKeywordSearchAuthor;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * The response for a keyword scopus search
 */
@Schema(description = "The response for a keyword scopus search")
@Validated



public class ScopusKeywordSearchResponse   {
  @JsonProperty("authors")
  @Valid
  private List<ScopusKeywordSearchAuthor> authors = new ArrayList<>();

  public ScopusKeywordSearchResponse authors(List<ScopusKeywordSearchAuthor> authors) {
    this.authors = authors;
    return this;
  }

  public ScopusKeywordSearchResponse addAuthorsItem(ScopusKeywordSearchAuthor authorsItem) {
    this.authors.add(authorsItem);
    return this;
  }

  /**
   * Get authors
   * @return authors
   **/
  @Schema(required = true, description = "")
      @NotNull
    @Valid
    public List<ScopusKeywordSearchAuthor> getAuthors() {
    return authors;
  }

  public void setAuthors(List<ScopusKeywordSearchAuthor> authors) {
    this.authors = authors;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ScopusKeywordSearchResponse scopusKeywordSearchResponse = (ScopusKeywordSearchResponse) o;
    return Objects.equals(this.authors, scopusKeywordSearchResponse.authors);
  }

  @Override
  public int hashCode() {
    return Objects.hash(authors);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ScopusKeywordSearchResponse {\n");
    
    sb.append("    authors: ").append(toIndentedString(authors)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
