package com.elsevier.find.reviewers.external;

import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class ScopusGraph {
    @EqualsAndHashCode(callSuper = true)
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    private static class GraphNodesWrapper<T> extends GraphPageInfo {
        @JsonProperty("nodes")
        private List<T> nodes;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    private static class GraphPageInfo {
        @Data
        @JsonIgnoreProperties(ignoreUnknown = true)
        private static class GraphPageInfoCount {
            @JsonProperty("totalCount")
            private Integer totalCount;
        }

        @JsonProperty("pageInfo")
        private GraphPageInfoCount pageInfo;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class GraphOrganization {
        @JsonProperty("prefname")
        private String prefname; // Affiliation Name (Fallback)
        @JsonProperty("prefparname")
        private String prefparname; // Affiliation Name (Preferred)
        @JsonProperty("affilcity")
        private String affilcity; // Affiliation City
        @JsonProperty("affilctry")
        private String affilctry; // Affiliation Country

        public String getAffiliationName() {
            return prefparname != null ? prefparname : prefname;
        }
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    private static class GraphRelations {
        @JsonProperty("coauthorship")
        private GraphPageInfo coauthorship;
    }

    // SonarQube not liking the capital ID
    @SuppressWarnings("java:S116")
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class GraphPerson {
        @JsonProperty("ID")
        private String ID; // Scopus Id
        @JsonProperty("authemail")
        private String authemail; // email
        @JsonProperty("preffirst")
        private String preffirst; // Given/First name (Preferred)
        @JsonProperty("preflast")
        private String preflast; // Family/Last name (Preferred)
        @JsonProperty("hIndex")
        private Integer hIndex; // Author hIndex
        @JsonProperty("hasAffiliation")
        private GraphNodesWrapper<GraphOrganization> hasAffiliation;
        @JsonProperty("relations")
        private GraphRelations relations;
        @JsonProperty("authorOf")
        private GraphPageInfo authorOf;

        public GraphOrganization getOrganization() {
            if (hasAffiliation == null || hasAffiliation.getNodes() == null || hasAffiliation.getNodes().isEmpty()) {
                return null;
            }
            return hasAffiliation.getNodes().get(0);
        }

        public Integer getCoauthorshipCount() {
            if (relations == null || relations.getCoauthorship() == null ||
                    relations.getCoauthorship().getPageInfo() == null) {
                return null;
            }
            return relations.getCoauthorship().getPageInfo().getTotalCount();
        }

        public Integer getPublishedInJournalCount() {
            if (authorOf == null || authorOf.getPageInfo() == null) {
                return null;
            }
            return authorOf.getPageInfo().getTotalCount();
        }
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class GraphDataCoauthor {
        @Data
        @JsonIgnoreProperties(ignoreUnknown = true)
        private static class GraphDataPerson {
            @Data
            @JsonIgnoreProperties(ignoreUnknown = true)
            private static class GraphCoauthorsDistinct {
                @JsonProperty("coauthorsDistinct")
                private GraphNodesWrapper<GraphPerson> coauthorsDistinct;
            }

            @JsonProperty("person")
            private GraphCoauthorsDistinct person;
        }

        @JsonProperty("data")
        private GraphDataPerson data;

        public List<GraphPerson> getCoauthors() {
            if (missingBaseData() || data.getPerson().getCoauthorsDistinct().getNodes() == null) {
                return Collections.emptyList();
            }
            return data.getPerson().getCoauthorsDistinct().getNodes();
        }

        public Integer getTotalCoauthors() {
            if (missingBaseData() || data.getPerson().getCoauthorsDistinct().getPageInfo() == null) {
                return null;
            }
            return data.getPerson().getCoauthorsDistinct().getPageInfo().getTotalCount();
        }

        private boolean missingBaseData() {
            return data == null || data.getPerson() == null || data.getPerson().getCoauthorsDistinct() == null;
        }
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class GraphPersonStatistics {
        @Data
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class GraphYearCount {
            @JsonProperty("startYear")
            private String startYear;

            @JsonProperty("count")
            private Integer count;
        }

        @JsonProperty("annualAuthorOf")
        private List<GraphYearCount> annualAuthorOf;

        @JsonProperty("annualReferencedBy")
        private List<GraphYearCount> annualReferencedBy;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class GraphDataStatistics {
        @Data
        @JsonIgnoreProperties(ignoreUnknown = true)
        private static class GraphDataPerson {
            @JsonProperty("person")
            private GraphPersonStatistics person;
        }

        @JsonProperty("data")
        private GraphDataPerson data;
    }

    private static final String COAUTHOR_REQUEST_TEMPLATE = """
            {
                person(personId: "%s") {
                    coauthorsDistinct(amount: 100, orderBy: PUBLICATION_COUNT_DESC) {
                        pageInfo {
                            totalCount
                        }
                        nodes {
                            ID
                            preffirst
                            preflast
                            hIndex
                            authemail
                            hasAffiliation {
                                nodes {
                                    affilcity
                                    affilctry
                                    prefname
                                    prefparname
                                }
                            }
                            relations(personId: "%s") {
                                coauthorship {
                                    pageInfo {
                                        totalCount
                                    }
                                }
                            }
                            %s
                        }
                    }
                }
            }
            """;

    private static final String COAUTHOR_REQUEST_PUB_IN_JOURNAL_TEMPLATE = """
                authorOf(issn: "%s") {
                    pageInfo {
                        totalCount
                    }
                }
            """;

    private static final String PUBLICATION_STATISTICS_REQUEST_TEMPLATE = """
            {
                person(personId: "%s") {
                    annualAuthorOf {
                        startYear
                        count: authorOfCount
                    }
                    annualReferencedBy {
                        startYear
                        count: referencedByCount
                    }
                }
            }
            """;

    private static final String SCOPUS_ID = "scopusId";

    private final WebClient webClient;
    private final String scopusGraphBaseUrl;
    private final ObjectMapper objectMapper;

    public ScopusGraph(@Qualifier("scopusgraph") WebClient webClient,
                       ObjectMapper objectMapper,
                       @Value("${scopusgraph.client.base.url}") String scopusGraphBaseUrl) {
        this.webClient = webClient;
        this.objectMapper = objectMapper;
        this.scopusGraphBaseUrl = scopusGraphBaseUrl.endsWith("/") ?
                scopusGraphBaseUrl.substring(0, scopusGraphBaseUrl.length() - 1) : scopusGraphBaseUrl;
    }

    public GraphDataCoauthor getCoauthors(String scopusId, String journalIssn) {
        String pubQueryPart = "";
        if (journalIssn != null && !journalIssn.isBlank()) {
            pubQueryPart = String.format(COAUTHOR_REQUEST_PUB_IN_JOURNAL_TEMPLATE, journalIssn);
        }
        String query = String.format(COAUTHOR_REQUEST_TEMPLATE, scopusId, scopusId, pubQueryPart);

        String rawResponse = null;
        GraphDataCoauthor coauthorsData = null;
        try {
            rawResponse = makeScopusGraphCall(query);

            if (rawResponse != null && !rawResponse.isBlank()) {
                coauthorsData = objectMapper.readValue(rawResponse, GraphDataCoauthor.class);
            }
        } catch (IOException e) {
            log.error("Scopus Graph response for coauthors with Scopus Id {} unexpected format {}", scopusId, rawResponse, e);
            throw new InternalException(
                    ErrorResponse.IdEnum.SCOPUSGRAPHFAILURE, HttpStatus.INTERNAL_SERVER_ERROR, Map.of(SCOPUS_ID, scopusId));
        }

        if (coauthorsData == null || coauthorsData.getData() == null) {
            log.error("Scopus Graph response for coauthors with Scopus Id {} did not have authors {}", scopusId, rawResponse);
            throw new InternalException(
                    ErrorResponse.IdEnum.SCOPUSGRAPHFAILURE, HttpStatus.INTERNAL_SERVER_ERROR, Map.of(SCOPUS_ID, scopusId));
        }

        return coauthorsData;
    }

    public GraphPersonStatistics getPublicationStatistics(String scopusId) {
        String query = String.format(PUBLICATION_STATISTICS_REQUEST_TEMPLATE, scopusId);

        String rawResponse = null;
        GraphDataStatistics statistics = null;
        try {
            rawResponse = makeScopusGraphCall(query);

            if (rawResponse != null && !rawResponse.isBlank()) {
                statistics = objectMapper.readValue(rawResponse, GraphDataStatistics.class);
            }
        } catch (IOException e) {
            log.error("Scopus Graph response for statistics with Scopus Id {} unexpected format {}", scopusId, rawResponse, e);
            throw new InternalException(
                    ErrorResponse.IdEnum.SCOPUSGRAPHFAILURE, HttpStatus.INTERNAL_SERVER_ERROR, Map.of(SCOPUS_ID, scopusId));
        }

        if (statistics == null || statistics.getData() == null) {
            log.error("Scopus Graph response for statistics with Scopus Id {} did not have data {}", scopusId, rawResponse);
            throw new InternalException(
                    ErrorResponse.IdEnum.SCOPUSGRAPHFAILURE, HttpStatus.INTERNAL_SERVER_ERROR, Map.of(SCOPUS_ID, scopusId));
        }

        return statistics.getData().getPerson() == null ? new GraphPersonStatistics() : statistics.getData().getPerson();
    }

    /**
     * Makes the API request to the Scopus Graph system with all the correct authentication
     *
     * @param query The GraphSQL query
     * @return The text returned from the request
     */
    private String makeScopusGraphCall(String query) {
        final String url = String.format("%s/graphql", scopusGraphBaseUrl);

        String requestBody = String.format("{\"query\": \"%s\" }", query.replaceAll("[\n\t]", " ")
                .replace("\"", "\\\""));

        log.info("Making Graph API {} request with body {}", url, requestBody);

        String response = null;
        try {
            response = webClient.post()
                    .uri(url)
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(requestBody)
                    .retrieve()
                    .bodyToMono(String.class)
                    // Subscribe to this Mono and block until a next signal is received or a timeout expires.
                    // Returns that value, or null if the Mono completes empty.
                    .block(Duration.ofSeconds(20));

        } catch (WebClientResponseException e) {
            log.error("Error calling Scopus Graph API {} HttpStatusCode = {}, HttpHeaders = {}, ResponseBody = {} for request = {}",
                    url, e.getStatusCode(), e.getHeaders(), e.getResponseBodyAsString(), requestBody, e);
            throw new InternalException(ErrorResponse.IdEnum.SCOPUSGRAPHFAILURE,
                    HttpStatus.INTERNAL_SERVER_ERROR, Map.of("body", requestBody));
        } catch (Exception e) {
            log.error("Exception calling Scopus Graph API {}", url, e);
            throw new InternalException(ErrorResponse.IdEnum.SCOPUSGRAPHFAILURE, HttpStatus.INTERNAL_SERVER_ERROR,
                    Map.of("body", requestBody));
        }

        return response;
    }
}
