package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.ReviewerDetails;
import com.elsevier.find.reviewers.generated.model.ReviewerStatus;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * ReviewersRequestItem
 */
@Validated



public class ReviewersRequestItem extends ReviewerDetails  {
  @JsonProperty("affiliation")
  private String affiliation = null;

  @JsonProperty("keywords")
  @Valid
  private List<String> keywords = null;

  public ReviewersRequestItem affiliation(String affiliation) {
    this.affiliation = affiliation;
    return this;
  }

  /**
   * Reviewers academic affiliation
   * @return affiliation
   **/
  @Schema(description = "Reviewers academic affiliation")
  
    public String getAffiliation() {
    return affiliation;
  }

  public void setAffiliation(String affiliation) {
    this.affiliation = affiliation;
  }

  public ReviewersRequestItem keywords(List<String> keywords) {
    this.keywords = keywords;
    return this;
  }

  public ReviewersRequestItem addKeywordsItem(String keywordsItem) {
    if (this.keywords == null) {
      this.keywords = new ArrayList<>();
    }
    this.keywords.add(keywordsItem);
    return this;
  }

  /**
   * Any Keywords for the reviewer
   * @return keywords
   **/
  @Schema(description = "Any Keywords for the reviewer")
  
    public List<String> getKeywords() {
    return keywords;
  }

  public void setKeywords(List<String> keywords) {
    this.keywords = keywords;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ReviewersRequestItem reviewersRequestItem = (ReviewersRequestItem) o;
    return Objects.equals(this.affiliation, reviewersRequestItem.affiliation) &&
        Objects.equals(this.keywords, reviewersRequestItem.keywords) &&
        super.equals(o);
  }

  @Override
  public int hashCode() {
    return Objects.hash(affiliation, keywords, super.hashCode());
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ReviewersRequestItem {\n");
    sb.append("    ").append(toIndentedString(super.toString())).append("\n");
    sb.append("    affiliation: ").append(toIndentedString(affiliation)).append("\n");
    sb.append("    keywords: ").append(toIndentedString(keywords)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
