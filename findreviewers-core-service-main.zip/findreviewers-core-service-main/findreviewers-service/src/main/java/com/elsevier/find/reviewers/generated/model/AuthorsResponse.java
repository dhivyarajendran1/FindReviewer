package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.ScopusSearchAuthor;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * The response for a list of authors
 */
@Schema(description = "The response for a list of authors")
@Validated



public class AuthorsResponse   {
  @JsonProperty("authors")
  @Valid
  private List<ScopusSearchAuthor> authors = new ArrayList<>();

  public AuthorsResponse authors(List<ScopusSearchAuthor> authors) {
    this.authors = authors;
    return this;
  }

  public AuthorsResponse addAuthorsItem(ScopusSearchAuthor authorsItem) {
    this.authors.add(authorsItem);
    return this;
  }

  /**
   * Get authors
   * @return authors
   **/
  @Schema(required = true, description = "")
      @NotNull
    @Valid
    public List<ScopusSearchAuthor> getAuthors() {
    return authors;
  }

  public void setAuthors(List<ScopusSearchAuthor> authors) {
    this.authors = authors;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AuthorsResponse authorsResponse = (AuthorsResponse) o;
    return Objects.equals(this.authors, authorsResponse.authors);
  }

  @Override
  public int hashCode() {
    return Objects.hash(authors);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AuthorsResponse {\n");
    
    sb.append("    authors: ").append(toIndentedString(authors)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
