package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * ScopusStatisticsResponseStatistics
 */
@Validated



public class ScopusStatisticsResponseStatistics   {
  @JsonProperty("year")
  private Integer year = null;

  @JsonProperty("publishedCount")
  private Integer publishedCount = null;

  @JsonProperty("citationsCount")
  private Integer citationsCount = null;

  public ScopusStatisticsResponseStatistics year(Integer year) {
    this.year = year;
    return this;
  }

  /**
   * Year the statistics are for
   * @return year
   **/
  @Schema(example = "2021", required = true, description = "Year the statistics are for")
      @NotNull

    public Integer getYear() {
    return year;
  }

  public void setYear(Integer year) {
    this.year = year;
  }

  public ScopusStatisticsResponseStatistics publishedCount(Integer publishedCount) {
    this.publishedCount = publishedCount;
    return this;
  }

  /**
   * Get publishedCount
   * minimum: 0
   * @return publishedCount
   **/
  @Schema(example = "30", description = "")
  
  @Min(0)  public Integer getPublishedCount() {
    return publishedCount;
  }

  public void setPublishedCount(Integer publishedCount) {
    this.publishedCount = publishedCount;
  }

  public ScopusStatisticsResponseStatistics citationsCount(Integer citationsCount) {
    this.citationsCount = citationsCount;
    return this;
  }

  /**
   * Get citationsCount
   * minimum: 0
   * @return citationsCount
   **/
  @Schema(example = "78", description = "")
  
  @Min(0)  public Integer getCitationsCount() {
    return citationsCount;
  }

  public void setCitationsCount(Integer citationsCount) {
    this.citationsCount = citationsCount;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ScopusStatisticsResponseStatistics scopusStatisticsResponseStatistics = (ScopusStatisticsResponseStatistics) o;
    return Objects.equals(this.year, scopusStatisticsResponseStatistics.year) &&
        Objects.equals(this.publishedCount, scopusStatisticsResponseStatistics.publishedCount) &&
        Objects.equals(this.citationsCount, scopusStatisticsResponseStatistics.citationsCount);
  }

  @Override
  public int hashCode() {
    return Objects.hash(year, publishedCount, citationsCount);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ScopusStatisticsResponseStatistics {\n");
    
    sb.append("    year: ").append(toIndentedString(year)).append("\n");
    sb.append("    publishedCount: ").append(toIndentedString(publishedCount)).append("\n");
    sb.append("    citationsCount: ").append(toIndentedString(citationsCount)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
