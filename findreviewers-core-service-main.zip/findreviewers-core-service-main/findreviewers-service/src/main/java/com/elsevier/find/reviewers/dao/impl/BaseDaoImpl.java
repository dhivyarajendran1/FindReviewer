package com.elsevier.find.reviewers.dao.impl;

import com.elsevier.find.reviewers.dao.BaseDao;
import com.elsevier.find.reviewers.generated.model.PersonBase;
import com.elsevier.find.reviewers.utils.PersonDetailsUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

/**
 * Common Database utility methods
 */
@Slf4j
public abstract class BaseDaoImpl implements BaseDao {
    protected final NamedParameterJdbcTemplate dbSource;

    protected final ObjectMapper objectMapper;
    protected final boolean isCloudUrsdb;

    protected BaseDaoImpl(NamedParameterJdbcTemplate dbSource, ObjectMapper objectMapper, String cloudUrsdbEnabled) {
        this.dbSource = dbSource;
        this.objectMapper = objectMapper;
        this.isCloudUrsdb = "true".equals(cloudUrsdbEnabled);
    }

    @Data
    private static class UserAvailability {
        private long start;
        private long stop;
    }

    /**
     * Base class with common methods to help when mapping data between the DB and the model
     */
    public class BaseRowMapper {
        protected String getOptionalString(ResultSet rs, String strColName) throws SQLException {
            // Some strings in the EM Replica database are stored as empty string if they are not set rather than null
            String value = rs.getString(strColName);
            return (value == null || value.isBlank()) ? null : value;
        }

        protected Long getOptionalLong(ResultSet rs, String strColName) throws SQLException {
            long nValue = rs.getLong(strColName);
            return rs.wasNull() ? null : nValue;
        }

        protected List<PersonBase> getPersonDetails(String personDetailsJson) {
            List<PersonBase> personList = null;
            if (personDetailsJson != null && !personDetailsJson.isBlank()) {
                try {
                    personList = objectMapper.readValue(personDetailsJson, new TypeReference<>() {
                    });

                    for (PersonBase person : personList) {
                        PersonDetailsUtils.setDisplayName(person);
                        person.setEmails(PersonDetailsUtils.processEmEmails(person.getEmails()));
                    }
                } catch (JsonProcessingException e) {
                    log.error("Failed to load person details from database for {}, error {}", personDetailsJson, e.getMessage());
                }
            }
            return personList;
        }

        protected boolean isUnavailable(String availabilityJson) {
            boolean unavailable = false;
            if (availabilityJson != null && !availabilityJson.isBlank()) {
                try {
                    List<UserAvailability> userAvailability = objectMapper.readValue(availabilityJson, new TypeReference<>() {
                    });

                    final long currentTime = System.currentTimeMillis();
                    unavailable = userAvailability.stream().anyMatch(a -> a.getStart() < currentTime && a.getStop() > currentTime);
                } catch (JsonProcessingException e) {
                    log.error("Failed to load user availability from database for {}, error {}", availabilityJson, e.getMessage());
                }
            }
            return unavailable;
        }
    }

    /**
     * Converts any paging request to the required SQL
     *
     * @param offset Where to start the listing from
     * @param limit  Maximum number of entries to return
     * @param params Any parameters
     * @return SQL String
     */
    protected String toSqlPaging(Integer offset, Integer limit, MapSqlParameterSource params) {
        String pagingSql = "";
        if (limit != null) {
            params.addValue("limit", limit);
            pagingSql = " LIMIT :limit";
        }
        if (offset != null) {
            params.addValue("offset", offset);
            pagingSql += " OFFSET :offset";
        }
        return pagingSql;
    }
}
