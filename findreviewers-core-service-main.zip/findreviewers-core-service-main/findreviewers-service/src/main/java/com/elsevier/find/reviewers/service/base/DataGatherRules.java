package com.elsevier.find.reviewers.service.base;

import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.generated.model.KeywordSearchLogic;
import com.elsevier.find.reviewers.generated.model.PersonDetails;
import com.elsevier.find.reviewers.generated.model.ScopusSearchAuthor;
import lombok.Getter;

import java.util.InputMismatchException;
import java.util.List;
import java.util.stream.Collectors;

@Getter
public class DataGatherRules<T extends PersonDetails> {
    private final List<T> candidateDetails;
    private final List<String> emails;
    private final List<String> scopusIds;

    private String keywords = null;
    private KeywordSearchLogic searchLogic = null;

    private boolean blockList = false;
    private boolean contentMatch = false;
    private boolean reviewStatistics = false;
    private boolean internalDbData = false;
    private boolean scopusData = false;
    private boolean applyRemovalRules = false;

    public DataGatherRules(List<T> candidateDetails) {
        this.candidateDetails = candidateDetails;
        this.emails = candidateDetails.stream().filter(p -> p.getEmails() != null && !p.getEmails().isEmpty())
                .map(p -> p.getEmails().get(0)).collect(Collectors.toList());
        this.scopusIds = candidateDetails.stream().filter(p -> p.getScopusIds() != null)
                .map(p -> p.getScopusIds().get(0)).collect(Collectors.toList());
    }

    public DataGatherRules<T> addBlockList() {
        blockList = SessionContext.isElsevierJournal() && !emails.isEmpty();
        return this;
    }

    public DataGatherRules<T> addReviewStatistics(boolean applyRemovalRules) {
        reviewStatistics = SessionContext.isUrsdbJournal() && !emails.isEmpty();
        this.applyRemovalRules = applyRemovalRules;
        return this;
    }

    public DataGatherRules<T> addInternalDbData() {
        internalDbData = !emails.isEmpty();
        return this;
    }

    public DataGatherRules<T> addScopusData() {
        scopusData = !scopusIds.isEmpty();
        return this;
    }

    public DataGatherRules<T> addContentMatch(String keywords, KeywordSearchLogic searchLogic) {
        this.keywords = keywords;
        this.searchLogic = searchLogic;
        // For content match we need to have a Scopus Author type as that has the field to save the data in
        if (!candidateDetails.isEmpty() && !(candidateDetails.get(0) instanceof ScopusSearchAuthor)) {
            throw new InputMismatchException();
        }
        contentMatch = !scopusIds.isEmpty() && keywords != null && !keywords.isBlank();
        return this;
    }
}
