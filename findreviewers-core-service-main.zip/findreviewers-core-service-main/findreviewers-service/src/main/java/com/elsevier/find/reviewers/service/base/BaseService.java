package com.elsevier.find.reviewers.service.base;

import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutionException;
import java.util.function.Supplier;

/**
 * Base class for all services that provides common behaviour
 */
@Slf4j
public abstract class BaseService {
    protected final ObjectMapper objectMapper;

    protected BaseService(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public Optional<ObjectMapper> getObjectMapper() {
        return Optional.ofNullable(objectMapper);
    }

    public Optional<HttpServletRequest> getRequest() {
        return Optional.empty();
    }

    protected <T> CompletableFuture<T> createAsyncFuture(Supplier<T> supplier) {
        final Map<String, String> parentThreadContext = MDC.getCopyOfContextMap();
        final List<Object> exportSession = SessionContext.export();
        return CompletableFuture.supplyAsync(() -> {
            // Set the context to match the parent so that the correlation information appears on all threads
            MDC.setContextMap(parentThreadContext);
            // Load the sessions onto the new thread
            SessionContext.load(exportSession);
            try {
                return supplier.get();
            } finally {
                SessionContext.destroy();
                MDC.clear();
            }
        });
    }

    protected <T> T waitAndGetFutureContent(CompletableFuture<T> future) {
        try {
            return future.get();
        } catch (ExecutionException e) {
            // There are cases where we need to handle DB exceptions and our own InternalException that are deliberately
            // RuntimeExceptions so that they can be thrown upto the interface boundary and handled there. These we
            // need to process separately to stop CompletableFuture converting it to its own type and hiding our error
            if (e.getCause() instanceof RuntimeException) {
                throw (RuntimeException) e.getCause();
            }
            log.error("Failed to complete Future request, with ExecutionException", e.getCause());
            throw new InternalException(HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log.error("Failed to complete Future request, most likely interrupted", e);
            throw new InternalException(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    protected void waitAndJoinFutures(List<CompletableFuture<Void>> futures) {
        try {
            futures.forEach(CompletableFuture::join);
        } catch (CompletionException e) {
            // There are cases where we need to handle DB exceptions and our own InternalException that are deliberately
            // RuntimeExceptions so that they can be thrown upto the interface boundary and handled there. These we
            // need to process separately to stop CompletableFuture converting it to its own type and hiding our error
            if (e.getCause() instanceof RuntimeException) {
                throw (RuntimeException) e.getCause();
            }
            log.error("Failed to complete Future request, with CompletionException", e.getCause());
            throw new InternalException(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
