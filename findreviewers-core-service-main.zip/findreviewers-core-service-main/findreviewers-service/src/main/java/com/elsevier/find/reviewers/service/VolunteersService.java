package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.dao.VolunteerDao;
import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.generated.api.VolunteersApiDelegate;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.generated.model.KeywordSearchLogic;
import com.elsevier.find.reviewers.generated.model.Volunteer;
import com.elsevier.find.reviewers.generated.model.VolunteersResponse;
import com.elsevier.find.reviewers.service.base.BaseService;
import com.elsevier.find.reviewers.service.base.DataGatherRules;
import com.elsevier.find.reviewers.service.base.PersonDetailsSupportService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

/**
 * Class to handle all requests on the volunteer endpoint
 */
@Slf4j
@Service
public class VolunteersService extends BaseService implements VolunteersApiDelegate {

    private final VolunteerDao volunteerDao;

    private final PersonDetailsSupportService personDetailsSupportService;

    public VolunteersService(ObjectMapper objectMapper,
                             VolunteerDao volunteerDao,
                             PersonDetailsSupportService personDetailsSupportService) {
        super(objectMapper);
        this.volunteerDao = volunteerDao;
        this.personDetailsSupportService = personDetailsSupportService;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class, readOnly = true)
    public ResponseEntity<VolunteersResponse> getVolunteers(String emJournalAcronym,
                                                            String xScope,
                                                            String keywords,
                                                            KeywordSearchLogic searchLogic,
                                                            Integer offset,
                                                            Integer limit) {
        // We only have volunteers for Elsevier journals
        if (!SessionContext.isElsevierJournal()) {
            return ResponseEntity.ok().body(new VolunteersResponse());
        }

        if (emJournalAcronym == null || emJournalAcronym.isBlank()) {
            log.error("Volunteer request made without EM Journal Acronym");
            throw new InternalException(ErrorResponse.IdEnum.INVALIDARGUMENT,
                    HttpStatus.BAD_REQUEST, Map.of("emJournalAcronym", "null"));
        }

        VolunteersResponse response = new VolunteersResponse();

        List<Volunteer> volunteers = volunteerDao.getVolunteersByEmJournalAcronym(
                emJournalAcronym, offset, limit);

        // If the request was to limit the records, and we found fewer records than the limit, then there is no more
        // records available
        response.setMore(limit != null && volunteers.size() >= limit);

        DataGatherRules<Volunteer> rules = new DataGatherRules<>(volunteers)
                .addInternalDbData().addReviewStatistics(true).addScopusData().addContentMatch(keywords, searchLogic);

        volunteers = personDetailsSupportService.gatherAdditionalData(emJournalAcronym, rules);

        response.setVolunteers(volunteers);

        log.info("Returning {} volunteers for journal {}", volunteers.size(), emJournalAcronym);

        return ResponseEntity.ok().body(response);
    }
}
