package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.dao.VolunteerDao;
import com.elsevier.find.reviewers.enums.ReviewerStatusType;
import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.external.EditorialManager;
import com.elsevier.find.reviewers.external.EditorialManager.Reviewer;
import com.elsevier.find.reviewers.external.ReviewerHub;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.generated.api.ReviewersApiDelegate;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.generated.model.ReviewersRequest;
import com.elsevier.find.reviewers.generated.model.ReviewersRequestItem;
import com.elsevier.find.reviewers.service.base.BaseService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Class to handle all requests on the reviewers endpoint
 */
@Slf4j
@Service
public class ReviewersService extends BaseService implements ReviewersApiDelegate {

    private final EditorialManager editorialManager;

    private final ReviewerHub reviewerHub;

    private final VolunteerDao volunteerDao;

    public ReviewersService(ObjectMapper objectMapper,
                            EditorialManager editorialManager,
                            ReviewerHub reviewerHub,
                            VolunteerDao volunteerDao) {
        super(objectMapper);
        this.editorialManager = editorialManager;
        this.reviewerHub = reviewerHub;
        this.volunteerDao = volunteerDao;
    }

    @SuppressWarnings("squid:S3776")
    @Override
    public ResponseEntity<Void> updateReviewers(String xScope,
                                                String emJournalAcronym,
                                                Long documentId,
                                                ReviewersRequest body) {
        log.info("Update Reviewers request for journal {} document {} with reviewers {}", emJournalAcronym, documentId, body);

        if (SessionContext.isReadOnly()) {
            log.warn("Update Reviewers request for journal {} document {} rejected on readonly session with reviewers {}",
                    emJournalAcronym, documentId, body);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        if (emJournalAcronym == null || emJournalAcronym.isBlank() || documentId == null ||
                body == null || body.getReviewers() == null || body.getReviewers().isEmpty()) {
            final Map<String, String> args = Map.of("emJournalAcronym", String.valueOf(emJournalAcronym),
                    "documentId", String.valueOf(documentId),
                    "body", String.valueOf(body));
            log.error("Invalid request for update reviewers, mandatory parameters not set {}", args);
            throw new InternalException(ErrorResponse.IdEnum.INVALIDARGUMENT, HttpStatus.BAD_REQUEST, args);
        }

        List<Reviewer> reviewers = new ArrayList<>();
        for (ReviewersRequestItem reviewerItem : body.getReviewers()) {
            Reviewer reviewer = new Reviewer();
            reviewer.setJournalCode(emJournalAcronym);
            reviewer.setGivenName(reviewerItem.getFirstName());
            reviewer.setFamilyName(reviewerItem.getLastName());
            if (reviewerItem.getAffiliation() != null && !reviewerItem.getAffiliation().isEmpty()) {
                reviewer.addAffiliation(reviewerItem.getAffiliation());
            }
            if (reviewerItem.getKeywords() != null) {
                // There can be a lot of keywords, so we limit the number we send to EM
                reviewer.setKeywords(reviewerItem.getKeywords().stream().limit(10).collect(Collectors.toList()));
            }
            reviewer.setEmailAddresses(reviewerItem.getEmails());
            if (reviewerItem.getScopusIds() != null && !reviewerItem.getScopusIds().isEmpty()) {
                reviewerItem.getScopusIds().forEach(reviewer::addScopusIdentifier);
            }
            reviewer.setStatus(ReviewerStatusType.fromInterface(reviewerItem.getStatus()));
            reviewers.add(reviewer);
        }

        editorialManager.updateReviewers(emJournalAcronym, documentId, reviewers);

        return ResponseEntity.ok().build();
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class, readOnly = true)
    public ResponseEntity<Void> deleteReviewers(String emJournalAcronym, Long documentId, List<String> emails, String xScope) {
        if (emJournalAcronym == null || emJournalAcronym.isBlank() || documentId == null || emails == null || emails.isEmpty()) {
            final Map<String, String> args = Map.of("emJournalAcronym", String.valueOf(emJournalAcronym),
                    "documentId", String.valueOf(documentId),
                    "emails", String.valueOf(emails));
            log.error("Invalid request for delete reviewers, mandatory parameters not set {}", args);
            throw new InternalException(ErrorResponse.IdEnum.INVALIDARGUMENT, HttpStatus.BAD_REQUEST, args);
        }

        final List<String> lowerEmails = emails.stream().map(String::toLowerCase).collect(Collectors.toList());

        // The only option for a reject is a crowd sourced reviewer
        List<Long> ids = volunteerDao.getCrowdsourcedReviewerIds(emJournalAcronym, documentId, lowerEmails);

        log.info("Delete Reviewers request for journal {} document {} with emails {} found {} crowd sourced reviewers",
                emJournalAcronym, documentId, emails, ids);

        for (Long id : new LinkedHashSet<>(ids)) {
            reviewerHub.deleteCrowdsourcedReviewer(id);
        }

        return ResponseEntity.ok().build();
    }
}
