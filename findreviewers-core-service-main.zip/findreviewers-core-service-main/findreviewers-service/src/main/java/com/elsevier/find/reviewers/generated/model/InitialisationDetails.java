package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.ClassificationDetails;
import com.elsevier.find.reviewers.generated.model.ClassificationTree;
import com.elsevier.find.reviewers.generated.model.InitialisationDetailsCrowdsourcedReviewers;
import com.elsevier.find.reviewers.generated.model.PersonBase;
import com.elsevier.find.reviewers.generated.model.ReviewerDetails;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * The details for a initialisation details
 */
@Schema(description = "The details for a initialisation details")
@Validated



public class InitialisationDetails   {
  @JsonProperty("isElsevier")
  private Boolean isElsevier = true;

  /**
   * Gets or Sets permittedFeatures
   */
  public enum PermittedFeaturesEnum {
    RECOMMENDATIONS("recommendations"),
    
    KEYWORDSEARCH("keywordSearch"),
    
    CANDIDATESEARCH("candidateSearch"),
    
    AUTHORSEARCH("authorSearch"),
    
    REFERENCEDAUTHORS("referencedAuthors"),
    
    VOLUNTEERS("volunteers"),
    
    JOURNALREVIEWERS("journalReviewers"),
    
    EDITORIALBOARDMEMBERS("editorialBoardMembers"),
    
    ADDEDREVIEWERS("addedReviewers"),
    
    MANUSCRIPTDETAILS("manuscriptDetails"),
    
    REVIEWERHISTORY("reviewerHistory"),
    
    REVIEWERLIMITS("reviewerLimits"),
    
    SESSIONPREFERENCES("sessionPreferences");

    private String value;

    PermittedFeaturesEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static PermittedFeaturesEnum fromValue(String text) {
      for (PermittedFeaturesEnum b : PermittedFeaturesEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("permittedFeatures")
  @Valid
  private List<PermittedFeaturesEnum> permittedFeatures = null;

  @JsonProperty("journalIssnl")
  private String journalIssnl = null;

  @JsonProperty("journalClassifications")
  @Valid
  private List<ClassificationTree> journalClassifications = null;

  @JsonProperty("keywords")
  @Valid
  private List<String> keywords = null;

  @JsonProperty("classifications")
  @Valid
  private List<ClassificationDetails> classifications = null;

  @JsonProperty("reviewers")
  @Valid
  private List<ReviewerDetails> reviewers = null;

  @JsonProperty("correspondingAuthors")
  @Valid
  private List<PersonBase> correspondingAuthors = null;

  @JsonProperty("coAuthors")
  @Valid
  private List<PersonBase> coAuthors = null;

  @JsonProperty("opposedReviewers")
  @Valid
  private List<PersonBase> opposedReviewers = null;

  @JsonProperty("suggestedReviewers")
  @Valid
  private List<PersonBase> suggestedReviewers = null;

  @JsonProperty("crowdsourcedReviewers")
  @Valid
  private List<InitialisationDetailsCrowdsourcedReviewers> crowdsourcedReviewers = null;

  public InitialisationDetails isElsevier(Boolean isElsevier) {
    this.isElsevier = isElsevier;
    return this;
  }

  /**
   * If the session is based on an Elsevier environment
   * @return isElsevier
   **/
  @Schema(required = true, description = "If the session is based on an Elsevier environment")
      @NotNull

    public Boolean isIsElsevier() {
    return isElsevier;
  }

  public void setIsElsevier(Boolean isElsevier) {
    this.isElsevier = isElsevier;
  }

  public InitialisationDetails permittedFeatures(List<PermittedFeaturesEnum> permittedFeatures) {
    this.permittedFeatures = permittedFeatures;
    return this;
  }

  public InitialisationDetails addPermittedFeaturesItem(PermittedFeaturesEnum permittedFeaturesItem) {
    if (this.permittedFeatures == null) {
      this.permittedFeatures = new ArrayList<>();
    }
    this.permittedFeatures.add(permittedFeaturesItem);
    return this;
  }

  /**
   * The features for this manuscript should be restricted to include only the listed ones
   * @return permittedFeatures
   **/
  @Schema(example = "[\"keywordSearch\",\"authorSearch\",\"addedReviewers\",\"manuscriptDetails\"]", description = "The features for this manuscript should be restricted to include only the listed ones")
  
    public List<PermittedFeaturesEnum> getPermittedFeatures() {
    return permittedFeatures;
  }

  public void setPermittedFeatures(List<PermittedFeaturesEnum> permittedFeatures) {
    this.permittedFeatures = permittedFeatures;
  }

  public InitialisationDetails journalIssnl(String journalIssnl) {
    this.journalIssnl = journalIssnl;
    return this;
  }

  /**
   * The ISSN-L of the Journal
   * @return journalIssnl
   **/
  @Schema(example = "0736-5748", description = "The ISSN-L of the Journal")
  
    public String getJournalIssnl() {
    return journalIssnl;
  }

  public void setJournalIssnl(String journalIssnl) {
    this.journalIssnl = journalIssnl;
  }

  public InitialisationDetails journalClassifications(List<ClassificationTree> journalClassifications) {
    this.journalClassifications = journalClassifications;
    return this;
  }

  public InitialisationDetails addJournalClassificationsItem(ClassificationTree journalClassificationsItem) {
    if (this.journalClassifications == null) {
      this.journalClassifications = new ArrayList<>();
    }
    this.journalClassifications.add(journalClassificationsItem);
    return this;
  }

  /**
   * The list of classifications for the journal
   * @return journalClassifications
   **/
  @Schema(description = "The list of classifications for the journal")
      @Valid
    public List<ClassificationTree> getJournalClassifications() {
    return journalClassifications;
  }

  public void setJournalClassifications(List<ClassificationTree> journalClassifications) {
    this.journalClassifications = journalClassifications;
  }

  public InitialisationDetails keywords(List<String> keywords) {
    this.keywords = keywords;
    return this;
  }

  public InitialisationDetails addKeywordsItem(String keywordsItem) {
    if (this.keywords == null) {
      this.keywords = new ArrayList<>();
    }
    this.keywords.add(keywordsItem);
    return this;
  }

  /**
   * Keywords for the manuscript entered by the author
   * @return keywords
   **/
  @Schema(description = "Keywords for the manuscript entered by the author")
  
    public List<String> getKeywords() {
    return keywords;
  }

  public void setKeywords(List<String> keywords) {
    this.keywords = keywords;
  }

  public InitialisationDetails classifications(List<ClassificationDetails> classifications) {
    this.classifications = classifications;
    return this;
  }

  public InitialisationDetails addClassificationsItem(ClassificationDetails classificationsItem) {
    if (this.classifications == null) {
      this.classifications = new ArrayList<>();
    }
    this.classifications.add(classificationsItem);
    return this;
  }

  /**
   * Manuscript classifications selected by the author
   * @return classifications
   **/
  @Schema(description = "Manuscript classifications selected by the author")
      @Valid
    public List<ClassificationDetails> getClassifications() {
    return classifications;
  }

  public void setClassifications(List<ClassificationDetails> classifications) {
    this.classifications = classifications;
  }

  public InitialisationDetails reviewers(List<ReviewerDetails> reviewers) {
    this.reviewers = reviewers;
    return this;
  }

  public InitialisationDetails addReviewersItem(ReviewerDetails reviewersItem) {
    if (this.reviewers == null) {
      this.reviewers = new ArrayList<>();
    }
    this.reviewers.add(reviewersItem);
    return this;
  }

  /**
   * Get reviewers
   * @return reviewers
   **/
  @Schema(description = "")
      @Valid
    public List<ReviewerDetails> getReviewers() {
    return reviewers;
  }

  public void setReviewers(List<ReviewerDetails> reviewers) {
    this.reviewers = reviewers;
  }

  public InitialisationDetails correspondingAuthors(List<PersonBase> correspondingAuthors) {
    this.correspondingAuthors = correspondingAuthors;
    return this;
  }

  public InitialisationDetails addCorrespondingAuthorsItem(PersonBase correspondingAuthorsItem) {
    if (this.correspondingAuthors == null) {
      this.correspondingAuthors = new ArrayList<>();
    }
    this.correspondingAuthors.add(correspondingAuthorsItem);
    return this;
  }

  /**
   * Get correspondingAuthors
   * @return correspondingAuthors
   **/
  @Schema(description = "")
      @Valid
    public List<PersonBase> getCorrespondingAuthors() {
    return correspondingAuthors;
  }

  public void setCorrespondingAuthors(List<PersonBase> correspondingAuthors) {
    this.correspondingAuthors = correspondingAuthors;
  }

  public InitialisationDetails coAuthors(List<PersonBase> coAuthors) {
    this.coAuthors = coAuthors;
    return this;
  }

  public InitialisationDetails addCoAuthorsItem(PersonBase coAuthorsItem) {
    if (this.coAuthors == null) {
      this.coAuthors = new ArrayList<>();
    }
    this.coAuthors.add(coAuthorsItem);
    return this;
  }

  /**
   * Get coAuthors
   * @return coAuthors
   **/
  @Schema(description = "")
      @Valid
    public List<PersonBase> getCoAuthors() {
    return coAuthors;
  }

  public void setCoAuthors(List<PersonBase> coAuthors) {
    this.coAuthors = coAuthors;
  }

  public InitialisationDetails opposedReviewers(List<PersonBase> opposedReviewers) {
    this.opposedReviewers = opposedReviewers;
    return this;
  }

  public InitialisationDetails addOpposedReviewersItem(PersonBase opposedReviewersItem) {
    if (this.opposedReviewers == null) {
      this.opposedReviewers = new ArrayList<>();
    }
    this.opposedReviewers.add(opposedReviewersItem);
    return this;
  }

  /**
   * Get opposedReviewers
   * @return opposedReviewers
   **/
  @Schema(description = "")
      @Valid
    public List<PersonBase> getOpposedReviewers() {
    return opposedReviewers;
  }

  public void setOpposedReviewers(List<PersonBase> opposedReviewers) {
    this.opposedReviewers = opposedReviewers;
  }

  public InitialisationDetails suggestedReviewers(List<PersonBase> suggestedReviewers) {
    this.suggestedReviewers = suggestedReviewers;
    return this;
  }

  public InitialisationDetails addSuggestedReviewersItem(PersonBase suggestedReviewersItem) {
    if (this.suggestedReviewers == null) {
      this.suggestedReviewers = new ArrayList<>();
    }
    this.suggestedReviewers.add(suggestedReviewersItem);
    return this;
  }

  /**
   * Get suggestedReviewers
   * @return suggestedReviewers
   **/
  @Schema(description = "")
      @Valid
    public List<PersonBase> getSuggestedReviewers() {
    return suggestedReviewers;
  }

  public void setSuggestedReviewers(List<PersonBase> suggestedReviewers) {
    this.suggestedReviewers = suggestedReviewers;
  }

  public InitialisationDetails crowdsourcedReviewers(List<InitialisationDetailsCrowdsourcedReviewers> crowdsourcedReviewers) {
    this.crowdsourcedReviewers = crowdsourcedReviewers;
    return this;
  }

  public InitialisationDetails addCrowdsourcedReviewersItem(InitialisationDetailsCrowdsourcedReviewers crowdsourcedReviewersItem) {
    if (this.crowdsourcedReviewers == null) {
      this.crowdsourcedReviewers = new ArrayList<>();
    }
    this.crowdsourcedReviewers.add(crowdsourcedReviewersItem);
    return this;
  }

  /**
   * Get crowdsourcedReviewers
   * @return crowdsourcedReviewers
   **/
  @Schema(description = "")
      @Valid
    public List<InitialisationDetailsCrowdsourcedReviewers> getCrowdsourcedReviewers() {
    return crowdsourcedReviewers;
  }

  public void setCrowdsourcedReviewers(List<InitialisationDetailsCrowdsourcedReviewers> crowdsourcedReviewers) {
    this.crowdsourcedReviewers = crowdsourcedReviewers;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    InitialisationDetails initialisationDetails = (InitialisationDetails) o;
    return Objects.equals(this.isElsevier, initialisationDetails.isElsevier) &&
        Objects.equals(this.permittedFeatures, initialisationDetails.permittedFeatures) &&
        Objects.equals(this.journalIssnl, initialisationDetails.journalIssnl) &&
        Objects.equals(this.journalClassifications, initialisationDetails.journalClassifications) &&
        Objects.equals(this.keywords, initialisationDetails.keywords) &&
        Objects.equals(this.classifications, initialisationDetails.classifications) &&
        Objects.equals(this.reviewers, initialisationDetails.reviewers) &&
        Objects.equals(this.correspondingAuthors, initialisationDetails.correspondingAuthors) &&
        Objects.equals(this.coAuthors, initialisationDetails.coAuthors) &&
        Objects.equals(this.opposedReviewers, initialisationDetails.opposedReviewers) &&
        Objects.equals(this.suggestedReviewers, initialisationDetails.suggestedReviewers) &&
        Objects.equals(this.crowdsourcedReviewers, initialisationDetails.crowdsourcedReviewers);
  }

  @Override
  public int hashCode() {
    return Objects.hash(isElsevier, permittedFeatures, journalIssnl, journalClassifications, keywords, classifications, reviewers, correspondingAuthors, coAuthors, opposedReviewers, suggestedReviewers, crowdsourcedReviewers);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class InitialisationDetails {\n");
    
    sb.append("    isElsevier: ").append(toIndentedString(isElsevier)).append("\n");
    sb.append("    permittedFeatures: ").append(toIndentedString(permittedFeatures)).append("\n");
    sb.append("    journalIssnl: ").append(toIndentedString(journalIssnl)).append("\n");
    sb.append("    journalClassifications: ").append(toIndentedString(journalClassifications)).append("\n");
    sb.append("    keywords: ").append(toIndentedString(keywords)).append("\n");
    sb.append("    classifications: ").append(toIndentedString(classifications)).append("\n");
    sb.append("    reviewers: ").append(toIndentedString(reviewers)).append("\n");
    sb.append("    correspondingAuthors: ").append(toIndentedString(correspondingAuthors)).append("\n");
    sb.append("    coAuthors: ").append(toIndentedString(coAuthors)).append("\n");
    sb.append("    opposedReviewers: ").append(toIndentedString(opposedReviewers)).append("\n");
    sb.append("    suggestedReviewers: ").append(toIndentedString(suggestedReviewers)).append("\n");
    sb.append("    crowdsourcedReviewers: ").append(toIndentedString(crowdsourcedReviewers)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
