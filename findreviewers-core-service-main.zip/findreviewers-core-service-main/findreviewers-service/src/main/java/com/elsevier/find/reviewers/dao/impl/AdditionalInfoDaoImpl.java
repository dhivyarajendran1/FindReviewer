package com.elsevier.find.reviewers.dao.impl;

import com.elsevier.find.reviewers.dao.AdditionalInfoDao;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Implementation for the data access for additional information
 */
// Suppress SonarQube 'String literals should not be duplicated' flagged against the inline sql
@SuppressWarnings("squid:S1192")
@Slf4j
@Repository
public class AdditionalInfoDaoImpl extends BaseDaoImpl implements AdditionalInfoDao {
    public AdditionalInfoDaoImpl(NamedParameterJdbcTemplate dbSource, ObjectMapper objectMapper,
                                 @Value("${findreviewers.cloud.ursdb:false}") String cloudUrsdbEnabled) {
        super(dbSource, objectMapper, cloudUrsdbEnabled);
    }

    /**
     * The Row mapper will convert the SQL returned to the object format
     */
    public class AdditionalInfoResultsExtractor extends BaseRowMapper implements ResultSetExtractor<Map<String, AdditionalInfo>> {
        @SuppressWarnings("squid:S3776")
        @Override
        public Map<String, AdditionalInfo> extractData(ResultSet rs) throws SQLException {
            Map<String, AdditionalInfo> infoByUser = new HashMap<>();

            while (rs.next()) {
                final String email = getOptionalString(rs, "email");

                // Check for the user being in the inoperative email table because we know the email is no longer
                // valid and results for that user should be removed
                if (rs.getBoolean("is_inoperative")) {
                    infoByUser.put(email, new AdditionalInfo(false));
                    continue;
                }

                AdditionalInfo additionalInfo = new AdditionalInfo(true);
                additionalInfo.setUnavailable(isUnavailable(rs.getString("unavailability")));
                additionalInfo.setConcurrentReviewLimit(rs.getInt("concurrent_review_limit"));
                additionalInfo.setVolunteer(rs.getBoolean("volunteer"));
                additionalInfo.setEBM(rs.getBoolean("is_ebm"));
                additionalInfo.setEditorialHistoryCount(rs.getInt("editorial_history_count"));
                additionalInfo.setRecentAuthorThisJournal(rs.getBoolean("this_recently_accepted_author"));
                additionalInfo.setRecentAuthorOtherJournal(rs.getBoolean("other_recently_accepted_author"));
                additionalInfo.setForbiddenReviewer(rs.getBoolean("is_forbidden"));

                infoByUser.put(email, additionalInfo);
            }

            return infoByUser;
        }
    }

    public class InoperativeEmailResultsExtractor extends BaseRowMapper implements ResultSetExtractor<Map<String, AdditionalInfo>> {
        @Override
        public Map<String, AdditionalInfo> extractData(ResultSet rs) throws SQLException {
            Map<String, AdditionalInfo> infoByUser = new HashMap<>();

            while (rs.next()) {
                infoByUser.put(getOptionalString(rs, "email"), new AdditionalInfo(false));
            }

            return infoByUser;
        }
    }

    public class InitialisationInfoResultsExtractor extends BaseRowMapper implements ResultSetExtractor<InitialisationInfo> {
        @SuppressWarnings("squid:S3776")
        @Override
        public InitialisationInfo extractData(ResultSet rs) throws SQLException {
            InitialisationInfo info = new InitialisationInfo();

            if (rs.next()) {
                info.setIssnL(rs.getString("issn_l"));
                info.setHasEBMs(rs.getBoolean("has_ebms"));

                String classificationsJson = getOptionalString(rs, "classifications");
                if (classificationsJson != null) {
                    try {
                        info.setClassifications(objectMapper.readValue(classificationsJson, new TypeReference<>() {
                        }));
                    } catch (JsonProcessingException e) {
                        log.error("Failed to load classifications from database for issn {}, error {}", info.getIssnL(),
                                e.getMessage());
                    }
                }

                String crowdsourcedJson = rs.getString("crowdsourced_reviewers");
                if (crowdsourcedJson != null) {
                    try {
                        info.setCrowdsourcedReviewers(objectMapper.readValue(crowdsourcedJson, new TypeReference<>() {
                        }));
                    } catch (JsonProcessingException e) {
                        log.error("Failed to load Crowdsourced reviewers from database for {}, error {}",
                                crowdsourcedJson, e.getMessage());
                    }
                }
            }

            return info;
        }
    }

    @Override
    public Map<String, AdditionalInfo> getAdditionalInfoByEmail(String emJournalAcronym, List<String> emails) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("emJournalAcronym", emJournalAcronym != null ? emJournalAcronym.toUpperCase() : null);
        params.addValue("emails", emails);

        // For the Union: Get all the emails that have any data so that we can collect the information
        // together easily by left joining to the data in the earlier selects
        String sql = """
                with inoperative as (
                  select email, true::bool as is_inoperative
                  from find_reviewers.inoperative_email where email in (:emails)
                ),
                forbidden_reviewer as (
                  select a."Email__lower" as email, true::bool as is_forbidden
                  from rr_ursdb."PEOPLE" p
                  inner join rr_ursdb."ADDRESS_EMAIL" a on p."JOURNAL_ID" = a."JOURNAL_ID" and p."PEOPLEID" = a."PeopleID"
                  inner join rr_ursdb."JOURNAL_INFO" j on j."JOURNAL_ID" = p."JOURNAL_ID"
                  where j."JOURNAL__upper" = :emJournalAcronym and p."FORBIDREVIEW" is true and
                  a."Email__lower" in (:emails) and a."Email__lower" not in (select email from inoperative)
                ),
                preferences as (
                  select a.email, a.unavailability->'unavailability' as unavailability,
                  a.concurrent_review_limit as concurrent_review_limit
                  from find_reviewers.rh_reviewer_preferences a
                  where a.email in (:emails) and a.email not in (select email from inoperative)
                ),
                volunteers as (
                  select v.email, true::bool as volunteer
                  from find_reviewers.rh_review_volunteer v
                  inner join rr_ursdb."JOURNAL_INFO" j on j.pts_code = v.journal_acronym
                  where j."JOURNAL__upper" = :emJournalAcronym and v.email in (:emails)
                  and v.email not in (select email from inoperative)
                ),
                editor_history as (
                  select e.email, count(*) as editorial_history_count,
                  case when count(ebm.journal_acronym) > 0 then true else false end as is_ebm
                  from find_reviewers.rh_editor e
                  inner join rr_ursdb."JOURNAL_INFO" i on i.pts_code = e.journal_acronym
                  left join find_reviewers.rh_editor ebm on ebm.editor_id = e.editor_id
                    and ebm.editor_journal_id = e.editor_journal_id
                    and ebm.classification = 'editorialBoardMember'
                    and i."JOURNAL__upper" = :emJournalAcronym
                    and (ebm.stop_date is null or ebm.stop_date > (extract(EPOCH from CURRENT_TIMESTAMP) * 1000))
                  where e.email in (:emails) and e.email not in (select email from inoperative)
                  group by e.email
                ),
                recently_accepted as (
                  select email, em_journal_acronym, true::bool as recently_accepted_author
                  from find_reviewers.recently_accepted_authors
                  where email in (:emails) and email not in (select email from inoperative)
                ),
                emails_with_data as (
                  select email from inoperative
                  union
                  select email from forbidden_reviewer
                  union
                  select email from preferences
                  union
                  select email from volunteers
                  union
                  select email from editor_history
                  union
                  select email from recently_accepted
                )
                select e.email as email,
                i.is_inoperative as is_inoperative,
                a.unavailability as unavailability,
                a.concurrent_review_limit as concurrent_review_limit,
                v.volunteer as volunteer,
                h.editorial_history_count as editorial_history_count,
                h.is_ebm as is_ebm,
                rt.recently_accepted_author as this_recently_accepted_author,
                ro.recently_accepted_author as other_recently_accepted_author,
                f.is_forbidden as is_forbidden
                from emails_with_data e
                left join inoperative i on i.email = e.email
                left join preferences a on a.email = e.email
                left join volunteers v on v.email = e.email
                left join editor_history h on h.email = e.email
                left join recently_accepted rt on rt.email = e.email and rt.em_journal_acronym = :emJournalAcronym
                left join recently_accepted ro on ro.email = e.email and ro.em_journal_acronym != :emJournalAcronym
                left join forbidden_reviewer f on f.email = e.email
                """;

        if (isCloudUrsdb) {
            sql = """
                    with inoperative as (
                      select email, true::bool as is_inoperative
                      from find_reviewers.inoperative_email where email in (:emails)
                    ),
                    forbidden_reviewer as (
                      select a.email__lower as email, true::bool as is_forbidden
                      from fr_ursdb.people p
                      inner join fr_ursdb.address_email a on p.journal_id = a.journal_id and p.peopleid = a.peopleid
                      inner join fr_ursdb.journal_info j on j.journal_id = p.journal_id
                      where j.journal__upper = :emJournalAcronym and p.forbidreview is true and
                      a.email__lower in (:emails) and a.email__lower not in (select email from inoperative)
                    ),
                    preferences as (
                      select a.email, a.unavailability->'unavailability' as unavailability,
                      a.concurrent_review_limit as concurrent_review_limit
                      from find_reviewers.rh_reviewer_preferences a
                      where a.email in (:emails) and a.email not in (select email from inoperative)
                    ),
                    volunteers as (
                      select v.email, true::bool as volunteer
                      from find_reviewers.rh_review_volunteer v
                      inner join fr_ursdb.journal_info j on j.pts_code = v.journal_acronym
                      where j.journal__upper = :emJournalAcronym and v.email in (:emails)
                      and v.email not in (select email from inoperative)
                    ),
                    editor_history as (
                      select e.email, count(*) as editorial_history_count,
                      case when count(ebm.journal_acronym) > 0 then true else false end as is_ebm
                      from find_reviewers.rh_editor e
                      inner join fr_ursdb.journal_info i on i.pts_code = e.journal_acronym
                      left join find_reviewers.rh_editor ebm on ebm.editor_id = e.editor_id
                        and ebm.editor_journal_id = e.editor_journal_id
                        and ebm.classification = 'editorialBoardMember'
                        and i.journal__upper = :emJournalAcronym
                        and (ebm.stop_date is null or ebm.stop_date > (extract(EPOCH from CURRENT_TIMESTAMP) * 1000))
                      where e.email in (:emails) and e.email not in (select email from inoperative)
                      group by e.email
                    ),
                    recently_accepted as (
                      select email, em_journal_acronym, true::bool as recently_accepted_author
                      from find_reviewers.recently_accepted_authors
                      where email in (:emails) and email not in (select email from inoperative)
                    ),
                    emails_with_data as (
                      select email from inoperative
                      union
                      select email from forbidden_reviewer
                      union
                      select email from preferences
                      union
                      select email from volunteers
                      union
                      select email from editor_history
                      union
                      select email from recently_accepted
                    )
                    select e.email as email,
                    i.is_inoperative as is_inoperative,
                    a.unavailability as unavailability,
                    a.concurrent_review_limit as concurrent_review_limit,
                    v.volunteer as volunteer,
                    h.editorial_history_count as editorial_history_count,
                    h.is_ebm as is_ebm,
                    rt.recently_accepted_author as this_recently_accepted_author,
                    ro.recently_accepted_author as other_recently_accepted_author,
                    f.is_forbidden as is_forbidden
                    from emails_with_data e
                    left join inoperative i on i.email = e.email
                    left join preferences a on a.email = e.email
                    left join volunteers v on v.email = e.email
                    left join editor_history h on h.email = e.email
                    left join recently_accepted rt on rt.email = e.email and rt.em_journal_acronym = :emJournalAcronym
                    left join recently_accepted ro on ro.email = e.email and ro.em_journal_acronym != :emJournalAcronym
                    left join forbidden_reviewer f on f.email = e.email
                    """;
        }

        return dbSource.query(sql, params, new AdditionalInfoResultsExtractor());
    }

    @Override
    public Map<String, AdditionalInfo> getInoperativeByEmail(List<String> emails) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("emails", emails);

        final String sql = "select email from find_reviewers.inoperative_email where email in (:emails)";

        return dbSource.query(sql, params, new InoperativeEmailResultsExtractor());
    }

    @Override
    public InitialisationInfo getInitialisationInfo(String emJournalAcronym, Long documentId) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("emJournalAcronym", emJournalAcronym.toUpperCase());
        params.addValue("documentId", documentId);
        params.addValue("classification", "editorialBoardMember");

        String sql = """
                with ebms as (
                  select exists(select 1 from find_reviewers.rh_editor e
                  inner join find_reviewers.rh_em_journal j on e.journal_acronym = j.journal_acronym
                  where j.em_journal_acronym = :emJournalAcronym and e.classification = :classification and
                  (e.stop_date is null or e.stop_date > (extract(EPOCH from CURRENT_TIMESTAMP) * 1000))) as ebms_exist
                ),
                crowdsourced as (
                  select json_build_object('email', c.email, 'scopusIds', c.scopus_ids->'scopus') as crowdsourced_review
                  from find_reviewers.rh_crowdsourced_manuscript_review c
                  inner join find_reviewers.rh_em_journal j on c.journal_acronym = j.journal_acronym
                  where j.em_journal_acronym = :emJournalAcronym and c.document_id = :documentId
                )
                select j.issn_l as issn_l, j.classifications->'classifications' as classifications,
                (select ebms_exist from ebms) as has_ebms,
                (select to_json(coalesce(array_agg(c.crowdsourced_review))) from crowdsourced c) as crowdsourced_reviewers
                from find_reviewers.rh_em_journal j
                where j.em_journal_acronym = :emJournalAcronym
                """;

        return dbSource.query(sql, params, new InitialisationInfoResultsExtractor());
    }

    @Override
    public InitialisationInfo getInitialisationInfo(String journalAcronym, String issn) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("journalAcronym", journalAcronym);
        params.addValue("issn", issn);
        params.addValue("classification", "editorialBoardMember");

        String sql = """
                with ebms as (
                  select exists(select 1 from find_reviewers.rh_editor e
                  where e.journal_acronym = :journalAcronym and e.classification = :classification and
                  (e.stop_date is null or e.stop_date > (extract(EPOCH from CURRENT_TIMESTAMP) * 1000))) as ebms_exist
                )
                select :issn as issn_l, null as classifications,
                (select ebms_exist from ebms) as has_ebms,
                null as crowdsourced_reviewers
                """;

        return dbSource.query(sql, params, new InitialisationInfoResultsExtractor());
    }
}
