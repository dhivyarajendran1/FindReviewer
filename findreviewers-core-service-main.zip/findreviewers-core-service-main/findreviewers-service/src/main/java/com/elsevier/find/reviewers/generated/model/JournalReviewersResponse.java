package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.ScopusSearchAuthor;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * The response for a list of reviewers
 */
@Schema(description = "The response for a list of reviewers")
@Validated



public class JournalReviewersResponse   {
  @JsonProperty("more")
  private Boolean more = null;

  @JsonProperty("reviewers")
  @Valid
  private List<ScopusSearchAuthor> reviewers = new ArrayList<>();

  public JournalReviewersResponse more(Boolean more) {
    this.more = more;
    return this;
  }

  /**
   * To support paging, specifies if there are more entries available after the last one returned
   * @return more
   **/
  @Schema(description = "To support paging, specifies if there are more entries available after the last one returned")
  
    public Boolean isMore() {
    return more;
  }

  public void setMore(Boolean more) {
    this.more = more;
  }

  public JournalReviewersResponse reviewers(List<ScopusSearchAuthor> reviewers) {
    this.reviewers = reviewers;
    return this;
  }

  public JournalReviewersResponse addReviewersItem(ScopusSearchAuthor reviewersItem) {
    this.reviewers.add(reviewersItem);
    return this;
  }

  /**
   * Get reviewers
   * @return reviewers
   **/
  @Schema(required = true, description = "")
      @NotNull
    @Valid
    public List<ScopusSearchAuthor> getReviewers() {
    return reviewers;
  }

  public void setReviewers(List<ScopusSearchAuthor> reviewers) {
    this.reviewers = reviewers;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    JournalReviewersResponse journalReviewersResponse = (JournalReviewersResponse) o;
    return Objects.equals(this.more, journalReviewersResponse.more) &&
        Objects.equals(this.reviewers, journalReviewersResponse.reviewers);
  }

  @Override
  public int hashCode() {
    return Objects.hash(more, reviewers);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class JournalReviewersResponse {\n");
    
    sb.append("    more: ").append(toIndentedString(more)).append("\n");
    sb.append("    reviewers: ").append(toIndentedString(reviewers)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
