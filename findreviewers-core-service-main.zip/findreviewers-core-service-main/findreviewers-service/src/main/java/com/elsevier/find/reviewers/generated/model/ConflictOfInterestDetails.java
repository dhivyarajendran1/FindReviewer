package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.Indicators;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * Details about a users conflict of interest
 */
@Schema(description = "Details about a users conflict of interest")
@Validated



public class ConflictOfInterestDetails   {
  @JsonProperty("scopusId")
  private String scopusId = null;

  @JsonProperty("indicators")
  @Valid
  private List<Indicators> indicators = null;

  public ConflictOfInterestDetails scopusId(String scopusId) {
    this.scopusId = scopusId;
    return this;
  }

  /**
   * Scopus Id
   * @return scopusId
   **/
  @Schema(example = "56909569200", required = true, description = "Scopus Id")
      @NotNull

    public String getScopusId() {
    return scopusId;
  }

  public void setScopusId(String scopusId) {
    this.scopusId = scopusId;
  }

  public ConflictOfInterestDetails indicators(List<Indicators> indicators) {
    this.indicators = indicators;
    return this;
  }

  public ConflictOfInterestDetails addIndicatorsItem(Indicators indicatorsItem) {
    if (this.indicators == null) {
      this.indicators = new ArrayList<>();
    }
    this.indicators.add(indicatorsItem);
    return this;
  }

  /**
   * List of indicators for the user to detail possible relationships or roles
   * @return indicators
   **/
  @Schema(description = "List of indicators for the user to detail possible relationships or roles")
      @Valid
    public List<Indicators> getIndicators() {
    return indicators;
  }

  public void setIndicators(List<Indicators> indicators) {
    this.indicators = indicators;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ConflictOfInterestDetails conflictOfInterestDetails = (ConflictOfInterestDetails) o;
    return Objects.equals(this.scopusId, conflictOfInterestDetails.scopusId) &&
        Objects.equals(this.indicators, conflictOfInterestDetails.indicators);
  }

  @Override
  public int hashCode() {
    return Objects.hash(scopusId, indicators);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ConflictOfInterestDetails {\n");
    
    sb.append("    scopusId: ").append(toIndentedString(scopusId)).append("\n");
    sb.append("    indicators: ").append(toIndentedString(indicators)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
