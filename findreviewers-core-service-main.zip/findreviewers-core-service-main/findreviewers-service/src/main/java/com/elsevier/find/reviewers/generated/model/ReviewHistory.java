package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * Statistics for given journal
 */
@Schema(description = "Statistics for given journal")
@Validated



public class ReviewHistory   {
  @JsonProperty("emJournalAcronym")
  private String emJournalAcronym = null;

  @JsonProperty("documentId")
  private Long documentId = null;

  @JsonProperty("revision")
  private Integer revision = null;

  @JsonProperty("startDate")
  private Long startDate = null;

  @JsonProperty("stopDate")
  private Long stopDate = null;

  @JsonProperty("acceptDate")
  private Long acceptDate = null;

  @JsonProperty("dueDate")
  private Long dueDate = null;

  /**
   * The state of a given review
   */
  public enum StateEnum {
    WORKINPROGRESS("WorkInProgress"),
    
    HASNOTRESPONDED("HasNotResponded"),
    
    DECLINED("Declined"),
    
    TERMINATED("Terminated"),
    
    COMPLETED("Completed"),
    
    ALTERNATE("Alternate"),
    
    PROMOTED("Promoted"),
    
    UNINVITED("Uninvited"),
    
    ASSIGNEDNOTINVITED("AssignedNotInvited");

    private String value;

    StateEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static StateEnum fromValue(String text) {
      for (StateEnum b : StateEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("state")
  private StateEnum state = null;

  @JsonProperty("reviewerDecision")
  private String reviewerDecision = null;

  @JsonProperty("editorDecision")
  private String editorDecision = null;

  public ReviewHistory emJournalAcronym(String emJournalAcronym) {
    this.emJournalAcronym = emJournalAcronym;
    return this;
  }

  /**
   * Journal reviewed for EM acronym
   * @return emJournalAcronym
   **/
  @Schema(example = "ACR", required = true, description = "Journal reviewed for EM acronym")
      @NotNull

    public String getEmJournalAcronym() {
    return emJournalAcronym;
  }

  public void setEmJournalAcronym(String emJournalAcronym) {
    this.emJournalAcronym = emJournalAcronym;
  }

  public ReviewHistory documentId(Long documentId) {
    this.documentId = documentId;
    return this;
  }

  /**
   * The manuscripts document Id
   * @return documentId
   **/
  @Schema(example = "10", required = true, description = "The manuscripts document Id")
      @NotNull

    public Long getDocumentId() {
    return documentId;
  }

  public void setDocumentId(Long documentId) {
    this.documentId = documentId;
  }

  public ReviewHistory revision(Integer revision) {
    this.revision = revision;
    return this;
  }

  /**
   * The manuscripts revision
   * @return revision
   **/
  @Schema(example = "0", required = true, description = "The manuscripts revision")
      @NotNull

    public Integer getRevision() {
    return revision;
  }

  public void setRevision(Integer revision) {
    this.revision = revision;
  }

  public ReviewHistory startDate(Long startDate) {
    this.startDate = startDate;
    return this;
  }

  /**
   * The date the review was started (EPOCH - milliseconds)
   * minimum: 0
   * @return startDate
   **/
  @Schema(example = "1579866980000", description = "The date the review was started (EPOCH - milliseconds)")
  
  @Min(0L)  public Long getStartDate() {
    return startDate;
  }

  public void setStartDate(Long startDate) {
    this.startDate = startDate;
  }

  public ReviewHistory stopDate(Long stopDate) {
    this.stopDate = stopDate;
    return this;
  }

  /**
   * The date the review was stopped (EPOCH - milliseconds)
   * minimum: 0
   * @return stopDate
   **/
  @Schema(example = "1579867000000", description = "The date the review was stopped (EPOCH - milliseconds)")
  
  @Min(0L)  public Long getStopDate() {
    return stopDate;
  }

  public void setStopDate(Long stopDate) {
    this.stopDate = stopDate;
  }

  public ReviewHistory acceptDate(Long acceptDate) {
    this.acceptDate = acceptDate;
    return this;
  }

  /**
   * The date the review was accepted (EPOCH - milliseconds)
   * minimum: 0
   * @return acceptDate
   **/
  @Schema(example = "1579866990000", description = "The date the review was accepted (EPOCH - milliseconds)")
  
  @Min(0L)  public Long getAcceptDate() {
    return acceptDate;
  }

  public void setAcceptDate(Long acceptDate) {
    this.acceptDate = acceptDate;
  }

  public ReviewHistory dueDate(Long dueDate) {
    this.dueDate = dueDate;
    return this;
  }

  /**
   * The date the review was due (EPOCH - milliseconds)
   * minimum: 0
   * @return dueDate
   **/
  @Schema(example = "1579867980000", description = "The date the review was due (EPOCH - milliseconds)")
  
  @Min(0L)  public Long getDueDate() {
    return dueDate;
  }

  public void setDueDate(Long dueDate) {
    this.dueDate = dueDate;
  }

  public ReviewHistory state(StateEnum state) {
    this.state = state;
    return this;
  }

  /**
   * The state of a given review
   * @return state
   **/
  @Schema(example = "Completed", description = "The state of a given review")
  
    public StateEnum getState() {
    return state;
  }

  public void setState(StateEnum state) {
    this.state = state;
  }

  public ReviewHistory reviewerDecision(String reviewerDecision) {
    this.reviewerDecision = reviewerDecision;
    return this;
  }

  /**
   * The decision for the review entered by the reviewer
   * @return reviewerDecision
   **/
  @Schema(example = "Accept", description = "The decision for the review entered by the reviewer")
  
    public String getReviewerDecision() {
    return reviewerDecision;
  }

  public void setReviewerDecision(String reviewerDecision) {
    this.reviewerDecision = reviewerDecision;
  }

  public ReviewHistory editorDecision(String editorDecision) {
    this.editorDecision = editorDecision;
    return this;
  }

  /**
   * The final editor decision for the reviewed manuscript
   * @return editorDecision
   **/
  @Schema(example = "Reject and Transfer", description = "The final editor decision for the reviewed manuscript")
  
    public String getEditorDecision() {
    return editorDecision;
  }

  public void setEditorDecision(String editorDecision) {
    this.editorDecision = editorDecision;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ReviewHistory reviewHistory = (ReviewHistory) o;
    return Objects.equals(this.emJournalAcronym, reviewHistory.emJournalAcronym) &&
        Objects.equals(this.documentId, reviewHistory.documentId) &&
        Objects.equals(this.revision, reviewHistory.revision) &&
        Objects.equals(this.startDate, reviewHistory.startDate) &&
        Objects.equals(this.stopDate, reviewHistory.stopDate) &&
        Objects.equals(this.acceptDate, reviewHistory.acceptDate) &&
        Objects.equals(this.dueDate, reviewHistory.dueDate) &&
        Objects.equals(this.state, reviewHistory.state) &&
        Objects.equals(this.reviewerDecision, reviewHistory.reviewerDecision) &&
        Objects.equals(this.editorDecision, reviewHistory.editorDecision);
  }

  @Override
  public int hashCode() {
    return Objects.hash(emJournalAcronym, documentId, revision, startDate, stopDate, acceptDate, dueDate, state, reviewerDecision, editorDecision);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ReviewHistory {\n");
    
    sb.append("    emJournalAcronym: ").append(toIndentedString(emJournalAcronym)).append("\n");
    sb.append("    documentId: ").append(toIndentedString(documentId)).append("\n");
    sb.append("    revision: ").append(toIndentedString(revision)).append("\n");
    sb.append("    startDate: ").append(toIndentedString(startDate)).append("\n");
    sb.append("    stopDate: ").append(toIndentedString(stopDate)).append("\n");
    sb.append("    acceptDate: ").append(toIndentedString(acceptDate)).append("\n");
    sb.append("    dueDate: ").append(toIndentedString(dueDate)).append("\n");
    sb.append("    state: ").append(toIndentedString(state)).append("\n");
    sb.append("    reviewerDecision: ").append(toIndentedString(reviewerDecision)).append("\n");
    sb.append("    editorDecision: ").append(toIndentedString(editorDecision)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
