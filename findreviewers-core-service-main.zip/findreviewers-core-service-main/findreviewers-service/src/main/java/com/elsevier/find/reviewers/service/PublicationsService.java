package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.external.ScopusSharedSearchAbstract;
import com.elsevier.find.reviewers.external.ScopusSharedSearchAbstract.ScopusSharedSearchPublicationResults;
import com.elsevier.find.reviewers.generated.api.PublicationsApiDelegate;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.generated.model.ScopusAuthor;
import com.elsevier.find.reviewers.generated.model.ScopusPublication;
import com.elsevier.find.reviewers.generated.model.ScopusPublicationsResponse;
import com.elsevier.find.reviewers.service.base.BaseService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
public class PublicationsService extends BaseService implements PublicationsApiDelegate {
    private final ScopusSharedSearchAbstract scopusSharedSearchAbstract;

    protected PublicationsService(ObjectMapper objectMapper,
                                  ScopusSharedSearchAbstract scopusSharedSearchAbstract) {
        super(objectMapper);
        this.scopusSharedSearchAbstract = scopusSharedSearchAbstract;
    }

    @Override
    public ResponseEntity<ScopusPublicationsResponse> getPublicationsByIds(List<String> publicationIds, String xScope) {
        if (publicationIds == null || publicationIds.isEmpty()) {
            log.error("Publications request made without publication Ids");
            throw new InternalException(ErrorResponse.IdEnum.INVALIDARGUMENT,
                    HttpStatus.BAD_REQUEST, Map.of("publicationIds", "null"));
        }

        List<ScopusSharedSearchPublicationResults> publications = scopusSharedSearchAbstract.getPublications(publicationIds);

        ScopusPublicationsResponse response = new ScopusPublicationsResponse();
        response.setPublications(publications.stream().map(this::convertPublication).collect(Collectors.toList()));

        return ResponseEntity.ok().body(response);
    }

    private ScopusPublication convertPublication(ScopusSharedSearchPublicationResults publication) {
        ScopusPublication pub = new ScopusPublication();
        pub.setEid(publication.getEid());
        if (publication.getItemtitle() != null && !publication.getItemtitle().isEmpty()) {
            pub.setTitle(publication.getItemtitle().get(0));
        }
        pub.setJournalTitle(publication.getSrctitle());
        if (publication.getPubyr() != null) {
            try {
                pub.setYear(Integer.parseUnsignedInt(publication.getPubyr()));
            } catch (NumberFormatException e) {
                // Log an error and continue, it is more important to be tolerant of invalid data
                log.error("Publication with invalid year {} for Id {}", publication.getPubyr(), publication.getEid());
            }
        }
        pub.setCitationCount(publication.getNumcitedby());
        if (publication.getAuthors() != null) {
            pub.setAuthors(publication.getAuthors().stream().map(a -> {
                ScopusAuthor author = new ScopusAuthor();
                author.setId(a.getAuthid());
                author.setName(a.getAuthidxname());
                return author;
            }).collect(Collectors.toList()));
            pub.setAuthorCount(pub.getAuthors().size());
        }
        return pub;
    }
}
