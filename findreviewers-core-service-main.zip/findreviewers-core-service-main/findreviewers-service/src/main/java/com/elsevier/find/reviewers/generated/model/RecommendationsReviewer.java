package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.Indicators;
import com.elsevier.find.reviewers.generated.model.PersonDetails;
import com.elsevier.find.reviewers.generated.model.PersonDetailsReviewStatistics;
import com.elsevier.find.reviewers.generated.model.ScopusPublication;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * RecommendationsReviewer
 */
@Validated



public class RecommendationsReviewer extends PersonDetails  {
  @JsonProperty("publication5YearCount")
  private Integer publication5YearCount = null;

  @JsonProperty("citation5YearCount")
  private Integer citation5YearCount = null;

  @JsonProperty("yearsActive")
  private Integer yearsActive = null;

  @JsonProperty("publishedInJournalCount")
  private Integer publishedInJournalCount = null;

  @JsonProperty("similarPublicationsCount")
  private Integer similarPublicationsCount = null;

  @JsonProperty("similarPublications")
  @Valid
  private List<ScopusPublication> similarPublications = null;

  @JsonProperty("recentPublications")
  @Valid
  private List<ScopusPublication> recentPublications = null;

  public RecommendationsReviewer publication5YearCount(Integer publication5YearCount) {
    this.publication5YearCount = publication5YearCount;
    return this;
  }

  /**
   * The number of publications in the last 5 years
   * @return publication5YearCount
   **/
  @Schema(example = "22", description = "The number of publications in the last 5 years")
  
    public Integer getPublication5YearCount() {
    return publication5YearCount;
  }

  public void setPublication5YearCount(Integer publication5YearCount) {
    this.publication5YearCount = publication5YearCount;
  }

  public RecommendationsReviewer citation5YearCount(Integer citation5YearCount) {
    this.citation5YearCount = citation5YearCount;
    return this;
  }

  /**
   * The number of citations in the last 5 years
   * @return citation5YearCount
   **/
  @Schema(example = "105", description = "The number of citations in the last 5 years")
  
    public Integer getCitation5YearCount() {
    return citation5YearCount;
  }

  public void setCitation5YearCount(Integer citation5YearCount) {
    this.citation5YearCount = citation5YearCount;
  }

  public RecommendationsReviewer yearsActive(Integer yearsActive) {
    this.yearsActive = yearsActive;
    return this;
  }

  /**
   * The number of years active as an author
   * @return yearsActive
   **/
  @Schema(example = "5", description = "The number of years active as an author")
  
    public Integer getYearsActive() {
    return yearsActive;
  }

  public void setYearsActive(Integer yearsActive) {
    this.yearsActive = yearsActive;
  }

  public RecommendationsReviewer publishedInJournalCount(Integer publishedInJournalCount) {
    this.publishedInJournalCount = publishedInJournalCount;
    return this;
  }

  /**
   * The number publications this author has in this journal
   * @return publishedInJournalCount
   **/
  @Schema(example = "2", description = "The number publications this author has in this journal")
  
    public Integer getPublishedInJournalCount() {
    return publishedInJournalCount;
  }

  public void setPublishedInJournalCount(Integer publishedInJournalCount) {
    this.publishedInJournalCount = publishedInJournalCount;
  }

  public RecommendationsReviewer similarPublicationsCount(Integer similarPublicationsCount) {
    this.similarPublicationsCount = similarPublicationsCount;
    return this;
  }

  /**
   * The number of similar publications this author has
   * @return similarPublicationsCount
   **/
  @Schema(example = "1", description = "The number of similar publications this author has")
  
    public Integer getSimilarPublicationsCount() {
    return similarPublicationsCount;
  }

  public void setSimilarPublicationsCount(Integer similarPublicationsCount) {
    this.similarPublicationsCount = similarPublicationsCount;
  }

  public RecommendationsReviewer similarPublications(List<ScopusPublication> similarPublications) {
    this.similarPublications = similarPublications;
    return this;
  }

  public RecommendationsReviewer addSimilarPublicationsItem(ScopusPublication similarPublicationsItem) {
    if (this.similarPublications == null) {
      this.similarPublications = new ArrayList<>();
    }
    this.similarPublications.add(similarPublicationsItem);
    return this;
  }

  /**
   * The list similar publications this author has (This may be a partial list and less than similarPublicationsCount)
   * @return similarPublications
   **/
  @Schema(description = "The list similar publications this author has (This may be a partial list and less than similarPublicationsCount)")
      @Valid
    public List<ScopusPublication> getSimilarPublications() {
    return similarPublications;
  }

  public void setSimilarPublications(List<ScopusPublication> similarPublications) {
    this.similarPublications = similarPublications;
  }

  public RecommendationsReviewer recentPublications(List<ScopusPublication> recentPublications) {
    this.recentPublications = recentPublications;
    return this;
  }

  public RecommendationsReviewer addRecentPublicationsItem(ScopusPublication recentPublicationsItem) {
    if (this.recentPublications == null) {
      this.recentPublications = new ArrayList<>();
    }
    this.recentPublications.add(recentPublicationsItem);
    return this;
  }

  /**
   * The list recent publications this author has
   * @return recentPublications
   **/
  @Schema(description = "The list recent publications this author has")
      @Valid
    public List<ScopusPublication> getRecentPublications() {
    return recentPublications;
  }

  public void setRecentPublications(List<ScopusPublication> recentPublications) {
    this.recentPublications = recentPublications;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RecommendationsReviewer recommendationsReviewer = (RecommendationsReviewer) o;
    return Objects.equals(this.publication5YearCount, recommendationsReviewer.publication5YearCount) &&
        Objects.equals(this.citation5YearCount, recommendationsReviewer.citation5YearCount) &&
        Objects.equals(this.yearsActive, recommendationsReviewer.yearsActive) &&
        Objects.equals(this.publishedInJournalCount, recommendationsReviewer.publishedInJournalCount) &&
        Objects.equals(this.similarPublicationsCount, recommendationsReviewer.similarPublicationsCount) &&
        Objects.equals(this.similarPublications, recommendationsReviewer.similarPublications) &&
        Objects.equals(this.recentPublications, recommendationsReviewer.recentPublications) &&
        super.equals(o);
  }

  @Override
  public int hashCode() {
    return Objects.hash(publication5YearCount, citation5YearCount, yearsActive, publishedInJournalCount, similarPublicationsCount, similarPublications, recentPublications, super.hashCode());
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RecommendationsReviewer {\n");
    sb.append("    ").append(toIndentedString(super.toString())).append("\n");
    sb.append("    publication5YearCount: ").append(toIndentedString(publication5YearCount)).append("\n");
    sb.append("    citation5YearCount: ").append(toIndentedString(citation5YearCount)).append("\n");
    sb.append("    yearsActive: ").append(toIndentedString(yearsActive)).append("\n");
    sb.append("    publishedInJournalCount: ").append(toIndentedString(publishedInJournalCount)).append("\n");
    sb.append("    similarPublicationsCount: ").append(toIndentedString(similarPublicationsCount)).append("\n");
    sb.append("    similarPublications: ").append(toIndentedString(similarPublications)).append("\n");
    sb.append("    recentPublications: ").append(toIndentedString(recentPublications)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
