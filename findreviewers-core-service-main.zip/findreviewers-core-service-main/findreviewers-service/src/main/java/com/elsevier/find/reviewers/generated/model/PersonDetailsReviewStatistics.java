package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * PersonDetailsReviewStatistics
 */
@Validated



public class PersonDetailsReviewStatistics   {
  @JsonProperty("emJournalAcronym")
  private String emJournalAcronym = null;

  @JsonProperty("invitationCount")
  private Integer invitationCount = null;

  @JsonProperty("workInProgressCount")
  private Integer workInProgressCount = null;

  @JsonProperty("completedCount")
  private Integer completedCount = null;

  @JsonProperty("mostRecentCompleted")
  private Long mostRecentCompleted = null;

  public PersonDetailsReviewStatistics emJournalAcronym(String emJournalAcronym) {
    this.emJournalAcronym = emJournalAcronym;
    return this;
  }

  /**
   * Journal volunteered for EM acronym
   * @return emJournalAcronym
   **/
  @Schema(example = "ACR", required = true, description = "Journal volunteered for EM acronym")
      @NotNull

    public String getEmJournalAcronym() {
    return emJournalAcronym;
  }

  public void setEmJournalAcronym(String emJournalAcronym) {
    this.emJournalAcronym = emJournalAcronym;
  }

  public PersonDetailsReviewStatistics invitationCount(Integer invitationCount) {
    this.invitationCount = invitationCount;
    return this;
  }

  /**
   * Get invitationCount
   * minimum: 0
   * @return invitationCount
   **/
  @Schema(example = "4", description = "")
  
  @Min(0)  public Integer getInvitationCount() {
    return invitationCount;
  }

  public void setInvitationCount(Integer invitationCount) {
    this.invitationCount = invitationCount;
  }

  public PersonDetailsReviewStatistics workInProgressCount(Integer workInProgressCount) {
    this.workInProgressCount = workInProgressCount;
    return this;
  }

  /**
   * Get workInProgressCount
   * minimum: 0
   * @return workInProgressCount
   **/
  @Schema(example = "1", description = "")
  
  @Min(0)  public Integer getWorkInProgressCount() {
    return workInProgressCount;
  }

  public void setWorkInProgressCount(Integer workInProgressCount) {
    this.workInProgressCount = workInProgressCount;
  }

  public PersonDetailsReviewStatistics completedCount(Integer completedCount) {
    this.completedCount = completedCount;
    return this;
  }

  /**
   * Get completedCount
   * minimum: 0
   * @return completedCount
   **/
  @Schema(example = "3", description = "")
  
  @Min(0)  public Integer getCompletedCount() {
    return completedCount;
  }

  public void setCompletedCount(Integer completedCount) {
    this.completedCount = completedCount;
  }

  public PersonDetailsReviewStatistics mostRecentCompleted(Long mostRecentCompleted) {
    this.mostRecentCompleted = mostRecentCompleted;
    return this;
  }

  /**
   * Get mostRecentCompleted
   * minimum: 0
   * @return mostRecentCompleted
   **/
  @Schema(example = "1579866980000", description = "")
  
  @Min(0L)  public Long getMostRecentCompleted() {
    return mostRecentCompleted;
  }

  public void setMostRecentCompleted(Long mostRecentCompleted) {
    this.mostRecentCompleted = mostRecentCompleted;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PersonDetailsReviewStatistics personDetailsReviewStatistics = (PersonDetailsReviewStatistics) o;
    return Objects.equals(this.emJournalAcronym, personDetailsReviewStatistics.emJournalAcronym) &&
        Objects.equals(this.invitationCount, personDetailsReviewStatistics.invitationCount) &&
        Objects.equals(this.workInProgressCount, personDetailsReviewStatistics.workInProgressCount) &&
        Objects.equals(this.completedCount, personDetailsReviewStatistics.completedCount) &&
        Objects.equals(this.mostRecentCompleted, personDetailsReviewStatistics.mostRecentCompleted);
  }

  @Override
  public int hashCode() {
    return Objects.hash(emJournalAcronym, invitationCount, workInProgressCount, completedCount, mostRecentCompleted);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PersonDetailsReviewStatistics {\n");
    
    sb.append("    emJournalAcronym: ").append(toIndentedString(emJournalAcronym)).append("\n");
    sb.append("    invitationCount: ").append(toIndentedString(invitationCount)).append("\n");
    sb.append("    workInProgressCount: ").append(toIndentedString(workInProgressCount)).append("\n");
    sb.append("    completedCount: ").append(toIndentedString(completedCount)).append("\n");
    sb.append("    mostRecentCompleted: ").append(toIndentedString(mostRecentCompleted)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
