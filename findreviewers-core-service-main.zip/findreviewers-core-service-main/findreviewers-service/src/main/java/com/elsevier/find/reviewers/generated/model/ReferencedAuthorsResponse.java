package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.ScopusReferencedAuthor;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * The response for a list of referenced authors
 */
@Schema(description = "The response for a list of referenced authors")
@Validated



public class ReferencedAuthorsResponse   {
  @JsonProperty("referencedAuthors")
  @Valid
  private List<ScopusReferencedAuthor> referencedAuthors = null;

  public ReferencedAuthorsResponse referencedAuthors(List<ScopusReferencedAuthor> referencedAuthors) {
    this.referencedAuthors = referencedAuthors;
    return this;
  }

  public ReferencedAuthorsResponse addReferencedAuthorsItem(ScopusReferencedAuthor referencedAuthorsItem) {
    if (this.referencedAuthors == null) {
      this.referencedAuthors = new ArrayList<>();
    }
    this.referencedAuthors.add(referencedAuthorsItem);
    return this;
  }

  /**
   * Get referencedAuthors
   * @return referencedAuthors
   **/
  @Schema(description = "")
      @Valid
    public List<ScopusReferencedAuthor> getReferencedAuthors() {
    return referencedAuthors;
  }

  public void setReferencedAuthors(List<ScopusReferencedAuthor> referencedAuthors) {
    this.referencedAuthors = referencedAuthors;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ReferencedAuthorsResponse referencedAuthorsResponse = (ReferencedAuthorsResponse) o;
    return Objects.equals(this.referencedAuthors, referencedAuthorsResponse.referencedAuthors);
  }

  @Override
  public int hashCode() {
    return Objects.hash(referencedAuthors);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ReferencedAuthorsResponse {\n");
    
    sb.append("    referencedAuthors: ").append(toIndentedString(referencedAuthors)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
