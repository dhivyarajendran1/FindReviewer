package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.ScopusSearchAuthor;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * ScopusReferencedAuthor
 */
@Validated



public class ScopusReferencedAuthor extends ScopusSearchAuthor  {
  @JsonProperty("publications")
  @Valid
  private List<String> publications = null;

  public ScopusReferencedAuthor publications(List<String> publications) {
    this.publications = publications;
    return this;
  }

  public ScopusReferencedAuthor addPublicationsItem(String publicationsItem) {
    if (this.publications == null) {
      this.publications = new ArrayList<>();
    }
    this.publications.add(publicationsItem);
    return this;
  }

  /**
   * The publications for this author that were referenced
   * @return publications
   **/
  @Schema(description = "The publications for this author that were referenced")
  
    public List<String> getPublications() {
    return publications;
  }

  public void setPublications(List<String> publications) {
    this.publications = publications;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ScopusReferencedAuthor scopusReferencedAuthor = (ScopusReferencedAuthor) o;
    return Objects.equals(this.publications, scopusReferencedAuthor.publications) &&
        super.equals(o);
  }

  @Override
  public int hashCode() {
    return Objects.hash(publications, super.hashCode());
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ScopusReferencedAuthor {\n");
    sb.append("    ").append(toIndentedString(super.toString())).append("\n");
    sb.append("    publications: ").append(toIndentedString(publications)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
