package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.ConflictOfInterestDetails;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * The response to a request to check for conflict of interest
 */
@Schema(description = "The response to a request to check for conflict of interest")
@Validated



public class ConflictOfInterestResponse   {
  @JsonProperty("reviewers")
  @Valid
  private List<ConflictOfInterestDetails> reviewers = new ArrayList<>();

  public ConflictOfInterestResponse reviewers(List<ConflictOfInterestDetails> reviewers) {
    this.reviewers = reviewers;
    return this;
  }

  public ConflictOfInterestResponse addReviewersItem(ConflictOfInterestDetails reviewersItem) {
    this.reviewers.add(reviewersItem);
    return this;
  }

  /**
   * Get reviewers
   * @return reviewers
   **/
  @Schema(required = true, description = "")
      @NotNull
    @Valid
    public List<ConflictOfInterestDetails> getReviewers() {
    return reviewers;
  }

  public void setReviewers(List<ConflictOfInterestDetails> reviewers) {
    this.reviewers = reviewers;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ConflictOfInterestResponse conflictOfInterestResponse = (ConflictOfInterestResponse) o;
    return Objects.equals(this.reviewers, conflictOfInterestResponse.reviewers);
  }

  @Override
  public int hashCode() {
    return Objects.hash(reviewers);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ConflictOfInterestResponse {\n");
    
    sb.append("    reviewers: ").append(toIndentedString(reviewers)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
