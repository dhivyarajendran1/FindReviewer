package com.elsevier.find.reviewers.exception;

import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.generated.model.RecommendationsFailureResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.catalina.connector.ClientAbortException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import jakarta.validation.ConstraintViolationException;

/**
 * This class will catch specific exceptions that are thrown over the interface boundary and convert
 * then into REST error responses
 */
@Slf4j
@RestControllerAdvice
public class ControllerExceptionResponseHandler extends ResponseEntityExceptionHandler {
    private static final String MESSAGE = "Message";

    /**
     * Internal Application error detected with knowledge of the error. This allows
     * for additional useful information to be returned with the error
     *
     * @param e       The internal exception format
     * @param request Details of the request made that triggered the error
     * @return REST interface error format
     */
    @ExceptionHandler(value = {InternalException.class})
    protected ResponseEntity<ErrorResponse> handleInternalException(InternalException e, WebRequest request) {
        ErrorResponse response = e.toErrorResponse();
        if (response == null) {
            return ResponseEntity.status(e.getHttpStatus()).build();
        }
        return ResponseEntity.status(e.getHttpStatus()).contentType(MediaType.APPLICATION_JSON).body(response);
    }

    @ExceptionHandler(value = {RecommendationException.class})
    protected ResponseEntity<RecommendationsFailureResponse> handleRecommendationException(RecommendationException e, WebRequest request) {
        RecommendationsFailureResponse response = e.getResponse();
        if (response == null) {
            return ResponseEntity.status(e.getHttpStatus()).build();
        }
        return ResponseEntity.status(e.getHttpStatus()).contentType(MediaType.APPLICATION_JSON).body(response);
    }

    /**
     * Invalid argument detected during processing. This is a non-specific error that we
     * extract the generated error message out of as an attribute
     *
     * @param e       The root exception
     * @param request Details of the request made that triggered the error
     * @return REST interface error format
     */
    @ExceptionHandler(value = {IllegalArgumentException.class})
    protected ResponseEntity<ErrorResponse> handleIllegalArgument(RuntimeException e, WebRequest request) {
        log.error("Unexpected IllegalArgumentException thrown", e);

        ErrorResponse response = new ErrorResponse();
        response.setId(ErrorResponse.IdEnum.INVALIDARGUMENT);
        String msg = getCleanExceptionMessage(e);
        if (msg != null) {
            response.putAttributesItem(MESSAGE, msg);
        }

        return ResponseEntity.badRequest().contentType(MediaType.APPLICATION_JSON).body(response);
    }

    /**
     * If the client terminates the connection while we are in the middle of processing a request
     * we will get a ClientAbortException - this extends IOException, but better to handle the
     * specific case as there are many things that can throw IOException.
     * <p>
     * In these cases there is no need to return any data - as there is nowhere to return it to
     * as the client has terminated communications. (Returning data would just raise another warning)
     *
     * @param e       The root exception
     * @param request Details of the request made that triggered the error
     * @return REST interface error format
     */
    @ExceptionHandler(value = {ClientAbortException.class})
    protected ResponseEntity<Object> handleClientAbortException(ClientAbortException e, WebRequest request) {
        log.warn("Unexpected ClientAbortException thrown", e);
        return null;
    }

    /**
     * Handle the exception that the framework throws if the REST API is called with invalid data
     *
     * @param e       The root exception
     * @param request Details of the request made that triggered the error
     * @return REST interface error format
     */
    @ExceptionHandler(value = {ConstraintViolationException.class})
    protected ResponseEntity<ErrorResponse> handleConstraintViolationException(ConstraintViolationException e, WebRequest request) {
        log.warn("REST API called with invalid data", e);

        ErrorResponse response = new ErrorResponse();
        response.setId(ErrorResponse.IdEnum.INVALIDARGUMENT);
        String msg = getCleanExceptionMessage(e);
        if (msg != null) {
            response.putAttributesItem(MESSAGE, msg);
        }

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).contentType(MediaType.APPLICATION_JSON).body(response);
    }

    /**
     * Default catch all exception handler. This should, in theory, never be called and seeing
     * of this exception and it's return over the interface should be reported as a bug
     *
     * @param e       The root exception
     * @param request Details of the request made that triggered the error
     * @return REST interface error format
     */
    @ExceptionHandler(value = {Exception.class})
    protected ResponseEntity<ErrorResponse> handleOther(Exception e, WebRequest request) {
        log.error("Unexpected Exception thrown", e);

        ErrorResponse response = new ErrorResponse();
        response.setId(ErrorResponse.IdEnum.UNKNOWN);
        // No not print the Message in the exception as this could display a security issue such
        // as a database error. For unexpected errors they will still be logged
        response.putAttributesItem(MESSAGE, "Unexpected error, see log for more details");

        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).contentType(MediaType.APPLICATION_JSON).body(response);
    }

    /**
     * Overwrite the default spring boot error handling response to be our own response format
     * Otherwise we will never see the content of the error as spring boot returns an empty body
     * most of the time
     *
     * @param ex      Original exception
     * @param body    The body written by spring boot
     * @param headers The headers set by spring boot
     * @param status  The status spring boot would use
     * @param request Details of the request made that triggered the error
     * @return REST interface error format
     */
    @Override
    protected ResponseEntity<Object> handleExceptionInternal(
            Exception ex, Object body, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
        ErrorResponse response = new ErrorResponse();
        response.setId(ErrorResponse.IdEnum.INVALIDARGUMENT);
        String msg = getCleanExceptionMessage(ex);
        if (msg != null) {
            response.putAttributesItem(MESSAGE, msg);
        }
        if (status != null) {
            response.putAttributesItem("SpringHttpStatus", status.toString());
        }
        return new ResponseEntity<>(response, headers, HttpStatus.BAD_REQUEST);
    }

    private String getCleanExceptionMessage(Exception ex) {
        if (ex != null && ex.getMessage() != null && !ex.getMessage().isBlank()) {
            // Some exceptions have a base description of the error followed by some more technical details,
            // this can include class names, so try and remove the chance of sending this complex data
            String[] msgParts = ex.getMessage().split(":");
            if (msgParts.length > 0) {
                return msgParts[0];
            }
        }
        return null;
    }
}
