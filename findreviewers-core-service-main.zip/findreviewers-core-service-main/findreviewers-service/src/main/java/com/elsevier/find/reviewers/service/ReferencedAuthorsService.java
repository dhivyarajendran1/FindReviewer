package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.dao.ManuscriptDao;
import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.external.ScopusSharedSearchAbstract;
import com.elsevier.find.reviewers.external.ScopusSharedSearchAbstract.ScopusSharedSearchDocumentResults;
import com.elsevier.find.reviewers.external.ScopusSharedSearchBase.ScopusSharedSearchAuthorIds;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.generated.api.ReferencedAuthorsApiDelegate;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.generated.model.KeywordSearchLogic;
import com.elsevier.find.reviewers.generated.model.ReferencedAuthorsResponse;
import com.elsevier.find.reviewers.generated.model.ScopusReferencedAuthor;
import com.elsevier.find.reviewers.service.base.BaseService;
import com.elsevier.find.reviewers.service.base.DataGatherRules;
import com.elsevier.find.reviewers.service.base.PersonDetailsSupportService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Slf4j
@Service
public class ReferencedAuthorsService extends BaseService implements ReferencedAuthorsApiDelegate {

    private final ManuscriptDao manuscriptDao;

    private final ScopusSharedSearchAbstract scopusSharedSearchAbstract;

    private final PersonDetailsSupportService personDetailsSupportService;

    protected ReferencedAuthorsService(ObjectMapper objectMapper,
                                       ManuscriptDao manuscriptDao,
                                       ScopusSharedSearchAbstract scopusSharedSearchAbstract,
                                       PersonDetailsSupportService personDetailsSupportService) {
        super(objectMapper);
        this.manuscriptDao = manuscriptDao;
        this.scopusSharedSearchAbstract = scopusSharedSearchAbstract;
        this.personDetailsSupportService = personDetailsSupportService;
    }

    // SonarQube complaining about complexity - but it's not complex
    @SuppressWarnings("java:S3776")
    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class, readOnly = true)
    public ResponseEntity<ReferencedAuthorsResponse> getReferencedAuthors(String emJournalAcronym,
                                                                          Long documentId,
                                                                          String xScope,
                                                                          String keywords,
                                                                          KeywordSearchLogic searchLogic) {
        if (!SessionContext.isUrsdbJournal()) {
            return ResponseEntity.ok().body(new ReferencedAuthorsResponse());
        }

        if (emJournalAcronym == null || emJournalAcronym.isBlank() || documentId == null) {
            log.error("Referenced Authors request made without EM Journal Acronym or document Id");
            throw new InternalException(ErrorResponse.IdEnum.INVALIDARGUMENT,
                    HttpStatus.BAD_REQUEST, Map.of("emJournalAcronym", String.valueOf(emJournalAcronym),
                    "documentId", String.valueOf(documentId)));
        }

        Set<String> references = manuscriptDao.getReferenceIdentifiers(emJournalAcronym, documentId);

        ReferencedAuthorsResponse response = new ReferencedAuthorsResponse();

        if (!references.isEmpty()) {
            List<ScopusSharedSearchDocumentResults> refDocAuthors = scopusSharedSearchAbstract.getAuthorsFromReferences(references);

            // The authors are grouped by each document, need to convert to a list of authors with
            // their documents as a property
            Map<String, ScopusReferencedAuthor> uniqueAuthors = new HashMap<>();

            for (ScopusSharedSearchDocumentResults refDoc : refDocAuthors) {
                if (refDoc.getAuthors() == null) {
                    continue;
                }
                for (int i = 0; i < refDoc.getAuthors().size(); i++) {
                    final ScopusSharedSearchAuthorIds author = refDoc.getAuthors().get(i);

                    if (author.getAuthid() == null || author.getAuthemail() == null) {
                        continue;
                    }

                    ScopusReferencedAuthor refAuthor = uniqueAuthors.computeIfAbsent(author.getAuthid(), k -> convertAuthor(author));
                    if (refDoc.getEid() != null &&
                            (refAuthor.getPublications() == null || !refAuthor.getPublications().contains(refDoc.getEid()))) {
                        refAuthor.addPublicationsItem(refDoc.getEid());
                    }
                }
            }

            log.info("Journal {} document {} referenced authors lookup for {} references found {} authors",
                    emJournalAcronym, documentId, references.size(), uniqueAuthors.size());

            if (!uniqueAuthors.isEmpty()) {
                List<ScopusReferencedAuthor> authors = new ArrayList<>(uniqueAuthors.values());

                DataGatherRules<ScopusReferencedAuthor> rules = new DataGatherRules<>(authors)
                        .addBlockList().addInternalDbData().addReviewStatistics(true).addScopusData()
                        .addContentMatch(keywords, searchLogic);

                response.setReferencedAuthors(personDetailsSupportService.gatherAdditionalData(emJournalAcronym, rules));
            }
        } else {
            log.info("No references found for journal {} document {}", emJournalAcronym, documentId);
        }

        return ResponseEntity.ok().body(response);
    }

    private ScopusReferencedAuthor convertAuthor(ScopusSharedSearchAuthorIds scopusAuthor) {
        ScopusReferencedAuthor author = new ScopusReferencedAuthor();
        author.addScopusIdsItem(scopusAuthor.getAuthid());
        author.addEmailsItem(scopusAuthor.getAuthemail());

        return author;
    }
}
