package com.elsevier.find.reviewers.dao;


import com.elsevier.find.reviewers.generated.model.JournalDetails;
import com.elsevier.find.reviewers.generated.model.ScopusSearchAuthor;

import java.util.List;

/**
 * Interface that supports operations on journals
 */
public interface JournalDao {
    /**
     * Checks if a given journal is in URSDB
     *
     * @param emJournalAcronym EM Journal Acronym
     * @return True if supports URSDB, false otherwise
     */
    boolean isUrsdbJournal(String emJournalAcronym);

    /**
     * Gets the EM Journal Id for an EM acronym
     *
     * @param emJournalAcronym EM Journal Acronym
     * @return EM Journal Id
     */
    Long getEmJournalId(String emJournalAcronym);

    /**
     * Gets the details for all journals in URSDB
     *
     * @return  List of journal details
     */
    List<JournalDetails> getJournals();

    /**
     * Gets the reviewers for a given journal
     *
     * @param emJournalAcronym EM Journal Acronym to get reviewers for
     * @param offset           Where to start the listing from
     * @param limit            Maximum number of entries to return
     * @return List of reviewers
     */
    List<ScopusSearchAuthor> getJournalReviewers(String emJournalAcronym,
                                                 Integer offset,
                                                 Integer limit);
}
