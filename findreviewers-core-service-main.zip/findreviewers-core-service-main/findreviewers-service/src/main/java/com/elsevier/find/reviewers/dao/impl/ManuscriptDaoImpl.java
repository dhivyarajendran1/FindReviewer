package com.elsevier.find.reviewers.dao.impl;

import com.elsevier.find.reviewers.dao.ManuscriptDao;
import com.elsevier.find.reviewers.generated.model.ClassificationDetails;
import com.elsevier.find.reviewers.generated.model.InitialisationDetails;
import com.elsevier.find.reviewers.generated.model.ManuscriptDetails;
import com.elsevier.find.reviewers.generated.model.ReviewerDetails;
import com.elsevier.find.reviewers.generated.model.ReviewerStatus;
import com.elsevier.find.reviewers.utils.KeywordUtils;
import com.elsevier.find.reviewers.utils.PersonDetailsUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.web.util.HtmlUtils;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Implementation for the data access to manuscripts
 */
// Suppress SonarQube 'String literals should not be duplicated' flagged against the inline sql
@SuppressWarnings("squid:S1192")
@Slf4j
@Repository
public class ManuscriptDaoImpl extends BaseDaoImpl implements ManuscriptDao {
    private final Pattern referencePattern = Pattern.compile("<pub-id pub-id-type=\"doi\">(.*?)</pub-id>");

    public ManuscriptDaoImpl(NamedParameterJdbcTemplate dbSource, ObjectMapper objectMapper,
                             @Value("${findreviewers.cloud.ursdb:false}") String cloudUrsdbEnabled) {
        super(dbSource, objectMapper, cloudUrsdbEnabled);
    }

    /**
     * The Row mapper will convert the SQL returned to the object format
     */
    public class InitialisationResultsExtractor extends BaseRowMapper implements ResultSetExtractor<InitialisationDetails> {
        @SuppressWarnings("squid:S3776")
        @Override
        public InitialisationDetails extractData(ResultSet rs) throws SQLException {
            InitialisationDetails details = null;
            Map<Long, ReviewerDetails> reviewers = new HashMap<>();

            while (rs.next()) {
                if (details == null) {
                    details = new InitialisationDetails();
                    details.setKeywords(getKeywords(rs.getString("keywords")));
                    details.setClassifications(getClassifications(rs.getString("classifications")));
                    details.setCorrespondingAuthors(getPersonDetails(rs.getString("corresponding_authors")));
                    details.setCoAuthors(getPersonDetails(rs.getString("co_authors")));
                    details.setSuggestedReviewers(getPersonDetails(rs.getString("suggested_reviewers")));
                    details.setOpposedReviewers(getPersonDetails(rs.getString("opposed_reviewers")));
                    if (Boolean.TRUE.equals(rs.getBoolean("has_references"))) {
                        details.addPermittedFeaturesItem(InitialisationDetails.PermittedFeaturesEnum.REFERENCEDAUTHORS);
                    }
                }

                // Process the reviewers, they need an email for them to be useful
                String email = getOptionalString(rs, "email");
                if (email != null) {
                    email = email.toLowerCase();
                    // Reviewers can have multiple email addresses, the query will return a row per email address
                    // so need to make sure we do not duplicate the reviewer and instead extend the email list
                    // if we already have a record for them
                    Long reviewerId = rs.getLong("review_udb_id");
                    if (reviewers.containsKey(reviewerId)) {
                        List<String> existingEmails = reviewers.get(reviewerId).getEmails();
                        if (!existingEmails.contains(email)) {
                            existingEmails.add(email);
                        }
                    } else {
                        ReviewerDetails reviewer = new ReviewerDetails();
                        reviewer.addEmailsItem(email);
                        reviewer.setFirstName(getOptionalString(rs, "first_name"));
                        reviewer.setLastName(getOptionalString(rs, "last_name"));
                        PersonDetailsUtils.setDisplayName(reviewer);

                        reviewer.setStatus(getReviewerStatus(rs));
                        reviewers.put(reviewerId, reviewer);
                    }
                    final String scopusId = getOptionalString(rs, "scopus_id");
                    if (scopusId != null) {
                        List<String> existingScopusIds = reviewers.get(reviewerId).getScopusIds();
                        if (existingScopusIds == null || !existingScopusIds.contains(scopusId)) {
                            reviewers.get(reviewerId).addScopusIdsItem(scopusId);
                        }
                    }
                }
            }

            if (details != null) {
                for (ReviewerDetails reviewer : reviewers.values()) {
                    details.addReviewersItem(reviewer);
                }
            }
            return details;
        }

        private ReviewerStatus getReviewerStatus(ResultSet rs) throws SQLException {
            // If none of the flags are set, then the default is Invited
            ReviewerStatus status = ReviewerStatus.INVITED;
            if (rs.getBoolean("completed")) {
                status = ReviewerStatus.COMPLETED;
            } else if (rs.getBoolean("terminated")) {
                status = ReviewerStatus.TERMINATED;
            } else if (rs.getBoolean("declined")) {
                status = ReviewerStatus.DECLINED;
            } else if (rs.getBoolean("uninvited")) {
                status = ReviewerStatus.UNINVITED;
            } else if (rs.getBoolean("workinprogress")) {
                status = ReviewerStatus.INPROGRESS;
            } else if (rs.getBoolean("alternate")) {
                status = ReviewerStatus.ALTERNATE;
            } else if (rs.getBoolean("assigned_not_invited")) {
                status = ReviewerStatus.ASSIGNED;
            }

            return status;
        }

        private List<String> getKeywords(String keywordsJson) {
            List<String> keywords = null;
            if (keywordsJson != null && !keywordsJson.isBlank()) {
                try {
                    keywords = KeywordUtils.processKeywords(Arrays.asList(objectMapper.readValue(keywordsJson, String[].class)));
                } catch (JsonProcessingException e) {
                    log.error("Failed to load keywords from database for keywords {}, error {}", keywordsJson, e.getMessage());
                }
            }
            return keywords;
        }

        private List<ClassificationDetails> getClassifications(String classificationsJson) {
            List<ClassificationDetails> classifications = null;
            if (classificationsJson != null && !classificationsJson.isBlank()) {
                try {
                    classifications = objectMapper.readValue(classificationsJson, new TypeReference<>() {
                    });
                } catch (JsonProcessingException e) {
                    log.error("Failed to load classifications from database for {}, error {}", classificationsJson, e.getMessage());
                }
            }
            return classifications;
        }
    }

    /**
     * The Row mapper will convert the SQL returned to the object format
     */
    class ManuscriptRowMapper extends BaseRowMapper implements RowMapper<ManuscriptDetails> {
        @Override
        public ManuscriptDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
            ManuscriptDetails manuscript = new ManuscriptDetails();
            manuscript.setManuscriptNumber(getOptionalString(rs, "pubd_number"));
            manuscript.setTitle(getOptionalString(rs, "manuscript_title"));
            manuscript.setAbstract(getOptionalString(rs, "abstract"));
            manuscript.setCorrespondingAuthors(getPersonDetails(rs.getString("corresponding_authors")));
            manuscript.setCoAuthors(getPersonDetails(rs.getString("co_authors")));
            return manuscript;
        }
    }

    @Override
    public InitialisationDetails getInitialisationDetails(String emJournalAcronym, Long documentId) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("emJournalAcronym", emJournalAcronym.toUpperCase());
        params.addValue("documentId", documentId);

        String sql = """
                with journal_id as (
                  select "JOURNAL_ID" from rr_ursdb."JOURNAL_INFO" where "JOURNAL__upper" = :emJournalAcronym
                ),
                keywords as (
                  select k."WORD" as description from rr_ursdb."KEYWORD" k
                  inner join rr_ursdb."KEYWDATA" d on k."JOURNAL_ID" = d."JOURNAL_ID" and k."KEYWORDID" = d."KEYWORDID"
                  where k."JOURNAL_ID" = (select * from journal_id) and d."DOCUMENTID" = :documentId
                ),
                classifications as (
                  select d."CLASSCID" as classid, c."DESCRIPTION" as description, c."CLASS" as classcode
                  from rr_ursdb."CLASDDAT" d
                  inner join rr_ursdb."CLASCODE" c on d."JOURNAL_ID" = c."JOURNAL_ID" and d."CLASSCID" = c."CLASSCID"
                  where d."JOURNAL_ID" = (select * from journal_id) and d."DOCUMENTID" = :documentId
                ),
                authors as (
                  select distinct on (a."EMAIL__lower") json_build_object('emails',
                   to_json(array_remove(array_prepend(a."EMAIL__lower", array_remove(array_agg(distinct ae2."Email__lower"), a."EMAIL__lower")), null)),
                   'firstName', a."FIRSTNAME", 'lastName', a."LASTNAME") as author_details,
                   (a."AUTHTYPE" = 'on') as is_corresponding
                  from rr_ursdb."AUTHORS" a
                  left join rr_ursdb."ADDRESS_EMAIL" ae on ae."Email__lower" = a."EMAIL__lower"
                  left join rr_ursdb."ADDRESS_EMAIL" ae2 on ae2."JOURNAL_ID" = ae."JOURNAL_ID" and ae2."PeopleID" = ae."PeopleID"
                  where a."JOURNAL_ID" = (select * from journal_id) and a."DOCUMENTID" = :documentId
                  group by a."EMAIL__lower", a."FIRSTNAME", a."LASTNAME", is_corresponding
                ),
                suggested as (
                  select distinct on (r."EMAIL__lower") json_build_object('emails', json_build_array(r."EMAIL__lower"),
                   'firstName', r."FIRST_NAME", 'lastName', r."LAST_NAME") as person_details,
                   r."SUGGEST" as suggest, r."OPPOSE" as oppose
                  from rr_ursdb."REVIEWERS" r
                  where r."JOURNAL_ID" = (select * from journal_id) and r."DOCUMENTID" = :documentId
                ),
                refs_exist as (
                   select position('<pub-id pub-id-type="doi">' in r."RL_XML_RESULTS") > 0 as has_references
                   from rr_ursdb."RC_RESULTS" r
                   inner join rr_ursdb."JOURNAL_INFO" j on j."JOURNAL_ID" = r."JOURNAL_ID"
                   inner join rr_ursdb."RC_RUNS" rr on rr."JOURNAL_ID" = r."JOURNAL_ID" and rr."RC_RUN_ID" = r."RC_RUN_ID"
                   where j."JOURNAL__upper" = :emJournalAcronym and rr."DOCUMENT_ID" = :documentId and r."RL_XML_RESULTS" is not null
                   order by rr."SUBMITTED" desc limit 1
                )
                select
                (select to_json(coalesce(array_agg(keywords.description))) from keywords) as keywords,
                (select to_json(coalesce(array_agg(json_build_object('code', classifications.classcode,
                 'description', classifications.description)))) from classifications) as classifications,
                (select to_json(coalesce(array_agg(authors.author_details))) from authors
                 where authors.is_corresponding is true) as corresponding_authors,
                (select to_json(coalesce(array_agg(authors.author_details))) from authors
                 where authors.is_corresponding is false) as co_authors,
                (select to_json(coalesce(array_agg(suggested.person_details))) from suggested
                 where suggested.suggest is true) as suggested_reviewers,
                (select to_json(coalesce(array_agg(suggested.person_details))) from suggested
                 where suggested.oppose is true) as opposed_reviewers,
                (select has_references::bool from refs_exist) as has_references,
                r."UDB_ID" as review_udb_id, r."WORKINPROGRESS" as workinprogress, r."DECLINED" as declined,
                r."TERMINATED" as terminated, r."COMPLETED" as completed, r."ALTERNATE" as alternate,
                r."UNINVITED" as uninvited, r."ASSIGNED_NOT_INVITED" as assigned_not_invited,
                p."FIRSTNAME" as first_name, p."LASTNAME" as last_name, a."Email__lower" as email,
                i."SCOPUSAUTHORID" as scopus_id
                from rr_ursdb."DOCUMENT" d
                left join rr_ursdb."ROLEREVU" r on r."JOURNAL_ID" = d."JOURNAL_ID" and
                 r."DOCUMENTID" = d."DOCUMENTID" and r."REVISION" = d."REVISION"
                left join rr_ursdb."PEOPLE" p on p."JOURNAL_ID" = r."JOURNAL_ID" and p."PEOPLEID" = r."PEOPLEID"
                left join rr_ursdb."ADDRESS_EMAIL" a on a."JOURNAL_ID" = p."JOURNAL_ID" and a."PeopleID" = p."PEOPLEID"
                left join rr_ursdb."PERSONAL_IDENTIFIERS" i on p."JOURNAL_ID" = i."JOURNAL_ID" and
                 i."PERSONAL_IDENTIFIERS_ID" = p."PERSONAL_IDENTIFIERS_ID"
                where d."JOURNAL_ID" = (select * from journal_id) and d."DOCUMENTID" = :documentId
                """;

        if (isCloudUrsdb) {
            sql = """
                    with journal_id as (
                      select journal_id from fr_ursdb.journal_info where journal__upper = :emJournalAcronym
                    ),
                    keywords as (
                      select k.word as description from fr_ursdb.keyword k
                      inner join fr_ursdb.keywdata d on k.journal_id = d.journal_id and k.keywordid = d.keywordid
                      where k.journal_id = (select * from journal_id) and d.documentid = :documentId
                    ),
                    classifications as (
                      select d.classcid as classid, c.description as description, c.class as classcode
                      from fr_ursdb.clasddat d
                      inner join fr_ursdb.clascode c on d.journal_id = c.journal_id and d.classcid = c.classcid
                      where d.journal_id = (select * from journal_id) and d.documentid = :documentId
                    ),
                    authors as (
                      select distinct on (a.email__lower) json_build_object('emails',
                       to_json(array_remove(array_prepend(a.email__lower, array_remove(array_agg(distinct ae2.email__lower), a.email__lower)), null)),
                       'firstName', a.firstname, 'lastName', a.lastname) as author_details,
                       (a.authtype = 'on') as is_corresponding
                      from fr_ursdb.authors a
                      left join fr_ursdb.address_email ae on ae.email__lower = a.email__lower
                      left join fr_ursdb.address_email ae2 on ae2.journal_id = ae.journal_id and ae2.peopleid = ae.peopleid
                      where a.journal_id = (select * from journal_id) and a.documentid = :documentId
                      group by a.email__lower, a.firstname, a.lastname, is_corresponding
                    ),
                    suggested as (
                      select distinct on (r.email__lower) json_build_object('emails', json_build_array(r.email__lower),
                       'firstName', r.first_name, 'lastName', r.last_name) as person_details,
                       r.suggest as suggest, r.oppose as oppose
                      from fr_ursdb.reviewers r
                      where r.journal_id = (select * from journal_id) and r.documentid = :documentId
                    ),
                    refs_exist as (
                       select position('<pub-id pub-id-type="doi">' in r.rl_xml_results) > 0 as has_references
                       from fr_ursdb.rc_results r
                       inner join fr_ursdb.journal_info j on j.journal_id = r.journal_id
                       inner join fr_ursdb.rc_runs rr on rr.journal_id = r.journal_id and rr.rc_run_id = r.rc_run_id
                       where j.journal__upper = :emJournalAcronym and rr.document_id = :documentId and r.rl_xml_results is not null
                       order by rr.submitted desc limit 1
                    )
                    select
                    (select to_json(coalesce(array_agg(keywords.description))) from keywords) as keywords,
                    (select to_json(coalesce(array_agg(json_build_object('code', classifications.classcode,
                     'description', classifications.description)))) from classifications) as classifications,
                    (select to_json(coalesce(array_agg(authors.author_details))) from authors
                     where authors.is_corresponding is true) as corresponding_authors,
                    (select to_json(coalesce(array_agg(authors.author_details))) from authors
                     where authors.is_corresponding is false) as co_authors,
                    (select to_json(coalesce(array_agg(suggested.person_details))) from suggested
                     where suggested.suggest is true) as suggested_reviewers,
                    (select to_json(coalesce(array_agg(suggested.person_details))) from suggested
                     where suggested.oppose is true) as opposed_reviewers,
                    (select has_references::bool from refs_exist) as has_references,
                    r.udb_id as review_udb_id, r.workinprogress as workinprogress, r.declined as declined,
                    r.terminated as terminated, r.completed as completed, r.alternate as alternate,
                    r.uninvited as uninvited, r.assigned_not_invited as assigned_not_invited,
                    p.firstname as first_name, p.lastname as last_name, a.email__lower as email,
                    i.scopusauthorid as scopus_id
                    from fr_ursdb.document d
                    left join fr_ursdb.rolerevu r on r.journal_id = d.journal_id and
                     r.documentid = d.documentid and r.revision = d.revision
                    left join fr_ursdb.people p on p.journal_id = r.journal_id and p.peopleid = r.peopleid
                    left join fr_ursdb.address_email a on a.journal_id = p.journal_id and a.peopleid = p.peopleid
                    left join fr_ursdb.personal_identifiers i on p.journal_id = i.journal_id and
                     i.personal_identifiers_id = p.personal_identifiers_id
                    where d.journal_id = (select * from journal_id) and d.documentid = :documentId
                    """;
        }

        return dbSource.query(sql, params, new InitialisationResultsExtractor());
    }

    @Override
    public ManuscriptDetails getManuscriptDetails(String emJournalAcronym, Long documentId) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("emJournalAcronym", emJournalAcronym.toUpperCase());
        params.addValue("documentId", documentId);

        String sql = """
                with journal_id as (
                  select "JOURNAL_ID" from rr_ursdb."JOURNAL_INFO" where "JOURNAL__upper" = :emJournalAcronym
                ),
                authors as (
                  select distinct on (a."EMAIL__lower") json_build_object('emails',
                   to_json(array_remove(array_prepend(a."EMAIL__lower", array_remove(array_agg(distinct ae2."Email__lower"), a."EMAIL__lower")), null)),
                   'firstName', a."FIRSTNAME", 'lastName', a."LASTNAME") as author_details,
                   (a."AUTHTYPE" = 'on') as is_corresponding
                  from rr_ursdb."AUTHORS" a
                  left join rr_ursdb."ADDRESS_EMAIL" ae on ae."Email__lower" = a."EMAIL__lower"
                  left join rr_ursdb."ADDRESS_EMAIL" ae2 on ae2."JOURNAL_ID" = ae."JOURNAL_ID" and ae2."PeopleID" = ae."PeopleID"
                  where a."JOURNAL_ID" = (select * from journal_id) and a."DOCUMENTID" = :documentId
                  group by a."EMAIL__lower", a."FIRSTNAME", a."LASTNAME", is_corresponding
                )
                select d."PUBDNUMBER" as pubd_number, d."DTITLE" as manuscript_title, d."ABSTRACT_TEXT" as abstract,
                (select to_json(coalesce(array_agg(authors.author_details))) from authors
                 where authors.is_corresponding is true) as corresponding_authors,
                (select to_json(coalesce(array_agg(authors.author_details))) from authors
                 where authors.is_corresponding is false) as co_authors
                from rr_ursdb."DOCUMENT" d
                where d."JOURNAL_ID" = (select * from journal_id) and d."DOCUMENTID" = :documentId
                """;

        if (isCloudUrsdb) {
            sql = """
                    with journal_id as (
                      select journal_id from fr_ursdb.journal_info where journal__upper = :emJournalAcronym
                    ),
                    authors as (
                      select distinct on (a.email__lower) json_build_object('emails',
                       to_json(array_remove(array_prepend(a.email__lower, array_remove(array_agg(distinct ae2.email__lower), a.email__lower)), null)),
                       'firstName', a.firstname, 'lastName', a.lastname) as author_details,
                       (a.authtype = 'on') as is_corresponding
                      from fr_ursdb.authors a
                      left join fr_ursdb.address_email ae on ae.email__lower = a.email__lower
                      left join fr_ursdb.address_email ae2 on ae2.journal_id = ae.journal_id and ae2.peopleid = ae.peopleid
                      where a.journal_id = (select * from journal_id) and a.documentid = :documentId
                      group by a.email__lower, a.firstname, a.lastname, is_corresponding
                    )
                    select d.pubdnumber as pubd_number, d.dtitle as manuscript_title, d.abstract_text as abstract,
                    (select to_json(coalesce(array_agg(authors.author_details))) from authors
                     where authors.is_corresponding is true) as corresponding_authors,
                    (select to_json(coalesce(array_agg(authors.author_details))) from authors
                     where authors.is_corresponding is false) as co_authors
                    from fr_ursdb.document d
                    where d.journal_id = (select * from journal_id) and d.documentid = :documentId
                    """;
        }

        List<ManuscriptDetails> manuscripts = dbSource.query(sql, params, new ManuscriptRowMapper());
        return manuscripts.isEmpty() ? new ManuscriptDetails() : manuscripts.get(0);
    }

    @Override
    public Set<String> getReferenceIdentifiers(String emJournalAcronym, Long documentId) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("emJournalAcronym", emJournalAcronym.toUpperCase());
        params.addValue("documentId", documentId);

        // Get the most recently generated list of references
        String sql = """
                select r."RL_XML_RESULTS" as refs from rr_ursdb."RC_RESULTS" r
                inner join rr_ursdb."JOURNAL_INFO" j on j."JOURNAL_ID" = r."JOURNAL_ID"
                inner join rr_ursdb."RC_RUNS" rr on rr."JOURNAL_ID" = r."JOURNAL_ID" and rr."RC_RUN_ID" = r."RC_RUN_ID"
                where j."JOURNAL__upper" = :emJournalAcronym and rr."DOCUMENT_ID" = :documentId and r."RL_XML_RESULTS" is not null
                order by rr."SUBMITTED" desc limit 1
                """;

        if (isCloudUrsdb) {
            sql = """
                    select r.rl_xml_results as refs from fr_ursdb.rc_results r
                    inner join fr_ursdb.journal_info j on j.journal_id = r.journal_id
                    inner join fr_ursdb.rc_runs rr on rr.journal_id = r.journal_id and rr.rc_run_id = r.rc_run_id
                    where j.journal__upper = :emJournalAcronym and rr.document_id = :documentId and r.rl_xml_results is not null
                    order by rr.submitted desc limit 1
                    """;
        }

        // As we limit the results set to 1 we will only get the most recent reference set
        // Unfortunately we can not use queryForObject as that will fail if there are no rows
        List<String> referenceXml = dbSource.query(sql, params, (rs, rowNum) -> rs.getString("refs"));

        Set<String> references = new HashSet<>();
        if (!referenceXml.isEmpty()) {
            Matcher matcher = referencePattern.matcher(referenceXml.get(0));
            while (matcher.find()) {
                final String ref = matcher.group(1).trim();
                if (!ref.isEmpty()) {
                    references.add(HtmlUtils.htmlUnescape(ref));
                }
            }
        }

        return references;
    }
}
