package com.elsevier.find.reviewers.external;

import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.generated.model.Indicators;
import com.elsevier.find.reviewers.generated.model.KeywordSearchLogic;
import com.elsevier.find.reviewers.utils.KeywordUtils;
import com.elsevier.find.reviewers.utils.PersonDetailsUtils;
import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.util.DefaultUriBuilderFactory;

import java.io.IOException;
import java.net.URI;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Slf4j
@Service
public class PersonFinder {
    // The author name (authspan) and Scopus Ids (authid) are all in a text attribute with a separator
    private static final String AUTHOR_SEPARATOR = " \\| ";

    private static final Pattern yearPattern = Pattern.compile("^\\d{4}$");

    private static final Pattern hIndexPattern = Pattern.compile("^\\d+$");

    // SonarQube wants the finals to be static, but if they are they will not be serialised.
    @SuppressWarnings("java:S1170")
    @Data
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private static class PersonFinderPostRequest {
        @JsonProperty("authorKeywordFacets")
        private final boolean authorKeywordFacets = true;
        @JsonProperty("subjectCodeFacets")
        private final boolean subjectCodeFacets = true;
        @JsonProperty("useElasticSearch")
        private final boolean useElasticSearch = true;
        @JsonProperty("rankingModel")
        private final String rankingModel = "pf_recentPublishedModelWithIssnBoost";
        @JsonProperty("pageSize")
        private Integer pageSize;
        @JsonProperty("keyword")
        private String keyword;
        @JsonProperty("minYear")
        private Integer minYear;
        @JsonProperty("searchLogic")
        private String searchLogic;
        @JsonProperty("authorId")
        private String authorId;
        @JsonProperty("sort")
        private Map<String, String> sort;
        @JsonProperty("issnFacetFilters")
        private List<String> issnFacetFilters;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ScopusKeyword {
        @JsonProperty("keyword")
        private String keyword;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class KeywordCount {
        @JsonProperty("keyword")
        private String keyword;
        @JsonProperty("count")
        private Integer count;
    }

    // Stop SonarQube complaining about the attribute names with underscores
    @SuppressWarnings("squid:S00116")
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class PersonFinderScopusAuthor {
        // The author object contains more data that this, but we only extract what information we require
        @JsonProperty("authid")
        private String authid; // Scopus Id
        @JsonProperty("authemail")
        private String authemail; // email
        @JsonProperty("preffirst")
        private String preffirst; // Given/First name
        @JsonProperty("authlast")
        private String authlast; // Family/Last name
        @JsonProperty("afdispname")
        private String afdispname; // Affiliation Name
        @JsonProperty("afdispcity")
        private String afdispcity; // Affiliation City
        @JsonProperty("afdispctry")
        private String afdispctry; // Affiliation Country
        @JsonProperty("count")
        private Integer count; // Publication Count
        @JsonProperty("count_matching")
        private Integer count_matching; // Keyword match count
        @JsonProperty("num_cited_by")
        private Integer num_cited_by; // The number of citations
        @JsonProperty("h_index")
        private String h_index; // Author hIndex
        @JsonProperty("authkeywords")
        private List<ScopusKeyword> authkeywords; // Author keywords
        @JsonProperty("subjmain")
        private List<ScopusKeyword> subjmain; // Author subject areas
        @JsonProperty("issn")
        private List<KeywordCount> issn; // Journal Publication data (based on ISSNs requested)

        public String getFirstName() {
            if (preffirst == null || preffirst.isBlank()) {
                return null;
            }
            return preffirst.trim();
        }

        public String getLastName() {
            if (authlast == null || authlast.isBlank()) {
                return null;
            }
            return authlast.split(AUTHOR_SEPARATOR)[0].trim();
        }

        public Integer getHIndex() {
            Integer hIndex = null;
            if (h_index != null) {
                if (hIndexPattern.matcher(h_index).matches()) {
                    hIndex = Integer.parseUnsignedInt(h_index);
                } else {
                    // Log an error and continue, it is more important to be tolerant of invalid data
                    log.error("Person Finder supplied invalid hIndex {} for scopus Id {}", h_index, authid);
                }
            }
            return hIndex;
        }

        public List<String> getAuthorKeywords() {
            return authkeywords == null || authkeywords.isEmpty() ? null :
                    authkeywords.stream().map(ScopusKeyword::getKeyword).collect(Collectors.toList());
        }

        public List<String> getSubjectAreaCodes() {
            return subjmain == null || subjmain.isEmpty() ? null :
                    subjmain.stream().map(ScopusKeyword::getKeyword).collect(Collectors.toList());
        }

        public Integer getPublishedInJournalCount(String journalIssn) {
            if (journalIssn == null || issn == null || issn.isEmpty()) {
                return null;
            }
            int pubInJournalCount = issn.stream().filter(i -> journalIssn.equals(i.getKeyword()) && i.count != null)
                    .mapToInt(KeywordCount::getCount).sum();

            return pubInJournalCount == 0 ? null : pubInJournalCount;
        }
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class KeywordAuthors {
        @JsonProperty("authors")
        private List<PersonFinderScopusAuthor> authors;

        public List<PersonFinderScopusAuthor> cleanAuthors() {
            if (authors == null) {
                return Collections.emptyList();
            }
            // Authors without email addresses are of no use and make them lower case
            authors.removeIf(r -> !PersonDetailsUtils.isValidEmail(r.getAuthemail()));
            authors.forEach(r -> r.setAuthemail(r.getAuthemail().trim().toLowerCase()));
            return authors;
        }
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Publication {
        // The publication object contains more data that this, but we only extract what information we require
        @JsonProperty("eid")
        private String eid; // Unique Id to link to scopus for this publication
        @JsonProperty("itemtitle")
        private String itemtitle; // Publication title
        @JsonProperty("srctitle")
        private String srctitle; // Journal title
        @JsonProperty("numcitedby")
        private Integer numcitedby; // The number of citations
        @JsonProperty("pubyr")
        private String pubyr; // The year of the publication
        @JsonProperty("authspan")
        private String authspan; // List of Author names separated by ' | '
        @JsonProperty("authid")
        private String authid; // List of Author Scopus Id's separated by ' | '

        public String[] getAuthorNames() {
            return authspan == null ? new String[]{} : authspan.split(AUTHOR_SEPARATOR);
        }

        public String[] getAuthorIds() {
            return authid == null ? new String[]{} : authid.split(AUTHOR_SEPARATOR);
        }

        public Integer getPublicationYear() {
            Integer publicationYear = null;
            if (pubyr != null) {
                if (yearPattern.matcher(pubyr).matches()) {
                    publicationYear = Integer.parseUnsignedInt(pubyr);
                } else {
                    // Log an error and continue, it is more important to be tolerant of invalid data
                    log.error("Person Finder supplied invalid publication year {} for Id {}", pubyr, eid);
                }
            }
            return publicationYear;
        }
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ConflictOfInterests {
        @Data
        @JsonIgnoreProperties(ignoreUnknown = true)
        private static class Conflicts {
            private enum ConflictType {
                @JsonProperty("COAFFILIATION")
                @JsonAlias("CURRENT_COAFFILIATION")
                COAFFILIATION(Indicators.SAMEINSTITUTION),
                @JsonProperty("MANUSCRIPT_AUTHOR")
                MANUSCRIPT_AUTHOR(Indicators.MANUSCRIPTAUTHOR),
                @JsonProperty("RECENT_COAUTHOR")
                RECENT_COAUTHOR(Indicators.COAUTHORLAST5YEARS),
                @JsonProperty("SAME_COUNTRY")
                SAME_COUNTRY(Indicators.SAMECOUNTRY);

                @Getter
                private final Indicators indicator;

                ConflictType(Indicators indicator) {
                    this.indicator = indicator;
                }
            }

            @JsonProperty("conflictTypes")
            private List<ConflictType> conflictTypes;

            public List<Indicators> getIndicators() {
                if (conflictTypes == null) {
                    return Collections.emptyList();
                }
                return conflictTypes.stream().filter(Objects::nonNull).map(ConflictType::getIndicator).collect(Collectors.toList());
            }
        }

        @Data
        @JsonIgnoreProperties(ignoreUnknown = true)
        private static class ConflictOfInterest {
            @JsonProperty("reviewerId")
            private String reviewerId;
            @JsonProperty("conflicts")
            private List<Conflicts> conflicts;
        }

        @JsonProperty("conflictOfInterests")
        private List<ConflictOfInterest> conflictOfInterests;

        public Map<String, List<Indicators>> getAllConflicts() {
            Map<String, List<Indicators>> allConflicts = new HashMap<>();
            if (conflictOfInterests != null) {
                for (ConflictOfInterest conflictOfInterest : conflictOfInterests) {
                    if (conflictOfInterest.getReviewerId() != null && conflictOfInterest.getConflicts() != null) {
                        List<Indicators> indicators = conflictOfInterest.getConflicts().stream().map(Conflicts::getIndicators)
                                .flatMap(List::stream).distinct().collect(Collectors.toList());
                        if (!indicators.isEmpty()) {
                            allConflicts.computeIfAbsent(conflictOfInterest.getReviewerId(),
                                    i -> new ArrayList<>()).addAll(indicators);
                        }
                    }
                }
            }
            return allConflicts;
        }
    }

    private static final String ARGUMENT_URL = "URL";
    private static final String SCOPUS_ID = "scopusId";

    private final WebClient webClient;
    private final String personFinderBaseUrl;
    private final DefaultUriBuilderFactory uriBuilderFactory;
    private final ObjectMapper objectMapper;

    public PersonFinder(@Qualifier("personfinder") WebClient webClient,
                        ObjectMapper objectMapper,
                        @Value("${personfinder.client.base.url}") String personFinderBaseUrl) {
        this.webClient = webClient;
        this.objectMapper = objectMapper;
        this.personFinderBaseUrl = personFinderBaseUrl;
        uriBuilderFactory = new DefaultUriBuilderFactory(personFinderBaseUrl.endsWith("/") ?
                personFinderBaseUrl.substring(0, personFinderBaseUrl.length() - 1) : personFinderBaseUrl);
    }

    public KeywordAuthors getKeywordAuthors(String keywords,
                                            KeywordSearchLogic searchLogic,
                                            Integer publishedSince,
                                            String journalIssn) {
        final String url = String.format("%s/person", personFinderBaseUrl);

        PersonFinderPostRequest postBody = new PersonFinderPostRequest();
        postBody.setPageSize(160);
        postBody.setKeyword(KeywordUtils.cleanKeywordForQuery(keywords));
        postBody.setSearchLogic(KeywordUtils.getSearchLogicString(searchLogic));
        postBody.setMinYear(publishedSince);
        postBody.setSort(Map.of("order", "desc", "property", "relevance"));
        if (journalIssn != null && !journalIssn.isBlank()) {
            postBody.setIssnFacetFilters(List.of(journalIssn));
        }

        String rawResponse = null;
        KeywordAuthors authors = null;
        try {
            rawResponse = makePersonFinderCall(url, postBody);

            if (rawResponse != null && !rawResponse.isBlank()) {
                authors = objectMapper.readValue(rawResponse, KeywordAuthors.class);
            }
        } catch (IOException e) {
            log.error("Person Finder response for keyword search with keywords {} unexpected format {}", keywords, rawResponse, e);
            throw new InternalException(
                    ErrorResponse.IdEnum.PERSONFINDERFAILURE, HttpStatus.INTERNAL_SERVER_ERROR, Map.of("keywords", keywords));
        }

        return authors;
    }

    public List<Publication> getPublications(String scopusId, String keywords, KeywordSearchLogic searchLogic, Integer publishedSince) {
        final String url = String.format("%s/publications", personFinderBaseUrl);

        PersonFinderPostRequest postBody = new PersonFinderPostRequest();
        postBody.setAuthorId(scopusId);
        postBody.setKeyword(keywords == null || keywords.isBlank() ? null : KeywordUtils.cleanKeywordForQuery(keywords));
        postBody.setSearchLogic(keywords == null || keywords.isBlank() ? null : KeywordUtils.getSearchLogicString(searchLogic));
        postBody.setMinYear(publishedSince);

        String rawResponse = null;
        List<Publication> publications = null;
        try {
            rawResponse = makePersonFinderCall(url, postBody);

            if (rawResponse != null && !rawResponse.isBlank()) {
                Map<String, List<Publication>> fullResponse = objectMapper.readValue(rawResponse, new TypeReference<>() {
                });
                publications = fullResponse.get("publications");
            }
        } catch (IOException e) {
            log.error("Person Finder response for publications with Scopus Id {} unexpected format {}", scopusId, rawResponse, e);
            throw new InternalException(
                    ErrorResponse.IdEnum.PERSONFINDERFAILURE, HttpStatus.INTERNAL_SERVER_ERROR, Map.of(SCOPUS_ID, scopusId));
        }

        return publications == null ? Collections.emptyList() : publications;
    }

    public List<PersonFinderScopusAuthor> getScopusDetailsByIds(List<String> scopusIds) {
        String rawResponse = null;
        List<PersonFinderScopusAuthor> authors = null;
        try {
            URI uri = uriBuilderFactory.builder().path("/authors")
                    .queryParam("authorIds", String.join(",", scopusIds))
                    .build();

            final Instant start = Instant.now();

            rawResponse = makePersonFinderCall(uri);

            final long time = Duration.between(start, Instant.now()).toMillis();
            log.info("PERSONFINDER TIMINGS: Scopus count {}, duration {}", scopusIds.size(), time);

            if (rawResponse != null && !rawResponse.isBlank()) {
                authors = objectMapper.readValue(rawResponse, new TypeReference<>() {
                });
            }
        } catch (IOException e) {
            log.error("Person Finder response for author search with Scopus Ids {} unexpected format {}", scopusIds, rawResponse, e);
        }

        return authors == null ? Collections.emptyList() : authors;
    }

    public Map<String, List<Indicators>> getConflictOfInterests(List<String> authorScopusIds,
                                                                List<String> reviewerScopusIds) {
        String rawResponse = null;
        ConflictOfInterests conflicts = null;
        try {
            URI uri = uriBuilderFactory.builder().path("/conflict-of-interests")
                    .queryParam("manuscriptAuthorIds", String.join(",", authorScopusIds))
                    .queryParam("reviewerIds", String.join(",", reviewerScopusIds))
                    .build();

            rawResponse = makePersonFinderCall(uri);

            if (rawResponse != null && !rawResponse.isBlank()) {
                conflicts = objectMapper.readValue(rawResponse, ConflictOfInterests.class);
            }
        } catch (IOException e) {
            log.error("Person Finder response for Conflict of Interest with authorScopusIds {} and reviewerScopusIds {} unexpected format {}",
                    authorScopusIds, reviewerScopusIds, rawResponse, e);
            throw new InternalException(
                    ErrorResponse.IdEnum.PERSONFINDERFAILURE, HttpStatus.INTERNAL_SERVER_ERROR,
                    Map.of("authorScopusIds", String.join(",", authorScopusIds),
                            "reviewerIds ", String.join(",", reviewerScopusIds)));
        }

        return conflicts == null ? Collections.emptyMap() : conflicts.getAllConflicts();
    }

    /**
     * Makes the API request to the Person Finder system with all the correct authentication
     *
     * @param url The URL specifics to be called (with all parameters)
     * @return The text returned from the request
     */
    private String makePersonFinderCall(URI url) {
        final String traceToken = getTraceToken();
        log.info("Making Person Finder API {} (Trace-Token: {}) request", url, traceToken);

        String response = null;
        try {
            response = webClient.get().uri(url)
                    .header("X-FR-Trace-Token", traceToken)
                    .accept(MediaType.APPLICATION_JSON)
                    .retrieve()
                    .bodyToMono(String.class)
                    // Subscribe to this Mono and block until a next signal is received or a timeout expires.
                    // Returns that value, or null if the Mono completes empty.
                    .block(Duration.ofSeconds(20));

        } catch (WebClientResponseException e) {
            // WebClient throws an exception by default when a 4xx or 5xx error is received, need to strip out the
            // 404 - Not Found one as it may be there was no data available in Person Finder that we were requesting
            // and that is not really an error case for us
            if (e.getStatusCode() == HttpStatus.NOT_FOUND) {
                log.warn("Entry not found for Person Finder API {} (Trace-Token: {}) HttpStatusCode = {}, HttpHeaders = {}, ResponseBody = {}",
                        url, traceToken, e.getStatusCode(), e.getHeaders(), e.getResponseBodyAsString());
                response = null;
            } else {
                ErrorResponse.IdEnum errorEnum = ErrorResponse.IdEnum.PERSONFINDERFAILURE;
                if (e.getStatusCode() == HttpStatus.BAD_REQUEST && e.getResponseBodyAsString().contains("PF-02")) {
                    log.warn("Bad Request error calling Person Finder API {} (Trace-Token: {}) HttpStatusCode = {}, HttpHeaders = {}, ResponseBody = {}",
                            url, traceToken, e.getStatusCode(), e.getHeaders(), e.getResponseBodyAsString());
                    errorEnum = ErrorResponse.IdEnum.LIMITEXCEEDED;
                } else {
                    log.error("Error calling Person Finder API {} (Trace-Token: {}) HttpStatusCode = {}, HttpHeaders = {}, ResponseBody = {}",
                            url, traceToken, e.getStatusCode(), e.getHeaders(), e.getResponseBodyAsString());
                }
                throw new InternalException(errorEnum, HttpStatus.INTERNAL_SERVER_ERROR, Map.of(ARGUMENT_URL, url.toString()));
            }
        } catch (Exception e) {
            log.error("Exception calling Person Finder API {} (Trace-Token: {})", url, traceToken, e);
            throw new InternalException(ErrorResponse.IdEnum.PERSONFINDERFAILURE, HttpStatus.INTERNAL_SERVER_ERROR,
                    Map.of(ARGUMENT_URL, url.toString()));
        }

        log.info("Person Finder API {} (Trace-Token: {}) completed", url, traceToken);
        return response;
    }

    private String makePersonFinderCall(String url, PersonFinderPostRequest requestBody) {
        final String traceToken = getTraceToken();
        log.info("Making Person Finder POST API {} (Trace-Token: {}) request with body {}", url, traceToken, requestBody);

        String response = null;
        try {
            response = webClient.post()
                    .uri(url)
                    .header("X-FR-Trace-Token", traceToken)
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(objectMapper.writeValueAsString(requestBody))
                    .retrieve()
                    .bodyToMono(String.class)
                    // Subscribe to this Mono and block until a next signal is received or a timeout expires.
                    // Returns that value, or null if the Mono completes empty.
                    .block(Duration.ofSeconds(20));

        } catch (WebClientResponseException e) {
            // WebClient throws an exception by default when a 4xx or 5xx error is received, need to strip out the
            // 404 - Not Found one as it may be there was no data available in Person Finder that we were requesting
            // and that is not really an error case for us
            if (e.getStatusCode() == HttpStatus.NOT_FOUND) {
                log.warn("Entry not found for Person Finder API {} (Trace-Token: {}) HttpStatusCode = {}, HttpHeaders = {}, ResponseBody = {}",
                        url, traceToken, e.getStatusCode(), e.getHeaders(), e.getResponseBodyAsString(), e);
                response = null;
            } else {
                log.error("Error calling Person Finder API {} (Trace-Token: {}) HttpStatusCode = {}, HttpHeaders = {}, ResponseBody = {} for request = {}",
                        url, traceToken, e.getStatusCode(), e.getHeaders(), e.getResponseBodyAsString(), requestBody, e);
                throw new InternalException(ErrorResponse.IdEnum.PERSONFINDERFAILURE,
                        HttpStatus.INTERNAL_SERVER_ERROR, Map.of(ARGUMENT_URL, url));
            }
        } catch (Exception e) {
            log.error("Exception calling Person Finder API {} (Trace-Token: {})", url, traceToken, e);
            throw new InternalException(ErrorResponse.IdEnum.PERSONFINDERFAILURE, HttpStatus.INTERNAL_SERVER_ERROR,
                    Map.of(ARGUMENT_URL, url));
        }

        log.info("Person Finder POST API {} (Trace-Token: {}) completed", url, traceToken);
        return response;
    }

    /**
     * Gets the trace token to send with API calls, default to the correlationId we use for logging
     * and if that is not set default one
     *
     * @return Trace token string
     */
    private String getTraceToken() {
        return ThreadContext.containsKey("correlationId") ? ThreadContext.get("correlationId") : UUID.randomUUID().toString();
    }
}
