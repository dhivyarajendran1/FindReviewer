package com.elsevier.find.reviewers.service.base;

import com.elsevier.find.reviewers.dao.AdditionalInfoDao;
import com.elsevier.find.reviewers.dao.BaseDao.AdditionalInfo;
import com.elsevier.find.reviewers.dao.CandidateInfoDao;
import com.elsevier.find.reviewers.dao.CandidateInfoDao.ReviewStatistics;
import com.elsevier.find.reviewers.external.EmSupport;
import com.elsevier.find.reviewers.external.PersonFinder;
import com.elsevier.find.reviewers.external.PersonFinder.PersonFinderScopusAuthor;
import com.elsevier.find.reviewers.external.ScopusSharedSearchAbstract;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.generated.model.Indicators;
import com.elsevier.find.reviewers.generated.model.KeywordSearchLogic;
import com.elsevier.find.reviewers.generated.model.PersonDetails;
import com.elsevier.find.reviewers.generated.model.PersonDetailsReviewStatistics;
import com.elsevier.find.reviewers.generated.model.ScopusSearchAuthor;
import com.elsevier.find.reviewers.utils.Analytics;
import com.elsevier.find.reviewers.utils.Constants;
import com.elsevier.find.reviewers.utils.PersonDetailsUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Slf4j
@Service
public class PersonDetailsSupportService extends BaseService {
    private static final int PERSON_FINDER_BATCH_SIZE = 200;
    private static final int SHARED_SEARCH_BATCH_SIZE = 34;

    private final Analytics analytics;

    private final EmSupport emSupport;

    private final ScopusSharedSearchAbstract scopusSharedSearchAbstract;

    private final PersonFinder personFinder;

    private final AdditionalInfoDao additionalInfoDao;

    private final CandidateInfoDao candidateInfoDao;

    public PersonDetailsSupportService(ObjectMapper objectMapper,
                                       Analytics analytics,
                                       EmSupport emSupport,
                                       ScopusSharedSearchAbstract scopusSharedSearchAbstract,
                                       PersonFinder personFinder,
                                       AdditionalInfoDao additionalInfoDao,
                                       CandidateInfoDao candidateInfoDao) {
        super(objectMapper);
        this.analytics = analytics;
        this.emSupport = emSupport;
        this.scopusSharedSearchAbstract = scopusSharedSearchAbstract;
        this.personFinder = personFinder;
        this.additionalInfoDao = additionalInfoDao;
        this.candidateInfoDao = candidateInfoDao;
    }

    // Ignore SonarQube complaining about the complexity, it isn't that complex
    @SuppressWarnings("squid:S3776")
    public <T extends PersonDetails> List<T> gatherAdditionalData(String emJournalAcronym,
                                                                  DataGatherRules<T> rules) {
        // The data that is required to add the required information to the person object means that multiple
        // different calls are required. As this would be slow to do them in serial the calls are all made
        // at the same time and then the results grouped together

        // Note: These CompletableFuture calls could, in theory, make use for the thenApply option. However, because
        //       the response from the calls would result in the same structure being updating there
        //       is a chance that threading issues could be experienced trying to update/remove the same entry
        //       because of this the responses are dealt with one after another.
        CompletableFuture<Map<String, AdditionalInfo>> internalDbDataFuture = createAsyncFuture(() -> {
            Map<String, AdditionalInfo> additionalInfo = null;
            if (rules.isInternalDbData()) {
                if (!SessionContext.isElsevierJournal()) {
                    additionalInfo = additionalInfoDao.getInoperativeByEmail(rules.getEmails());
                } else {
                    additionalInfo = additionalInfoDao.getAdditionalInfoByEmail(emJournalAcronym, rules.getEmails());
                }
            }
            return additionalInfo == null ? Collections.emptyMap() : additionalInfo;
        });

        CompletableFuture<List<String>> blockedEmails = createAsyncFuture(
                () -> rules.isBlockList() ? emSupport.getBlockedEmails(emJournalAcronym, rules.getEmails()) : Collections.emptyList());

        CompletableFuture<Map<String, ReviewStatistics>> reviewStatsByEmail = createAsyncFuture(
                () -> rules.isReviewStatistics() ? candidateInfoDao.getReviewStatistics(rules.getEmails()) : Collections.emptyMap());

        CompletableFuture<Map<String, PersonFinderScopusAuthor>> scopusDataFuture = createAsyncFuture(
                () -> rules.isScopusData() ? getScopusAuthorData(rules.getScopusIds()) : Collections.emptyMap());

        CompletableFuture<Map<String, ScopusSearchAuthor>> contentMatchFuture = createAsyncFuture(
                () -> rules.isContentMatch() ? getContentMatch(rules.getScopusIds(), rules.getKeywords(), rules.getSearchLogic())
                        : Collections.emptyMap());

        // Now that all the calls have been made for the data we can wait for the responses and then start processing
        // the required updates. The following are ordered in which call we expect to return first, Review history is
        // first as it is needed for reviewer preference handling
        List<T> personDetails = handleReviewStatistics(rules.getCandidateDetails(), waitAndGetFutureContent(reviewStatsByEmail),
                rules.isApplyRemovalRules());
        personDetails = handleAdditionalInfo(emJournalAcronym, personDetails,
                waitAndGetFutureContent(internalDbDataFuture));
        handleBlockList(personDetails, waitAndGetFutureContent(blockedEmails));

        Map<String, PersonFinderScopusAuthor> scopusAuthorData = waitAndGetFutureContent(scopusDataFuture);
        Map<String, ScopusSearchAuthor> contentMatchDetails = waitAndGetFutureContent(contentMatchFuture);

        if (!scopusAuthorData.isEmpty() || !contentMatchDetails.isEmpty()) {
            for (PersonDetails person : personDetails) {
                if (person.getScopusIds() != null) {
                    PersonDetailsUtils.setScopusData(person, scopusAuthorData.get(person.getScopusIds().get(0)));
                    if (contentMatchDetails.containsKey(person.getScopusIds().get(0))) {
                        ScopusSearchAuthor contentMatchAuthor = contentMatchDetails.get(person.getScopusIds().get(0));
                        person.setKeywords(contentMatchAuthor.getKeywords());
                        person.setSubjectAreas(contentMatchAuthor.getSubjectAreas());

                        // We know that the rules class enforces the correct person type for Content Match (but verify anyway)
                        if (person instanceof ScopusSearchAuthor) {
                            ((ScopusSearchAuthor) person).setKeywordMatchCount(contentMatchDetails.get(
                                    person.getScopusIds().get(0)).getKeywordMatchCount());
                        }
                    }
                }
            }
        }

        if (personDetails.isEmpty()) {
            log.warn("All entries removed by block list or preferences for journal {}", emJournalAcronym);
        }

        return personDetails;
    }

    private Map<String, PersonFinderScopusAuthor> getScopusAuthorData(List<String> scopusIds) {
        // Make a threadsafe map to store all the Scopus details, this we be written to by each thread that
        // is retrieving the scopus details in batches
        ConcurrentHashMap<String, PersonFinderScopusAuthor> scopusDetails = new ConcurrentHashMap<>();
        List<CompletableFuture<Void>> scopusCalls = new ArrayList<>();

        // Scopus lookup requests are split into batches as getting too large a batch takes a long time, and we can not
        // request too many in one go, if it takes too long to get the details then the interface will time out
        int processedIndex = 0;
        while (processedIndex < scopusIds.size()) {
            List<String> idsBatch = scopusIds.subList(processedIndex,
                    Math.min(processedIndex + PERSON_FINDER_BATCH_SIZE, scopusIds.size()));

            scopusCalls.add(createAsyncFuture(() -> personFinder.getScopusDetailsByIds(idsBatch))
                    .thenAccept(ids -> ids.forEach(a -> scopusDetails.put(a.getAuthid(), a))));

            processedIndex += PERSON_FINDER_BATCH_SIZE;
        }

        waitAndJoinFutures(scopusCalls);

        return scopusDetails;
    }

    private Map<String, ScopusSearchAuthor> getContentMatch(List<String> scopusIds,
                                                            String keywords,
                                                            KeywordSearchLogic searchLogic) {
        // Make a threadsafe map to store all the Content match details, this we be written to by each thread that
        // is retrieving the details in batches
        Map<String, ScopusSearchAuthor> contentMatchByAuthor = new ConcurrentHashMap<>();

        List<CompletableFuture<Void>> contentMatchCalls = new ArrayList<>();

        // Scopus lookup requests are split into batches as getting too large a batch takes a long time, and we can not
        // request too many in one go, if it takes too long to get the details then the interface will time out
        int processedIndex = 0;
        while (processedIndex < scopusIds.size()) {
            List<String> idsBatch = scopusIds.subList(processedIndex,
                    Math.min(processedIndex + SHARED_SEARCH_BATCH_SIZE, scopusIds.size()));

            contentMatchCalls.add(createAsyncFuture(() -> scopusSharedSearchAbstract.getContentMatchPublications(
                    keywords, searchLogic, idsBatch)).thenAccept(
                    // This makes use of the Concurrent threadsafe map, so we want to keep it together
                    // with the map that it is updating which is why it is not in another method
                    s -> s.forEach(content -> {
                        // There will be several authors listed that will have the same keywords and subject areas
                        // so convert and format them, then apply them to each author
                        final List<String> subjectAreas = Constants.getScopusSubjectAreaDescriptions(content.getSubjmain());
                        final List<String> keywordList = (content.getAuthkeywords() == null) ? Collections.emptyList() :
                                content.getAuthkeywords().stream().map(String::toLowerCase).collect(Collectors.toList());

                        content.getAuthors().forEach(author -> {
                            ScopusSearchAuthor sa = contentMatchByAuthor.computeIfAbsent(author.getAuthid(),
                                    a -> new ScopusSearchAuthor().keywordMatchCount(0));

                            sa.setKeywordMatchCount(sa.getKeywordMatchCount() + 1);
                            keywordList.forEach(sa::addKeywordsItem);
                            if (subjectAreas != null) {
                                subjectAreas.forEach(sa::addSubjectAreasItem);
                            }
                        });
                    })));

            processedIndex += SHARED_SEARCH_BATCH_SIZE;
        }

        waitAndJoinFutures(contentMatchCalls);

        // At this point we have all the data - we need to tidy up the keywords and subject areas as
        // we want to remove duplicates and order on frequency
        for (ScopusSearchAuthor details : contentMatchByAuthor.values()) {
            details.setKeywords(uniqueFrequencySort(details.getKeywords()));
            details.setSubjectAreas(uniqueFrequencySort(details.getSubjectAreas()));
        }

        return contentMatchByAuthor;
    }

    // Prevent SonarQube complaining about returning null
    @SuppressWarnings("java:S1168")
    private List<String> uniqueFrequencySort(List<String> source) {
        if (source == null) {
            return null;
        }
        // Remove duplicates and order by the number of occurrences - the highest first
        return source.stream().sorted(Comparator.comparing(i -> Collections.frequency(source, i)).reversed())
                .distinct().collect(Collectors.toList());
    }

    // Ignore SonarQube complaining about the complexity, it isn't that complex
    @SuppressWarnings("squid:S3776")
    private <T extends PersonDetails> List<T> handleReviewStatistics(List<T> personDetails,
                                                                     Map<String, ReviewStatistics> reviewStatsByEmail,
                                                                     boolean applyRemovalRules) {
        List<T> remainingUsers = personDetails;

        if (reviewStatsByEmail != null) {
            remainingUsers = new ArrayList<>();
            for (T person : personDetails) {
                if (!person.getEmails().isEmpty()) {
                    ReviewStatistics reviewStatistics = reviewStatsByEmail.get(person.getEmails().get(0));
                    if (reviewStatistics != null) {
                        if (applyRemovalRules && reviewStatistics.toRemove()) {
                            continue;
                        }
                        person.setReviewStatistics(reviewStatistics.getStatistics());
                    }
                }
                remainingUsers.add(person);
            }
        }

        if (applyRemovalRules && remainingUsers.size() < personDetails.size()) {
            final int personRemovedCount = personDetails.size() - remainingUsers.size();
            log.info("UNRESPONSIVE REVIEWERS: {} reviewers blocked ({} remaining)", personRemovedCount, remainingUsers.size());
            analytics.recordUnresponsiveReviewer(personRemovedCount);
        }

        return remainingUsers;
    }

    private void handleBlockList(List<? extends PersonDetails> personDetails, List<String> blockedEmails) {
        // There is a block list that contains a list of emails of users that should never be contacted
        // to invite for reviews. These users need to be stripped from any search results
        if (!blockedEmails.isEmpty()) {
            personDetails.removeIf(a -> blockedEmails.contains(a.getEmails().get(0)));
            analytics.recordBlocklistReviewer(blockedEmails.size());
        }
    }

    // Ignore SonarQube complaining about the complexity, it isn't that complex
    @SuppressWarnings("squid:S3776")
    private <T extends PersonDetails> List<T> handleAdditionalInfo(String emJournalAcronym,
                                                                   List<T> personDetails,
                                                                   Map<String, AdditionalInfo> additionalInfoByEmail) {
        int personRemovedCount = 0;
        int personAvailabilityCount = 0;
        int concurrentReviewLimitCount = 0;

        List<T> remainingUsers = new ArrayList<>();

        for (T person : personDetails) {
            PersonDetailsUtils.setDisplayName(person);
            AdditionalInfo additionalInfo = additionalInfoByEmail.get(person.getEmails().isEmpty() ? "" : person.getEmails().get(0));
            if (additionalInfo != null) {
                if (!additionalInfo.isValidUser()) {
                    personRemovedCount++;
                } else if (additionalInfo.isUnavailable()) {
                    personAvailabilityCount++;
                } else if (additionalInfo.getConcurrentReviewLimit() > 0 &&
                        getInProgressReviewCount(person) >= additionalInfo.getConcurrentReviewLimit()) {
                    concurrentReviewLimitCount++;
                } else {
                    if (additionalInfo.isVolunteer()) {
                        person.addIndicatorsItem(Indicators.VOLUNTEERTHISJOURNAL);
                    }
                    if (additionalInfo.isRecentAuthorThisJournal()) {
                        person.addIndicatorsItem(Indicators.RECENTLYACCEPTEDAUTHORTHISJOURNAL);
                    }
                    if (additionalInfo.isRecentAuthorOtherJournal()) {
                        person.addIndicatorsItem(Indicators.RECENTLYACCEPTEDAUTHOROTHERJOURNAL);
                    }
                    if (additionalInfo.isForbiddenReviewer()) {
                        person.addIndicatorsItem(Indicators.FORBIDDENREVIEWER);
                    }
                    if (additionalInfo.isEBM()) {
                        person.addIndicatorsItem(Indicators.EDITORIALBOARDMEMBER);
                    }
                    if (additionalInfo.getEditorialHistoryCount() > 0) {
                        person.setEditorialHistoryCount(additionalInfo.getEditorialHistoryCount());
                    }
                    remainingUsers.add(person);
                }
            } else {
                remainingUsers.add(person);
            }
        }

        if (personRemovedCount > 0) {
            log.info("INVALID REVIEWERS: {} reviewers blocked for journal {} ({} remaining)", personRemovedCount,
                    emJournalAcronym, remainingUsers.size());
            analytics.recordInoperativeReviewer(personRemovedCount);
        }
        recordPersonPreferences(personAvailabilityCount, concurrentReviewLimitCount, remainingUsers.size());

        return remainingUsers;
    }

    private void recordPersonPreferences(int personAvailabilityCount, int concurrentReviewLimitCount, int remaining) {
        final int totalRemoved = personAvailabilityCount + concurrentReviewLimitCount;
        if (totalRemoved > 0) {
            log.info("USER PREFERENCES: {} reviewers removed due to reviewer preferences ({} remaining)",
                    totalRemoved, remaining);

            if (personAvailabilityCount > 0) {
                analytics.recordReviewerAvailability(personAvailabilityCount);
            }
            if (concurrentReviewLimitCount > 0) {
                analytics.recordReviewerConcurrentLimit(concurrentReviewLimitCount);
            }
        }
    }

    private long getInProgressReviewCount(PersonDetails person) {
        List<PersonDetailsReviewStatistics> reviewStats = person.getReviewStatistics();
        long inProgress = 0;

        if (reviewStats != null) {
            for (PersonDetailsReviewStatistics stats : reviewStats) {
                inProgress += stats.getWorkInProgressCount();
            }
        }
        return inProgress;
    }
}
