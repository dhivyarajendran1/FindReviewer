package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.dao.ManuscriptDao;
import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.external.EditorialManagerWebApi;
import com.elsevier.find.reviewers.external.EditorialManagerWebApi.EmWebApiManuscript;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.generated.api.ManuscriptsApiDelegate;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.generated.model.ManuscriptDetails;
import com.elsevier.find.reviewers.service.base.BaseService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;

/**
 * Class to handle all requests on the manuscripts endpoint
 */
@Slf4j
@Service
public class ManuscriptsService extends BaseService implements ManuscriptsApiDelegate {

    private final ManuscriptDao manuscriptDao;

    private final EditorialManagerWebApi editorialManagerWebApi;

    public ManuscriptsService(ObjectMapper objectMapper,
                              ManuscriptDao manuscriptDao,
                              EditorialManagerWebApi editorialManagerWebApi) {
        super(objectMapper);
        this.manuscriptDao = manuscriptDao;
        this.editorialManagerWebApi = editorialManagerWebApi;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class, readOnly = true)
    public ResponseEntity<ManuscriptDetails> getManuscript(String emJournalAcronym, Long documentId, String xScope) {

        if (emJournalAcronym == null || emJournalAcronym.isBlank() || documentId == null) {
            final Map<String, String> args = Map.of("emJournalAcronym", String.valueOf(emJournalAcronym),
                    "documentId", String.valueOf(documentId));
            log.error("Manuscript request made without EM Journal Acronym or Document Id {}", args);
            throw new InternalException(ErrorResponse.IdEnum.INVALIDARGUMENT, HttpStatus.BAD_REQUEST, args);
        }

        log.info("Manuscript details request for journal {} and document Id {}", emJournalAcronym, documentId);

        ManuscriptDetails response;

        if (SessionContext.isUrsdbJournal()) {
            response = manuscriptDao.getManuscriptDetails(emJournalAcronym, documentId);
        } else {
            response = new ManuscriptDetails();
            EmWebApiManuscript emManuscript = editorialManagerWebApi.getManuscript(emJournalAcronym, documentId);
            if (emManuscript != null) {
                response.setManuscriptNumber(emManuscript.getSubmissionId());
                response.setTitle(emManuscript.getSubmissionTitle());
                response.setAbstract(emManuscript.getAbstractText());
            }
        }

        log.debug("Manuscript details response for journal {} and document Id {} {}", emJournalAcronym, documentId, response);

        return ResponseEntity.ok().body(response);
    }
}
