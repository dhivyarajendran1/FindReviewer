package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.dao.AdditionalInfoDao;
import com.elsevier.find.reviewers.dao.AdditionalInfoDao.ClassificationItem;
import com.elsevier.find.reviewers.dao.AdditionalInfoDao.InitialisationInfo;
import com.elsevier.find.reviewers.dao.ManuscriptDao;
import com.elsevier.find.reviewers.enums.ProductType;
import com.elsevier.find.reviewers.enums.ReviewerStatusType;
import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.external.EditorialManager;
import com.elsevier.find.reviewers.external.EditorialManager.Reviewer;
import com.elsevier.find.reviewers.external.EditorialManagerWebApi;
import com.elsevier.find.reviewers.external.EditorialManagerWebApi.EmWebApiAuthor;
import com.elsevier.find.reviewers.external.EditorialManagerWebApi.EmWebApiManuscript;
import com.elsevier.find.reviewers.external.EditorialManagerWebApi.EmWebApiManuscript.EmWebApiManuscriptKeywords;
import com.elsevier.find.reviewers.external.EditorialManagerWebApi.EmWebApiReviewer;
import com.elsevier.find.reviewers.external.ScopusSharedSearchPeople;
import com.elsevier.find.reviewers.external.ScopusSources;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.generated.api.InitialisationApiDelegate;
import com.elsevier.find.reviewers.generated.model.ClassificationDetails;
import com.elsevier.find.reviewers.generated.model.ClassificationTree;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.generated.model.InitialisationDetails;
import com.elsevier.find.reviewers.generated.model.InitialisationDetailsCrowdsourcedReviewers;
import com.elsevier.find.reviewers.generated.model.PersonBase;
import com.elsevier.find.reviewers.generated.model.ReviewerDetails;
import com.elsevier.find.reviewers.generated.model.ReviewerStatus;
import com.elsevier.find.reviewers.service.base.BaseService;
import com.elsevier.find.reviewers.utils.Constants;
import com.elsevier.find.reviewers.utils.Constants.JournalIds;
import com.elsevier.find.reviewers.utils.KeywordUtils;
import com.elsevier.find.reviewers.utils.PersonDetailsUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Class to handle all requests on the initialisation endpoint
 */
@Slf4j
@Service
public class InitialisationService extends BaseService implements InitialisationApiDelegate {

    private final ManuscriptDao manuscriptDao;

    private final AdditionalInfoDao additionalInfoDao;

    private final EditorialManager editorialManager;

    private final EditorialManagerWebApi editorialManagerWebApi;

    private final ScopusSharedSearchPeople scopusSharedSearchPeople;

    private final ScopusSources scopusSources;

    protected InitialisationService(ObjectMapper objectMapper,
                                    ManuscriptDao manuscriptDao,
                                    AdditionalInfoDao additionalInfoDao,
                                    EditorialManager editorialManager,
                                    EditorialManagerWebApi editorialManagerWebApi,
                                    ScopusSharedSearchPeople scopusSharedSearchPeople,
                                    ScopusSources scopusSources) {
        super(objectMapper);
        this.manuscriptDao = manuscriptDao;
        this.additionalInfoDao = additionalInfoDao;
        this.editorialManager = editorialManager;
        this.editorialManagerWebApi = editorialManagerWebApi;
        this.scopusSharedSearchPeople = scopusSharedSearchPeople;
        this.scopusSources = scopusSources;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class, readOnly = true)
    public ResponseEntity<InitialisationDetails> getInitialisation(String xScope, String emJournalAcronym, Long documentId) {
        log.info("Initialisation details request for journal {} and document Id {}", emJournalAcronym, documentId);

        InitialisationDetails response = null;
        if (emJournalAcronym != null && !emJournalAcronym.isBlank() && documentId != null) {
            if (SessionContext.isUrsdbJournal()) {
                // Elsevier Journal
                response = ursdbInitialisation(emJournalAcronym, documentId);
            } else {
                // Non-Elsevier Journal (This also covers the Cell and Lancet Special cases)
                response = nonUrsdbInitialisation(emJournalAcronym, documentId);
                response.setIsElsevier(SessionContext.isElsevierJournal());
            }
        } else {
            // Only Find Editors can be launched without Journal details or document Id
            if (!ProductType.FindEditors.equals(SessionContext.getProductType())) {
                log.error("Find Reviewers initialisation called without Journal {} or document Id {}", emJournalAcronym,
                        documentId);
                throw new InternalException(ErrorResponse.IdEnum.INVALIDARGUMENT,
                        HttpStatus.BAD_REQUEST, Map.of("emJournalAcronym", String.valueOf(emJournalAcronym),
                        "documentId", String.valueOf(documentId)));
            }
            response = findEditorsInitialisation(emJournalAcronym);
        }

        log.info("Initialisation details response for journal {} and document Id {} {}", emJournalAcronym, documentId, response);

        return ResponseEntity.ok().body(response);
    }

    private InitialisationDetails ursdbInitialisation(String emJournalAcronym, Long documentId) {
        CompletableFuture<List<ReviewerDetails>> reviewersFuture = createAsyncFuture(() -> {
            // Only make the call to EM if we do not have a Readonly token as we will not have a valid bearer token
            if (SessionContext.isReadOnly() || SessionContext.isIdPlusAuthenticated()) {
                return Collections.emptyList();
            }
            List<Reviewer> emReviewer = editorialManager.getReviewers(emJournalAcronym, documentId);

            return emReviewer.stream().map(this::convertReviewer).collect(Collectors.toList());
        });

        CompletableFuture<InitialisationInfo> journalInfoFuture = createAsyncFuture(
                () -> additionalInfoDao.getInitialisationInfo(emJournalAcronym, documentId));

        // A couple of requests have been kicked off in threads, the remaining data can be collected in the
        // main thread
        InitialisationDetails response = manuscriptDao.getInitialisationDetails(emJournalAcronym, documentId);
        if (response == null) {
            log.debug("No manuscript data found for EM Journal Acronym {} Document Id {}", emJournalAcronym, documentId);
            response = new InitialisationDetails();
        }
        response.addPermittedFeaturesItem(InitialisationDetails.PermittedFeaturesEnum.ADDEDREVIEWERS);
        response.addPermittedFeaturesItem(InitialisationDetails.PermittedFeaturesEnum.AUTHORSEARCH);
        response.addPermittedFeaturesItem(InitialisationDetails.PermittedFeaturesEnum.KEYWORDSEARCH);
        response.addPermittedFeaturesItem(InitialisationDetails.PermittedFeaturesEnum.SESSIONPREFERENCES);
        response.addPermittedFeaturesItem(InitialisationDetails.PermittedFeaturesEnum.RECOMMENDATIONS);
        response.addPermittedFeaturesItem(InitialisationDetails.PermittedFeaturesEnum.VOLUNTEERS);
        response.addPermittedFeaturesItem(InitialisationDetails.PermittedFeaturesEnum.MANUSCRIPTDETAILS);
        response.addPermittedFeaturesItem(InitialisationDetails.PermittedFeaturesEnum.REVIEWERHISTORY);
        response.addPermittedFeaturesItem(InitialisationDetails.PermittedFeaturesEnum.REVIEWERLIMITS);
        response.addPermittedFeaturesItem(InitialisationDetails.PermittedFeaturesEnum.JOURNALREVIEWERS);

        // Once we have the initial data we need to do a lookup for Scopus Ids of the authors. We do not need to do
        // this in its own thread as everything else is already running in its own thread, so it will not block anything
        populateScopusIdsForAuthors(response);

        // Reviewers are read from a mix of URSDB and the EM API so need to merge them otherwise there will be duplicates
        List<ReviewerDetails> reviewers = waitAndGetFutureContent(reviewersFuture);
        response.setReviewers(mergeReviewers(response.getReviewers(), reviewers));

        InitialisationInfo journalInfo = waitAndGetFutureContent(journalInfoFuture);
        if (journalInfo != null) {
            response.setJournalIssnl(journalInfo.getIssnL());
            response.setJournalClassifications(getJournalClassifications(journalInfo.getClassifications()));
            response.setCrowdsourcedReviewers(
                    getCrowdsourcedReviewers(journalInfo.getCrowdsourcedReviewers(), response.getReviewers()));

            // We do not have the EBM list for all journals, so only enable if we have the data
            if (journalInfo.isHasEBMs()) {
                response.addPermittedFeaturesItem(InitialisationDetails.PermittedFeaturesEnum.EDITORIALBOARDMEMBERS);
            }
        }

        return response;
    }

    // Ignore SonarQube complaining about the complexity, it isn't that complex
    @SuppressWarnings("squid:S3776")
    private InitialisationDetails nonUrsdbInitialisation(String emJournalAcronym, Long documentId) {
        final JournalIds journalIds = Constants.nonUrsdbElsevierJournals.get(emJournalAcronym.trim().toUpperCase());

        CompletableFuture<List<ReviewerDetails>> reviewersFuture = createNonElsevierReviewersFuture(emJournalAcronym, documentId);

        CompletableFuture<InitialisationDetails> authorsFuture = createNonElsevierAuthorsFuture(emJournalAcronym, documentId);

        CompletableFuture<Boolean> hasEBMsFuture = createAsyncFuture(() -> {
            if (journalIds != null) {
                InitialisationInfo info = additionalInfoDao.getInitialisationInfo(journalIds.getAcronym(), journalIds.getIssn());
                return info != null && info.isHasEBMs();
            }
            return false;
        });

        // While the other threads run to get the reviewers and authors, gather the information about the manuscript
        EmWebApiManuscript manuscript = editorialManagerWebApi.getManuscript(emJournalAcronym, documentId);

        InitialisationDetails response = new InitialisationDetails();
        if (manuscript != null) {
            if (manuscript.getKeywords() != null) {
                final List<String> cleanedKeywords = KeywordUtils.processKeywords(
                        manuscript.getKeywords().stream()
                                .filter(k -> k.getWord() != null && !k.getWord().isBlank())
                                .map(EmWebApiManuscriptKeywords::getWord)
                                .collect(Collectors.toList()));
                response.setKeywords(cleanedKeywords.isEmpty() ? null : cleanedKeywords);
            }
            if (manuscript.getClassifications() != null) {
                manuscript.getClassifications().stream()
                        .filter(c -> c.getDescription() != null && !c.getDescription().isBlank())
                        .map(c -> {
                            ClassificationDetails details = new ClassificationDetails();
                            details.setDescription(c.getDescription());
                            return details;
                        }).forEach(response::addClassificationsItem);
            }

            if (journalIds == null && manuscript.getJournalName() != null && !manuscript.getJournalName().isBlank()) {
                response.setJournalIssnl(scopusSources.getJournalIssn(manuscript.getJournalName()));
            }
        }

        // Now wait for the requests to start completing
        InitialisationDetails authors = waitAndGetFutureContent(authorsFuture);
        response.setCorrespondingAuthors(authors.getCorrespondingAuthors());
        response.setCoAuthors(authors.getCoAuthors());

        List<ReviewerDetails> reviewers = waitAndGetFutureContent(reviewersFuture);
        reviewers.forEach(response::addReviewersItem);
        response.addPermittedFeaturesItem(InitialisationDetails.PermittedFeaturesEnum.ADDEDREVIEWERS);
        response.addPermittedFeaturesItem(InitialisationDetails.PermittedFeaturesEnum.AUTHORSEARCH);
        response.addPermittedFeaturesItem(InitialisationDetails.PermittedFeaturesEnum.KEYWORDSEARCH);
        response.addPermittedFeaturesItem(InitialisationDetails.PermittedFeaturesEnum.SESSIONPREFERENCES);
        response.addPermittedFeaturesItem(InitialisationDetails.PermittedFeaturesEnum.MANUSCRIPTDETAILS);

        if (journalIds != null) {
            response.setJournalIssnl(journalIds.getIssn());
            response.addPermittedFeaturesItem(InitialisationDetails.PermittedFeaturesEnum.REVIEWERHISTORY);
            response.addPermittedFeaturesItem(InitialisationDetails.PermittedFeaturesEnum.REVIEWERLIMITS);
        }

        boolean hasEBMs = waitAndGetFutureContent(hasEBMsFuture);
        if (hasEBMs) {
            response.addPermittedFeaturesItem(InitialisationDetails.PermittedFeaturesEnum.EDITORIALBOARDMEMBERS);
        }
        return response;
    }

    private InitialisationDetails findEditorsInitialisation(String emJournalAcronym) {
        InitialisationDetails response = new InitialisationDetails();
        response.addPermittedFeaturesItem(InitialisationDetails.PermittedFeaturesEnum.ADDEDREVIEWERS);
        response.addPermittedFeaturesItem(InitialisationDetails.PermittedFeaturesEnum.AUTHORSEARCH);
        response.addPermittedFeaturesItem(InitialisationDetails.PermittedFeaturesEnum.CANDIDATESEARCH);
        response.addPermittedFeaturesItem(InitialisationDetails.PermittedFeaturesEnum.REVIEWERHISTORY);

        if (emJournalAcronym != null && !emJournalAcronym.isBlank()) {
            response.addPermittedFeaturesItem(InitialisationDetails.PermittedFeaturesEnum.VOLUNTEERS);

            // We can use the existing lookup when we have a Journal acronym to get details about the journal
            InitialisationInfo info = additionalInfoDao.getInitialisationInfo(emJournalAcronym, -1L);

            if (info != null) {
                response.setJournalIssnl(info.getIssnL());
                response.setJournalClassifications(getJournalClassifications(info.getClassifications()));

                // We do not have the EBM list for all journals, so only enable if we have the data
                if (info.isHasEBMs()) {
                    response.addPermittedFeaturesItem(InitialisationDetails.PermittedFeaturesEnum.EDITORIALBOARDMEMBERS);
                }
            }
        }

        return response;
    }

    private List<InitialisationDetailsCrowdsourcedReviewers> getCrowdsourcedReviewers(
            List<InitialisationDetailsCrowdsourcedReviewers> crowdsourcedReviewers,
            List<ReviewerDetails> reviewers) {
        if (crowdsourcedReviewers == null || reviewers == null) {
            return crowdsourcedReviewers;
        }

        List<String> reviewersEmails = reviewers.stream().map(ReviewerDetails::getEmails)
                .flatMap(Collection::stream).collect(Collectors.toList());

        // Remove any crowdsourced reviewers that have already been invited
        return crowdsourcedReviewers.stream().filter(c -> !reviewersEmails.contains(c.getEmail())).collect(Collectors.toList());
    }

    private CompletableFuture<List<ReviewerDetails>> createNonElsevierReviewersFuture(String emJournalAcronym, Long documentId) {
        return createAsyncFuture(() -> {
            // Call the standard EM interface to get the reviewer that are active
            CompletableFuture<List<ReviewerDetails>> emReviewersFuture = createAsyncFuture(() -> {
                // Only make the call to EM if we do not have a Readonly token as we will not have a valid bearer token
                if (SessionContext.isReadOnly() || SessionContext.isIdPlusAuthenticated()) {
                    return Collections.emptyList();
                }
                List<Reviewer> emReviewers = editorialManager.getReviewers(emJournalAcronym, documentId);

                return emReviewers.stream().map(this::convertReviewer).collect(Collectors.toList());
            });

            // Need to call a different EM interface to get the inactive reviewers
            CompletableFuture<List<ReviewerDetails>> emWebApiReviewersFuture = createAsyncFuture(() -> {
                List<EmWebApiReviewer> reviewers = editorialManagerWebApi.getReviewers(emJournalAcronym, documentId);

                if (reviewers == null) {
                    return Collections.emptyList();
                }

                return reviewers.stream().filter(r -> r.getEmailAddress() != null).map(r -> {
                    ReviewerDetails reviewerDetails = new ReviewerDetails();
                    reviewerDetails.setFirstName(r.getReviewerFirstName());
                    reviewerDetails.setLastName(r.getReviewerLastName());
                    reviewerDetails.setDisplayName(r.getReviewerFullName());
                    reviewerDetails.addEmailsItem(r.getEmailAddress());
                    reviewerDetails.setStatus(ReviewerStatusType.toInterface(r.getStatus()));
                    return reviewerDetails;
                }).collect(Collectors.toList());
            });

            // Now wait for the requests to start completing
            List<ReviewerDetails> emReviewer = waitAndGetFutureContent(emReviewersFuture);
            List<ReviewerDetails> emWebApiReviewers = waitAndGetFutureContent(emWebApiReviewersFuture);

            return mergeReviewers(emWebApiReviewers, emReviewer);
        });
    }

    private CompletableFuture<InitialisationDetails> createNonElsevierAuthorsFuture(String emJournalAcronym, Long documentId) {
        return createAsyncFuture(
                () -> {
                    List<EmWebApiAuthor> emAuthors = editorialManagerWebApi.getAuthors(emJournalAcronym, documentId);
                    InitialisationDetails init = new InitialisationDetails();

                    if (!emAuthors.isEmpty()) {
                        init.setCorrespondingAuthors(emAuthors.stream().filter(EmWebApiAuthor::isCorrespondingAuthor)
                                .map(this::toPersonBase).collect(
                                        Collectors.collectingAndThen(Collectors.toList(), a -> a.isEmpty() ? null : a)));
                        init.setCoAuthors(emAuthors.stream().filter(a -> a.getIsCorresponding() != null && !a.isCorrespondingAuthor())
                                .map(this::toPersonBase).collect(
                                        Collectors.collectingAndThen(Collectors.toList(), a -> a.isEmpty() ? null : a)));

                        // Once we have the initial data we need to do a lookup for Scopus Ids of the authors.
                        populateScopusIdsForAuthors(init);
                    }
                    return init;
                });

    }

    private void populateScopusIdsForAuthors(InitialisationDetails init) {
        List<PersonBase> authors = Stream.of(init.getCorrespondingAuthors(), init.getCoAuthors())
                .flatMap(a -> a == null ? null : a.stream())
                .filter(a -> a.getEmails() != null)
                .collect(Collectors.toList());

        List<String> emails = authors.stream()
                .flatMap(a -> a.getEmails().stream())
                .collect(Collectors.toList());

        if (!emails.isEmpty()) {
            Map<String, List<String>> scopusMap = scopusSharedSearchPeople.getScopusIdsFromEmails(emails);

            for (PersonBase author : authors) {
                for (String email : author.getEmails()) {
                    if (scopusMap.containsKey(email)) {
                        scopusMap.get(email).forEach(author::addScopusIdsItem);
                    }
                }
            }
        }
    }

    // Ignore SonarQube complaining about the complexity, it isn't that complex
    @SuppressWarnings("squid:S3776")
    private List<ReviewerDetails> mergeReviewers(List<ReviewerDetails> dbReviewers, List<ReviewerDetails> apiReviewers) {
        if (apiReviewers.isEmpty()) {
            return dbReviewers;
        }

        List<ReviewerDetails> reviewers = (dbReviewers == null) ? new ArrayList<>() : new ArrayList<>(dbReviewers);

        for (ReviewerDetails reviewer : apiReviewers) {
            ReviewerDetails matching = reviewers.stream().filter(
                    r -> !Collections.disjoint(r.getEmails(), reviewer.getEmails())).findFirst().orElse(null);

            if (matching != null) {
                // Need to update the emails to merge them, the user might have a different set of emails in
                // the different results sets, so we want to create the complete list
                for (String email : reviewer.getEmails()) {
                    if (!matching.getEmails().contains(email)) {
                        matching.getEmails().add(email);
                    }
                }
                final List<String> apiScopusIds = reviewer.getScopusIds();
                if (apiScopusIds != null) {
                    if (matching.getScopusIds() == null) {
                        matching.setScopusIds(apiScopusIds);
                    } else {
                        for (String scopusId : apiScopusIds) {
                            if (!matching.getScopusIds().contains(scopusId)) {
                                matching.getScopusIds().add(scopusId);
                            }
                        }
                    }
                }
                // If we already have the user with a given status from the database we only want to
                // overwrite it with the EM provided data if it is not in "proposed" status. This is because
                // there are cases where EM will return "proposed" for users that have been uninvited
                if (reviewer.getStatus() != ReviewerStatus.PROPOSED) {
                    matching.setStatus(reviewer.getStatus());
                }
            } else {
                reviewers.add(reviewer);
            }
        }

        return reviewers;
    }

    private PersonBase toPersonBase(EmWebApiAuthor author) {
        PersonBase person = new PersonBase();
        person.setDisplayName(author.getAuthorFullName());
        person.setFirstName(author.getAuthorFirstName());
        person.setLastName(author.getAuthorLastName());
        person.setEmails(author.getEmailAddresses());
        PersonDetailsUtils.setDisplayName(person);
        return person;
    }

    private ReviewerDetails convertReviewer(Reviewer reviewer) {
        ReviewerDetails reviewerDetails = new ReviewerDetails();
        reviewerDetails.setFirstName(reviewer.getGivenName());
        reviewerDetails.setLastName(reviewer.getFamilyName());
        reviewerDetails.setEmails(reviewer.getEmailAddresses());
        reviewerDetails.setStatus(ReviewerStatusType.toInterface(reviewer.getStatus()));
        reviewerDetails.setScopusIds(reviewer.getScopusIdentifiers());
        PersonDetailsUtils.setDisplayName(reviewerDetails);
        return reviewerDetails;
    }

    // SonarQube does not want null returned, but that is exactly what we want as it will prevent an empty
    // array in the JSON that is returned from the interface
    @SuppressWarnings("squid:S1168")
    private List<ClassificationTree> getJournalClassifications(List<ClassificationItem> classifications) {
        if (classifications == null || classifications.isEmpty()) {
            return null;
        }

        // Create all the classification objects and store them in a map keyed off of their code
        Map<String, ClassificationTree> classDetailsMap = new HashMap<>();
        classifications.forEach(c -> classDetailsMap.put(c.getCode(), c));

        // Now we can work through the list of classifications linking all the items to their parent
        // The classifications have already been ordered alphabetically by description so everything
        // will remain ordered once the nested classification have been put together
        List<ClassificationTree> classDetails = new ArrayList<>();
        for (ClassificationItem classification : classifications) {
            if (classification.getParentCode() != null) {
                ClassificationTree parent = classDetailsMap.get(classification.getParentCode());
                // Need to check to make sure the parent being referred to exists, there have been cases where
                // a parent is referenced in EM that does not exist (We will ignore those entries)
                if (parent != null) {
                    ClassificationTree child = classDetailsMap.get(classification.getCode());
                    // Make sure this entry is not already listed as a child in case this is a duplicate
                    if (parent.getChildren() == null ||
                            parent.getChildren().stream().noneMatch(c -> c.getCode().equals(child.getCode()))) {
                        parent.addChildrenItem(child);
                    }
                }
            } else if (classDetails.stream().noneMatch(c -> c.getCode().equals(classification.getCode()))) {
                // If there are no parents, then this is a top level item, so save it off if there is not
                // already an entry for this code. (handling duplicates)
                classDetails.add(classDetailsMap.get(classification.getCode()));
            }
        }
        return classDetails;
    }
}
