package com.elsevier.find.reviewers.utils;

import com.elsevier.find.reviewers.external.PersonFinder.PersonFinderScopusAuthor;
import com.elsevier.find.reviewers.external.ScopusSharedSearchPeople.ScopusSharedSearchAuthor;
import com.elsevier.find.reviewers.generated.model.PersonBase;
import com.elsevier.find.reviewers.generated.model.PersonDetails;
import com.elsevier.find.reviewers.generated.model.ScopusSearchAuthor;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

@Slf4j
public class PersonDetailsUtils {

    // SonarQube doesn't like regular expressions
    @SuppressWarnings({"squid:S4784", "java:S5998"})
    private static final Pattern validEmailPattern = Pattern.compile("^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*$");

    private PersonDetailsUtils() {
    }

    public static boolean isValidEmail(String email) {
        return email != null && !email.isBlank() && validEmailPattern.matcher(email).matches() && !email.contains("**");
    }

    // SonarQube does not want null returned, but that is exactly what we want as that what was passed in
    @SuppressWarnings("squid:S1168")
    public static List<String> processEmEmails(List<String> emails) {
        if (emails == null) {
            return null;
        }

        List<String> processedEmails = new ArrayList<>();
        for (String email : emails) {
            if (email != null) {
                // EM can store multiple emails with a semicolon seperator in a single email field
                // There are also cases where emails incorrectly start with a minus character
                Arrays.stream(email.split(";"))
                        .map(e -> e.trim().toLowerCase().replaceAll("[\\{}]", "")
                                .replaceFirst("^-", "").trim())
                        .filter(e -> !e.isBlank())
                        .forEach(processedEmails::add);
            }
        }

        return processedEmails;
    }

    public static void setDisplayName(PersonBase personDetails) {
        if (personDetails.getDisplayName() == null || personDetails.getDisplayName().isBlank()) {
            final String displayName = (personDetails.getFirstName() != null ? personDetails.getFirstName() + " " : "") +
                    (personDetails.getLastName() != null ? personDetails.getLastName() : "");
            personDetails.setDisplayName(displayName.isBlank() ? null : displayName.trim());
        }
    }

    public static void setScopusData(PersonDetails personDetails, PersonFinderScopusAuthor scopusDetails) {
        if (scopusDetails != null) {
            if (personDetails.getFirstName() == null) {
                personDetails.setFirstName(scopusDetails.getFirstName());
            }
            if (personDetails.getLastName() == null) {
                personDetails.setLastName(scopusDetails.getLastName());
            }
            setDisplayName(personDetails);

            personDetails.setAffiliationName(scopusDetails.getAfdispname());
            personDetails.setAffiliationCity(scopusDetails.getAfdispcity());
            personDetails.setAffiliationCountry(scopusDetails.getAfdispctry());
            personDetails.setPublicationCount(scopusDetails.getCount());
            personDetails.setCitationCount(scopusDetails.getNum_cited_by());
            personDetails.setHindex(scopusDetails.getHIndex());
        }
    }

    public static ScopusSearchAuthor convertAuthor(ScopusSharedSearchAuthor scopusAuthor) {
        ScopusSearchAuthor author = new ScopusSearchAuthor();
        author.addScopusIdsItem(scopusAuthor.getAuthid());
        author.addEmailsItem(scopusAuthor.getAuthemail());
        author.setFirstName(scopusAuthor.getFirstName());
        author.setLastName(scopusAuthor.getLastName());
        author.setAffiliationName(scopusAuthor.getAffiliationName());
        author.setAffiliationCity(scopusAuthor.getAfdispcity());
        author.setAffiliationCountry(scopusAuthor.getAfdispctry());
        author.setPublicationCount(scopusAuthor.getCount());
        author.setCitationCount(scopusAuthor.getCitedby());
        author.setHindex(scopusAuthor.getHindex());

        return author;
    }
}
