package com.elsevier.find.reviewers.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.sqs.SqsClient;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLEngine;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509ExtendedTrustManager;
import java.net.Socket;
import java.net.URI;
import java.net.http.HttpClient;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.time.Duration;

@Configuration
public class ApplicationConfig {
    // SonarQube understandably does not like the fact that the certificate is not checked, however this
    // is required as we do not control the interface with a missmatch on the certificate
    @SuppressWarnings("java:S4830")
    public static class TrustManagerWithoutCertificateCheck extends X509ExtendedTrustManager {
        public void checkClientTrusted(X509Certificate[] x509Certificates, String s, Socket socket) throws CertificateException {
            // Approve any certificate
        }

        public void checkServerTrusted(X509Certificate[] x509Certificates, String s, Socket socket) throws CertificateException {
            // Approve any certificate
        }

        public void checkClientTrusted(X509Certificate[] x509Certificates, String s, SSLEngine sslEngine) throws CertificateException {
            // Approve any certificate
        }

        public void checkServerTrusted(X509Certificate[] x509Certificates, String s, SSLEngine sslEngine) throws CertificateException {
            // Approve any certificate
        }

        public void checkClientTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
            // Approve any certificate
        }

        public void checkServerTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
            // Approve any certificate
        }

        public X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[0];
        }
    }

    @Bean
    public SqsClient sqsClient(@Value("${rev.rec.aws.region}") String region,
                               @Value("${rev.rec.aws.sqs.endpoint.override:#{null}}") String endpointOverride) {
        // This gives the ability to override the AWS endpoint when running service tests so that all SQS
        // messages can be redirected to a local SQS instance (It will never be set in production)
        if (endpointOverride != null) {
            return SqsClient.builder().region(Region.of(region)).endpointOverride(URI.create(endpointOverride)).build();
        }
        return SqsClient.builder().region(Region.of(region)).build();
    }

    @Bean
    public HttpClient httpClient() {
        return HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(7L))
                .build();
    }

    @Bean
    public HttpClient httpClientWithoutCertificateCheck() throws GeneralSecurityException {
        // There is a certificate issue with the Scopus Sources endpoint because the host in the certificate
        // does not match. Because of this we need to disable the certificate checking for calls to this endpoint
        SSLContext ctx = SSLContext.getInstance("TLS");
        ctx.init(null, new TrustManager[]{new TrustManagerWithoutCertificateCheck()}, new SecureRandom());
        return HttpClient.newBuilder().sslContext(ctx).connectTimeout(Duration.ofSeconds(5L)).build();
    }

    @Bean
    public DynamoDbEnhancedClient dynamoDbEnhancedClient(@Value("${rev.rec.aws.region}") String region,
                                                         @Value("${rev.rec.aws.dynamodb.endpoint.override:#{null}}") String endpointOverride) {
        // This gives the ability to override the AWS endpoint when running service tests so that all DynamoDb
        // queries can be redirected to a local instance (It will never be set in production)
        if (endpointOverride != null) {
            DynamoDbClient ddb = DynamoDbClient.builder().region(Region.of(region)).endpointOverride(URI.create(endpointOverride))
                    .credentialsProvider(StaticCredentialsProvider.create(AwsBasicCredentials.create("x", "x")))
                    .build();
            return DynamoDbEnhancedClient.builder().dynamoDbClient(ddb).build();
        }
        return DynamoDbEnhancedClient.create();
    }
}
