package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * Minimal details about a person
 */
@Schema(description = "Minimal details about a person")
@Validated



public class PersonBase   {
  @JsonProperty("emails")
  @Valid
  private List<String> emails = new ArrayList<>();

  @JsonProperty("displayName")
  private String displayName = null;

  @JsonProperty("firstName")
  private String firstName = null;

  @JsonProperty("lastName")
  private String lastName = null;

  @JsonProperty("scopusIds")
  @Valid
  private List<String> scopusIds = null;

  public PersonBase emails(List<String> emails) {
    this.emails = emails;
    return this;
  }

  public PersonBase addEmailsItem(String emailsItem) {
    this.emails.add(emailsItem);
    return this;
  }

  /**
   * Persons email addresses
   * @return emails
   **/
  @Schema(required = true, description = "Persons email addresses")
      @NotNull

  @Size(min=1)   public List<String> getEmails() {
    return emails;
  }

  public void setEmails(List<String> emails) {
    this.emails = emails;
  }

  public PersonBase displayName(String displayName) {
    this.displayName = displayName;
    return this;
  }

  /**
   * Persons full display name
   * @return displayName
   **/
  @Schema(example = "John Smith", description = "Persons full display name")
  
    public String getDisplayName() {
    return displayName;
  }

  public void setDisplayName(String displayName) {
    this.displayName = displayName;
  }

  public PersonBase firstName(String firstName) {
    this.firstName = firstName;
    return this;
  }

  /**
   * Persons first name
   * @return firstName
   **/
  @Schema(description = "Persons first name")
  
    public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public PersonBase lastName(String lastName) {
    this.lastName = lastName;
    return this;
  }

  /**
   * Persons last name
   * @return lastName
   **/
  @Schema(description = "Persons last name")
  
    public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public PersonBase scopusIds(List<String> scopusIds) {
    this.scopusIds = scopusIds;
    return this;
  }

  public PersonBase addScopusIdsItem(String scopusIdsItem) {
    if (this.scopusIds == null) {
      this.scopusIds = new ArrayList<>();
    }
    this.scopusIds.add(scopusIdsItem);
    return this;
  }

  /**
   * Scopus Ids
   * @return scopusIds
   **/
  @Schema(description = "Scopus Ids")
  
    public List<String> getScopusIds() {
    return scopusIds;
  }

  public void setScopusIds(List<String> scopusIds) {
    this.scopusIds = scopusIds;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PersonBase personBase = (PersonBase) o;
    return Objects.equals(this.emails, personBase.emails) &&
        Objects.equals(this.displayName, personBase.displayName) &&
        Objects.equals(this.firstName, personBase.firstName) &&
        Objects.equals(this.lastName, personBase.lastName) &&
        Objects.equals(this.scopusIds, personBase.scopusIds);
  }

  @Override
  public int hashCode() {
    return Objects.hash(emails, displayName, firstName, lastName, scopusIds);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PersonBase {\n");
    
    sb.append("    emails: ").append(toIndentedString(emails)).append("\n");
    sb.append("    displayName: ").append(toIndentedString(displayName)).append("\n");
    sb.append("    firstName: ").append(toIndentedString(firstName)).append("\n");
    sb.append("    lastName: ").append(toIndentedString(lastName)).append("\n");
    sb.append("    scopusIds: ").append(toIndentedString(scopusIds)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
