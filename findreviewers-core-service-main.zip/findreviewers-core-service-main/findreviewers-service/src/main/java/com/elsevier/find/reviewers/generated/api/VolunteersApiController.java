package com.elsevier.find.reviewers.generated.api;

import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.generated.model.KeywordSearchLogic;
import com.elsevier.find.reviewers.generated.model.VolunteersResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.util.List;
import java.util.Map;


@RestController
public class VolunteersApiController implements VolunteersApi {

    private final VolunteersApiDelegate delegate;

    @org.springframework.beans.factory.annotation.Autowired
    public VolunteersApiController(VolunteersApiDelegate delegate) {
        this.delegate = delegate;
    }

    @Override
    public VolunteersApiDelegate getDelegate() {
        return delegate;
    }
    public ResponseEntity<VolunteersResponse> getVolunteers(@NotNull @Parameter(in = ParameterIn.QUERY, description = "The EM journal acronym to return the list of volunteers for" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "emJournalAcronym", required = true) String emJournalAcronym,@Parameter(in = ParameterIn.HEADER, description = "The scope of the application, valid values are FE-IDP (Find Editors) FR-IDP-JOURNAL (Find Reviewers stand alone, JOURNAL = upper case EM journal acronym) FR-EM-JOURNAL (Find Reviewers from EM, JOURNAL = upper case EM journal acronym)" ,required=true,schema=@Schema()) @RequestHeader(value="X-Scope", required=true) String xScope,@Size(min=3) @Parameter(in = ParameterIn.QUERY, description = "The set of keywords to apply content matches for" ,schema=@Schema()) @Valid @RequestParam(value = "keywords", required = false) String keywords,@Parameter(in = ParameterIn.QUERY, description = "The logical operator that is used to join multiple keywords" ,schema=@Schema()) @Valid @RequestParam(value = "searchLogic", required = false) KeywordSearchLogic searchLogic,@Min(0)@Parameter(in = ParameterIn.QUERY, description = "The number of elements to skip before starting to collect the result set" ,schema=@Schema(allowableValues={ "0" }
)) @Valid @RequestParam(value = "offset", required = false) Integer offset,@Min(1)@Parameter(in = ParameterIn.QUERY, description = "The maximum numbers of elements to return" ,schema=@Schema(allowableValues={ "1" }, minimum="1"
)) @Valid @RequestParam(value = "limit", required = false) Integer limit) {
        return delegate.getVolunteers(emJournalAcronym, xScope, keywords, searchLogic, offset, limit);
    }

}
