package com.elsevier.find.reviewers.exception;

import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import org.springframework.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;

/**
 * The exception to be used when an error needs to be reported anywhere in the system.
 */
public class InternalException extends RuntimeException {
    private final ErrorResponse.IdEnum id;
    private final HttpStatus httpStatus;
    private final Map<String, String> attributes = new HashMap<>();

    /**
     * Creates the internal exception without a body
     *
     * @param httpStatus The HTTP Status to use when reporting the error
     */
    public InternalException(HttpStatus httpStatus) {
        this(null, httpStatus);
    }

    /**
     * Creates the internal exception
     *
     * @param id         The application specific Error Id
     * @param httpStatus The HTTP Status to use when reporting the error
     */
    public InternalException(ErrorResponse.IdEnum id, HttpStatus httpStatus) {
        this.id = id;
        this.httpStatus = httpStatus;
    }

    /**
     * Creates the internal exception
     *
     * @param id         The application specific Error Id
     * @param httpStatus The HTTP Status to use when reporting the error
     * @param attributes The Map of attributes to add to the error
     */
    public InternalException(ErrorResponse.IdEnum id, HttpStatus httpStatus, Map<String, String> attributes) {
        this.id = id;
        this.httpStatus = httpStatus;
        attributes.forEach(this.attributes::put);
    }

    /**
     * Optionally add an attribute that helps explain the error
     *
     * @param key   The key/name of the data
     * @param value The value of the data
     */
    public void addAttribute(String key, String value) {
        attributes.put(key, value);
    }

    /**
     * Converts the Internal Exception into the interface format
     *
     * @return Interface ErrorResponse
     */
    public ErrorResponse toErrorResponse() {
        // There is no Error specifics if there is no response type
        if (id == null) {
            return null;
        }
        ErrorResponse response = new ErrorResponse();
        response.setId(id);
        response.setAttributes(attributes);
        return response;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }
}
