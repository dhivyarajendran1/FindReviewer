package com.elsevier.find.reviewers.external;

import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.utils.PersonDetailsUtils;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
public class ScopusSharedSearchPeople extends ScopusSharedSearchBase {
    private static final String AUTHOR_NAME_SEPARATOR = " \\| ";

    @EqualsAndHashCode(callSuper = true)
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ScopusSharedSearchAuthor extends ScopusSharedSearchAuthorIds {
        @JsonProperty("preffirst")
        private String preffirst; // Given/First name (Preferred)
        @JsonProperty("authfirst")
        private String authfirst; // Given/First name
        @JsonProperty("authlast")
        private String authlast; // Family/Last name
        @JsonProperty("afdispname")
        private List<String> afdispname; // Affiliation Name (only interested in the first)
        @JsonProperty("afdispcity")
        private String afdispcity; // Affiliation City
        @JsonProperty("afdispctry")
        private String afdispctry; // Affiliation Country
        @JsonProperty("count")
        private Integer count; // Publication Count
        @JsonProperty("citedby")
        private Integer citedby; // The number of citations
        @JsonProperty("hindex")
        private Integer hindex; // Author hIndex

        public String getFirstName() {
            if (preffirst == null || preffirst.isBlank()) {
                if (authfirst != null && !authfirst.isBlank()) {
                    return authfirst.split(AUTHOR_NAME_SEPARATOR)[0].trim();
                }
                return null;
            }
            return preffirst.trim();
        }

        public String getLastName() {
            if (authlast == null || authlast.isBlank()) {
                return null;
            }
            return authlast.split(AUTHOR_NAME_SEPARATOR)[0].trim();
        }

        public String getAffiliationName() {
            return (afdispname == null || afdispname.isEmpty()) ? null : afdispname.get(0);
        }
    }

    private static final String AUTHOR_REQUEST_TEMPLATE = """
            {"query":{"queryString": "%s"},
             "returnFields":["afdispctry","authid","authemail","preffirst","authfirst",
             "afdispcity","authlast","afdispname","count","hindex","citedby"],
             "resultSet": {"amount": 500 },
             "sortBy": [{"fieldName": "hindex","order": "desc"}]}
            """;

    private static final String SCOPUS_ID_FROM_EMAIL_TEMPLATE = """
            {"query":{"queryString": "%s", "defaultOperator": "OR"},
             "returnFields":["authid", "authemail"]}
            """;

    private final ObjectMapper objectMapper;

    public ScopusSharedSearchPeople(@Qualifier("scopussharedsearch") WebClient webClient,
                                    ObjectMapper objectMapper,
                                    @Value("${scopussharedsearch.client.base.url}") String scopusSharedSearchBaseUrl) {
        super("people", webClient, scopusSharedSearchBaseUrl);
        this.objectMapper = objectMapper;
    }

    public List<ScopusSharedSearchAuthor> getAuthors(String firstName,
                                                     String lastName,
                                                     String affiliation,
                                                     String email) {
        List<String> query = new ArrayList<>();
        if (firstName != null && !firstName.isBlank()) {
            query.add(createQueryItem("authfirst", firstName));
        }
        if (lastName != null && !lastName.isBlank()) {
            query.add(createQueryItem("authlast", lastName));
        }
        if (affiliation != null && !affiliation.isBlank()) {
            query.add(createQueryItem("afdispname", affiliation));
        }
        if (email != null && !email.isBlank()) {
            query.add(createQueryItem("authemail", email));
        }

        final String body = String.format(AUTHOR_REQUEST_TEMPLATE, String.join(" AND ", query));
        String rawResponse = null;
        ScopusSharedSearchResponse<ScopusSharedSearchAuthor> authors = null;

        try {
            rawResponse = makeScopusSharedSearchCall(body);

            if (rawResponse != null && !rawResponse.isBlank()) {
                authors = objectMapper.readValue(rawResponse, new TypeReference<>() {
                });
            }
        } catch (IOException e) {
            log.error("Scopus Shared Search response with body {} unexpected format {}", body, rawResponse, e);
            throw new InternalException(
                    ErrorResponse.IdEnum.SCOPUSSHAREDSEARCHFAILURE, HttpStatus.INTERNAL_SERVER_ERROR, Map.of("body", body));
        }

        // When requesting the list of authors we deliberately use a very large range because lots of authors can
        // have no email address so will be removed. Not all of these are required, so we restrict the list to 100
        return authors == null || authors.getHits() == null ? Collections.emptyList() :
                authors.getHits().stream().filter(a -> a.getAuthemail() != null).limit(100).collect(Collectors.toList());
    }

    public Map<String, List<String>> getScopusIdsFromEmails(List<String> emails) {
        final String emailInput = emails.stream().filter(PersonDetailsUtils::isValidEmail)
                .map(e -> createLiteralQueryItem("authemail", e.trim().toLowerCase())).collect(Collectors.joining(" "));

        // It is possible that all emails passes in were invalid, so we end up with no emails to
        // perform a lookup on
        if (emailInput.isBlank()) {
            return Collections.emptyMap();
        }

        final String body = String.format(SCOPUS_ID_FROM_EMAIL_TEMPLATE, emailInput);
        ScopusSharedSearchResponse<ScopusSharedSearchAuthor> authors = null;

        try {
            String rawResponse = makeScopusSharedSearchCall(body);

            if (rawResponse != null && !rawResponse.isBlank()) {
                authors = objectMapper.readValue(rawResponse, new TypeReference<>() {
                });
            }
        } catch (Exception e) {
            // Just log an error and continue, it just means we have not managed to do a scopus lookup to get
            // the Scopus Ids. This is OK as there was a good chance the email lookup would return no data
            // anyway and this is viewed as optional data and an email lookup should never fail the operation
            log.error("Scopus Shared Search using emails request {} with body {} failed", body, e);
        }

        Map<String, List<String>> emailMapping = new HashMap<>();
        if (authors != null && authors.getHits() != null) {
            authors.getHits().stream().filter(a -> a.getAuthemail() != null && a.getAuthid() != null)
                    .forEach(a -> emailMapping.computeIfAbsent(a.getAuthemail(), v -> new ArrayList<>()).add(a.getAuthid()));
        }

        return emailMapping;
    }

    private String createQueryItem(String key, String value) {
        String quoted = "";
        // It is safe to quote everything other than wildcard statements. Quoting a wildcard statement
        // will make a match against the asterisk character instead of using as a wildcard
        if (!value.contains("*")) {
            quoted = "\\\"";
        }
        return key + ":" + quoted + value + quoted;
    }

    private String createLiteralQueryItem(String key, String value) {
        // This is the case where we have a query string with a wildcard, but we want to force it do a literal
        // search using that wildcard as an asterisk
        final String quoted = value.contains("*") ? "\\\"" : "";
        return key + ":" + quoted + value + quoted;
    }
}
