package com.elsevier.find.reviewers.exception;

import com.elsevier.find.reviewers.generated.model.RecommendationsFailureResponse;
import com.elsevier.find.reviewers.generated.model.RecommendationsFailureResponse.MissingManuscriptDataEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;

import java.util.List;
import java.util.Objects;

@Slf4j
public class RecommendationException extends RuntimeException {
    private final transient RecommendationsFailureResponse response = new RecommendationsFailureResponse();

    public RecommendationException(List<String> missingAttributes) {
        missingAttributes.stream().map(this::toEnum).filter(Objects::nonNull)
                .forEach(response::addMissingManuscriptDataItem);
    }

    public HttpStatus getHttpStatus() {
        return HttpStatus.NOT_FOUND;
    }

    public RecommendationsFailureResponse getResponse() {
        return response.getMissingManuscriptData().isEmpty() ? null : response;
    }

    private MissingManuscriptDataEnum toEnum(String attribStr) {
        MissingManuscriptDataEnum missing = null;
        switch (attribStr) {
            case "title":
                missing = MissingManuscriptDataEnum.TITLE;
                break;
            case "status":
                missing = MissingManuscriptDataEnum.STATUS;
                break;
            case "submissionDate":
                missing = MissingManuscriptDataEnum.SUBMISSIONDATE;
                break;
            case "authors":
                missing = MissingManuscriptDataEnum.AUTHORS;
                break;
            case "journal":
                missing = MissingManuscriptDataEnum.JOURNAL;
                break;
            case "abstract":
                missing = MissingManuscriptDataEnum.ABSTRACT;
                break;
            case "authors.corresponding":
                missing = MissingManuscriptDataEnum.CORRESPONDINGAUTHOR;
                break;
            case "journal.acronym":
                missing = MissingManuscriptDataEnum.JOURNALACRONYM;
                break;
            default:
                log.error("Unexpected Audit entry for Missing attribute {}", attribStr);
                break;
        }
        return missing;
    }
}
