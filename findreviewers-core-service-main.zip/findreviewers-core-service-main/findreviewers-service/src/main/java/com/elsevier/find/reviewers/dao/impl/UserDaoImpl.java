package com.elsevier.find.reviewers.dao.impl;

import com.elsevier.find.reviewers.dao.UserDao;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Implementation for the data access to editors
 */
// Suppress SonarQube 'String literals should not be duplicated' flagged against the inline sql
@SuppressWarnings("squid:S1192")
@Slf4j
@Repository
public class UserDaoImpl extends BaseDaoImpl implements UserDao {
    public UserDaoImpl(NamedParameterJdbcTemplate dbSource, ObjectMapper objectMapper,
                       @Value("${findreviewers.cloud.ursdb:false}") String cloudUrsdbEnabled) {
        super(dbSource, objectMapper, cloudUrsdbEnabled);
    }

    @Override
    public boolean isAllowedFindEditorAccess(List<String> emails) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("emails", emails);

        // This may seem overly complicated, but it will ensure that we only check if the user is a CAS/CAL
        // if we do not find them as a publisher - reducing the cost of the lookup
        final String sql = """
                select
                case
                  exists(select 1 from find_reviewers.eph_journal_publisher p
                    where p.email in (:emails) and (p.stop_date is null or p.stop_date > (extract(EPOCH from CURRENT_TIMESTAMP) * 1000)))
                  when true then true
                else
                  case
                    exists(select 1 from find_reviewers.eph_content_lead l
                      where l.email in (:emails) and (l.stop_date is null or l.stop_date > (extract(EPOCH from CURRENT_TIMESTAMP) * 1000)))
                    when true then true
                  else
                    exists(select 1 from find_reviewers.eph_content_specialist s
                      where s.email in (:emails) and (s.stop_date is null or s.stop_date > (extract(EPOCH from CURRENT_TIMESTAMP) * 1000)))
                  end
                end
                """;

        return dbSource.queryForObject(sql, params, Boolean.class);
    }
}
