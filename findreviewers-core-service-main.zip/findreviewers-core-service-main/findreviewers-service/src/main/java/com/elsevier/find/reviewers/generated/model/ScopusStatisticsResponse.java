package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.ScopusStatisticsResponseStatistics;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * The response for a candidates publication statistics
 */
@Schema(description = "The response for a candidates publication statistics")
@Validated



public class ScopusStatisticsResponse   {
  @JsonProperty("statistics")
  @Valid
  private List<ScopusStatisticsResponseStatistics> statistics = null;

  public ScopusStatisticsResponse statistics(List<ScopusStatisticsResponseStatistics> statistics) {
    this.statistics = statistics;
    return this;
  }

  public ScopusStatisticsResponse addStatisticsItem(ScopusStatisticsResponseStatistics statisticsItem) {
    if (this.statistics == null) {
      this.statistics = new ArrayList<>();
    }
    this.statistics.add(statisticsItem);
    return this;
  }

  /**
   * Get statistics
   * @return statistics
   **/
  @Schema(description = "")
      @Valid
    public List<ScopusStatisticsResponseStatistics> getStatistics() {
    return statistics;
  }

  public void setStatistics(List<ScopusStatisticsResponseStatistics> statistics) {
    this.statistics = statistics;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ScopusStatisticsResponse scopusStatisticsResponse = (ScopusStatisticsResponse) o;
    return Objects.equals(this.statistics, scopusStatisticsResponse.statistics);
  }

  @Override
  public int hashCode() {
    return Objects.hash(statistics);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ScopusStatisticsResponse {\n");
    
    sb.append("    statistics: ").append(toIndentedString(statistics)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
