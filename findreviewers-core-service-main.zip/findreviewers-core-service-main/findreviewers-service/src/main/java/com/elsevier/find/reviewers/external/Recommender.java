package com.elsevier.find.reviewers.external;

import com.elsevier.find.reviewers.dao.JournalDao;
import com.elsevier.find.reviewers.dao.RecommenderAuditDao;
import com.elsevier.find.reviewers.dao.RecommenderAuditDao.ManuscriptAudit;
import com.elsevier.find.reviewers.exception.RecommendationException;
import com.elsevier.find.reviewers.utils.Analytics;
import com.elsevier.find.reviewers.utils.PersonDetailsUtils;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.GetQueueUrlRequest;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;
import software.amazon.awssdk.services.sqs.model.SendMessageResponse;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Instant;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class Recommender {
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class RecommendedAffiliation {
        @JsonProperty("name")
        private String name;
        @JsonProperty("city")
        private String city;
        @JsonProperty("country")
        private String country;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class RecommendedAuthor {
        @JsonProperty("id")
        private String id;
        @JsonProperty("givenName")
        private String givenName;
        @JsonProperty("surname")
        private String surname;

        public String getName() {
            String name = null;
            if (surname == null || surname.isBlank()) {
                // If there is nothing in the surname field use the whole of the given name rather than just the initial
                if (givenName != null && !givenName.isBlank()) {
                    name = givenName;
                }
            } else {
                final String initial = (givenName == null || givenName.isBlank()) ? "" :
                        ", " + givenName.trim().substring(0, 1).toUpperCase() + ".";
                name = surname.trim() + initial;
            }

            return name;
        }
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class RecommenderPublication {
        @JsonProperty("title")
        private String title;
        @JsonProperty("year")
        private Integer year;
        @JsonProperty("journal")
        private String journal;
        @JsonProperty("scopusUrl")
        private String scopusUrl;
        @JsonProperty("nCitations")
        private Integer nCitations;
        @JsonProperty("numAuthors")
        private Integer numAuthors;
        @JsonProperty("authorsPreview")
        private List<RecommendedAuthor> authorsPreview;

        public String getScopusEid() {
            String eid = null;
            if (scopusUrl != null) {
                int startIdx = scopusUrl.indexOf("eid=");
                if (startIdx > 0) {
                    int endIdx = scopusUrl.indexOf('&', startIdx);
                    if (endIdx > 0) {
                        eid = scopusUrl.substring(startIdx + 4, endIdx);
                    }
                }
            }
            return eid;
        }
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class RecommendedReviewer {
        @JsonProperty("scopusId")
        private String scopusId;
        @JsonProperty("email")
        private String email;
        @JsonProperty("name")
        private String name;
        @JsonProperty("surname")
        private String surname;
        @JsonProperty("hIndex")
        private Integer hIndex;
        @JsonProperty("affiliations")
        private List<RecommendedAffiliation> affiliations;
        @JsonProperty("numPublications")
        private Integer numPublications;
        @JsonProperty("citationTotal")
        private Integer citationTotal;
        @JsonProperty("numPubsLast5Year")
        private Integer numPubsLast5Year;
        @JsonProperty("citationTotalLast5Years")
        private Integer citationTotalLast5Years;
        @JsonProperty("yearsActive")
        private Integer yearsActive;
        @JsonProperty("keywords")
        private List<String> keywords;
        @JsonProperty("subjectAreas")
        private List<String> subjectAreas;
        @JsonProperty("isSuggestedByAuthor")
        private Boolean isSuggestedByAuthor;
        @JsonProperty("hasCitedManuscriptAuthors")
        private Boolean hasCitedManuscriptAuthors;
        @JsonProperty("isOpposedByAuthor")
        private Boolean isOpposedByAuthor;
        @JsonProperty("sameInstitutionAsAuthors")
        private Boolean sameInstitutionAsAuthors;
        @JsonProperty("isInSameCountry")
        private Boolean isInSameCountry;
        @JsonProperty("numberOfSimilarWorks")
        private Integer numberOfSimilarWorks;
        @JsonProperty("numReviewerPublishedInManuscriptJournal")
        private Integer numReviewerPublishedInManuscriptJournal;
        @JsonProperty("topContentMatch")
        private List<RecommenderPublication> topContentMatch;
        @JsonProperty("recentPublications")
        private List<RecommenderPublication> recentPublications;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class RecommenderResponse {
        @JsonProperty("generationTime")
        private Long generationTime;
        @JsonProperty("recommendations")
        private List<RecommendedReviewer> recommendations;
        @JsonProperty("analyticsInfo")
        private Map<String, Object> analyticsInfo;

        public List<RecommendedReviewer> getRecommendedReviewers() {
            if (recommendations == null) {
                return Collections.emptyList();
            }
            recommendations.removeIf(r -> !PersonDetailsUtils.isValidEmail(r.getEmail()));
            return recommendations;
        }
    }

    private final ObjectMapper objectMapper;
    private final HttpClient httpClient;
    private final String recommenderApiUrl;
    private final JournalDao journalDao;
    private final RecommenderAuditDao recommenderAuditDao;

    // AWS SQS queue interface and details
    private final SqsClient sqsClient;
    private final String reflowQueueName;
    private final Analytics analytics;
    private final boolean isNonProd;
    private final boolean isCloudUrsdb;

    // SonarQube does not like the number of arguments
    @SuppressWarnings("java:S107")
    public Recommender(ObjectMapper objectMapper,
                       HttpClient httpClient,
                       JournalDao journalDao,
                       RecommenderAuditDao recommenderAuditDao,
                       SqsClient sqsClient,
                       Analytics analytics,
                       @Value("${recommender.base.url}") String recommenderApiUrl,
                       @Value("${findreviewers.reflow.queuename}") String reflowQueueName,
                       @Value("${spring.profiles.active:unknown}") String activeProfile,
                       @Value("${findreviewers.cloud.ursdb:false}") String cloudUrsdbEnabled) {
        this.objectMapper = objectMapper;
        this.httpClient = httpClient;
        this.journalDao = journalDao;
        this.recommenderAuditDao = recommenderAuditDao;
        this.sqsClient = sqsClient;
        this.analytics = analytics;
        this.reflowQueueName = reflowQueueName;
        this.recommenderApiUrl = recommenderApiUrl.endsWith("/") ?
                recommenderApiUrl.substring(0, recommenderApiUrl.length() - 1) : recommenderApiUrl;
        this.isNonProd = "nonprod".equals(activeProfile);
        this.isCloudUrsdb = "true".equals(cloudUrsdbEnabled);
    }

    public RecommenderResponse getRecommendations(String emJournalAcronym, String manuscriptId, Long documentId, int resultsLimit) {
        RecommenderResponse response = null;
        try {
            final String url = String.format("%s/recommendations/reviewers?manuscript_id=%s&size=%d", recommenderApiUrl,
                    manuscriptId, resultsLimit);

            log.info("Recommendations request for journal {} url {}", emJournalAcronym, url);

            final HttpRequest request = HttpRequest.newBuilder(new URI(url))
                    .header("Content-Type", "application/json")
                    .header("Accept", "application/vnd.elsevier.rr-recommendations-v2+json")
                    .GET()
                    .build();

            HttpResponse<String> httpResponse = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

            final int statusCode = httpResponse.statusCode();
            if (statusCode == HttpStatus.OK.value()) {
                final String rawResponse = httpResponse.body();
                if (rawResponse != null) {
                    response = objectMapper.readValue(rawResponse, new TypeReference<>() {
                    });
                }
            } else if (statusCode == HttpStatus.NOT_FOUND.value()) {
                final String responseBody = httpResponse.body();
                log.info("Recommender call found no recommendations for manuscript {} with response {}", manuscriptId,
                        responseBody);
                reflowManuscript(emJournalAcronym, documentId);
            } else {
                final String errorBody = httpResponse.body();
                log.error("Recommender call failed for manuscript {} with error {} and response {}", manuscriptId,
                        statusCode, errorBody);
            }
        } catch (RecommendationException e) {
            throw e;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log.error("Interrupt exception when getting recommendations for manuscript {}", manuscriptId, e);
        } catch (Exception e) {
            log.error("Failed to get recommendations for manuscript {}", manuscriptId, e);
        }

        return response;
    }

    // SonarQube complaining about complexity - but it's not complex, splitting it would make it harder to follow
    @SuppressWarnings("java:S3776")
    private void reflowManuscript(String emJournalAcronym, Long documentId) {
        if (documentId == null) {
            log.error("Unable to reflow manuscript for journal {} as no document Id provided", emJournalAcronym);
            return;
        }

        // Any reflow requires the JournalId rather than the Journal Acronym
        Long journalId = journalDao.getEmJournalId(emJournalAcronym);
        if (journalId == null) {
            // Don't raise errors for non-prod or if the Test journal is used (even in production, as it does happen)
            if (isNonProd || "JOURNAL".equalsIgnoreCase(emJournalAcronym)) {
                log.warn("No Journal entry found for non-prod journal acronym {}", emJournalAcronym);
            } else {
                log.error("No Journal entry found for journal acronym {}", emJournalAcronym);
            }
            return;
        }

        // Check the status of the manuscript in the audit log
        List<ManuscriptAudit> manuscriptAudit = recommenderAuditDao.getManuscriptAudit(emJournalAcronym, documentId);

        // Do not reflow if we have already done so in the last 24 hours
        final long reflowThreshold = Instant.now().toEpochMilli() - 86400000;
        if (manuscriptAudit.stream().anyMatch(a -> a.getForced() && a.getEventTime() > reflowThreshold)) {
            log.info("No reflow performed for Journal {} document {} as reflow exists withing last 24 hours",
                    emJournalAcronym, documentId);
        } else {
            // It is OK to reflow this manuscript, so make the request by adding the reflow message to the
            // queue which will trigger the regeneration of the Recommendation pre-requisite data
            String payload = String.format("""
                    {"operation": "UPSERT", "force": true, "manuscripts": [{"journalId": %d, "journalAcronym": "%s", "documentId": %d }]}
                    """, journalId, emJournalAcronym.toUpperCase(), documentId);

            if (isCloudUrsdb) {
                payload = String.format("""
                        {"operation": "UPDATE", "force": true, "journal_id": %d, "document_id": %d }
                        """, journalId, documentId);
            }

            log.info("Making reflow request with payload {}", payload);

            try {
                // Build the AWS queue request up, we explicitly set the delay to zero to ensure it is processed
                // as early as possible, this will override any default delay configured on the queue
                SendMessageRequest request = SendMessageRequest.builder()
                        .queueUrl(sqsClient.getQueueUrl(GetQueueUrlRequest.builder().queueName(reflowQueueName).build()).queueUrl())
                        .messageBody(payload)
                        .delaySeconds(0)
                        .build();

                SendMessageResponse sqsResponse = sqsClient.sendMessage(request);
                String sqsMessageId = sqsResponse != null ? sqsResponse.messageId() : "unknown";

                log.info("Reflow request for journal {} document Id {} with sqs id: {}", emJournalAcronym, documentId, sqsMessageId);
                analytics.recordManuscriptReflow(1);

            } catch (Exception e) {
                // AWS throws runtime exceptions, so need to catch everything
                log.error("Failed to reflow manuscript for journal {} document Id {} {}", emJournalAcronym, documentId, e);
            }
        }

        // Get the most recent audit entry to see if there is a specific issue with the manuscript that prevents
        // recommendations being generated
        ManuscriptAudit recentAudit = manuscriptAudit.stream().max(Comparator.comparing(ManuscriptAudit::getEventTime)).orElse(null);
        if (recentAudit != null && recentAudit.getMissingAttributes() != null && !recentAudit.getMissingAttributes().isEmpty()) {
            throw new RecommendationException(recentAudit.getMissingAttributes());
        }
    }
}
