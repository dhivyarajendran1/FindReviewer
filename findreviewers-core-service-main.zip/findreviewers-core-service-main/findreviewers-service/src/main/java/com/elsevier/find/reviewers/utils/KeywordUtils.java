package com.elsevier.find.reviewers.utils;

import com.elsevier.find.reviewers.generated.model.KeywordSearchLogic;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class KeywordUtils {
    private KeywordUtils() {
    }

    private static String cleanKeyword(String keyword) {
        // The regular expression below can be broken into 2 sections.
        // - The first part in the square brackets is a straight match to the characters in [...]
        // - The second part after the | matches minuses either at the start of a line or the beginning of a word
        // The $1 in the replaceAll only comes into play when we are using groups, so it says, if there was a match
        // using the group - then the value used for the replacement is what was in the group (so a space in this case)

        // The encoded values are different formats of bullet point that seem to appear in some keywords
        // when copied from a document into EM
        return keyword.replaceAll("[\\\\{}\\[\\]<>#\\r\\n\\t\uF06C\u2022\u2023\u25E6\u2043\u2219]|(^| )-", "$1").trim();
    }

    public static String cleanKeywordForQuery(String keyword) {
        // Some additional characters are OK to display to the user or allow entering. However, they need to
        // be escaped before using them in a query
        return cleanKeyword(keyword.replace("(", " ").replace(")", " "));
    }

    public static List<String> processKeywords(List<String> keywords) {
        List<String> splitKeywords = keywords;
        // When the author enters the keywords in EM they are entered into a text field and requested
        // to separate them with a semicolon. It has been seen that some authors use a comma (or other character)
        // rather than a semicolon so all keywords get added into one field.
        if (splitKeywords.size() == 1) {
            final String onlyKeyword = splitKeywords.get(0);

            for (String splitValue : List.of(",", ";", "\r\n", "*")) {
                if (onlyKeyword.contains(splitValue)) {
                    splitKeywords = new ArrayList<>();
                    for (String keyword : onlyKeyword.split(Pattern.quote(splitValue))) {
                        splitKeywords.add(cleanKeyword(keyword));
                    }
                    break;
                }
            }
        }

        // If there is a quote in the keyword, remove it as the quotes have special meaning in the
        // apis to group phrases, also \ * and ending in :
        return splitKeywords.stream().map(KeywordUtils::cleanKeyword)
                .map(k -> k.replaceAll("\"|\\\\|\\*|(:$)", "")).collect(Collectors.toList());
    }

    public static String getSearchLogicString(KeywordSearchLogic searchLogic) {
        return searchLogic == KeywordSearchLogic.OR ? "OR" : "AND";
    }
}
