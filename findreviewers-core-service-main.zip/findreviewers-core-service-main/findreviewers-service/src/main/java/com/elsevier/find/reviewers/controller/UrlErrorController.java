package com.elsevier.find.reviewers.controller;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * This class handles the case where a user enters a URL that is not mapped to a service
 */
@RestController
public class UrlErrorController implements ErrorController {

    private static final String ERROR_MAPPING = "/error";

    @GetMapping(value = ERROR_MAPPING)
    public ResponseEntity<String> error() {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }
}
