package com.elsevier.find.reviewers.dao;

import com.elsevier.find.reviewers.generated.model.InitialisationDetails;
import com.elsevier.find.reviewers.generated.model.ManuscriptDetails;

import java.util.Set;

/**
 * Interface that supports operations on manuscripts
 */
public interface ManuscriptDao {

    /**
     * Gets the initialisation details for a given manuscript
     *
     * @param emJournalAcronym EM Journal Acronym to get volunteers for
     * @param documentId       EM Document Id
     * @return Details about the given manuscript
     */
    InitialisationDetails getInitialisationDetails(String emJournalAcronym, Long documentId);

    /**
     * Gets the details for a given manuscript
     *
     * @param emJournalAcronym EM Journal Acronym to get volunteers for
     * @param documentId       EM Document Id
     * @return Details about the given manuscript
     */
    ManuscriptDetails getManuscriptDetails(String emJournalAcronym, Long documentId);

    /**
     * Gets the identifiers for all the references for a given manuscript
     *
     * @param emJournalAcronym EM Journal Acronym to get references for
     * @param documentId       EM Document Id
     * @return Reference identifiers
     */
    Set<String> getReferenceIdentifiers(String emJournalAcronym, Long documentId);
}
