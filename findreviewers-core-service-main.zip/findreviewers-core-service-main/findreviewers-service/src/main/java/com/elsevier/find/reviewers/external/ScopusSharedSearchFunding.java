package com.elsevier.find.reviewers.external;

import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Slf4j
@Service
public class ScopusSharedSearchFunding extends ScopusSharedSearchBase {
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    private static class ValuePair {
        @JsonProperty("language")
        private String language;
        @JsonProperty("type")
        private String type;
        @JsonProperty("value")
        private String value;

        public boolean isEnglish() {
            return "en".equalsIgnoreCase(language);
        }

        public boolean isScopusId() {
            return "SCOPUSAUTHORID".equalsIgnoreCase(type);
        }
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Awardee {
        @JsonProperty("fundingBodyPersonId")
        private String fundingBodyPersonId;
        @JsonProperty("role")
        private String role;    // Values of PI (Principal Investigator) and COPI (Co awardees)
        @JsonProperty("givenName")
        private String givenName;
        @JsonProperty("familyName")
        private String familyName;
        @JsonProperty("name")
        private List<ValuePair> name;
        @JsonProperty("identifier")
        private List<ValuePair> identifier;

        public String getScopusId() {
            if (identifier == null) {
                return null;
            }
            return identifier.stream().filter(i -> i.isScopusId() && i.getValue() != null && !i.getValue().isBlank())
                    .map(ValuePair::getValue).findFirst().orElse(null);
        }

        public String getDisplayName() {
            if (name != null) {
                // Names have a language tag, so sort English version of the names first
                String displayName = name.stream().sorted(Comparator.comparing(ValuePair::isEnglish, Comparator.reverseOrder()))
                        .map(ValuePair::getValue)
                        .filter(n -> n != null && !n.isBlank()).findFirst().orElse(null);
                if (displayName != null) {
                    return displayName;
                }
            }
            // Fallback to building the name
            return ((givenName != null ? givenName + " " : "") + (familyName != null ? familyName : "")).trim();
        }

        public boolean isSameAwardee(Awardee other) {
            if (this.fundingBodyPersonId != null && other.fundingBodyPersonId != null) {
                return this.fundingBodyPersonId.equals(other.fundingBodyPersonId);
            }
            final String thisScopusId = this.getScopusId();
            final String otherScopusId = other.getScopusId();
            if (thisScopusId != null && otherScopusId != null) {
                return thisScopusId.equals(otherScopusId);
            }

            return this.getDisplayName().equalsIgnoreCase(other.getDisplayName());
        }
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ScopusSharedSearchFundingResults {
        @Data
        @JsonIgnoreProperties(ignoreUnknown = true)
        private static class Abstract {
            @JsonProperty("abstract")
            private ValuePair abstractSet;
        }

        @Data
        @JsonIgnoreProperties(ignoreUnknown = true)
        private static class AwardeeList {
            @JsonProperty("affiliationOf")
            private List<Awardee> affiliationOf;
        }

        @JsonProperty("grantAwardId")
        private String grantAwardId;
        @JsonProperty("startDate")
        @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'hh:mm:ss")
        private Date startDate;
        @JsonProperty("endDate")
        @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'hh:mm:ss")
        private Date endDate;
        @JsonProperty("funderName")
        private String funderName;
        @JsonProperty("title")
        private List<ValuePair> title;
        @JsonProperty("synopsis")
        private List<Abstract> synopsis;
        @JsonProperty("awardeeDetail")
        private List<AwardeeList> awardeeDetail;

        public String getFundingTitle() {
            if (title == null) {
                return null;
            }
            // Prioritise English titles
            return title.stream().sorted(Comparator.comparing(ValuePair::isEnglish, Comparator.reverseOrder()))
                    .map(ValuePair::getValue).filter(t -> t != null && !t.isBlank()).findFirst().orElse(null);
        }

        public String getAbstract() {
            if (synopsis == null) {
                return null;
            }
            // Prioritise English abstracts
            return synopsis.stream().map(Abstract::getAbstractSet).filter(Objects::nonNull)
                    .sorted(Comparator.comparing(ValuePair::isEnglish, Comparator.reverseOrder()))
                    .map(ValuePair::getValue).filter(a -> a != null && !a.isBlank()).findFirst().orElse(null);
        }

        public List<Awardee> getAwardees() {
            if (awardeeDetail == null) {
                return Collections.emptyList();
            }

            // Order the Awardees with the Principals first, they might also appear multiple times in the list
            // when they are grouped in different affiliations so ensure only one is shown for each identified awardee
            List<Awardee> awardees = new ArrayList<>();
            awardeeDetail.stream().filter(a -> a.getAffiliationOf() != null)
                    .flatMap(a -> a.getAffiliationOf().stream())
                    .sorted((a, b) -> {
                        if (a.getRole().equals(b.getRole())) {
                            return 0;
                        } else if ("PI".equalsIgnoreCase(b.getRole())) {
                            return 1;
                        } else {
                            return -1;
                        }
                    })
                    .forEach(a -> {
                        for (Awardee existingAwardee : awardees) {
                            if (a.isSameAwardee(existingAwardee)) {
                                return;
                            }
                        }
                        awardees.add(a);
                    });

            return awardees;
        }
    }

    private static final String FUNDING_TEMPLATE = """
            {"query": {"queryString": "authorId:%s"},
             "sortBy": [{"fieldName": "startDate","order": "desc"}],
             "returnFields":["grantAwardId","startDate","endDate","title","funderName","synopsis","awardeeDetail"]}
            """;

    private final ObjectMapper objectMapper;

    public ScopusSharedSearchFunding(@Qualifier("scopussharedsearch") WebClient webClient,
                                     ObjectMapper objectMapper,
                                     @Value("${scopussharedsearch.client.base.url}") String scopusSharedSearchBaseUrl) {
        super("hydra_award", webClient, scopusSharedSearchBaseUrl);
        this.objectMapper = objectMapper;
    }

    public List<ScopusSharedSearchFundingResults> getFundingAwards(String scopusId) {
        final String body = String.format(FUNDING_TEMPLATE, scopusId);

        ScopusSharedSearchResponse<ScopusSharedSearchFundingResults> response = null;

        String rawFundingResponse = null;
        try {
            rawFundingResponse = makeScopusSharedSearchCall(body);

            if (rawFundingResponse != null && !rawFundingResponse.isBlank()) {
                response = objectMapper.readValue(rawFundingResponse, new TypeReference<>() {
                });
            }
        } catch (Exception e) {
            log.error("Scopus Shared Search Funding response with body {} unexpected format {}", body, rawFundingResponse, e);
            throw new InternalException(
                    ErrorResponse.IdEnum.SCOPUSSHAREDSEARCHFAILURE, HttpStatus.INTERNAL_SERVER_ERROR, Map.of("body", body));
        }

        return response == null || response.getHits() == null ? Collections.emptyList() : response.getHits();
    }
}
