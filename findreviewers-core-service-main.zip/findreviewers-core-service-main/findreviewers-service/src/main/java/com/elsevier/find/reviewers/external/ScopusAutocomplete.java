package com.elsevier.find.reviewers.external;

import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.util.DefaultUriBuilderFactory;

import java.io.IOException;
import java.net.URI;
import java.time.Duration;
import java.util.*;

@Slf4j
@Service
public class ScopusAutocomplete {

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class AutocompleteSuggestion {
        @JsonProperty("term")
        private String term; // Suggestion term
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ScopusAutocompleteSuggestions {
        // The Autocomplete object contains more data that this, but we only extract what information we require
        @JsonProperty("suggestions")
        private List<AutocompleteSuggestion> suggestions; // List of returned suggestions

        public List<String> getAutocompleteTerms() {
            List<String> autocompleteTerms = new ArrayList<>();
            if (suggestions != null) {
                for (AutocompleteSuggestion suggestion : suggestions) {
                    if (suggestion.getTerm() != null) {
                        autocompleteTerms.add(suggestion.getTerm());
                    }
                }
            }
            return autocompleteTerms;
        }
    }

    private final WebClient webClient;

    private final DefaultUriBuilderFactory uriBuilderFactory;

    private final ObjectMapper objectMapper;

    public ScopusAutocomplete(@Qualifier("scopusautocomplete") WebClient webClient,
                              ObjectMapper objectMapper,
                              @Value("${scopusautocomplete.client.base.url}") String scopusAutocompleteBaseUrl) {
        this.webClient = webClient;
        this.objectMapper = objectMapper;
        uriBuilderFactory = new DefaultUriBuilderFactory(scopusAutocompleteBaseUrl.endsWith("/") ?
                scopusAutocompleteBaseUrl.substring(0, scopusAutocompleteBaseUrl.length() - 1) : scopusAutocompleteBaseUrl);
    }

    public List<String> getAutocompleteSuggestions(String query) {
        String rawResponse = null;
        ScopusAutocompleteSuggestions suggestionsResponse = null;
        try {
            rawResponse = makeScopusAutocompleteCall(query);

            if (rawResponse != null && !rawResponse.isBlank()) {
                suggestionsResponse = objectMapper.readValue(rawResponse, ScopusAutocompleteSuggestions.class);
            }
        } catch (IOException e) {
            log.error("ScopusSharedSearch response for Autocomplete with query {} unexpected format {}",
                    query, rawResponse, e);
            throw new InternalException(
                    ErrorResponse.IdEnum.SCOPUSAUTOCOMPLETEFAILURE, HttpStatus.INTERNAL_SERVER_ERROR,
                    Map.of("query", query));
        }
        return suggestionsResponse == null ? Collections.emptyList() : suggestionsResponse.getAutocompleteTerms();
    }

    /**
     * Makes the API request to the Scopus Autocomplete system with all the correct authentication
     *
     * @param query the query text to get suggestions on
     * @return The text returned from the request
     */
    private String makeScopusAutocompleteCall(String query) {

        final URI uri = uriBuilderFactory.builder()
                .queryParam("entity", "concept")
                .queryParam("maxReturnCount", 10)
                .queryParam("query", query)
                .build();

        log.info("Making Autocomplete API {} request with query {}", uri, query);

        String response = null;
        try {
            response = webClient.get()
                    .uri(uri)
                    .header("x-els-dataset", "autocomplete")
                    .header("x-els-product", "mendeley")
                    .accept(MediaType.APPLICATION_JSON)
                    .retrieve()
                    .bodyToMono(String.class)
                    // Subscribe to this Mono and block until a next signal is received or a timeout expires.
                    // Returns that value, or null if the Mono completes empty.
                    .block(Duration.ofSeconds(20));

        } catch (WebClientResponseException e) {
            // WebClient throws an exception by default when a 4xx or 5xx error is received, need to strip out the
            // 404 - Not Found one as it may be there was no data available in Scopus Autocomplete that we were requesting
            // and that is not really an error case for us
            if (e.getStatusCode() == HttpStatus.NOT_FOUND) {
                log.warn("Entry not found for Scopus Autocomplete API {} HttpStatusCode = {}, HttpHeaders = {}, ResponseBody = {}",
                        uri, e.getStatusCode(), e.getHeaders(), e.getResponseBodyAsString(), e);
                response = null;
            } else {
                log.error("Error calling Scopus Autocomplete API {} HttpStatusCode = {}, HttpHeaders = {}, ResponseBody = {}",
                        uri, e.getStatusCode(), e.getHeaders(), e.getResponseBodyAsString(), e);
                throw new InternalException(ErrorResponse.IdEnum.SCOPUSAUTOCOMPLETEFAILURE,
                        HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            log.error("Exception calling Scopus Autocomplete API {}", uri, e);
            throw new InternalException(ErrorResponse.IdEnum.SCOPUSAUTOCOMPLETEFAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }
}
