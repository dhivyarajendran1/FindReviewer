package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.CandidateNote;
import com.elsevier.find.reviewers.generated.model.EditorialHistory;
import com.elsevier.find.reviewers.generated.model.ReviewHistory;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * The details for a candidate
 */
@Schema(description = "The details for a candidate")
@Validated



public class CandidateDetails   {
  @JsonProperty("email")
  private String email = null;

  @JsonProperty("notes")
  @Valid
  private List<CandidateNote> notes = null;

  @JsonProperty("reviewHistory")
  @Valid
  private List<ReviewHistory> reviewHistory = null;

  @JsonProperty("editorialHistory")
  @Valid
  private List<EditorialHistory> editorialHistory = null;

  public CandidateDetails email(String email) {
    this.email = email;
    return this;
  }

  /**
   * Email of the candidate
   * @return email
   **/
  @Schema(example = "fred@bedrock.com", required = true, description = "Email of the candidate")
      @NotNull

    public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public CandidateDetails notes(List<CandidateNote> notes) {
    this.notes = notes;
    return this;
  }

  public CandidateDetails addNotesItem(CandidateNote notesItem) {
    if (this.notes == null) {
      this.notes = new ArrayList<>();
    }
    this.notes.add(notesItem);
    return this;
  }

  /**
   * Get notes
   * @return notes
   **/
  @Schema(description = "")
      @Valid
    public List<CandidateNote> getNotes() {
    return notes;
  }

  public void setNotes(List<CandidateNote> notes) {
    this.notes = notes;
  }

  public CandidateDetails reviewHistory(List<ReviewHistory> reviewHistory) {
    this.reviewHistory = reviewHistory;
    return this;
  }

  public CandidateDetails addReviewHistoryItem(ReviewHistory reviewHistoryItem) {
    if (this.reviewHistory == null) {
      this.reviewHistory = new ArrayList<>();
    }
    this.reviewHistory.add(reviewHistoryItem);
    return this;
  }

  /**
   * History of what the user has reviewed
   * @return reviewHistory
   **/
  @Schema(description = "History of what the user has reviewed")
      @Valid
    public List<ReviewHistory> getReviewHistory() {
    return reviewHistory;
  }

  public void setReviewHistory(List<ReviewHistory> reviewHistory) {
    this.reviewHistory = reviewHistory;
  }

  public CandidateDetails editorialHistory(List<EditorialHistory> editorialHistory) {
    this.editorialHistory = editorialHistory;
    return this;
  }

  public CandidateDetails addEditorialHistoryItem(EditorialHistory editorialHistoryItem) {
    if (this.editorialHistory == null) {
      this.editorialHistory = new ArrayList<>();
    }
    this.editorialHistory.add(editorialHistoryItem);
    return this;
  }

  /**
   * History of what the user has been an editor for
   * @return editorialHistory
   **/
  @Schema(description = "History of what the user has been an editor for")
      @Valid
    public List<EditorialHistory> getEditorialHistory() {
    return editorialHistory;
  }

  public void setEditorialHistory(List<EditorialHistory> editorialHistory) {
    this.editorialHistory = editorialHistory;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CandidateDetails candidateDetails = (CandidateDetails) o;
    return Objects.equals(this.email, candidateDetails.email) &&
        Objects.equals(this.notes, candidateDetails.notes) &&
        Objects.equals(this.reviewHistory, candidateDetails.reviewHistory) &&
        Objects.equals(this.editorialHistory, candidateDetails.editorialHistory);
  }

  @Override
  public int hashCode() {
    return Objects.hash(email, notes, reviewHistory, editorialHistory);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CandidateDetails {\n");
    
    sb.append("    email: ").append(toIndentedString(email)).append("\n");
    sb.append("    notes: ").append(toIndentedString(notes)).append("\n");
    sb.append("    reviewHistory: ").append(toIndentedString(reviewHistory)).append("\n");
    sb.append("    editorialHistory: ").append(toIndentedString(editorialHistory)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
