package com.elsevier.find.reviewers.external;

import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Base64;
import java.util.List;

@Slf4j
@Service
public class ReviewerHub {
    private static final String APPLICATION_JSON = "application/json";

    @JsonIgnoreProperties(ignoreUnknown = true)
    @Data
    private static class AccessResponse {
        @JsonProperty("access")
        private List<String> access;
    }

    private final ObjectMapper objectMapper;
    private final HttpClient httpClient;
    private final String reviewerHubApiUrl;
    private final String reviewerHubAuth;

    public ReviewerHub(ObjectMapper objectMapper,
                       HttpClient httpClient,
                       @Value("${reviewerhub.client.base.url}") String reviewerHubApiUrl,
                       @Value("${reviewerhub.client.username}") String reviewerHubUsername,
                       @Value("${reviewerhub.client.password}") String reviewerHubPassword) {
        this.objectMapper = objectMapper;
        this.httpClient = httpClient;
        this.reviewerHubApiUrl = reviewerHubApiUrl.endsWith("/") ? reviewerHubApiUrl.substring(0, reviewerHubApiUrl.length() - 1) : reviewerHubApiUrl;
        this.reviewerHubAuth = String.format("Basic %s", Base64.getEncoder().encodeToString(
                String.format("%s:%s", reviewerHubUsername, reviewerHubPassword).getBytes()));
    }

    public void deleteCrowdsourcedReviewer(long id) {
        try {
            final String url = String.format("%s/crowdsourcedReviews/%d", reviewerHubApiUrl, id);

            log.info("Making delete crowdsourced reviewer request {}", url);

            final HttpRequest request = HttpRequest.newBuilder(new URI(url))
                    .header("Authorization", reviewerHubAuth)
                    .header("Content-Type", APPLICATION_JSON)
                    .header("Accept", APPLICATION_JSON)
                    .timeout(Duration.ofSeconds(5L))
                    .DELETE()
                    .build();

            HttpResponse<String> httpResponse = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

            int status = httpResponse.statusCode();
            if (status != HttpStatus.OK.value() && status != HttpStatus.NO_CONTENT.value()) {
                log.error("Failed to delete crowd sourced reviewer Id {} with status {} error {}", id, status, httpResponse.body());
                throw new InternalException(ErrorResponse.IdEnum.REVIEWERHUBFAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (InterruptedException e) {
            log.error("Failed to delete crowd sourced reviewer Id {} with InterruptedException", id, e);
            Thread.currentThread().interrupt();
            throw new InternalException(ErrorResponse.IdEnum.REVIEWERHUBFAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            log.error("Failed to delete crowd sourced reviewer Id {}", id, e);
            throw new InternalException(ErrorResponse.IdEnum.REVIEWERHUBFAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public boolean checkFindEditorsAccess(List<String> emails) {
        final String emailParam = String.join(",", emails);

        boolean hasAccess = false;
        try {
            final String url = String.format("%s/access?product=findEditors&emails=%s", reviewerHubApiUrl,
                    URLEncoder.encode(emailParam, StandardCharsets.UTF_8));

            log.info("Making Find Editors access request {}", url);

            final HttpRequest request = HttpRequest.newBuilder(new URI(url))
                    .header("Authorization", reviewerHubAuth)
                    .header("Content-Type", APPLICATION_JSON)
                    .header("Accept", APPLICATION_JSON)
                    .timeout(Duration.ofSeconds(5L))
                    .GET()
                    .build();

            HttpResponse<String> httpResponse = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

            if (httpResponse.statusCode() == HttpStatus.OK.value()) {
                final String responseContent = httpResponse.body();
                if (responseContent != null) {
                    AccessResponse response = objectMapper.readValue(responseContent, AccessResponse.class);
                    if (response.getAccess() != null) {
                        // If any of the users emails are returned, then they have access
                        hasAccess = !response.getAccess().isEmpty();
                    }
                }
            }
        } catch (InterruptedException e) {
            log.error("Failed to get access for user {} with InterruptedException", emails, e);
            Thread.currentThread().interrupt();
        } catch (Exception e) {
            log.error("Failed to get access for user {}", emails, e);
        }

        log.info("Find Editors access request response was {}", hasAccess);

        return hasAccess;
    }
}
