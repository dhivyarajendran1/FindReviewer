package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.Indicators;
import com.elsevier.find.reviewers.generated.model.PersonBase;
import com.elsevier.find.reviewers.generated.model.PersonDetailsReviewStatistics;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * PersonDetails
 */
@Validated



public class PersonDetails extends PersonBase  {
  @JsonProperty("affiliationName")
  private String affiliationName = null;

  @JsonProperty("affiliationCity")
  private String affiliationCity = null;

  @JsonProperty("affiliationCountry")
  private String affiliationCountry = null;

  @JsonProperty("publicationCount")
  private Integer publicationCount = null;

  @JsonProperty("hindex")
  private Integer hindex = null;

  @JsonProperty("citationCount")
  private Integer citationCount = null;

  @JsonProperty("keywords")
  @Valid
  private List<String> keywords = null;

  @JsonProperty("subjectAreas")
  @Valid
  private List<String> subjectAreas = null;

  @JsonProperty("indicators")
  @Valid
  private List<Indicators> indicators = null;

  @JsonProperty("reviewStatistics")
  @Valid
  private List<PersonDetailsReviewStatistics> reviewStatistics = null;

  @JsonProperty("editorialHistoryCount")
  private Integer editorialHistoryCount = null;

  public PersonDetails affiliationName(String affiliationName) {
    this.affiliationName = affiliationName;
    return this;
  }

  /**
   * Persons affiliation institute
   * @return affiliationName
   **/
  @Schema(example = "UCL", description = "Persons affiliation institute")
  
    public String getAffiliationName() {
    return affiliationName;
  }

  public void setAffiliationName(String affiliationName) {
    this.affiliationName = affiliationName;
  }

  public PersonDetails affiliationCity(String affiliationCity) {
    this.affiliationCity = affiliationCity;
    return this;
  }

  /**
   * Persons affiliation city
   * @return affiliationCity
   **/
  @Schema(example = "London", description = "Persons affiliation city")
  
    public String getAffiliationCity() {
    return affiliationCity;
  }

  public void setAffiliationCity(String affiliationCity) {
    this.affiliationCity = affiliationCity;
  }

  public PersonDetails affiliationCountry(String affiliationCountry) {
    this.affiliationCountry = affiliationCountry;
    return this;
  }

  /**
   * Persons affiliation country
   * @return affiliationCountry
   **/
  @Schema(example = "England", description = "Persons affiliation country")
  
    public String getAffiliationCountry() {
    return affiliationCountry;
  }

  public void setAffiliationCountry(String affiliationCountry) {
    this.affiliationCountry = affiliationCountry;
  }

  public PersonDetails publicationCount(Integer publicationCount) {
    this.publicationCount = publicationCount;
    return this;
  }

  /**
   * The number of publication this person has
   * @return publicationCount
   **/
  @Schema(example = "22", description = "The number of publication this person has")
  
    public Integer getPublicationCount() {
    return publicationCount;
  }

  public void setPublicationCount(Integer publicationCount) {
    this.publicationCount = publicationCount;
  }

  public PersonDetails hindex(Integer hindex) {
    this.hindex = hindex;
    return this;
  }

  /**
   * The Persons hIndex
   * @return hindex
   **/
  @Schema(example = "35", description = "The Persons hIndex")
  
    public Integer getHindex() {
    return hindex;
  }

  public void setHindex(Integer hindex) {
    this.hindex = hindex;
  }

  public PersonDetails citationCount(Integer citationCount) {
    this.citationCount = citationCount;
    return this;
  }

  /**
   * The number of citations this person has for their publications
   * @return citationCount
   **/
  @Schema(example = "105", description = "The number of citations this person has for their publications")
  
    public Integer getCitationCount() {
    return citationCount;
  }

  public void setCitationCount(Integer citationCount) {
    this.citationCount = citationCount;
  }

  public PersonDetails keywords(List<String> keywords) {
    this.keywords = keywords;
    return this;
  }

  public PersonDetails addKeywordsItem(String keywordsItem) {
    if (this.keywords == null) {
      this.keywords = new ArrayList<>();
    }
    this.keywords.add(keywordsItem);
    return this;
  }

  /**
   * Get keywords
   * @return keywords
   **/
  @Schema(description = "")
  
    public List<String> getKeywords() {
    return keywords;
  }

  public void setKeywords(List<String> keywords) {
    this.keywords = keywords;
  }

  public PersonDetails subjectAreas(List<String> subjectAreas) {
    this.subjectAreas = subjectAreas;
    return this;
  }

  public PersonDetails addSubjectAreasItem(String subjectAreasItem) {
    if (this.subjectAreas == null) {
      this.subjectAreas = new ArrayList<>();
    }
    this.subjectAreas.add(subjectAreasItem);
    return this;
  }

  /**
   * Get subjectAreas
   * @return subjectAreas
   **/
  @Schema(description = "")
  
    public List<String> getSubjectAreas() {
    return subjectAreas;
  }

  public void setSubjectAreas(List<String> subjectAreas) {
    this.subjectAreas = subjectAreas;
  }

  public PersonDetails indicators(List<Indicators> indicators) {
    this.indicators = indicators;
    return this;
  }

  public PersonDetails addIndicatorsItem(Indicators indicatorsItem) {
    if (this.indicators == null) {
      this.indicators = new ArrayList<>();
    }
    this.indicators.add(indicatorsItem);
    return this;
  }

  /**
   * List of indicators for the user to detail possible relationships or roles
   * @return indicators
   **/
  @Schema(description = "List of indicators for the user to detail possible relationships or roles")
      @Valid
    public List<Indicators> getIndicators() {
    return indicators;
  }

  public void setIndicators(List<Indicators> indicators) {
    this.indicators = indicators;
  }

  public PersonDetails reviewStatistics(List<PersonDetailsReviewStatistics> reviewStatistics) {
    this.reviewStatistics = reviewStatistics;
    return this;
  }

  public PersonDetails addReviewStatisticsItem(PersonDetailsReviewStatistics reviewStatisticsItem) {
    if (this.reviewStatistics == null) {
      this.reviewStatistics = new ArrayList<>();
    }
    this.reviewStatistics.add(reviewStatisticsItem);
    return this;
  }

  /**
   * Statistics of what the user has reviewed
   * @return reviewStatistics
   **/
  @Schema(description = "Statistics of what the user has reviewed")
      @Valid
    public List<PersonDetailsReviewStatistics> getReviewStatistics() {
    return reviewStatistics;
  }

  public void setReviewStatistics(List<PersonDetailsReviewStatistics> reviewStatistics) {
    this.reviewStatistics = reviewStatistics;
  }

  public PersonDetails editorialHistoryCount(Integer editorialHistoryCount) {
    this.editorialHistoryCount = editorialHistoryCount;
    return this;
  }

  /**
   * The number of editorial roles the user has held
   * minimum: 0
   * @return editorialHistoryCount
   **/
  @Schema(example = "3", description = "The number of editorial roles the user has held")
  
  @Min(0)  public Integer getEditorialHistoryCount() {
    return editorialHistoryCount;
  }

  public void setEditorialHistoryCount(Integer editorialHistoryCount) {
    this.editorialHistoryCount = editorialHistoryCount;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PersonDetails personDetails = (PersonDetails) o;
    return Objects.equals(this.affiliationName, personDetails.affiliationName) &&
        Objects.equals(this.affiliationCity, personDetails.affiliationCity) &&
        Objects.equals(this.affiliationCountry, personDetails.affiliationCountry) &&
        Objects.equals(this.publicationCount, personDetails.publicationCount) &&
        Objects.equals(this.hindex, personDetails.hindex) &&
        Objects.equals(this.citationCount, personDetails.citationCount) &&
        Objects.equals(this.keywords, personDetails.keywords) &&
        Objects.equals(this.subjectAreas, personDetails.subjectAreas) &&
        Objects.equals(this.indicators, personDetails.indicators) &&
        Objects.equals(this.reviewStatistics, personDetails.reviewStatistics) &&
        Objects.equals(this.editorialHistoryCount, personDetails.editorialHistoryCount) &&
        super.equals(o);
  }

  @Override
  public int hashCode() {
    return Objects.hash(affiliationName, affiliationCity, affiliationCountry, publicationCount, hindex, citationCount, keywords, subjectAreas, indicators, reviewStatistics, editorialHistoryCount, super.hashCode());
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PersonDetails {\n");
    sb.append("    ").append(toIndentedString(super.toString())).append("\n");
    sb.append("    affiliationName: ").append(toIndentedString(affiliationName)).append("\n");
    sb.append("    affiliationCity: ").append(toIndentedString(affiliationCity)).append("\n");
    sb.append("    affiliationCountry: ").append(toIndentedString(affiliationCountry)).append("\n");
    sb.append("    publicationCount: ").append(toIndentedString(publicationCount)).append("\n");
    sb.append("    hindex: ").append(toIndentedString(hindex)).append("\n");
    sb.append("    citationCount: ").append(toIndentedString(citationCount)).append("\n");
    sb.append("    keywords: ").append(toIndentedString(keywords)).append("\n");
    sb.append("    subjectAreas: ").append(toIndentedString(subjectAreas)).append("\n");
    sb.append("    indicators: ").append(toIndentedString(indicators)).append("\n");
    sb.append("    reviewStatistics: ").append(toIndentedString(reviewStatistics)).append("\n");
    sb.append("    editorialHistoryCount: ").append(toIndentedString(editorialHistoryCount)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
