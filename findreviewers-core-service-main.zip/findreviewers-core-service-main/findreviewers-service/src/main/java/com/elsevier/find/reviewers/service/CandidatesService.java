package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.dao.CandidateInfoDao;
import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.filter.SessionContext;
import com.elsevier.find.reviewers.generated.api.CandidatesApiDelegate;
import com.elsevier.find.reviewers.generated.model.CandidatesResponse;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.service.base.BaseService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
public class CandidatesService extends BaseService implements CandidatesApiDelegate {

    private final CandidateInfoDao candidateInfoDao;

    protected CandidatesService(ObjectMapper objectMapper,
                                CandidateInfoDao candidateInfoDao) {
        super(objectMapper);
        this.candidateInfoDao = candidateInfoDao;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class, readOnly = true)
    public ResponseEntity<CandidatesResponse> getCandidateDetails(List<String> emails, String xScope, String emJournalAcronym) {
        if (emails == null || emails.isEmpty()) {
            final Map<String, String> args = Map.of("emails", String.valueOf(emails));
            log.error("Candidates request made without emails {}", args);
            throw new InternalException(ErrorResponse.IdEnum.INVALIDARGUMENT, HttpStatus.BAD_REQUEST, args);
        }

        CandidatesResponse response = new CandidatesResponse();

        // The candidates endpoint only ever returns data that is specific to Elsevier, so for
        // non-Elsevier journals just return and empty response
        if (!SessionContext.isElsevierJournal()) {
            log.info("Candidate details for {} emails {} returned no results as non-Elsevier journal", emJournalAcronym, emails);
        } else {
            final List<String> lowerEmails = emails.stream().map(String::toLowerCase).collect(Collectors.toList());

            response.setCandidates(candidateInfoDao.getCandidateDetails(emJournalAcronym, lowerEmails));

            log.info("Candidate details for {} emails {} returned {} results", emJournalAcronym, emails, response.getCandidates().size());
        }

        return ResponseEntity.ok().body(response);
    }
}
