package com.elsevier.find.reviewers.dao.impl;

import com.elsevier.find.reviewers.dao.CandidateInfoDao;
import com.elsevier.find.reviewers.generated.model.CandidateDetails;
import com.elsevier.find.reviewers.generated.model.PersonDetailsReviewStatistics;
import com.elsevier.find.reviewers.generated.model.ReviewHistory;
import com.elsevier.find.reviewers.generated.model.ReviewHistory.StateEnum;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Implementation for the data access to review history
 */
// Suppress SonarQube 'String literals should not be duplicated' flagged against the inline sql
@SuppressWarnings("squid:S1192")
@Slf4j
@Repository
public class CandidateInfoDaoImpl extends BaseDaoImpl implements CandidateInfoDao {
    public static class ReviewStatisticsImpl implements ReviewStatistics {
        private Map<String, PersonDetailsReviewStatistics> statsByJournal = new LinkedHashMap<>();
        private long recentInvites = 0;
        private long recentNonResponses = 0;

        public List<PersonDetailsReviewStatistics> getStatistics() {
            return statsByJournal.isEmpty() ? null : new ArrayList<>(statsByJournal.values());
        }

        public boolean toRemove() {
            return recentInvites > 3 && recentInvites == recentNonResponses;
        }

        public PersonDetailsReviewStatistics getStatsForJournal(String journalAcronym) {
            return statsByJournal.computeIfAbsent(journalAcronym, k -> {
                PersonDetailsReviewStatistics journalStats = new PersonDetailsReviewStatistics();
                journalStats.setEmJournalAcronym(journalAcronym);
                journalStats.setInvitationCount(0);
                journalStats.setCompletedCount(0);
                journalStats.setWorkInProgressCount(0);
                return journalStats;
            });
        }

        public void incrementInviteIfRecent(boolean isRecent) {
            if (isRecent) {
                recentInvites++;
            }
        }

        public void incrementNonResponseIfRecent(boolean isRecent) {
            if (isRecent) {
                recentNonResponses++;
            }
        }
    }


    public CandidateInfoDaoImpl(NamedParameterJdbcTemplate dbSource, ObjectMapper objectMapper,
                                @Value("${findreviewers.cloud.ursdb:false}") String cloudUrsdbEnabled) {
        super(dbSource, objectMapper, cloudUrsdbEnabled);
    }

    /**
     * The Row mapper will convert the SQL returned to the object format
     */
    public class ReviewStatisticsResultsExtractor extends BaseRowMapper implements ResultSetExtractor<Map<String, ReviewStatistics>> {
        @SuppressWarnings("squid:S3776")
        @Override
        public Map<String, ReviewStatistics> extractData(ResultSet rs) throws SQLException {
            Map<String, ReviewStatistics> statsByUser = new HashMap<>();

            while (rs.next()) {
                // Get the details for all the statistics for this user
                ReviewStatisticsImpl statsForEmail = (ReviewStatisticsImpl)
                        statsByUser.computeIfAbsent(rs.getString("email"), k -> new ReviewStatisticsImpl());

                // Now from this user get the statistics for this journal
                PersonDetailsReviewStatistics journalStats =
                        statsForEmail.getStatsForJournal(rs.getString("journal_acronym"));

                final boolean isRecent = rs.getBoolean("recent");

                // Count every review entry regardless of state, and also handle any recent reviews
                journalStats.setInvitationCount(journalStats.getInvitationCount() + 1);
                statsForEmail.incrementInviteIfRecent(isRecent);

                if (rs.getBoolean("completed")) {
                    journalStats.setCompletedCount(journalStats.getCompletedCount() + 1);
                    final Long completeTime = getOptionalLong(rs, "rstop");
                    if (completeTime != null && (journalStats.getMostRecentCompleted() == null ||
                            completeTime > journalStats.getMostRecentCompleted())) {
                        journalStats.setMostRecentCompleted(completeTime);
                    }
                } else if (rs.getBoolean("terminated") || rs.getBoolean("uninvited")) {
                    statsForEmail.incrementNonResponseIfRecent(isRecent);
                } else if (!rs.getBoolean("declined") && (rs.getBoolean("work_in_progress") ||
                        rs.getBoolean("assigned_not_invited"))) {
                    // As multiple states can be set in EM at the same time, we need to check the priority order
                    // to make sure it is not also marked as one of the other states before we determine it is
                    // a work in progress
                    journalStats.setWorkInProgressCount(journalStats.getWorkInProgressCount() + 1);
                }
            }

            return statsByUser;
        }
    }

    class CandidateDetailsResultsExtractor extends BaseRowMapper implements ResultSetExtractor<List<CandidateDetails>> {
        @Override
        public List<CandidateDetails> extractData(ResultSet rs) throws SQLException {
            Map<String, CandidateDetails> detailsByEmail = new HashMap<>();

            while (rs.next()) {
                final String email = rs.getString("email");
                CandidateDetails details = detailsByEmail.computeIfAbsent(email, k -> {
                    CandidateDetails candidateDetails = new CandidateDetails();
                    candidateDetails.setEmail(email);

                    try {
                        String notesJson = getOptionalString(rs, "notes");
                        if (notesJson != null) {
                            candidateDetails.setNotes(objectMapper.readValue(notesJson, new TypeReference<>() {
                            }));
                        }
                    } catch (Exception e) {
                        log.error("Failed to load reviewer notes from database for email {}, error {}", email,
                                e.getMessage());
                    }

                    try {
                        String editorJson = getOptionalString(rs, "editorial_history");
                        if (editorJson != null) {
                            candidateDetails.setEditorialHistory(objectMapper.readValue(editorJson, new TypeReference<>() {
                            }));
                        }
                    } catch (Exception e) {
                        log.error("Failed to load editor history from database for email {}, error {}", email,
                                e.getMessage());
                    }
                    return candidateDetails;
                });

                String journalAcronym = rs.getString("journal_acronym");
                if (journalAcronym != null) {
                    details.addReviewHistoryItem(createReviewHistory(journalAcronym, rs));
                }
            }

            return detailsByEmail.values().stream().toList();
        }

        private ReviewHistory createReviewHistory(String journalAcronym, ResultSet rs) throws SQLException {
            ReviewHistory review = new ReviewHistory();
            review.setEmJournalAcronym(journalAcronym);
            review.setDocumentId(rs.getLong("document_id"));
            review.setRevision(rs.getInt("revision"));
            review.setStartDate(getOptionalLong(rs, "rstart"));
            review.setStopDate(getOptionalLong(rs, "rstop"));
            review.setAcceptDate(getOptionalLong(rs, "accepted_date"));
            review.setDueDate(getOptionalLong(rs, "due_date"));
            review.setReviewerDecision(rs.getString("reviewer_decision"));
            review.setEditorDecision(rs.getString("editor_decision"));

            if (rs.getBoolean("completed")) {
                review.setState(StateEnum.COMPLETED);
            } else if (rs.getBoolean("declined")) {
                review.setState(StateEnum.DECLINED);
            } else if (rs.getBoolean("terminated")) {
                review.setState(StateEnum.TERMINATED);
            } else if (rs.getBoolean("uninvited")) {
                review.setState(StateEnum.UNINVITED);
            } else if (rs.getBoolean("work_in_progress")) {
                review.setState(StateEnum.WORKINPROGRESS);
            } else if (rs.getBoolean("assigned_not_invited")) {
                review.setState(StateEnum.ASSIGNEDNOTINVITED);
            } else if (rs.getBoolean("alternate")) {
                review.setState(StateEnum.ALTERNATE);
            } else if (rs.getBoolean("has_not_responded")) {
                review.setState(StateEnum.HASNOTRESPONDED);
            } else if (rs.getBoolean("promoted")) {
                review.setState(StateEnum.PROMOTED);
            }

            return review;
        }
    }

    @Override
    public Map<String, ReviewStatistics> getReviewStatistics(List<String> emails) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("emails", emails);

        String sql = """
                select e."Email__lower" as email, j."JOURNAL__upper" as journal_acronym,
                extract(epoch from r."RSTOP") * 1000 as rstop,
                (r."RSTART" > NOW() - INTERVAL '1 year')::bool as recent,
                r."WORKINPROGRESS" as work_in_progress, r."DECLINED" as declined, r."TERMINATED" as terminated,
                r."COMPLETED" as completed, r."UNINVITED" as uninvited,
                r."ASSIGNED_NOT_INVITED" as assigned_not_invited
                from rr_ursdb."ROLEREVU" r
                inner join rr_ursdb."JOURNAL_INFO" j on j."JOURNAL_ID" = r."JOURNAL_ID"
                inner join rr_ursdb."ADDRESS_EMAIL" e on e."JOURNAL_ID" = r."JOURNAL_ID" and e."PeopleID" = r."PEOPLEID"
                where e."Email__lower" in (:emails)
                """;

        if (isCloudUrsdb) {
            sql = """
                    select e.email__lower as email, j.journal__upper as journal_acronym,
                    extract(epoch from r.rstop) * 1000 as rstop,
                    (r.rstart > NOW() - INTERVAL '1 year')::bool as recent,
                    r.workinprogress as work_in_progress, r.declined as declined, r.terminated as terminated,
                    r.completed as completed, r.uninvited as uninvited,
                    r.assigned_not_invited as assigned_not_invited
                    from fr_ursdb.rolerevu r
                    inner join fr_ursdb.journal_info j on j.journal_id = r.journal_id
                    inner join fr_ursdb.address_email e on e.journal_id = r.journal_id and e.peopleid = r.peopleid
                    where e.email__lower in (:emails)
                    """;
        }

        return dbSource.query(sql, params, new ReviewStatisticsResultsExtractor());
    }

    @Override
    public List<CandidateDetails> getCandidateDetails(String emJournalAcronym, List<String> emails) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("emJournalAcronym", emJournalAcronym != null ? emJournalAcronym.toUpperCase() : null);
        params.addValue("emails", emails);

        String sql = """
                with notes as (
                  select e."Email__lower" as email, json_agg(json_strip_nulls(json_build_object('postedBy', n."POSTED_BY_FORMATTED_NAME",
                  'postedDate', trunc(extract(epoch from n."POST_DATE") * 1000), 'note', n."NOTE"))) as note
                  from rr_ursdb."DETAILED_PEOPLE_NOTES" n
                  inner join rr_ursdb."JOURNAL_INFO" j on j."JOURNAL_ID" = n."JOURNAL_ID"
                  inner join rr_ursdb."ADDRESS_EMAIL" e on e."JOURNAL_ID" = n."JOURNAL_ID" and e."PeopleID" = n."PEOPLEID"
                  where j."JOURNAL__upper" = :emJournalAcronym and e."Email__lower" in (:emails)
                  group by e."Email__lower"
                ),
                review_history as (
                  select e."Email__lower" as email, j."JOURNAL__upper" as journal_acronym,
                  r."DOCUMENTID" as document_id, r."REVISION" as revision,
                  extract(epoch from r."RSTART") * 1000 as rstart, extract(epoch from r."RSTOP") * 1000 as rstop,
                  r."WORKINPROGRESS" as work_in_progress, r."HASNOTRESPONDED" as has_not_responded,
                  r."DECLINED" as declined, r."TERMINATED" as terminated, r."COMPLETED" as completed,
                  r."ALTERNATE" as alternate, r."PROMOTED" as promoted, r."UNINVITED" as uninvited,
                  r."ASSIGNED_NOT_INVITED" as assigned_not_invited,
                  extract(epoch from r."ACCEPTDATE") * 1000 as accepted_date,
                  extract(epoch from r."DUEDATE" ) * 1000 as due_date,
                  r."RRESULT" as reviewer_decision,
                  (select df."DECISIONFAMILYNAME" from rr_ursdb."DECISION" d
                   inner join rr_ursdb."DECISIONFAMILY" df on df."JOURNAL_ID" = d."JOURNAL_ID"
                     and df."DECISIONFAMILYID" = d."DECISIONFAMILYID"
                   where d."JOURNAL_ID" = r."JOURNAL_ID" and d."DECISIONID" = (
                     select max(re."DECISIONID") from rr_ursdb."ROLEEDIT" re
                     where r."RRESULT" is not null and re."JOURNAL_ID" = r."JOURNAL_ID" and re."DOCUMENTID" = r."DOCUMENTID"
                     and re."REVISION" = r."REVISION" and re."DECISIONID" is not null)) as editor_decision
                  from rr_ursdb."ROLEREVU" r
                  inner join rr_ursdb."JOURNAL_INFO" j on j."JOURNAL_ID" = r."JOURNAL_ID"
                  inner join rr_ursdb."ADDRESS_EMAIL" e on e."JOURNAL_ID" = r."JOURNAL_ID" and e."PeopleID" = r."PEOPLEID"
                  where e."Email__lower" in (:emails)
                ),
                editor_history as (
                  select e.email, json_agg(json_strip_nulls(json_build_object('emJournalAcronym',
                   i."JOURNAL__upper", 'journalTitle', j.title, 'classification', e.classification,
                   'role', e.role, 'startDate', e.start_date, 'endDate', e.stop_date))) as editorial_history
                  from find_reviewers.rh_editor e
                  inner join find_reviewers.eph_journal j on j.acronym = e.journal_acronym
                  inner join rr_ursdb."JOURNAL_INFO" i on i.pts_code = j.acronym
                  where e.email in (:emails)
                  group by e.email
                ),
                emails_with_data as (
                  select email from notes
                  union
                  select email from review_history
                  union
                  select email from editor_history
                )
                select e.email as email,
                 n.note as notes,
                 r.journal_acronym as journal_acronym,
                 r.document_id as document_id,
                 r.revision as revision,
                 r.rstart as rstart,
                 r.rstop as rstop,
                 r.work_in_progress as work_in_progress,
                 r.has_not_responded as has_not_responded,
                 r.declined as declined,
                 r.terminated as terminated,
                 r.completed as completed,
                 r.alternate as alternate,
                 r.promoted as promoted,
                 r.uninvited as uninvited,
                 r.assigned_not_invited as assigned_not_invited,
                 r.accepted_date as accepted_date,
                 r.due_date as due_date,
                 r.reviewer_decision as reviewer_decision,
                 r.editor_decision as editor_decision,
                 h.editorial_history as editorial_history
                from emails_with_data e
                left join notes n on n.email = e.email
                left join review_history r on r.email = e.email
                left join editor_history h on h.email = e.email
                """;

        if (isCloudUrsdb) {
            sql = """
                    with notes as (
                      select e.email__lower as email, json_agg(json_strip_nulls(json_build_object('postedBy', n.posted_by_formatted_name,
                      'postedDate', trunc(extract(epoch from n.post_date) * 1000), 'note', n.note))) as note
                      from fr_ursdb.detailed_people_notes n
                      inner join fr_ursdb.journal_info j on j.journal_id = n.journal_id
                      inner join fr_ursdb.address_email e on e.journal_id = n.journal_id and e.peopleid = n.peopleid
                      where j.journal__upper = :emJournalAcronym and e.email__lower in (:emails)
                      group by e.email__lower
                    ),
                    review_history as (
                      select e.email__lower as email, j.journal__upper as journal_acronym,
                      r.documentid as document_id, r.revision as revision,
                      extract(epoch from r.rstart) * 1000 as rstart, extract(epoch from r.rstop) * 1000 as rstop,
                      r.workinprogress as work_in_progress, r.hasnotresponded as has_not_responded,
                      r.declined as declined, r.terminated as terminated, r.completed as completed,
                      r.alternate as alternate, r.promoted as promoted, r.uninvited as uninvited,
                      r.assigned_not_invited as assigned_not_invited,
                      extract(epoch from r.acceptdate) * 1000 as accepted_date,
                      extract(epoch from r.duedate ) * 1000 as due_date,
                      r.rresult as reviewer_decision,
                      (select df.decisionfamilyname from fr_ursdb.decision d
                       inner join fr_ursdb.decisionfamily df on df.journal_id = d.journal_id
                         and df.decisionfamilyid = d.decisionfamilyid
                       where d.journal_id = r.journal_id and d.decisionid = (
                         select max(re.decisionid) from fr_ursdb.roleedit re
                         where r.rresult is not null and re.journal_id = r.journal_id and re.documentid = r.documentid
                         and re.revision = r.revision and re.decisionid is not null)) as editor_decision
                      from fr_ursdb.rolerevu r
                      inner join fr_ursdb.journal_info j on j.journal_id = r.journal_id
                      inner join fr_ursdb.address_email e on e.journal_id = r.journal_id and e.peopleid = r.peopleid
                      where e.email__lower in (:emails)
                    ),
                    editor_history as (
                      select e.email, json_agg(json_strip_nulls(json_build_object('emJournalAcronym',
                       i.journal__upper, 'journalTitle', j.title, 'classification', e.classification,
                       'role', e.role, 'startDate', e.start_date, 'endDate', e.stop_date))) as editorial_history
                      from find_reviewers.rh_editor e
                      inner join find_reviewers.eph_journal j on j.acronym = e.journal_acronym
                      inner join fr_ursdb.journal_info i on i.pts_code = j.acronym
                      where e.email in (:emails)
                      group by e.email
                    ),
                    emails_with_data as (
                      select email from notes
                      union
                      select email from review_history
                      union
                      select email from editor_history
                    )
                    select e.email as email,
                     n.note as notes,
                     r.journal_acronym as journal_acronym,
                     r.document_id as document_id,
                     r.revision as revision,
                     r.rstart as rstart,
                     r.rstop as rstop,
                     r.work_in_progress as work_in_progress,
                     r.has_not_responded as has_not_responded,
                     r.declined as declined,
                     r.terminated as terminated,
                     r.completed as completed,
                     r.alternate as alternate,
                     r.promoted as promoted,
                     r.uninvited as uninvited,
                     r.assigned_not_invited as assigned_not_invited,
                     r.accepted_date as accepted_date,
                     r.due_date as due_date,
                     r.reviewer_decision as reviewer_decision,
                     r.editor_decision as editor_decision,
                     h.editorial_history as editorial_history
                    from emails_with_data e
                    left join notes n on n.email = e.email
                    left join review_history r on r.email = e.email
                    left join editor_history h on h.email = e.email
                    """;
        }

        return dbSource.query(sql, params, new CandidateDetailsResultsExtractor());
    }
}
