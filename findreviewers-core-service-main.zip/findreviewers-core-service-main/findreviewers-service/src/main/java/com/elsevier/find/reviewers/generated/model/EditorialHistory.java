package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * Editorial history for a given user
 */
@Schema(description = "Editorial history for a given user")
@Validated



public class EditorialHistory   {
  @JsonProperty("emJournalAcronym")
  private String emJournalAcronym = null;

  @JsonProperty("journalTitle")
  private String journalTitle = null;

  /**
   * The classification of the editor
   */
  public enum ClassificationEnum {
    HIGHESTRANKING("highestRanking"),
    
    LOWERRANKING("lowerRanking"),
    
    EDITORIALBOARDMEMBER("editorialBoardMember"),
    
    GUESTEDITOR("guestEditor");

    private String value;

    ClassificationEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static ClassificationEnum fromValue(String text) {
      for (ClassificationEnum b : ClassificationEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("classification")
  private ClassificationEnum classification = null;

  @JsonProperty("role")
  private String role = null;

  @JsonProperty("startDate")
  private Long startDate = null;

  @JsonProperty("endDate")
  private Long endDate = null;

  public EditorialHistory emJournalAcronym(String emJournalAcronym) {
    this.emJournalAcronym = emJournalAcronym;
    return this;
  }

  /**
   * EM Journal acronym they were an editor of
   * @return emJournalAcronym
   **/
  @Schema(example = "ACR", description = "EM Journal acronym they were an editor of")
  
    public String getEmJournalAcronym() {
    return emJournalAcronym;
  }

  public void setEmJournalAcronym(String emJournalAcronym) {
    this.emJournalAcronym = emJournalAcronym;
  }

  public EditorialHistory journalTitle(String journalTitle) {
    this.journalTitle = journalTitle;
    return this;
  }

  /**
   * The title of the journal they were an editor for
   * @return journalTitle
   **/
  @Schema(example = "Journal of Science", required = true, description = "The title of the journal they were an editor for")
      @NotNull

    public String getJournalTitle() {
    return journalTitle;
  }

  public void setJournalTitle(String journalTitle) {
    this.journalTitle = journalTitle;
  }

  public EditorialHistory classification(ClassificationEnum classification) {
    this.classification = classification;
    return this;
  }

  /**
   * The classification of the editor
   * @return classification
   **/
  @Schema(example = "editorialBoardMember", required = true, description = "The classification of the editor")
      @NotNull

    public ClassificationEnum getClassification() {
    return classification;
  }

  public void setClassification(ClassificationEnum classification) {
    this.classification = classification;
  }

  public EditorialHistory role(String role) {
    this.role = role;
    return this;
  }

  /**
   * The text description of the role
   * @return role
   **/
  @Schema(example = "Editor in Chief", description = "The text description of the role")
  
    public String getRole() {
    return role;
  }

  public void setRole(String role) {
    this.role = role;
  }

  public EditorialHistory startDate(Long startDate) {
    this.startDate = startDate;
    return this;
  }

  /**
   * The date the editor role started (EPOCH - milliseconds)
   * minimum: 0
   * @return startDate
   **/
  @Schema(example = "1579866980000", description = "The date the editor role started (EPOCH - milliseconds)")
  
  @Min(0L)  public Long getStartDate() {
    return startDate;
  }

  public void setStartDate(Long startDate) {
    this.startDate = startDate;
  }

  public EditorialHistory endDate(Long endDate) {
    this.endDate = endDate;
    return this;
  }

  /**
   * The date the editor role ended (EPOCH - milliseconds)
   * minimum: 0
   * @return endDate
   **/
  @Schema(example = "1579867000000", description = "The date the editor role ended (EPOCH - milliseconds)")
  
  @Min(0L)  public Long getEndDate() {
    return endDate;
  }

  public void setEndDate(Long endDate) {
    this.endDate = endDate;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    EditorialHistory editorialHistory = (EditorialHistory) o;
    return Objects.equals(this.emJournalAcronym, editorialHistory.emJournalAcronym) &&
        Objects.equals(this.journalTitle, editorialHistory.journalTitle) &&
        Objects.equals(this.classification, editorialHistory.classification) &&
        Objects.equals(this.role, editorialHistory.role) &&
        Objects.equals(this.startDate, editorialHistory.startDate) &&
        Objects.equals(this.endDate, editorialHistory.endDate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(emJournalAcronym, journalTitle, classification, role, startDate, endDate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class EditorialHistory {\n");
    
    sb.append("    emJournalAcronym: ").append(toIndentedString(emJournalAcronym)).append("\n");
    sb.append("    journalTitle: ").append(toIndentedString(journalTitle)).append("\n");
    sb.append("    classification: ").append(toIndentedString(classification)).append("\n");
    sb.append("    role: ").append(toIndentedString(role)).append("\n");
    sb.append("    startDate: ").append(toIndentedString(startDate)).append("\n");
    sb.append("    endDate: ").append(toIndentedString(endDate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
