package com.elsevier.find.reviewers.dao;


import java.util.List;

/**
 * Interface that supports operations on journals
 */
public interface UserDao extends BaseDao {

    /**
     * Determines if an email address is allowed access to the find editor tool
     *
     * @param emails List of emails to check
     * @return True is allowed, otherwise false
     */
    boolean isAllowedFindEditorAccess(List<String> emails);
}
