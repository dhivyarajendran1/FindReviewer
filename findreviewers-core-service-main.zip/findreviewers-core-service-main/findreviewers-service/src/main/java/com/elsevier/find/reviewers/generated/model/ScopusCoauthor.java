package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.Indicators;
import com.elsevier.find.reviewers.generated.model.PersonDetails;
import com.elsevier.find.reviewers.generated.model.PersonDetailsReviewStatistics;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * ScopusCoauthor
 */
@Validated



public class ScopusCoauthor extends PersonDetails  {
  @JsonProperty("coauthoredCount")
  private Integer coauthoredCount = null;

  @JsonProperty("publishedInJournalCount")
  private Integer publishedInJournalCount = null;

  public ScopusCoauthor coauthoredCount(Integer coauthoredCount) {
    this.coauthoredCount = coauthoredCount;
    return this;
  }

  /**
   * The number of publication this author has coauthored
   * @return coauthoredCount
   **/
  @Schema(example = "3", description = "The number of publication this author has coauthored")
  
    public Integer getCoauthoredCount() {
    return coauthoredCount;
  }

  public void setCoauthoredCount(Integer coauthoredCount) {
    this.coauthoredCount = coauthoredCount;
  }

  public ScopusCoauthor publishedInJournalCount(Integer publishedInJournalCount) {
    this.publishedInJournalCount = publishedInJournalCount;
    return this;
  }

  /**
   * The number publications this author has in this journal
   * @return publishedInJournalCount
   **/
  @Schema(example = "2", description = "The number publications this author has in this journal")
  
    public Integer getPublishedInJournalCount() {
    return publishedInJournalCount;
  }

  public void setPublishedInJournalCount(Integer publishedInJournalCount) {
    this.publishedInJournalCount = publishedInJournalCount;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ScopusCoauthor scopusCoauthor = (ScopusCoauthor) o;
    return Objects.equals(this.coauthoredCount, scopusCoauthor.coauthoredCount) &&
        Objects.equals(this.publishedInJournalCount, scopusCoauthor.publishedInJournalCount) &&
        super.equals(o);
  }

  @Override
  public int hashCode() {
    return Objects.hash(coauthoredCount, publishedInJournalCount, super.hashCode());
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ScopusCoauthor {\n");
    sb.append("    ").append(toIndentedString(super.toString())).append("\n");
    sb.append("    coauthoredCount: ").append(toIndentedString(coauthoredCount)).append("\n");
    sb.append("    publishedInJournalCount: ").append(toIndentedString(publishedInJournalCount)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
