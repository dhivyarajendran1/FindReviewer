package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.dao.JournalDao;
import com.elsevier.find.reviewers.generated.api.JournalsApiDelegate;
import com.elsevier.find.reviewers.generated.model.JournalsResponse;
import com.elsevier.find.reviewers.service.base.BaseService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
public class JournalsService extends BaseService implements JournalsApiDelegate {
    private final JournalDao journalDao;

    protected JournalsService(ObjectMapper objectMapper,
                              JournalDao journalDao) {
        super(objectMapper);
        this.journalDao = journalDao;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class, readOnly = true)
    public ResponseEntity<JournalsResponse> getJournals(String xScope) {

        JournalsResponse response = new JournalsResponse();
        response.setJournals(journalDao.getJournals());

        log.info("Journal request returned {} journals", response.getJournals().size());

        return ResponseEntity.ok().body(response);
    }
}
