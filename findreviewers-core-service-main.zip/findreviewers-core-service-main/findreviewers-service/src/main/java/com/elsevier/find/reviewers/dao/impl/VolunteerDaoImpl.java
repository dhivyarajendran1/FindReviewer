package com.elsevier.find.reviewers.dao.impl;

import com.elsevier.find.reviewers.dao.VolunteerDao;
import com.elsevier.find.reviewers.generated.model.Volunteer;
import com.elsevier.find.reviewers.utils.PersonDetailsUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

/**
 * Implementation for the data access to volunteers
 */
// Suppress SonarQube 'String literals should not be duplicated' flagged against the inline sql
@SuppressWarnings("squid:S1192")
@Slf4j
@Repository
public class VolunteerDaoImpl extends BaseDaoImpl implements VolunteerDao {
    public VolunteerDaoImpl(NamedParameterJdbcTemplate dbSource, ObjectMapper objectMapper,
                            @Value("${findreviewers.cloud.ursdb:false}") String cloudUrsdbEnabled) {
        super(dbSource, objectMapper, cloudUrsdbEnabled);
    }

    /**
     * The Row mapper will convert the SQL returned to the object format
     */
    class VolunteerRowMapper extends BaseRowMapper implements RowMapper<Volunteer> {
        @Override
        public Volunteer mapRow(ResultSet rs, int rowNum) throws SQLException {
            Volunteer volunteer = new Volunteer();
            volunteer.setWebUserId(rs.getLong("web_user_id"));
            volunteer.addEmailsItem(rs.getString("email"));
            volunteer.setFirstName(rs.getString("given_name"));
            volunteer.setLastName(rs.getString("family_name"));

            volunteer.setDisplayName(rs.getString("display_name"));
            PersonDetailsUtils.setDisplayName(volunteer);

            volunteer.setEmJournalAcronym(rs.getString("em_journal_acronym"));
            volunteer.setVolunteerDate(rs.getLong("volunteer_date"));
            volunteer.setReason(getReason(rs));
            volunteer.setMessage(rs.getString("message"));
            volunteer.setCampaign(rs.getString("campaign"));

            final String classificationsJson = rs.getString("classifications");
            if (classificationsJson != null && !classificationsJson.isBlank()) {
                try {
                    Arrays.stream(objectMapper.readValue(classificationsJson, String[].class))
                            .forEach(volunteer::addClassificationCodesItem);
                } catch (JsonProcessingException e) {
                    log.error("Failed to load classifications from database for webUserId {}, error {}", volunteer.getWebUserId(),
                            e.getMessage());
                }
            }

            final String scopusJson = rs.getString("scopus_ids");
            if (scopusJson != null && !scopusJson.isBlank()) {
                try {
                    Arrays.stream(objectMapper.readValue(scopusJson, String[].class)).forEach(volunteer::addScopusIdsItem);
                } catch (JsonProcessingException e) {
                    log.error("Failed to load Scopus from database for webUserId {}, error {}", volunteer.getWebUserId(),
                            e.getMessage());
                }
            }

            return volunteer;
        }

        private Volunteer.ReasonEnum getReason(ResultSet rs) throws SQLException {
            Volunteer.ReasonEnum reason = null;
            String dbReason = rs.getString("reason");
            if (dbReason != null) {
                switch (dbReason) {
                    case "ExpertOrInterest":
                        reason = Volunteer.ReasonEnum.EXPERTORINTEREST;
                        break;
                    case "PrestigeOfJournal":
                        reason = Volunteer.ReasonEnum.PRESTIGEOFJOURNAL;
                        break;
                    case "PreviouslyPublished":
                        reason = Volunteer.ReasonEnum.PREVIOUSLYPUBLISHED;
                        break;
                    case "LearnAndStayUpToDate":
                        reason = Volunteer.ReasonEnum.LEARNANDSTAYUPTODATE;
                        break;
                    default:
                        log.error("Unexpected reason for volunteering found {}", dbReason);
                        break;
                }
            }
            return reason;
        }
    }

    @Override
    public List<Volunteer> getVolunteersByEmJournalAcronym(String emJournalAcronym,
                                                           Integer offset,
                                                           Integer limit) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("emJournalAcronym", emJournalAcronym.toUpperCase());

        // The query when doing the join on the statistics joins on the email to both the volunteers and the profile
        // tables, although not required for the mapping of the data, it does improve performance as shown in the
        // explain plan
        String sql = """
                select v.web_user_id as web_user_id, v.email as email, v.display_name as display_name,
                v.given_name as given_name, v.family_name as family_name, j."JOURNAL__upper" as em_journal_acronym,
                v.volunteer_date as volunteer_date, v.reason as reason, v.message as message,
                jsonb_path_query_array(v.classifications, '$.classifications[*].code') as classifications,
                v.scopus_ids->'scopus' as scopus_ids, v.campaign as campaign
                from find_reviewers.rh_review_volunteer v
                inner join rr_ursdb."JOURNAL_INFO" j on j.pts_code = v.journal_acronym
                left join find_reviewers.inoperative_email i on i.email = v.email
                where j."JOURNAL__upper" = :emJournalAcronym and v.scopus_ids is not null and i.email is null
                order by v.volunteer_date desc
                """ + toSqlPaging(offset, limit, params);

        if (isCloudUrsdb) {
            sql = """
                    select v.web_user_id as web_user_id, v.email as email, v.display_name as display_name,
                    v.given_name as given_name, v.family_name as family_name, j.journal__upper as em_journal_acronym,
                    v.volunteer_date as volunteer_date, v.reason as reason, v.message as message,
                    jsonb_path_query_array(v.classifications, '$.classifications[*].code') as classifications,
                    v.scopus_ids->'scopus' as scopus_ids, v.campaign as campaign
                    from find_reviewers.rh_review_volunteer v
                    inner join fr_ursdb.journal_info j on j.pts_code = v.journal_acronym
                    left join find_reviewers.inoperative_email i on i.email = v.email
                    where j.journal__upper = :emJournalAcronym and v.scopus_ids is not null and i.email is null
                    order by v.volunteer_date desc
                    """ + toSqlPaging(offset, limit, params);
        }

        return dbSource.query(sql, params, new VolunteerRowMapper());
    }

    @Override
    public List<Long> getCrowdsourcedReviewerIds(String emJournalAcronym, long documentId, List<String> emails) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("emJournalAcronym", emJournalAcronym.toUpperCase());
        params.addValue("documentId", documentId);
        params.addValue("emails", emails);

        String sql = """
                select c.id as id from find_reviewers.rh_crowdsourced_manuscript_review c
                inner join rr_ursdb."JOURNAL_INFO" j on j.pts_code = c.journal_acronym
                where j."JOURNAL__upper" = :emJournalAcronym and c.document_id = :documentId and c.email in (:emails)
                """;

        if (isCloudUrsdb) {
            sql = """
                    select c.id as id from find_reviewers.rh_crowdsourced_manuscript_review c
                    inner join fr_ursdb.journal_info j on j.pts_code = c.journal_acronym
                    where j.journal__upper = :emJournalAcronym and c.document_id = :documentId and c.email in (:emails)
                    """;
        }

        return dbSource.query(sql, params, (rs, rowNum) -> rs.getLong("id"));
    }
}
