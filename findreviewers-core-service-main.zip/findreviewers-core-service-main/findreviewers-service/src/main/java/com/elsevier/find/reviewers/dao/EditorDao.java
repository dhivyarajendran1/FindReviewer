package com.elsevier.find.reviewers.dao;


import com.elsevier.find.reviewers.generated.model.Editor;

import java.util.List;

/**
 * Interface that supports operations on journals
 */
public interface EditorDao extends BaseDao {

    /**
     * Gets all the Editorial Board members for a given EM journal acronym
     *
     * @param emJournalAcronym EM Journal Acronym to get EBMs for
     * @param offset           Where to start the listing from
     * @param limit            Maximum number of entries to return
     * @return List of editor details
     */
    List<Editor> getEditorialBoardMembersByEmJournalAcronym(String emJournalAcronym,
                                                            Integer offset,
                                                            Integer limit);

    /**
     * Determines if an email address belongs to a L1 or L2 editor
     *
     * @param emails List of emails to check
     * @return True is an editor, otherwise false
     */
    boolean isEditor(String emJournalAcronym, List<String> emails);
}
