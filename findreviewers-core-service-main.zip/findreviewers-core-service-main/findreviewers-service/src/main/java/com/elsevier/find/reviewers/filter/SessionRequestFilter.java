package com.elsevier.find.reviewers.filter;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.elsevier.find.reviewers.utils.CookieManager;
import com.elsevier.find.reviewers.utils.CookieManager.SessionData;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.endpoint.web.servlet.ControllerEndpointHandlerMapping;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Filter that will be automatically triggered when the REST interface is invoked and will ensure that the Session was
 * correctly authorized.
 * <p>
 * Note: Filters are always called before ResponseHandlers, so this will not trigger the Exception Handler
 * as such we need to return an error response rather than throw exceptions from this class
 */
@Slf4j
@Component
public class SessionRequestFilter extends OncePerRequestFilter {
    @Data
    @SuppressWarnings("squid:S00116")
    private static class SecondaryEmails {
        private String email;
        private boolean email_verified;
    }

    // The default header for JWT storage is "Authorization" however with the AWS Application Load Balancer
    // it stores the JWT in a custom header called x-amzn-oidc-data
    // Note: The default header for JWT storage is prefixed by "Bearer ", but for AWS Application
    // Load Balancer it uses a custom header without any prefix
    private static final String AUTH_HEADER_NAME = "x-amzn-oidc-data";

    private final ControllerEndpointHandlerMapping handlerMapping;
    private final CookieManager cookieManager;
    private final boolean isNonProd;

    @Autowired
    public SessionRequestFilter(ControllerEndpointHandlerMapping handlerMapping,
                                CookieManager cookieManager,
                                @Value("${spring.profiles.active:unknown}") String activeProfile) {
        this.handlerMapping = handlerMapping;
        this.cookieManager = cookieManager;
        this.isNonProd = "nonprod".equals(activeProfile);
    }

    /**
     * Class to handle all the rules that enforce if a call should be authenticated or not
     */
    private static final class AuthenticationRules {
        private static final Set<String> exactMatch = Set.of("/", "/ping", "/api-docs", "/v3/api-docs", "/favicon.ico", "/authenticate");

        private static final Set<String> startsWith = Set.of("/swagger-ui/", "/swagger-resources", "/v3/");

        /**
         * Checks if a URI should be authenticated
         *
         * @param requestUri Full URI of the request
         * @return True if requires authentication, false otherwise
         */
        public static boolean needsAuthentication(String requestUri) {
            final String uri = cleanRequestUri(requestUri);

            if (uri == null || exactMatch.contains(uri)) {
                return false;
            }
            return startsWith.stream().parallel().noneMatch(uri::startsWith);
        }

        public static boolean isCallOnSupportedInterface(String requestUri, ControllerEndpointHandlerMapping handlerMapping) {
            final String uri = cleanRequestUri(requestUri);

            if (handlerMapping == null) {
                return true;
            }

            return handlerMapping.getHandlerMethods().keySet().stream().anyMatch(i -> i.getDirectPaths().contains(uri));
        }

        private static String cleanRequestUri(String requestUri) {
            if (requestUri == null) {
                return null;
            }
            return requestUri.replace("/api/v1", "");
        }
    }

    @Override
    @SuppressWarnings("squid:S3776")
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        // The client can optionally provide a correlationId. This will then be tagged on every log message
        // so that the end to end flow can be followed. If the client does not provide one, then create our
        // own, with multiple threads used, it will also make it easier to follow the server code
        String correlationId = request.getHeader("X-CorrelationId");
        if (correlationId == null || correlationId.isBlank()) {
            correlationId = UUID.randomUUID().toString();
        }

        try {
            ThreadContext.put("correlationId", correlationId);

            processIdentity(request);

            if (AuthenticationRules.needsAuthentication(request.getRequestURI())) {
                boolean isAuthorised = false;

                final Cookie[] requestCookies = request.getCookies();
                if (requestCookies != null) {
                    final String scope = request.getHeader("X-Scope");

                    Cookie cookie = Arrays.stream(requestCookies).filter(c -> cookieManager.isSessionCookie(scope, c))
                            .findFirst().orElse(null);

                    if (cookie != null) {
                        SessionData sessionData = cookieManager.getSessionData(cookie);
                        if (sessionData != null) {
                            // Create the Session Context so that it can be accessed from anywhere
                            SessionContext.initialize(sessionData);
                            log.debug("Request authorised with session {}", sessionData);
                            isAuthorised = true;
                        }
                    }
                }
                if (!isAuthorised) {
                    if (AuthenticationRules.isCallOnSupportedInterface(request.getRequestURI(), handlerMapping)) {
                        log.error("Request made without valid session cookie for {}", request.getRequestURI());
                        response.setStatus(HttpStatus.UNAUTHORIZED.value());
                    } else {
                        log.warn("Request made without valid session cookie on unknown URI {}", request.getRequestURI());
                        response.setStatus(HttpStatus.NOT_FOUND.value());
                    }
                    SessionContext.destroy();
                    return;
                }
            }

            filterChain.doFilter(request, response);
        } finally {
            ThreadContext.clearAll();
        }

        // Make sure we clean up the Session Context once we have finished the request. This is good so that any future
        // call to the interface does not accidentally reuse the same session context. In reality that will never happen
        // as it will be checked every time we make any call
        SessionContext.destroy();
    }

    /**
     * The Identity support is optional, so will never return an error, it will add the details to
     * the session if available
     *
     * @param request The details of the request made to the service
     */
    @SuppressWarnings("squid:S3776")
    private void processIdentity(HttpServletRequest request) {
        // Get the authentication header, as the tokens are passed in the authentication header
        String token = request.getHeader(AUTH_HEADER_NAME);

        if (token != null) {
            try {
                // Get the claims out of the token, the following does not currently validate the token, if that was
                // desirable then we can add in .setSigningKey()
                DecodedJWT jwtDecoded = JWT.decode(token);

                // The WebUserId is in the "sub" field
                String webUserIdStr = jwtDecoded.getSubject();
                Long webUserId = null;
                if (webUserIdStr == null) {
                    log.error("Web User Id not set in authentication token {}", token);
                } else {
                    webUserId = Long.parseLong(webUserIdStr);
                }

                Claim emailClaim = jwtDecoded.getClaim("email");
                String primaryEmail = null;
                if (emailClaim.isMissing() || emailClaim.isNull()) {
                    log.debug("JWT does not contain email address for user {} and token {}", webUserIdStr, token);
                } else {
                    Claim emailVerified = jwtDecoded.getClaim("email_verified");
                    if (emailVerified.isMissing() || emailVerified.isNull() || Boolean.FALSE.equals(emailVerified.asBoolean())) {
                        log.warn("JWT email verified incomplete for user {}, email {} and token {}", webUserIdStr,
                                emailClaim.asString(), token);
                    } else {
                        primaryEmail = emailClaim.asString().toLowerCase();
                    }
                }

                List<String> secondaryEmails = new ArrayList<>();
                Claim secondaryEmailsClaim = jwtDecoded.getClaim("secondary_emails");
                if (!secondaryEmailsClaim.isMissing() && !secondaryEmailsClaim.isNull()) {
                    secondaryEmailsClaim.asList(SecondaryEmails.class).stream().filter(s -> s.email_verified)
                            .forEach(s -> secondaryEmails.add(s.email.toLowerCase()));
                }

                Claim name = jwtDecoded.getClaim("name");
                String displayName = (!name.isMissing() && !name.isNull()) ? name.asString() : null;
                if (displayName == null || displayName.isBlank()) {
                    Claim givenName = jwtDecoded.getClaim("given_name");
                    final String firstName = (!givenName.isMissing() && !givenName.isNull()) ? givenName.asString() : "";

                    Claim familyName = jwtDecoded.getClaim("family_name");
                    final String lastName = (!familyName.isMissing() && !familyName.isNull()) ? familyName.asString() : "";

                    displayName = String.join(" ", firstName, lastName).trim();
                }

                // The analytic information is structured JSon, but we only pass this structure back
                // to the client so user operations can be tracked. Because of this we use a string
                // as we do not mind what the structure or content is
                Map<String, String> analyticsInfo = null;
                Claim analyticsInfoClaim = jwtDecoded.getClaim("analytics_info");
                if (!analyticsInfoClaim.isMissing() && !analyticsInfoClaim.isNull()) {
                    // Need to convert from a Map<String, Object> returned by the claims interface to
                    // the Map<String, String> that the data really is
                    analyticsInfo = analyticsInfoClaim.asMap().entrySet().stream()
                            .collect(Collectors.toMap(Map.Entry::getKey, e -> e.getValue().toString()));
                }

                SessionContext.initializeIdentity(webUserId, primaryEmail, secondaryEmails, displayName, analyticsInfo);

            } catch (NumberFormatException e) {
                // The number format exception can only be raised when we have an invalid format for the WebUserId
                log.error("Request made with a non numeric web user Id", e);
            } catch (Exception e) {
                log.error("Error processing JWT", e);
            }
        } else if (isNonProd) {
            // For non-prod we allow the ID+ session to be simulated by passing in a header with the
            // email and name of the user
            final String nonprodAuthorization = request.getHeader("X-Nonprod-Authorization");
            if (nonprodAuthorization != null) {
                String[] parts = nonprodAuthorization.split(";");
                if (parts.length != 2) {
                    log.error("X-Nonprod-Authorization set to {}, expected format is email;name", nonprodAuthorization);
                } else {
                    log.info("X-Nonprod-Authorization set for email {} and name {}", parts[0], parts[1]);
                    SessionContext.initializeIdentity(-100L, parts[0], null, parts[1], null);
                }
            }
        }
    }
}
