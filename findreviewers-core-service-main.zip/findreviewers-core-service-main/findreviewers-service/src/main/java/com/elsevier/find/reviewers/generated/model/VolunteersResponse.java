package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.Volunteer;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * The response for a list of volunteers
 */
@Schema(description = "The response for a list of volunteers")
@Validated



public class VolunteersResponse   {
  @JsonProperty("more")
  private Boolean more = null;

  @JsonProperty("volunteers")
  @Valid
  private List<Volunteer> volunteers = null;

  public VolunteersResponse more(Boolean more) {
    this.more = more;
    return this;
  }

  /**
   * To support paging, specifies if there are more entries available after the last one returned
   * @return more
   **/
  @Schema(description = "To support paging, specifies if there are more entries available after the last one returned")
  
    public Boolean isMore() {
    return more;
  }

  public void setMore(Boolean more) {
    this.more = more;
  }

  public VolunteersResponse volunteers(List<Volunteer> volunteers) {
    this.volunteers = volunteers;
    return this;
  }

  public VolunteersResponse addVolunteersItem(Volunteer volunteersItem) {
    if (this.volunteers == null) {
      this.volunteers = new ArrayList<>();
    }
    this.volunteers.add(volunteersItem);
    return this;
  }

  /**
   * Get volunteers
   * @return volunteers
   **/
  @Schema(description = "")
      @Valid
    public List<Volunteer> getVolunteers() {
    return volunteers;
  }

  public void setVolunteers(List<Volunteer> volunteers) {
    this.volunteers = volunteers;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    VolunteersResponse volunteersResponse = (VolunteersResponse) o;
    return Objects.equals(this.more, volunteersResponse.more) &&
        Objects.equals(this.volunteers, volunteersResponse.volunteers);
  }

  @Override
  public int hashCode() {
    return Objects.hash(more, volunteers);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class VolunteersResponse {\n");
    
    sb.append("    more: ").append(toIndentedString(more)).append("\n");
    sb.append("    volunteers: ").append(toIndentedString(volunteers)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
