package com.elsevier.find.reviewers.enums;

import com.fasterxml.jackson.annotation.JsonProperty;

@SuppressWarnings("squid:S00115")
public enum ProductType {
    @JsonProperty("R")
    FindReviewers,
    @JsonProperty("E")
    FindEditors
}
