package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * AuthenticateBody
 */
@Validated



public class AuthenticateBody   {
  @JsonProperty("authenticationCode")
  private String authenticationCode = null;

  @JsonProperty("emJournalAcronym")
  private String emJournalAcronym = null;

  public AuthenticateBody authenticationCode(String authenticationCode) {
    this.authenticationCode = authenticationCode;
    return this;
  }

  /**
   * The EM authentication code (Required for EM authentication)
   * @return authenticationCode
   **/
  @Schema(description = "The EM authentication code (Required for EM authentication)")
  
    public String getAuthenticationCode() {
    return authenticationCode;
  }

  public void setAuthenticationCode(String authenticationCode) {
    this.authenticationCode = authenticationCode;
  }

  public AuthenticateBody emJournalAcronym(String emJournalAcronym) {
    this.emJournalAcronym = emJournalAcronym;
    return this;
  }

  /**
   * Journal EM acronym (Required for FR authentication)
   * @return emJournalAcronym
   **/
  @Schema(example = "ACR", description = "Journal EM acronym (Required for FR authentication)")
  
    public String getEmJournalAcronym() {
    return emJournalAcronym;
  }

  public void setEmJournalAcronym(String emJournalAcronym) {
    this.emJournalAcronym = emJournalAcronym;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AuthenticateBody authenticateBody = (AuthenticateBody) o;
    return Objects.equals(this.authenticationCode, authenticateBody.authenticationCode) &&
        Objects.equals(this.emJournalAcronym, authenticateBody.emJournalAcronym);
  }

  @Override
  public int hashCode() {
    return Objects.hash(authenticationCode, emJournalAcronym);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AuthenticateBody {\n");
    
    sb.append("    authenticationCode: ").append(toIndentedString(authenticationCode)).append("\n");
    sb.append("    emJournalAcronym: ").append(toIndentedString(emJournalAcronym)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
