package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.PersonBase;
import com.elsevier.find.reviewers.generated.model.ReviewerStatus;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * ReviewerDetails
 */
@Validated



public class ReviewerDetails extends PersonBase  {
  @JsonProperty("status")
  private ReviewerStatus status = null;

  public ReviewerDetails status(ReviewerStatus status) {
    this.status = status;
    return this;
  }

  /**
   * Get status
   * @return status
   **/
  @Schema(description = "")
  
    @Valid
    public ReviewerStatus getStatus() {
    return status;
  }

  public void setStatus(ReviewerStatus status) {
    this.status = status;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ReviewerDetails reviewerDetails = (ReviewerDetails) o;
    return Objects.equals(this.status, reviewerDetails.status) &&
        super.equals(o);
  }

  @Override
  public int hashCode() {
    return Objects.hash(status, super.hashCode());
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ReviewerDetails {\n");
    sb.append("    ").append(toIndentedString(super.toString())).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
