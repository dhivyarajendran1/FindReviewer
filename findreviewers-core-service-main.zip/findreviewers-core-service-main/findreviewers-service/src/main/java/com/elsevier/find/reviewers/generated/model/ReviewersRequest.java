package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.ReviewersRequestItem;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * The request to add or update reviewers
 */
@Schema(description = "The request to add or update reviewers")
@Validated



public class ReviewersRequest   {
  @JsonProperty("reviewers")
  @Valid
  private List<ReviewersRequestItem> reviewers = null;

  public ReviewersRequest reviewers(List<ReviewersRequestItem> reviewers) {
    this.reviewers = reviewers;
    return this;
  }

  public ReviewersRequest addReviewersItem(ReviewersRequestItem reviewersItem) {
    if (this.reviewers == null) {
      this.reviewers = new ArrayList<>();
    }
    this.reviewers.add(reviewersItem);
    return this;
  }

  /**
   * Get reviewers
   * @return reviewers
   **/
  @Schema(description = "")
      @Valid
    public List<ReviewersRequestItem> getReviewers() {
    return reviewers;
  }

  public void setReviewers(List<ReviewersRequestItem> reviewers) {
    this.reviewers = reviewers;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ReviewersRequest reviewersRequest = (ReviewersRequest) o;
    return Objects.equals(this.reviewers, reviewersRequest.reviewers);
  }

  @Override
  public int hashCode() {
    return Objects.hash(reviewers);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ReviewersRequest {\n");
    
    sb.append("    reviewers: ").append(toIndentedString(reviewers)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
