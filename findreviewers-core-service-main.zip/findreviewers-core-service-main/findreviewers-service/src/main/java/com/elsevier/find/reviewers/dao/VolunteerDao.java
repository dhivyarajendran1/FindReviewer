package com.elsevier.find.reviewers.dao;

import com.elsevier.find.reviewers.generated.model.Volunteer;

import java.util.List;

/**
 * Interface that supports operations on volunteers
 */
public interface VolunteerDao extends BaseDao {

    /**
     * Gets the volunteers for a given journal
     *
     * @param emJournalAcronym EM Journal Acronym to get volunteers for
     * @param offset           Where to start the listing from
     * @param limit            Maximum number of entries to return
     * @return List of volunteers
     */
    List<Volunteer> getVolunteersByEmJournalAcronym(String emJournalAcronym,
                                                    Integer offset,
                                                    Integer limit);

    /**
     * Gets the list of Ids for possible crowdsourced reviewers
     *
     * @param emJournalAcronym EM Journal Acronym to get the crowdsourced reviewer for
     * @param documentId       Document the crowdsourced reviewer is for
     * @param emails           The emails for the crowdsourced reviewer
     * @return List of Ids for the crowdsourced reviewers
     */
    List<Long> getCrowdsourcedReviewerIds(String emJournalAcronym, long documentId, List<String> emails);
}
