package com.elsevier.find.reviewers.generated.api;

import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.generated.model.ScopusPublicationsResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.util.List;
import java.util.Map;


@RestController
public class PublicationsApiController implements PublicationsApi {

    private final PublicationsApiDelegate delegate;

    @org.springframework.beans.factory.annotation.Autowired
    public PublicationsApiController(PublicationsApiDelegate delegate) {
        this.delegate = delegate;
    }

    @Override
    public PublicationsApiDelegate getDelegate() {
        return delegate;
    }
    public ResponseEntity<ScopusPublicationsResponse> getPublicationsByIds(@NotNull @Parameter(in = ParameterIn.QUERY, description = "The EID of the publications that are required (comma separated list)" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "publicationIds", required = true) List<String> publicationIds,@Parameter(in = ParameterIn.HEADER, description = "The scope of the application, valid values are FE-IDP (Find Editors) FR-IDP-JOURNAL (Find Reviewers stand alone, JOURNAL = upper case EM journal acronym) FR-EM-JOURNAL (Find Reviewers from EM, JOURNAL = upper case EM journal acronym)" ,required=true,schema=@Schema()) @RequestHeader(value="X-Scope", required=true) String xScope) {
        return delegate.getPublicationsByIds(publicationIds, xScope);
    }

}
