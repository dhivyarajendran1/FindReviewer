package com.elsevier.find.reviewers.config;

import lombok.extern.slf4j.Slf4j;
import me.vzhilin.auth.DigestAuthenticator;
import me.vzhilin.auth.parser.ChallengeResponse;
import me.vzhilin.auth.parser.ChallengeResponseParser;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.ExchangeFunction;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.text.ParseException;

@Slf4j
@Configuration
public class DigestAuthConfig {
    // The following is a helper filter. It sits listening for the response, and when the response
    // is an unauthorised request it will check the nonce to see if it has expired or been used the
    // maximum number of times. In those cases it will refresh the nonce and make the required request
    // again. By doing it as a filter it prevents polluting the application code with the API behaviour
    // Unfortunately Digest Authentication is not supported out-of-the-box, there is a request here:
    //  https://github.com/spring-projects/spring-framework/issues/24425
    public static class DigestAuthFilterFunction implements ExchangeFilterFunction {
        private final DigestAuthenticator digestAuthenticator;

        public DigestAuthFilterFunction(DigestAuthenticator digestAuthenticator) {
            this.digestAuthenticator = digestAuthenticator;
        }

        @Override
        public Mono<ClientResponse> filter(ClientRequest request, ExchangeFunction next) {
            return next.exchange(addAuthorizationHeader(request))
                    .flatMap(response -> {
                        // It is possible the nonce has expired and a new one is required
                        if (response.statusCode() == HttpStatus.UNAUTHORIZED) {
                            updateAuthenticator(response.headers().asHttpHeaders());
                            return next.exchange(addAuthorizationHeader(request))
                                    .doOnNext(res -> {
                                        if (res.statusCode() == HttpStatus.UNAUTHORIZED) {
                                            updateAuthenticator(res.headers().asHttpHeaders());
                                        }
                                    });
                        } else {
                            return Mono.just(response);
                        }
                    });
        }

        private ClientRequest addAuthorizationHeader(ClientRequest request) {
            String authorization = digestAuthenticator.authorizationHeader(request.method().name(), request.url().getPath());
            if (authorization != null) {
                return ClientRequest.from(request)
                        .headers(headers -> headers.set(HttpHeaders.AUTHORIZATION, authorization))
                        .build();
            } else {
                return request;
            }
        }

        // Ignore SonarQube complaining about throwing Runtime Exception
        @SuppressWarnings("java:S112")
        private void updateAuthenticator(HttpHeaders headers) {
            String wwwAuthenticateHeader = headers.getFirst(HttpHeaders.WWW_AUTHENTICATE);
            if (wwwAuthenticateHeader != null) {
                try {
                    ChallengeResponse challenge = new ChallengeResponseParser(wwwAuthenticateHeader).parseChallenge();
                    digestAuthenticator.onResponseReceived(challenge, 401);
                } catch (ParseException e) {
                    // Need to convert the exception as the filter that called this does not throw exception
                    // so needs to be a Runtime Exception
                    log.error("Failed to parse the authentication header for Digest Authentication", e);
                    throw new RuntimeException(e);
                }
            }
        }
    }

    @Bean(name = "emWebClient")
    public WebClient emWebClient(@Value("${em.web.api.client.username}") String username,
                                 @Value("${em.web.api.client.password}") String password) {
        return WebClient.builder()
                .codecs(configurer -> configurer
                        .defaultCodecs()
                        .maxInMemorySize(16 * 1024 * 1024))
                .filters(filters -> filters.add(0, new DigestAuthFilterFunction(
                        new DigestAuthenticator(username, password))))
                .build();
    }
}
