package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.RecommendationsReviewer;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * The response for a recommendations request
 */
@Schema(description = "The response for a recommendations request")
@Validated



public class RecommendationsResponse   {
  @JsonProperty("recommendations")
  @Valid
  private List<RecommendationsReviewer> recommendations = null;

  @JsonProperty("generationTime")
  private Long generationTime = null;

  @JsonProperty("analyticsInfo")
  @Valid
  private Map<String, Object> analyticsInfo = null;

  public RecommendationsResponse recommendations(List<RecommendationsReviewer> recommendations) {
    this.recommendations = recommendations;
    return this;
  }

  public RecommendationsResponse addRecommendationsItem(RecommendationsReviewer recommendationsItem) {
    if (this.recommendations == null) {
      this.recommendations = new ArrayList<>();
    }
    this.recommendations.add(recommendationsItem);
    return this;
  }

  /**
   * Get recommendations
   * @return recommendations
   **/
  @Schema(description = "")
      @Valid
    public List<RecommendationsReviewer> getRecommendations() {
    return recommendations;
  }

  public void setRecommendations(List<RecommendationsReviewer> recommendations) {
    this.recommendations = recommendations;
  }

  public RecommendationsResponse generationTime(Long generationTime) {
    this.generationTime = generationTime;
    return this;
  }

  /**
   * The date the recommendations were generated (EPOCH - milliseconds)
   * minimum: 0
   * @return generationTime
   **/
  @Schema(example = "1666797249000", description = "The date the recommendations were generated (EPOCH - milliseconds)")
  
  @Min(0L)  public Long getGenerationTime() {
    return generationTime;
  }

  public void setGenerationTime(Long generationTime) {
    this.generationTime = generationTime;
  }

  public RecommendationsResponse analyticsInfo(Map<String, Object> analyticsInfo) {
    this.analyticsInfo = analyticsInfo;
    return this;
  }

  public RecommendationsResponse putAnalyticsInfoItem(String key, Object analyticsInfoItem) {
    if (this.analyticsInfo == null) {
      this.analyticsInfo = new HashMap<>();
    }
    this.analyticsInfo.put(key, analyticsInfoItem);
    return this;
  }

  /**
   * The analytics info about the recommendations
   * @return analyticsInfo
   **/
  @Schema(description = "The analytics info about the recommendations")
  
    public Map<String, Object> getAnalyticsInfo() {
    return analyticsInfo;
  }

  public void setAnalyticsInfo(Map<String, Object> analyticsInfo) {
    this.analyticsInfo = analyticsInfo;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RecommendationsResponse recommendationsResponse = (RecommendationsResponse) o;
    return Objects.equals(this.recommendations, recommendationsResponse.recommendations) &&
        Objects.equals(this.generationTime, recommendationsResponse.generationTime) &&
        Objects.equals(this.analyticsInfo, recommendationsResponse.analyticsInfo);
  }

  @Override
  public int hashCode() {
    return Objects.hash(recommendations, generationTime, analyticsInfo);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RecommendationsResponse {\n");
    
    sb.append("    recommendations: ").append(toIndentedString(recommendations)).append("\n");
    sb.append("    generationTime: ").append(toIndentedString(generationTime)).append("\n");
    sb.append("    analyticsInfo: ").append(toIndentedString(analyticsInfo)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
