package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * A note supplied about a candidate
 */
@Schema(description = "A note supplied about a candidate")
@Validated



public class CandidateNote   {
  @JsonProperty("postedBy")
  private String postedBy = null;

  @JsonProperty("postedDate")
  private Long postedDate = null;

  @JsonProperty("note")
  private String note = null;

  public CandidateNote postedBy(String postedBy) {
    this.postedBy = postedBy;
    return this;
  }

  /**
   * The name of the person that posted the note
   * @return postedBy
   **/
  @Schema(example = "Barney Rubble", description = "The name of the person that posted the note")
  
    public String getPostedBy() {
    return postedBy;
  }

  public void setPostedBy(String postedBy) {
    this.postedBy = postedBy;
  }

  public CandidateNote postedDate(Long postedDate) {
    this.postedDate = postedDate;
    return this;
  }

  /**
   * The date the note was posted (EPOCH - milliseconds)
   * minimum: 0
   * @return postedDate
   **/
  @Schema(example = "1579867980000", description = "The date the note was posted (EPOCH - milliseconds)")
  
  @Min(0L)  public Long getPostedDate() {
    return postedDate;
  }

  public void setPostedDate(Long postedDate) {
    this.postedDate = postedDate;
  }

  public CandidateNote note(String note) {
    this.note = note;
    return this;
  }

  /**
   * The details of the note
   * @return note
   **/
  @Schema(example = "I have received several excellent reviews from this candidate", required = true, description = "The details of the note")
      @NotNull

    public String getNote() {
    return note;
  }

  public void setNote(String note) {
    this.note = note;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CandidateNote candidateNote = (CandidateNote) o;
    return Objects.equals(this.postedBy, candidateNote.postedBy) &&
        Objects.equals(this.postedDate, candidateNote.postedDate) &&
        Objects.equals(this.note, candidateNote.note);
  }

  @Override
  public int hashCode() {
    return Objects.hash(postedBy, postedDate, note);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CandidateNote {\n");
    
    sb.append("    postedBy: ").append(toIndentedString(postedBy)).append("\n");
    sb.append("    postedDate: ").append(toIndentedString(postedDate)).append("\n");
    sb.append("    note: ").append(toIndentedString(note)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
