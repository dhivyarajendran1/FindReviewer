package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import io.swagger.v3.oas.annotations.media.Schema;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Indicators for the user to detail possible relationships or roles
 */
public enum Indicators {
  SUGGESTEDBYAUTHOR("SuggestedByAuthor"),
    CITEDMANUSCRIPTAUTHORS("CitedManuscriptAuthors"),
    OPPOSEDBYAUTHOR("OpposedByAuthor"),
    SAMEINSTITUTION("SameInstitution"),
    SAMECOUNTRY("SameCountry"),
    VOLUNTEERTHISJOURNAL("VolunteerThisJournal"),
    RECENTLYACCEPTEDAUTHORTHISJOURNAL("RecentlyAcceptedAuthorThisJournal"),
    RECENTLYACCEPTEDAUTHOROTHERJOURNAL("RecentlyAcceptedAuthorOtherJournal"),
    COAUTHORLAST3TO5YEARS("CoauthorLast3to5Years"),
    COAUTHORLAST5YEARS("CoauthorLast5Years"),
    MANUSCRIPTAUTHOR("ManuscriptAuthor"),
    EDITORIALBOARDMEMBER("EditorialBoardMember"),
    FORBIDDENREVIEWER("ForbiddenReviewer");

  private String value;

  Indicators(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static Indicators fromValue(String text) {
    for (Indicators b : Indicators.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
