package com.elsevier.find.reviewers.dao.impl;

import com.elsevier.find.reviewers.dao.EditorDao;
import com.elsevier.find.reviewers.generated.model.Editor;
import com.elsevier.find.reviewers.utils.Constants;
import com.elsevier.find.reviewers.utils.PersonDetailsUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

/**
 * Implementation for the data access to editors
 */
// Suppress SonarQube 'String literals should not be duplicated' flagged against the inline sql
@SuppressWarnings("squid:S1192")
@Slf4j
@Repository
public class EditorDaoImpl extends BaseDaoImpl implements EditorDao {
    public EditorDaoImpl(NamedParameterJdbcTemplate dbSource, ObjectMapper objectMapper,
                         @Value("${findreviewers.cloud.ursdb:false}") String cloudUrsdbEnabled) {
        super(dbSource, objectMapper, cloudUrsdbEnabled);
    }

    class EditorRowMapper extends BaseRowMapper implements RowMapper<Editor> {
        @Override
        public Editor mapRow(ResultSet rs, int rowNum) throws SQLException {
            Editor editor = new Editor();

            editor.addEmailsItem(rs.getString("email"));
            editor.setFirstName(rs.getString("first_name"));
            editor.setLastName(rs.getString("last_name"));
            PersonDetailsUtils.setDisplayName(editor);

            editor.setStartDate(rs.getLong("start_date"));
            editor.setAccreditation(rs.getString("accreditation"));
            editor.setJobTitle(rs.getString("job_title"));
            editor.setPersonalWebsite(rs.getString("personal_website"));

            final String scopusJson = rs.getString("scopus_ids");
            if (scopusJson != null && !scopusJson.isBlank()) {
                try {
                    Arrays.stream(objectMapper.readValue(scopusJson, String[].class)).forEach(editor::addScopusIdsItem);
                } catch (JsonProcessingException e) {
                    log.error("Failed to load Scopus from database for editor {}, error {}", editor.getEmails(),
                            e.getMessage());
                }
            }

            final String interestsJson = rs.getString("fields_of_interest");
            if (interestsJson != null && !interestsJson.isBlank()) {
                try {
                    Arrays.stream(objectMapper.readValue(interestsJson, String[].class)).forEach(editor::addFieldsOfInterestItem);
                } catch (JsonProcessingException e) {
                    log.error("Failed to load Fields of Interest from database for editor {}, error {}", editor.getEmails(),
                            e.getMessage());
                }
            }

            return editor;
        }
    }

    @Override
    public List<Editor> getEditorialBoardMembersByEmJournalAcronym(String emJournalAcronym,
                                                                   Integer offset,
                                                                   Integer limit) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("emJournalAcronym", emJournalAcronym.toUpperCase());
        params.addValue("classification", "editorialBoardMember");

        String sql = """
                select e.email as email, e.first_name as first_name,
                e.last_name as last_name, e.scopus_ids->'scopus' as scopus_ids, e.start_date as start_date,
                e.accreditation as accreditation, e.job_title as job_title, e.personal_website as personal_website,
                e.fields_of_interest->'fieldsOfInterest' as fields_of_interest
                from find_reviewers.rh_editor e
                inner join rr_ursdb."JOURNAL_INFO" j on j.pts_code = e.journal_acronym
                left join find_reviewers.inoperative_email i on i.email = e.email
                where j."JOURNAL__upper" = :emJournalAcronym and e.classification = :classification and
                e.scopus_ids is not null and (e.stop_date is null or e.stop_date > (extract(EPOCH from CURRENT_TIMESTAMP) * 1000))
                and i.email is null
                order by e.last_name, e.first_name
                """ + toSqlPaging(offset, limit, params);

        // There is a slightly different query if the journal is not in URSDB
        if (Constants.nonUrsdbElsevierJournals.containsKey(emJournalAcronym.toUpperCase())) {
            params.addValue("journalAcronym", Constants.nonUrsdbElsevierJournals.get(emJournalAcronym.toUpperCase()).getAcronym());

            sql = """
                    select e.email as email, e.first_name as first_name, e.last_name as last_name,
                    e.scopus_ids->'scopus' as scopus_ids, e.start_date as start_date, e.accreditation as accreditation,
                    e.job_title as job_title, e.personal_website as personal_website,
                    e.fields_of_interest->'fieldsOfInterest' as fields_of_interest
                    from find_reviewers.rh_editor e
                    left join find_reviewers.inoperative_email i on i.email = e.email
                    where e.journal_acronym = :journalAcronym and e.classification = :classification and
                    e.scopus_ids is not null and (e.stop_date is null or e.stop_date > (extract(EPOCH from CURRENT_TIMESTAMP) * 1000))
                    and i.email is null
                    order by e.last_name, e.first_name
                    """ + toSqlPaging(offset, limit, params);
        } else if (isCloudUrsdb) {
            sql = """
                    select e.email as email, e.first_name as first_name,
                    e.last_name as last_name, e.scopus_ids->'scopus' as scopus_ids, e.start_date as start_date,
                    e.accreditation as accreditation, e.job_title as job_title, e.personal_website as personal_website,
                    e.fields_of_interest->'fieldsOfInterest' as fields_of_interest
                    from find_reviewers.rh_editor e
                    inner join fr_ursdb.journal_info j on j.pts_code = e.journal_acronym
                    left join find_reviewers.inoperative_email i on i.email = e.email
                    where j.journal__upper = :emJournalAcronym and e.classification = :classification and
                    e.scopus_ids is not null and (e.stop_date is null or e.stop_date > (extract(EPOCH from CURRENT_TIMESTAMP) * 1000))
                    and i.email is null
                    order by e.last_name, e.first_name
                    """ + toSqlPaging(offset, limit, params);
        }

        return dbSource.query(sql, params, new EditorRowMapper());
    }

    @Override
    public boolean isEditor(String emJournalAcronym, List<String> emails) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("emJournalAcronym", emJournalAcronym.toUpperCase());
        params.addValue("classifications", List.of("highestRanking", "lowerRanking", "guestEditor"));
        params.addValue("emails", emails);

        String sql = """
                select exists(select 1 from find_reviewers.rh_editor e
                inner join rr_ursdb."JOURNAL_INFO" j on j.pts_code = e.journal_acronym
                where j."JOURNAL__upper" = :emJournalAcronym and e.classification in (:classifications)
                and e.email in (:emails) and
                (e.stop_date is null or e.stop_date > (extract(EPOCH from CURRENT_TIMESTAMP) * 1000)::int8))
                """;

        if (isCloudUrsdb) {
            sql = """
                    select exists(select 1 from find_reviewers.rh_editor e
                    inner join fr_ursdb.journal_info j on j.pts_code = e.journal_acronym
                    where j.journal__upper = :emJournalAcronym and e.classification in (:classifications)
                    and e.email in (:emails) and
                    (e.stop_date is null or e.stop_date > (extract(EPOCH from CURRENT_TIMESTAMP) * 1000)::int8))
                    """;
        }

        return dbSource.queryForObject(sql, params, Boolean.class);
    }
}
