package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.ScopusCoauthor;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * The response for a list of coauthors
 */
@Schema(description = "The response for a list of coauthors")
@Validated



public class ScopusCoauthorResponse   {
  @JsonProperty("totalCoauthors")
  private Integer totalCoauthors = null;

  @JsonProperty("coauthors")
  @Valid
  private List<ScopusCoauthor> coauthors = new ArrayList<>();

  public ScopusCoauthorResponse totalCoauthors(Integer totalCoauthors) {
    this.totalCoauthors = totalCoauthors;
    return this;
  }

  /**
   * The total number of coauthors for the candidate
   * @return totalCoauthors
   **/
  @Schema(example = "35", description = "The total number of coauthors for the candidate")
  
    public Integer getTotalCoauthors() {
    return totalCoauthors;
  }

  public void setTotalCoauthors(Integer totalCoauthors) {
    this.totalCoauthors = totalCoauthors;
  }

  public ScopusCoauthorResponse coauthors(List<ScopusCoauthor> coauthors) {
    this.coauthors = coauthors;
    return this;
  }

  public ScopusCoauthorResponse addCoauthorsItem(ScopusCoauthor coauthorsItem) {
    this.coauthors.add(coauthorsItem);
    return this;
  }

  /**
   * The top 100 co-authors based on the number of publications with the candidate (or all if less than 100)
   * @return coauthors
   **/
  @Schema(required = true, description = "The top 100 co-authors based on the number of publications with the candidate (or all if less than 100)")
      @NotNull
    @Valid
    public List<ScopusCoauthor> getCoauthors() {
    return coauthors;
  }

  public void setCoauthors(List<ScopusCoauthor> coauthors) {
    this.coauthors = coauthors;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ScopusCoauthorResponse scopusCoauthorResponse = (ScopusCoauthorResponse) o;
    return Objects.equals(this.totalCoauthors, scopusCoauthorResponse.totalCoauthors) &&
        Objects.equals(this.coauthors, scopusCoauthorResponse.coauthors);
  }

  @Override
  public int hashCode() {
    return Objects.hash(totalCoauthors, coauthors);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ScopusCoauthorResponse {\n");
    
    sb.append("    totalCoauthors: ").append(toIndentedString(totalCoauthors)).append("\n");
    sb.append("    coauthors: ").append(toIndentedString(coauthors)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
