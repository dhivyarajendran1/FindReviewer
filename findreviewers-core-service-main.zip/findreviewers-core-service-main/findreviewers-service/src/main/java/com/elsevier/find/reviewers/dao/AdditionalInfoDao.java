package com.elsevier.find.reviewers.dao;


import com.elsevier.find.reviewers.generated.model.ClassificationTree;
import com.elsevier.find.reviewers.generated.model.InitialisationDetailsCrowdsourcedReviewers;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;
import java.util.Map;

/**
 * Interface that supports the retrieval of the common additional information for potential reviewers
 */
public interface AdditionalInfoDao extends BaseDao {
    @EqualsAndHashCode(callSuper = true)
    @Data
    class ClassificationItem extends ClassificationTree {
        @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
        private String parentCode;
    }

    @Data
    class InitialisationInfo {
        String issnL = null;
        List<ClassificationItem> classifications = null;
        boolean hasEBMs = false;
        private List<InitialisationDetailsCrowdsourcedReviewers> crowdsourcedReviewers = null;
    }

    /**
     * Given a list of emails, gets the additional information. The return object has an isValidUser property
     * which, if set to false indicates that the user should be removed from any master list. If a user is not
     * in the list it means they are a valid user that has not reviewed for Elsevier previously
     *
     * @param emJournalAcronym EM Journal Acronym that data should be filtered for
     * @param emails           List of emails the information is required for
     * @return Map of emails and additional data
     */
    Map<String, AdditionalInfo> getAdditionalInfoByEmail(String emJournalAcronym, List<String> emails);

    /**
     * Given a list of emails, checks if any of them are inoperative
     *
     * @param emails List of emails the information is required for
     * @return Map of emails and additional data (if inoperative)
     */
    Map<String, AdditionalInfo> getInoperativeByEmail(List<String> emails);

    /**
     * Gets the data required for the initialisation call to summarise data for a manuscript
     *
     * @param emJournalAcronym EM Journal Acronym
     * @param documentId       Manuscript document identifier
     * @return Initialisation information
     */
    InitialisationInfo getInitialisationInfo(String emJournalAcronym, Long documentId);

    /**
     * Gets the data required for the initialisation call for a Non URSDB Elsevier Journal
     *
     * @param journalAcronym Journal Acronym (PTS Code)
     * @param issn           Journal ISSN
     * @return Initialisation information
     */
    InitialisationInfo getInitialisationInfo(String journalAcronym, String issn);
}
