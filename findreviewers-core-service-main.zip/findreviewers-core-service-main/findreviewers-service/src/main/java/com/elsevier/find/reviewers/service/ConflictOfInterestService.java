package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.external.PersonFinder;
import com.elsevier.find.reviewers.generated.api.ConflictOfInterestApiDelegate;
import com.elsevier.find.reviewers.generated.model.ConflictOfInterestDetails;
import com.elsevier.find.reviewers.generated.model.ConflictOfInterestResponse;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.generated.model.Indicators;
import com.elsevier.find.reviewers.service.base.BaseService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class ConflictOfInterestService extends BaseService implements ConflictOfInterestApiDelegate {
    private final PersonFinder personFinder;

    public ConflictOfInterestService(ObjectMapper objectMapper,
                                     PersonFinder personFinder) {
        super(objectMapper);
        this.personFinder = personFinder;
    }

    @Override
    public ResponseEntity<ConflictOfInterestResponse> getConflictOfInterest(List<String> authorScopusIds,
                                                                            List<String> reviewerScopusIds,
                                                                            String xScope) {
        if (reviewerScopusIds == null || reviewerScopusIds.isEmpty() || authorScopusIds == null || authorScopusIds.isEmpty()) {
            final Map<String, String> args = Map.of("authorScopusIds", String.valueOf(authorScopusIds),
                    "reviewerScopusIds", String.valueOf(reviewerScopusIds));
            log.error("Invalid request for conflict of interest, mandatory parameters not set {}", args);
            throw new InternalException(ErrorResponse.IdEnum.INVALIDARGUMENT, HttpStatus.BAD_REQUEST, args);
        }

        log.info("Conflict of interest request for authors {} and reviewers {}", authorScopusIds, reviewerScopusIds);

        Map<String, List<Indicators>> conflictReviewers = personFinder.getConflictOfInterests(authorScopusIds, reviewerScopusIds);

        ConflictOfInterestResponse response = new ConflictOfInterestResponse();
        for (Map.Entry<String, List<Indicators>> conflictedReviewer : conflictReviewers.entrySet()) {
            ConflictOfInterestDetails item = new ConflictOfInterestDetails();
            item.setScopusId(conflictedReviewer.getKey());
            item.setIndicators(conflictedReviewer.getValue());
            response.addReviewersItem(item);
        }

        return ResponseEntity.ok().body(response);
    }
}
