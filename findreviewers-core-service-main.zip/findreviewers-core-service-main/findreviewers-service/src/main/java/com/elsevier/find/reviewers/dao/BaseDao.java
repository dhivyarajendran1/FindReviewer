package com.elsevier.find.reviewers.dao;

import lombok.Data;

public interface BaseDao {
    @Data
    class AdditionalInfo {
        private final boolean isValidUser;
        private boolean unavailable = false;
        private int concurrentReviewLimit = 0;
        private boolean isVolunteer = false;
        private boolean isEBM = false;
        private int editorialHistoryCount = 0;
        private boolean recentAuthorThisJournal = false;
        private boolean recentAuthorOtherJournal = false;
        private boolean forbiddenReviewer = false;
    }
}
