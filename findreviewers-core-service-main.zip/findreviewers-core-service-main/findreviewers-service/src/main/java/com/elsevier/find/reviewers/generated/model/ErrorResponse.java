package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * Details about any error that has occurred
 */
@Schema(description = "Details about any error that has occurred")
@Validated



public class ErrorResponse   {
  /**
   * Identifier for the error that has occurred that can be mapped to a user message
   */
  public enum IdEnum {
    INVALIDARGUMENT("InvalidArgument"),
    
    INCOMPLETEDATA("IncompleteData"),
    
    LIMITEXCEEDED("LimitExceeded"),
    
    UNKNOWN("Unknown"),
    
    EMFAILURE("EmFailure"),
    
    PERSONFINDERFAILURE("PersonFinderFailure"),
    
    SCOPUSSHAREDSEARCHFAILURE("ScopusSharedSearchFailure"),
    
    SCOPUSGRAPHFAILURE("ScopusGraphFailure"),
    
    REVIEWERHUBFAILURE("ReviewerHubFailure"),
    
    SCOPUSAUTOCOMPLETEFAILURE("ScopusAutocompleteFailure");

    private String value;

    IdEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static IdEnum fromValue(String text) {
      for (IdEnum b : IdEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("id")
  private IdEnum id = null;

  @JsonProperty("attributes")
  @Valid
  private Map<String, String> attributes = null;

  public ErrorResponse id(IdEnum id) {
    this.id = id;
    return this;
  }

  /**
   * Identifier for the error that has occurred that can be mapped to a user message
   * @return id
   **/
  @Schema(description = "Identifier for the error that has occurred that can be mapped to a user message")
  
    public IdEnum getId() {
    return id;
  }

  public void setId(IdEnum id) {
    this.id = id;
  }

  public ErrorResponse attributes(Map<String, String> attributes) {
    this.attributes = attributes;
    return this;
  }

  public ErrorResponse putAttributesItem(String key, String attributesItem) {
    if (this.attributes == null) {
      this.attributes = new HashMap<>();
    }
    this.attributes.put(key, attributesItem);
    return this;
  }

  /**
   * Any attributes that might be helpful for the error details
   * @return attributes
   **/
  @Schema(description = "Any attributes that might be helpful for the error details")
  
    public Map<String, String> getAttributes() {
    return attributes;
  }

  public void setAttributes(Map<String, String> attributes) {
    this.attributes = attributes;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ErrorResponse errorResponse = (ErrorResponse) o;
    return Objects.equals(this.id, errorResponse.id) &&
        Objects.equals(this.attributes, errorResponse.attributes);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, attributes);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ErrorResponse {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    attributes: ").append(toIndentedString(attributes)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
