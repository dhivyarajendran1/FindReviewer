package com.elsevier.find.reviewers.exception;

import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;

@Slf4j
public class RetryableException extends Exception {
    private final InternalException internalException;
    private final String logFormat;
    private final transient Object[] logArgs;

    public RetryableException(Exception e, String logFormat, Object... logArgs) {
        if (e instanceof InternalException) {
            this.internalException = (InternalException) e;
        } else {
            InternalException error = new InternalException(ErrorResponse.IdEnum.UNKNOWN, HttpStatus.INTERNAL_SERVER_ERROR);
            if (e != null && e.getMessage() != null) {
                error.addAttribute("Message", e.getMessage());
            }
            this.internalException = error;
        }
        this.logFormat = logFormat;
        this.logArgs = logArgs;
    }

    public RetryableException logError() {
        if (logFormat != null) {
            log.error(logFormat, logArgs);
        }
        return this;
    }

    public RetryableException logWarn() {
        if (logFormat != null) {
            log.warn(logFormat, logArgs);
        }
        return this;
    }

    public InternalException getInternalException() {
        return internalException;
    }
}
