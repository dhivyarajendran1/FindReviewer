package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.JournalDetails;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * The response to a request to get journal details
 */
@Schema(description = "The response to a request to get journal details")
@Validated



public class JournalsResponse   {
  @JsonProperty("journals")
  @Valid
  private List<JournalDetails> journals = new ArrayList<>();

  public JournalsResponse journals(List<JournalDetails> journals) {
    this.journals = journals;
    return this;
  }

  public JournalsResponse addJournalsItem(JournalDetails journalsItem) {
    this.journals.add(journalsItem);
    return this;
  }

  /**
   * Get journals
   * @return journals
   **/
  @Schema(required = true, description = "")
      @NotNull
    @Valid
    public List<JournalDetails> getJournals() {
    return journals;
  }

  public void setJournals(List<JournalDetails> journals) {
    this.journals = journals;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    JournalsResponse journalsResponse = (JournalsResponse) o;
    return Objects.equals(this.journals, journalsResponse.journals);
  }

  @Override
  public int hashCode() {
    return Objects.hash(journals);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class JournalsResponse {\n");
    
    sb.append("    journals: ").append(toIndentedString(journals)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
