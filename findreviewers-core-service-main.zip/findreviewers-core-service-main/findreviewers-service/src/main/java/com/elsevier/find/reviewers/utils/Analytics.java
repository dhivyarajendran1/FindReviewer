package com.elsevier.find.reviewers.utils;

import com.newrelic.telemetry.Attributes;
import com.newrelic.telemetry.micrometer.NewRelicRegistry;
import com.newrelic.telemetry.micrometer.NewRelicRegistryConfig;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.util.NamedThreadFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.autoconfigure.metrics.CompositeMeterRegistryAutoConfiguration;
import org.springframework.boot.actuate.autoconfigure.metrics.MetricsAutoConfiguration;
import org.springframework.boot.actuate.autoconfigure.metrics.export.simple.SimpleMetricsExportAutoConfiguration;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * Handles all the analytics that are published externally to be viewed. This currently is deployed to New Relic
 */
@Configuration
@AutoConfigureBefore({
        CompositeMeterRegistryAutoConfiguration.class,
        SimpleMetricsExportAutoConfiguration.class
})
@AutoConfigureAfter(MetricsAutoConfiguration.class)
@ConditionalOnClass(NewRelicRegistry.class)
public class Analytics {
    private static final String SOURCE_TAG = "source";
    private static final String CUSTOM_BLOCKED_REVIEWER = "custom.blocked.reviewer";

    private Counter blocklistReviewerCounter;

    private Counter inoperativeReviewerCounter;

    private Counter unresponsiveReviewerCounter;

    private Counter manuscriptReflowCounter;

    private Counter reviewerAvailabilityCounter;

    private Counter reviewerConcurrentLimitCounter;

    @Bean
    public NewRelicRegistry newRelicRegistry(@Value("${management.metrics.export.newrelic.api-key}") String apiKey)
            throws UnknownHostException {
        NewRelicRegistryConfig config = new NewRelicRegistryConfig() {
            @Override
            public String get(String key) {
                return null;
            }

            @Override
            public String apiKey() {
                return apiKey;
            }

            @Override
            public String serviceName() {
                return "find-reviewers";
            }
        };

        NewRelicRegistry newRelicRegistry = NewRelicRegistry.builder(config)
                .commonAttributes(new Attributes().put("host", InetAddress.getLocalHost().getHostName()))
                .build();

        newRelicRegistry.start(new NamedThreadFactory("newrelic.micrometer.registry"));

        // Naming of the Metric should start with custom according to the New Relic documents
        blocklistReviewerCounter = Counter.builder(CUSTOM_BLOCKED_REVIEWER)
                .tags(SOURCE_TAG, "blocklist")
                .description("Excluded reviewers using the blocklist")
                .register(newRelicRegistry);
        inoperativeReviewerCounter = Counter.builder(CUSTOM_BLOCKED_REVIEWER)
                .tags(SOURCE_TAG, "inoperative")
                .description("Excluded reviewers using the inoperative list")
                .register(newRelicRegistry);
        unresponsiveReviewerCounter = Counter.builder(CUSTOM_BLOCKED_REVIEWER)
                .tags(SOURCE_TAG, "unresponsive")
                .description("Excluded reviewers that do not respond to invitations")
                .register(newRelicRegistry);
        manuscriptReflowCounter = Counter.builder("custom.manuscript.reflow")
                .tags(SOURCE_TAG, "recommendations")
                .description("Reflowed manuscripts due to no recommendations")
                .register(newRelicRegistry);
        reviewerAvailabilityCounter = Counter.builder("custom.preferences.reviewer")
                .tags(SOURCE_TAG, "availability")
                .description("Excluded reviewers using user preferences availability")
                .register(newRelicRegistry);
        reviewerConcurrentLimitCounter = Counter.builder("custom.preferences.reviewer")
                .tags(SOURCE_TAG, "concurrent.limit")
                .description("Excluded reviewers using user preferences concurrent limit")
                .register(newRelicRegistry);

        return newRelicRegistry;
    }

    public void recordBlocklistReviewer(int count) {
        blocklistReviewerCounter.increment(count);
    }

    public void recordInoperativeReviewer(int count) {
        inoperativeReviewerCounter.increment(count);
    }

    public void recordUnresponsiveReviewer(int count) {
        unresponsiveReviewerCounter.increment(count);
    }

    public void recordManuscriptReflow(int count) {
        manuscriptReflowCounter.increment(count);
    }

    public void recordReviewerAvailability(int count) {
        reviewerAvailabilityCounter.increment(count);
    }

    public void recordReviewerConcurrentLimit(int count) {
        reviewerConcurrentLimitCounter.increment(count);
    }
}
