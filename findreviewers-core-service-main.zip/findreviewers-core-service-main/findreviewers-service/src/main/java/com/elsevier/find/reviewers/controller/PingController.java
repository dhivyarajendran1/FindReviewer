package com.elsevier.find.reviewers.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * The ping controller is used as an "is alive" service
 */
@Slf4j
@RestController
@RequestMapping("/")
public class PingController {

    @GetMapping(value = "ping", produces = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<String> ping() {

        log.trace("Find Reviewers ping service called");

        return ResponseEntity.ok().body("Find Reviewers REST API is running");
    }
}
