package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import io.swagger.v3.oas.annotations.media.Schema;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * The logical operator that is used to join multiple keywords
 */
public enum KeywordSearchLogic {
  AND("And"),
    OR("Or");

  private String value;

  KeywordSearchLogic(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static KeywordSearchLogic fromValue(String text) {
    for (KeywordSearchLogic b : KeywordSearchLogic.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
