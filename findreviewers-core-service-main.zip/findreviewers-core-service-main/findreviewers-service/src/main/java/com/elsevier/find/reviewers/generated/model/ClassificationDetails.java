package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * Details about a Journals Classifications
 */
@Schema(description = "Details about a Journals Classifications")
@Validated



public class ClassificationDetails   {
  @JsonProperty("code")
  private String code = "NONE";

  @JsonProperty("description")
  private String description = null;

  public ClassificationDetails code(String code) {
    this.code = code;
    return this;
  }

  /**
   * The unique code of the classification (Where no code is available, contains NONE)
   * @return code
   **/
  @Schema(required = true, description = "The unique code of the classification (Where no code is available, contains NONE)")
      @NotNull

    public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public ClassificationDetails description(String description) {
    this.description = description;
    return this;
  }

  /**
   * Display name of the classification
   * @return description
   **/
  @Schema(required = true, description = "Display name of the classification")
      @NotNull

    public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ClassificationDetails classificationDetails = (ClassificationDetails) o;
    return Objects.equals(this.code, classificationDetails.code) &&
        Objects.equals(this.description, classificationDetails.description);
  }

  @Override
  public int hashCode() {
    return Objects.hash(code, description);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ClassificationDetails {\n");
    
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
