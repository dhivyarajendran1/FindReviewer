package com.elsevier.find.reviewers.service;

import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.external.PersonFinder;
import com.elsevier.find.reviewers.external.PersonFinder.KeywordAuthors;
import com.elsevier.find.reviewers.external.PersonFinder.PersonFinderScopusAuthor;
import com.elsevier.find.reviewers.external.PersonFinder.Publication;
import com.elsevier.find.reviewers.external.ScopusGraph;
import com.elsevier.find.reviewers.external.ScopusGraph.GraphDataCoauthor;
import com.elsevier.find.reviewers.external.ScopusGraph.GraphOrganization;
import com.elsevier.find.reviewers.external.ScopusGraph.GraphPerson;
import com.elsevier.find.reviewers.external.ScopusGraph.GraphPersonStatistics;
import com.elsevier.find.reviewers.external.ScopusSharedSearchFunding;
import com.elsevier.find.reviewers.external.ScopusSharedSearchFunding.ScopusSharedSearchFundingResults;
import com.elsevier.find.reviewers.generated.api.ScopusApiDelegate;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.generated.model.FundingAward;
import com.elsevier.find.reviewers.generated.model.FundingResponse;
import com.elsevier.find.reviewers.generated.model.KeywordSearchLogic;
import com.elsevier.find.reviewers.generated.model.ScopusAuthor;
import com.elsevier.find.reviewers.generated.model.ScopusCoauthor;
import com.elsevier.find.reviewers.generated.model.ScopusCoauthorResponse;
import com.elsevier.find.reviewers.generated.model.ScopusKeywordSearchAuthor;
import com.elsevier.find.reviewers.generated.model.ScopusKeywordSearchResponse;
import com.elsevier.find.reviewers.generated.model.ScopusPublication;
import com.elsevier.find.reviewers.generated.model.ScopusPublicationsResponse;
import com.elsevier.find.reviewers.generated.model.ScopusSearchAuthor;
import com.elsevier.find.reviewers.generated.model.ScopusStatisticsResponse;
import com.elsevier.find.reviewers.generated.model.ScopusStatisticsResponseStatistics;
import com.elsevier.find.reviewers.service.base.BaseService;
import com.elsevier.find.reviewers.service.base.DataGatherRules;
import com.elsevier.find.reviewers.service.base.PersonDetailsSupportService;
import com.elsevier.find.reviewers.utils.Constants;
import com.elsevier.find.reviewers.utils.PersonDetailsUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

/**
 * Class to handle all requests for Scopus information
 */
@Slf4j
@Service
public class ScopusService extends BaseService implements ScopusApiDelegate {
    public static final String SCOPUS_ID_TAG = "scopusId";

    private final PersonFinder personFinder;

    private final PersonDetailsSupportService personDetailsSupportService;

    private final ScopusSharedSearchFunding scopusSharedSearchFunding;

    private final ScopusGraph scopusGraph;

    public ScopusService(ObjectMapper objectMapper,
                         PersonFinder personFinder,
                         ScopusGraph scopusGraph,
                         ScopusSharedSearchFunding scopusSharedSearchFunding,
                         PersonDetailsSupportService personDetailsSupportService) {
        super(objectMapper);
        this.personFinder = personFinder;
        this.scopusGraph = scopusGraph;
        this.scopusSharedSearchFunding = scopusSharedSearchFunding;
        this.personDetailsSupportService = personDetailsSupportService;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class, readOnly = true)
    public ResponseEntity<ScopusKeywordSearchResponse> keywordSearch(String keywords,
                                                                     String xScope,
                                                                     String emJournalAcronym,
                                                                     String journalIssn,
                                                                     KeywordSearchLogic searchLogic,
                                                                     Integer publishedSince) {
        if (keywords == null || keywords.trim().length() < 3) {
            final Map<String, String> args = Map.of("keywords", String.valueOf(keywords));
            log.error("Invalid request for Keyword search, no journal acronym or without at least 3 character keyword {}", args);
            throw new InternalException(ErrorResponse.IdEnum.INVALIDARGUMENT, HttpStatus.BAD_REQUEST, args);
        }

        log.info("Keyword search for journal {} keywords {} logic {} published since {}", emJournalAcronym, keywords,
                searchLogic, publishedSince);

        KeywordAuthors keywordAuthorsResponse = personFinder.getKeywordAuthors(keywords, searchLogic, publishedSince, journalIssn);

        ScopusKeywordSearchResponse response = new ScopusKeywordSearchResponse();

        if (keywordAuthorsResponse != null) {
            List<PersonFinderScopusAuthor> keywordAuthors = keywordAuthorsResponse.cleanAuthors();

            log.info("Scopus keyword search for journal {} keywords {} returned {} results", emJournalAcronym, keywords,
                    keywordAuthors.size());

            if (!keywordAuthors.isEmpty()) {
                List<ScopusKeywordSearchAuthor> scopusAuthors = keywordAuthors.stream().map(a -> convertAuthor(a, journalIssn))
                        .collect(Collectors.toList());

                DataGatherRules<ScopusKeywordSearchAuthor> rules = new DataGatherRules<>(scopusAuthors)
                        .addBlockList().addInternalDbData().addReviewStatistics(true);

                scopusAuthors = personDetailsSupportService.gatherAdditionalData(emJournalAcronym, rules);

                log.info("Scopus search for journal {} keyword {} cleaned search returned {} results", emJournalAcronym,
                        keywords, scopusAuthors.size());

                response.setAuthors(scopusAuthors);
            }
        }

        return ResponseEntity.ok().body(response);
    }

    @Override
    public ResponseEntity<ScopusCoauthorResponse> getCoauthors(String scopusId, String xScope, String journalIssn) {
        if (scopusId == null || scopusId.isBlank()) {
            log.error("Invalid request for Scopus Coauthors with no Scopus Id");
            throw new InternalException(ErrorResponse.IdEnum.INVALIDARGUMENT, HttpStatus.BAD_REQUEST,
                    Map.of(SCOPUS_ID_TAG, "null"));
        }

        GraphDataCoauthor coauthors = scopusGraph.getCoauthors(scopusId, journalIssn);

        log.info("Coauthor request for Scopus Id {} with total {} returned {} results", scopusId, coauthors.getTotalCoauthors(),
                coauthors.getCoauthors().size());

        ScopusCoauthorResponse response = new ScopusCoauthorResponse();
        response.setTotalCoauthors(coauthors.getTotalCoauthors());
        for (GraphPerson coauthor : coauthors.getCoauthors()) {
            response.addCoauthorsItem(convertCoauthor(coauthor));
        }

        return ResponseEntity.ok().body(response);
    }

    @Override
    public ResponseEntity<FundingResponse> getFunding(String scopusId, String xScope) {
        if (scopusId == null || scopusId.isBlank()) {
            log.error("Invalid request for Funding with no Scopus Id");
            throw new InternalException(ErrorResponse.IdEnum.INVALIDARGUMENT, HttpStatus.BAD_REQUEST,
                    Map.of(SCOPUS_ID_TAG, "null"));
        }

        FundingResponse response = new FundingResponse();
        List<ScopusSharedSearchFundingResults> fundingAwards = scopusSharedSearchFunding.getFundingAwards(scopusId);

        log.info("Funding request for Scopus Id {} returned {} results", scopusId, fundingAwards.size());

        for (ScopusSharedSearchFundingResults findingAward : fundingAwards) {
            response.addFundingAwardsItem(convertFundingAward(findingAward));
        }

        return ResponseEntity.ok().body(response);
    }

    @Override
    public ResponseEntity<ScopusPublicationsResponse> getPublications(String scopusId,
                                                                      String xScope,
                                                                      String keywords,
                                                                      KeywordSearchLogic searchLogic,
                                                                      Integer publishedSince,
                                                                      Integer limit) {
        if (scopusId == null || scopusId.isBlank()) {
            log.error("Invalid request for Scopus publications with no Scopus Id");
            throw new InternalException(ErrorResponse.IdEnum.INVALIDARGUMENT, HttpStatus.BAD_REQUEST,
                    Map.of(SCOPUS_ID_TAG, "null"));
        }

        List<Publication> publications = personFinder.getPublications(scopusId, keywords, searchLogic, publishedSince);

        log.info("Scopus publications returned {} results for Scopus Id {} keywords {}", publications.size(), scopusId, keywords);

        ScopusPublicationsResponse response = new ScopusPublicationsResponse();

        if (limit != null && publications.size() > limit) {
            publications = publications.subList(0, limit);
        }

        publications.forEach(p -> response.addPublicationsItem(convertPublication(p)));

        return ResponseEntity.ok().body(response);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class, readOnly = true)
    public ResponseEntity<ScopusSearchAuthor> getScopusDetailsById(String scopusId,
                                                                   String xScope,
                                                                   String emJournalAcronym,
                                                                   String keywords,
                                                                   KeywordSearchLogic searchLogic) {
        if (scopusId == null || scopusId.isBlank()) {
            final Map<String, String> args = Map.of(SCOPUS_ID_TAG, String.valueOf(scopusId));
            log.error("Invalid request for Scopus details with no Scopus Id or EM Journal Acronym {}", args);
            throw new InternalException(ErrorResponse.IdEnum.INVALIDARGUMENT, HttpStatus.BAD_REQUEST, args);
        }

        log.info("Scopus details request for journal {} scopusId {} keywords {}", emJournalAcronym, scopusId, keywords);

        List<PersonFinderScopusAuthor> scopusDetails = personFinder.getScopusDetailsByIds(List.of(scopusId));

        List<ScopusSearchAuthor> scopusUser = new ArrayList<>();
        if (!scopusDetails.isEmpty()) {
            scopusUser.add(convertAuthor(scopusDetails.get(0), null));
            DataGatherRules<ScopusSearchAuthor> rules = new DataGatherRules<>(scopusUser)
                    .addBlockList().addInternalDbData().addReviewStatistics(false).addContentMatch(keywords, searchLogic);

            scopusUser = personDetailsSupportService.gatherAdditionalData(emJournalAcronym, rules);
        }

        if (scopusUser.isEmpty()) {
            log.debug("No scopus entries found for journal {} scopus Id {}", emJournalAcronym, scopusId);
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok().body(scopusUser.get(0));
    }

    @Override
    public ResponseEntity<ScopusStatisticsResponse> getStatistics(String scopusId, String xScope) {
        if (scopusId == null || scopusId.isBlank()) {
            log.error("Invalid request for Scopus statistics with no Scopus Id");
            throw new InternalException(ErrorResponse.IdEnum.INVALIDARGUMENT, HttpStatus.BAD_REQUEST,
                    Map.of(SCOPUS_ID_TAG, "null"));
        }

        GraphPersonStatistics statistics = scopusGraph.getPublicationStatistics(scopusId);

        // Using a TreeMap as that will ensure entries are ordered by the Key - which is year ascending
        Map<Integer, ScopusStatisticsResponseStatistics> statsByYear = new TreeMap<>();

        if (statistics.getAnnualAuthorOf() != null) {
            statistics.getAnnualAuthorOf().stream().filter(p -> p.getCount() != null && p.getCount() != 0)
                    .forEach(p -> statsByYear.computeIfAbsent(Integer.parseUnsignedInt(p.getStartYear()),
                                    y -> new ScopusStatisticsResponseStatistics().year(y))
                            .setPublishedCount(p.getCount()));
        }
        if (statistics.getAnnualReferencedBy() != null) {
            statistics.getAnnualReferencedBy().stream().filter(r -> r.getCount() != null && r.getCount() != 0)
                    .forEach(r -> statsByYear.computeIfAbsent(Integer.parseUnsignedInt(r.getStartYear()),
                                    y -> new ScopusStatisticsResponseStatistics().year(y))
                            .setCitationsCount(r.getCount()));
        }

        log.info("Scopus publication statistics returned {} years statistics for Scopus Id {}", statsByYear.size(), scopusId);

        ScopusStatisticsResponse response = new ScopusStatisticsResponse();
        statsByYear.values().forEach(response::addStatisticsItem);

        return ResponseEntity.ok().body(response);
    }

    private ScopusKeywordSearchAuthor convertAuthor(PersonFinderScopusAuthor scopusAuthor, String journalIssn) {
        ScopusKeywordSearchAuthor author = new ScopusKeywordSearchAuthor();
        author.addScopusIdsItem(scopusAuthor.getAuthid());
        author.addEmailsItem(scopusAuthor.getAuthemail());
        author.setFirstName(scopusAuthor.getFirstName());
        author.setLastName(scopusAuthor.getLastName());
        author.setAffiliationName(scopusAuthor.getAfdispname());
        author.setAffiliationCity(scopusAuthor.getAfdispcity());
        author.setAffiliationCountry(scopusAuthor.getAfdispctry());
        author.setPublicationCount(scopusAuthor.getCount());
        author.setKeywordMatchCount(scopusAuthor.getCount_matching());
        author.setCitationCount(scopusAuthor.getNum_cited_by());
        author.setHindex(scopusAuthor.getHIndex());
        author.setKeywords(scopusAuthor.getAuthorKeywords());
        author.setSubjectAreas(Constants.getScopusSubjectAreaDescriptions(scopusAuthor.getSubjectAreaCodes()));
        author.setPublishedInJournalCount(scopusAuthor.getPublishedInJournalCount(journalIssn));

        return author;
    }

    private ScopusCoauthor convertCoauthor(GraphPerson graphPerson) {
        ScopusCoauthor author = new ScopusCoauthor();
        author.addScopusIdsItem(graphPerson.getID());
        if (graphPerson.getAuthemail() != null) {
            author.addEmailsItem(graphPerson.getAuthemail().toLowerCase());
        }
        author.setFirstName(graphPerson.getPreffirst());
        author.setLastName(graphPerson.getPreflast());
        PersonDetailsUtils.setDisplayName(author);

        final GraphOrganization organization = graphPerson.getOrganization();
        if (organization != null) {
            author.setAffiliationName(organization.getAffiliationName());
            author.setAffiliationCity(organization.getAffilcity());
            author.setAffiliationCountry(organization.getAffilctry());
        }

        author.setCoauthoredCount(graphPerson.getCoauthorshipCount());
        author.setPublishedInJournalCount(graphPerson.getPublishedInJournalCount());
        author.setHindex(graphPerson.getHIndex());

        return author;
    }

    private FundingAward convertFundingAward(ScopusSharedSearchFundingResults award) {
        FundingAward fundingAward = new FundingAward();
        fundingAward.setAwardId(award.getGrantAwardId());
        fundingAward.setTitle(award.getFundingTitle());
        fundingAward.setFunderName(award.getFunderName());
        fundingAward.setAbstract(award.getAbstract());
        if (award.getStartDate() != null) {
            fundingAward.setStartDate(award.getStartDate().toInstant().toEpochMilli());
        }
        if (award.getEndDate() != null) {
            fundingAward.setEndDate(award.getEndDate().toInstant().toEpochMilli());
        }

        fundingAward.setAwardees(award.getAwardees().stream().map(a -> {
            ScopusAuthor author = new ScopusAuthor();
            author.setName(a.getDisplayName());
            author.setId(a.getScopusId());
            return author;
        }).collect(Collectors.toList()));

        return fundingAward;
    }

    private ScopusPublication convertPublication(Publication srcPublication) {
        ScopusPublication publication = new ScopusPublication();
        publication.setEid(srcPublication.getEid());
        publication.setTitle(srcPublication.getItemtitle());
        publication.setJournalTitle(srcPublication.getSrctitle());
        publication.setCitationCount(srcPublication.getNumcitedby());
        publication.setYear(srcPublication.getPublicationYear());

        // The list of Authors details are split between 2 fields, one containing the name and the other the
        // Scopus Id we need to merge these lists and match the 2 items together
        String[] authorNames = srcPublication.getAuthorNames();
        String[] authorIds = srcPublication.getAuthorIds();
        if (authorNames.length != authorIds.length) {
            log.error("Person Finder supplied mismatching Author details (names = {}, ids = {}) in response {}",
                    authorNames.length, authorIds.length, srcPublication);
        }
        if (authorNames.length == 0) {
            log.error("Person Finder supplied invalid publication without Authors in response {}", srcPublication);
            publication.setAuthorCount(0);
        } else {
            for (int i = 0; i < authorNames.length; ++i) {
                ScopusAuthor author = new ScopusAuthor();
                author.setName(authorNames[i]);
                if (i < authorIds.length) {
                    author.setId(authorIds[i]);
                }
                publication.addAuthorsItem(author);
            }
            publication.setAuthorCount(publication.getAuthors().size());
        }

        return publication;
    }
}
