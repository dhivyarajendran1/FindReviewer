package com.elsevier.find.reviewers.external;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * The Scopus Sources interface is provided for a basic lookup for ISSN details for non-Elsevier journals.
 * It is worth noting that the data supporting this API is only updated (at the time of writing) twice a
 * year (June and November) and this is accepted as it is the same data that Scopus use, and we only use
 * this ISSN to check against Scopus
 */
@Slf4j
@Service
public class ScopusSources {
    @JsonIgnoreProperties(ignoreUnknown = true)
    @Data
    private static class SourcesResponse {
        @JsonProperty("eissn")
        private String eissn;
        @JsonProperty("issnp")
        private String issnp;
        @JsonProperty("prefsrctitle")
        private String prefsrctitle;
    }

    private final ObjectMapper objectMapper;
    private final HttpClient httpClientWithoutCertificateCheck;
    private final String sourcesApiUrl;

    public ScopusSources(ObjectMapper objectMapper,
                         HttpClient httpClientWithoutCertificateCheck,
                         @Value("${scopussources.client.base.url}") String sourcesApiUrl) {
        this.objectMapper = objectMapper;
        this.httpClientWithoutCertificateCheck = httpClientWithoutCertificateCheck;
        this.sourcesApiUrl = sourcesApiUrl.endsWith("/") ? sourcesApiUrl.substring(0, sourcesApiUrl.length() - 1) : sourcesApiUrl;
    }

    public String getJournalIssn(String journalTitle) {
        String issn = null;

        try {
            String payload = String.format("title=%s&fields=id&fields=issn&fields=title",
                    URLEncoder.encode(journalTitle, StandardCharsets.UTF_8));

            HttpRequest request = HttpRequest.newBuilder(new URI(sourcesApiUrl))
                    .header("Content-Type", "application/x-www-form-urlencoded")
                    .POST(HttpRequest.BodyPublishers.ofString(payload)).build();

            HttpResponse<String> httpResponse = httpClientWithoutCertificateCheck.send(request, HttpResponse.BodyHandlers.ofString());

            if (httpResponse.statusCode() == HttpStatus.OK.value()) {
                final String responseContent = httpResponse.body();
                if (responseContent != null) {
                    List<SourcesResponse> response = objectMapper.readValue(responseContent, new TypeReference<>() {
                    });
                    // As we are doing a title lookup we do not want to risk getting similar matches so do an exact
                    // match for the title name for the ISSN lookup
                    List<SourcesResponse> matchedJournals =
                            response.stream().filter(j -> journalTitle.trim().equalsIgnoreCase(j.getPrefsrctitle()))
                                    .collect(Collectors.toList());
                    if (matchedJournals.isEmpty()) {
                        log.warn("Failed to find ISSN for Journal {}, response {}", journalTitle, responseContent);
                    } else {
                        issn = matchedJournals.stream().map(j -> j.getEissn() == null ? j.getIssnp() : j.getEissn())
                                .filter(Objects::nonNull).findFirst().orElse(null);

                        log.info("ISSN lookup found ISSN {} for {} with response {}", issn, journalTitle, responseContent);
                    }
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log.error("Interrupted while getting ISSN for {}", journalTitle, e);
        } catch (Exception e) {
            log.error("Failed to get ISSN for {}", journalTitle, e);
        }

        return issn;
    }
}
