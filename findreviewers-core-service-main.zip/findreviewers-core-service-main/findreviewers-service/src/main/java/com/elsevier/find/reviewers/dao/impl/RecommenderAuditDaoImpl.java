package com.elsevier.find.reviewers.dao.impl;

import com.elsevier.find.reviewers.dao.RecommenderAuditDao;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.TableSchema;
import software.amazon.awssdk.enhanced.dynamodb.model.PageIterable;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryConditional;

import java.util.List;
import java.util.stream.Collectors;

@Repository
public class RecommenderAuditDaoImpl implements RecommenderAuditDao {

    private final DynamoDbTable<ManuscriptAudit> manuscriptAuditTable;

    public RecommenderAuditDaoImpl(DynamoDbEnhancedClient dynamoDbEnhancedClient,
                                   @Value("${findreviewers.manuscript.audit.tablename}") String manuscriptAuditTableName) {
        manuscriptAuditTable = dynamoDbEnhancedClient.table(manuscriptAuditTableName,
                TableSchema.fromBean(ManuscriptAudit.class));
    }

    public List<ManuscriptAudit> getManuscriptAudit(String journalAcronym, Long documentId) {
        Key queryKey = Key.builder().partitionValue(journalAcronym.toUpperCase()).sortValue(documentId + "#").build();
        QueryConditional queryConditional = QueryConditional.sortBeginsWith(queryKey);

        PageIterable<ManuscriptAudit> results = manuscriptAuditTable.query(queryConditional);

        return results.items().stream().collect(Collectors.toList());
    }
}
