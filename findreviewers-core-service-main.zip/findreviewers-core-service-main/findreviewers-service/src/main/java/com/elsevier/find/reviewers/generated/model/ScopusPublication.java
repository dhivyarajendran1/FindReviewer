package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.ScopusAuthor;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * Details about a Scopus Publication
 */
@Schema(description = "Details about a Scopus Publication")
@Validated



public class ScopusPublication   {
  @JsonProperty("eid")
  private String eid = null;

  @JsonProperty("title")
  private String title = null;

  @JsonProperty("journalTitle")
  private String journalTitle = null;

  @JsonProperty("citationCount")
  private Integer citationCount = null;

  @JsonProperty("year")
  private Integer year = null;

  @JsonProperty("authorCount")
  private Integer authorCount = null;

  @JsonProperty("authors")
  @Valid
  private List<ScopusAuthor> authors = null;

  public ScopusPublication eid(String eid) {
    this.eid = eid;
    return this;
  }

  /**
   * Unique Scopus identifier for the publication
   * @return eid
   **/
  @Schema(example = "2-s2.0-85110607671", description = "Unique Scopus identifier for the publication")
  
    public String getEid() {
    return eid;
  }

  public void setEid(String eid) {
    this.eid = eid;
  }

  public ScopusPublication title(String title) {
    this.title = title;
    return this;
  }

  /**
   * The title of the publication
   * @return title
   **/
  @Schema(example = "Study designs for comparative diagnostic test accuracy", description = "The title of the publication")
  
    public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public ScopusPublication journalTitle(String journalTitle) {
    this.journalTitle = journalTitle;
    return this;
  }

  /**
   * The title of the journal the publication was in
   * @return journalTitle
   **/
  @Schema(example = "Journal of Clinical Epidemiology", description = "The title of the journal the publication was in")
  
    public String getJournalTitle() {
    return journalTitle;
  }

  public void setJournalTitle(String journalTitle) {
    this.journalTitle = journalTitle;
  }

  public ScopusPublication citationCount(Integer citationCount) {
    this.citationCount = citationCount;
    return this;
  }

  /**
   * The number of citations this publication has
   * @return citationCount
   **/
  @Schema(example = "22", description = "The number of citations this publication has")
  
    public Integer getCitationCount() {
    return citationCount;
  }

  public void setCitationCount(Integer citationCount) {
    this.citationCount = citationCount;
  }

  public ScopusPublication year(Integer year) {
    this.year = year;
    return this;
  }

  /**
   * The year of publication
   * @return year
   **/
  @Schema(example = "2021", description = "The year of publication")
  
    public Integer getYear() {
    return year;
  }

  public void setYear(Integer year) {
    this.year = year;
  }

  public ScopusPublication authorCount(Integer authorCount) {
    this.authorCount = authorCount;
    return this;
  }

  /**
   * The number of authors this publication has
   * @return authorCount
   **/
  @Schema(example = "22", description = "The number of authors this publication has")
  
    public Integer getAuthorCount() {
    return authorCount;
  }

  public void setAuthorCount(Integer authorCount) {
    this.authorCount = authorCount;
  }

  public ScopusPublication authors(List<ScopusAuthor> authors) {
    this.authors = authors;
    return this;
  }

  public ScopusPublication addAuthorsItem(ScopusAuthor authorsItem) {
    if (this.authors == null) {
      this.authors = new ArrayList<>();
    }
    this.authors.add(authorsItem);
    return this;
  }

  /**
   * The list of authors for the publication (This may be a partial list and less than authorCount)
   * @return authors
   **/
  @Schema(description = "The list of authors for the publication (This may be a partial list and less than authorCount)")
      @Valid
    public List<ScopusAuthor> getAuthors() {
    return authors;
  }

  public void setAuthors(List<ScopusAuthor> authors) {
    this.authors = authors;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ScopusPublication scopusPublication = (ScopusPublication) o;
    return Objects.equals(this.eid, scopusPublication.eid) &&
        Objects.equals(this.title, scopusPublication.title) &&
        Objects.equals(this.journalTitle, scopusPublication.journalTitle) &&
        Objects.equals(this.citationCount, scopusPublication.citationCount) &&
        Objects.equals(this.year, scopusPublication.year) &&
        Objects.equals(this.authorCount, scopusPublication.authorCount) &&
        Objects.equals(this.authors, scopusPublication.authors);
  }

  @Override
  public int hashCode() {
    return Objects.hash(eid, title, journalTitle, citationCount, year, authorCount, authors);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ScopusPublication {\n");
    
    sb.append("    eid: ").append(toIndentedString(eid)).append("\n");
    sb.append("    title: ").append(toIndentedString(title)).append("\n");
    sb.append("    journalTitle: ").append(toIndentedString(journalTitle)).append("\n");
    sb.append("    citationCount: ").append(toIndentedString(citationCount)).append("\n");
    sb.append("    year: ").append(toIndentedString(year)).append("\n");
    sb.append("    authorCount: ").append(toIndentedString(authorCount)).append("\n");
    sb.append("    authors: ").append(toIndentedString(authors)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
