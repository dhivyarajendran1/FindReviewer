package com.elsevier.find.reviewers.external;

import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.utils.PersonDetailsUtils;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.time.Duration;
import java.util.List;
import java.util.Map;

@Slf4j
public abstract class ScopusSharedSearchBase {
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ScopusSharedSearchAuthorIds {
        @JsonProperty("authid")
        private String authid; // Scopus Id
        @JsonProperty("authemail")
        private String authemail; // email

        @JsonSetter("authemail")
        public void setAuthemail(String rawAuthemail) {
            authemail = PersonDetailsUtils.isValidEmail(rawAuthemail) ? rawAuthemail.trim().toLowerCase() : null;
        }
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    protected static class ScopusSharedSearchResponse<T> {
        @JsonProperty("totalResultsCount")
        private Integer totalResultsCount;
        @JsonProperty("hits")
        private List<T> hits;
    }

    private final WebClient webClient;
    private final String scopusSharedSearchBaseUrl;
    private final String dataset;

    protected ScopusSharedSearchBase(String dataset,
                                     WebClient webClient,
                                     String scopusSharedSearchBaseUrl) {
        this.dataset = dataset;
        this.webClient = webClient;
        this.scopusSharedSearchBaseUrl = scopusSharedSearchBaseUrl.endsWith("/") ?
                scopusSharedSearchBaseUrl.substring(0, scopusSharedSearchBaseUrl.length() - 1) : scopusSharedSearchBaseUrl;
    }

    /**
     * Makes the API request to the Scopus Shared Search system with all the correct authentication
     *
     * @param requestBody The body to be called with
     * @return The text returned from the request
     */
    protected String makeScopusSharedSearchCall(String requestBody) {
        final String url = String.format("%s/document/result", scopusSharedSearchBaseUrl);

        log.info("Making Shared Search {} API {} request with body {}", dataset, url, requestBody);

        String response = null;
        try {
            response = webClient.post()
                    .uri(url)
                    .header("x-els-dataset", dataset)
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(requestBody)
                    .retrieve()
                    .bodyToMono(String.class)
                    // Subscribe to this Mono and block until a next signal is received or a timeout expires.
                    // Returns that value, or null if the Mono completes empty.
                    .block(Duration.ofSeconds(20));

        } catch (WebClientResponseException e) {
            // WebClient throws an exception by default when a 4xx or 5xx error is received, need to strip out the
            // 404 - Not Found one as it may be there was no data available in Person Finder that we were requesting
            // and that is not really an error case for us
            if (e.getStatusCode() == HttpStatus.NOT_FOUND) {
                log.warn("Entry not found for Scopus Shared Search API {} HttpStatusCode = {}, HttpHeaders = {}, ResponseBody = {}",
                        url, e.getStatusCode(), e.getHeaders(), e.getResponseBodyAsString(), e);
                response = null;
            } else {
                log.error("Error calling Scopus Shared Search API {} HttpStatusCode = {}, HttpHeaders = {}, ResponseBody = {} for request = {}",
                        url, e.getStatusCode(), e.getHeaders(), e.getResponseBodyAsString(), requestBody, e);
                throw new InternalException(ErrorResponse.IdEnum.SCOPUSSHAREDSEARCHFAILURE,
                        HttpStatus.INTERNAL_SERVER_ERROR, Map.of("body", requestBody));
            }
        } catch (Exception e) {
            log.error("Exception calling Scopus Shared Search API {}", url, e);
            throw new InternalException(ErrorResponse.IdEnum.SCOPUSSHAREDSEARCHFAILURE, HttpStatus.INTERNAL_SERVER_ERROR,
                    Map.of("body", requestBody));
        }

        return response;
    }
}
