package com.elsevier.find.reviewers.filter;

import com.elsevier.find.reviewers.enums.ProductType;
import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.utils.Constants;
import com.elsevier.find.reviewers.utils.CookieManager.SessionData;
import lombok.Data;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * The Session Context contains a combination of:
 * - The Session built from the cookie when a REST call is made
 * - Identity information when a user logs onto the system
 * This class gives a single view of the data so that other code does not need to know where the data is sourced from
 * It will be available to all interfaces and can be queried to work out information about the session
 */
public class SessionContext {
    @Data
    private static class IdentitySession {
        private final Long webUserId;
        private final String email;
        private final List<String> secondaryEmails;
        private final String displayName;
        private final Map<String, String> analyticsInfo;
    }

    // Thread local is used to store the details for the given request. This means that as a
    // request is received it will be available for anything that is working on that thread
    // to handle the request.
    private static final ThreadLocal<SessionData> sessionDetails = new ThreadLocal<>();

    private static final ThreadLocal<IdentitySession> identitySessionDetails = new ThreadLocal<>();

    private SessionContext() {
    }

    public static void initialize(SessionData sessionData) {
        sessionDetails.set(sessionData);
    }

    public static void initializeIdentity(Long webUserId,
                                          String email,
                                          List<String> secondaryEmails,
                                          String displayName,
                                          Map<String, String> analyticsInfo) {
        identitySessionDetails.set(new IdentitySession(webUserId, email, secondaryEmails, displayName, analyticsInfo));
    }

    public static List<Object> export() {
        List<Object> exportList = new ArrayList<>();
        exportList.add(sessionDetails.get());
        exportList.add(identitySessionDetails.get());
        return exportList;
    }

    public static void load(List<Object> sessions) {
        destroy();
        for (Object session : sessions) {
            if (session instanceof SessionData) {
                sessionDetails.set((SessionData) session);
            } else if (session instanceof IdentitySession) {
                identitySessionDetails.set((IdentitySession) session);
            }
        }
    }

    /**
     * Clears out the session details from the Session Context
     */
    public static void destroy() {
        sessionDetails.remove();
        identitySessionDetails.remove();
    }

    public static ProductType getProductType() {
        return getInternalSession().getProductType();
    }

    public static boolean isReadOnly() {
        return getInternalSession().isReadOnly();
    }

    public static boolean isUrsdbJournal() {
        return getInternalSession().isUrsdbJournal();
    }

    public static boolean isElsevierJournal() {
        return getInternalSession().isUrsdbJournal() || (getInternalSession().getEmJournalAcronym() != null &&
                Constants.nonUrsdbElsevierJournals.containsKey(getInternalSession().getEmJournalAcronym()));
    }

    public static String getBearerToken() {
        return getInternalSession().getBearerToken();
    }

    public static int getMaxAge() {
        return getInternalSession().getMaxAge();
    }

    private static SessionData getInternalSession() {
        final SessionData iSession = sessionDetails.get();
        if (iSession == null) {
            throw new InternalException(HttpStatus.UNAUTHORIZED);
        }
        return iSession;
    }

    public static boolean isIdPlusAuthenticated() {
        return identitySessionDetails.get() != null;
    }

    public static Long getWebUserId() {
        final IdentitySession iSession = identitySessionDetails.get();
        return (iSession == null) ? null : iSession.getWebUserId();
    }

    public static List<String> getAllEmails() {
        final IdentitySession iSession = identitySessionDetails.get();

        List<String> allEmails = new ArrayList<>();
        if (iSession != null) {
            if (iSession.getEmail() != null) {
                allEmails.add(iSession.getEmail());
            }
            if (iSession.getSecondaryEmails() != null) {
                allEmails.addAll(iSession.getSecondaryEmails());
            }
        }
        return allEmails;
    }

    public static String getDisplayName() {
        final IdentitySession iSession = identitySessionDetails.get();
        return (iSession == null) ? null : iSession.getDisplayName();
    }

    // SonarQube - stop complaining about returning null - that is exactly what we need
    @SuppressWarnings("java:S1168")
    public static Map<String, String> getAnalyticsInfo() {
        final IdentitySession identSession = identitySessionDetails.get();
        if (identSession != null) {
            return identSession.getAnalyticsInfo();
        }
        return null;
    }
}
