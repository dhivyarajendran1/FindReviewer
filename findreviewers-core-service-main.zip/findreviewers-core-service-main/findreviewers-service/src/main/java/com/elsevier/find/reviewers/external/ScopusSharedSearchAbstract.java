package com.elsevier.find.reviewers.external;

import com.elsevier.find.reviewers.exception.InternalException;
import com.elsevier.find.reviewers.generated.model.ErrorResponse;
import com.elsevier.find.reviewers.generated.model.KeywordSearchLogic;
import com.elsevier.find.reviewers.utils.KeywordUtils;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.io.IOException;
import java.time.Year;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Slf4j
@Service
public class ScopusSharedSearchAbstract extends ScopusSharedSearchBase {
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ScopusSharedSearchDocumentResults {
        @JsonProperty("eid")
        private String eid;
        @JsonProperty("authors")
        private List<ScopusSharedSearchAuthorIds> authors;
        @JsonProperty("authkeywords")
        private List<String> authkeywords;
        @JsonProperty("subjmain")
        private List<String> subjmain;  // These are the id's for the subject area
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ScopusSharedSearchPublicationResults {
        @EqualsAndHashCode(callSuper = true)
        @Data
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class ScopusSharedSearchPubAuthor extends ScopusSharedSearchAuthorIds {
            @JsonProperty("authidxname")
            private String authidxname;
        }

        @JsonProperty("eid")
        private String eid;
        @JsonProperty("itemtitle")
        private List<String> itemtitle; // Publication Title
        @JsonProperty("srctitle")
        private String srctitle; // Journal Title
        @JsonProperty("numcitedby")
        private Integer numcitedby;
        @JsonProperty("pubyr")
        private String pubyr;
        @JsonProperty("authors")
        private List<ScopusSharedSearchPubAuthor> authors;
    }

    private static final String CONTENT_MATCH_REQUEST_TEMPLATE = """
            {"query":{"queryString": "(%s) AND (%s)",
             "defaultOperator": "%s"},
             "facetFilters": [{"fieldName": "pubyr", "terms": [ %s ]},
                              {"fieldName": "subtype", "terms": [ "pp" ], "operator": "NOT"}],
             "returnFields": ["eid", "authors", "authid", "authkeywords", "subjmain"],
             "resultSet": {"skip": 0, "amount": 5000},
             "sortBy": [{"fieldName": "pubyr", "order": "desc"}]}
            """;

    private static final String REFERENCE_AUTHOR_TEMPLATE = """
            {"query":{ "queryString": "%s", "defaultOperator": "OR" },
             "returnFields":["authors","authid","authemail","eid"]}
            """;

    private static final String PUBLICATION_TEMPLATE = """
            {"query":{ "queryString": "%s", "defaultOperator": "OR" },
             "sortBy": [{"fieldName": "pubyyyymm","order": "desc"}],
             "returnFields":["eid","itemtitle","srctitle","numcitedby","pubyr","authors","authid","authidxname"]}
            """;

    private final ObjectMapper objectMapper;

    public ScopusSharedSearchAbstract(@Qualifier("scopussharedsearch") WebClient webClient,
                                      ObjectMapper objectMapper,
                                      @Value("${scopussharedsearch.client.base.url}") String scopusSharedSearchBaseUrl) {
        super("abstract", webClient, scopusSharedSearchBaseUrl);
        this.objectMapper = objectMapper;
    }

    /**
     * Gets the number of content matches for a list of users based on supplied keywords
     *
     * @param keywords    Keywords to check
     * @param searchLogic How the keywords should be assessed
     * @param scopusIds   List of scopusIds to check
     * @return List of publications with their authors, keywords and subject areas
     */
    // SonarQube complaining about complexity - but it's not complex, splitting it would make it harder to follow
    @SuppressWarnings("java:S3776")
    public List<ScopusSharedSearchDocumentResults> getContentMatchPublications(String keywords,
                                                                               KeywordSearchLogic searchLogic,
                                                                               List<String> scopusIds) {
        final String scopusIdInput = scopusIds.stream().map(s -> "authid:" + s).collect(Collectors.joining(" OR "));

        // Need to limit any query to the last 5 years and the next year - this matches the publications API behaviour
        final int maxPublicationYear = Year.now().plusYears(1).getValue();
        final String publicationYears = IntStream.rangeClosed(maxPublicationYear - 5, maxPublicationYear)
                .mapToObj(s -> "\"" + s + "\"").collect(Collectors.joining(", "));

        final String body = String.format(CONTENT_MATCH_REQUEST_TEMPLATE,
                KeywordUtils.cleanKeywordForQuery(keywords).replace("\"", "\\\""),
                scopusIdInput,
                KeywordUtils.getSearchLogicString(searchLogic), publicationYears);
        String rawResponse = null;
        ScopusSharedSearchResponse<ScopusSharedSearchDocumentResults> contentMatchResponse = null;

        try {
            rawResponse = makeScopusSharedSearchCall(body);

            if (rawResponse != null && !rawResponse.isBlank()) {
                contentMatchResponse = objectMapper.readValue(rawResponse, new TypeReference<>() {
                });
            }
        } catch (IOException e) {
            log.error("Scopus Shared Search Content match response with body {} unexpected format {}", body, rawResponse, e);
            throw new InternalException(
                    ErrorResponse.IdEnum.SCOPUSSHAREDSEARCHFAILURE, HttpStatus.INTERNAL_SERVER_ERROR, Map.of("body", body));
        }

        List<ScopusSharedSearchDocumentResults> contentMatches = new ArrayList<>();
        if (contentMatchResponse != null && contentMatchResponse.getHits() != null) {
            if (contentMatchResponse.getTotalResultsCount() != null && contentMatchResponse.getTotalResultsCount() >= 5000) {
                log.error("Content match count failed to get all data for keywords {} and scopusIds {}", keywords, scopusIds);
            }

            for (ScopusSharedSearchDocumentResults result : contentMatchResponse.getHits()) {
                if (result.getAuthors() != null) {
                    // Remove any authors that are not the ones that were requested
                    result.setAuthors(result.getAuthors().stream().filter(a -> scopusIds.contains(a.getAuthid()))
                            .collect(Collectors.toList()));
                    if (!result.getAuthors().isEmpty()) {
                        contentMatches.add(result);
                    }
                }
            }
        }

        return contentMatches;
    }

    public List<ScopusSharedSearchDocumentResults> getAuthorsFromReferences(Set<String> references) {
        final String body = String.format(REFERENCE_AUTHOR_TEMPLATE,
                references.stream().map(r -> "doi:" + r).collect(Collectors.joining(" ")));

        ScopusSharedSearchResponse<ScopusSharedSearchDocumentResults> response = null;

        String rawResponse = null;
        try {
            rawResponse = makeScopusSharedSearchCall(body);

            if (rawResponse != null && !rawResponse.isBlank()) {
                response = objectMapper.readValue(rawResponse, new TypeReference<>() {
                });
            }
        } catch (Exception e) {
            log.error("Scopus Shared Search Reference response with body {} unexpected format {}", body, rawResponse, e);
            throw new InternalException(
                    ErrorResponse.IdEnum.SCOPUSSHAREDSEARCHFAILURE, HttpStatus.INTERNAL_SERVER_ERROR, Map.of("body", body));
        }

        return response == null || response.getHits() == null ? Collections.emptyList() : response.getHits();
    }

    public List<ScopusSharedSearchPublicationResults> getPublications(List<String> publicationIds) {
        final String body = String.format(PUBLICATION_TEMPLATE,
                publicationIds.stream().map(p -> "eid:" + p).collect(Collectors.joining(" ")));

        ScopusSharedSearchResponse<ScopusSharedSearchPublicationResults> response = null;

        String rawPublicationsResponse = null;
        try {
            rawPublicationsResponse = makeScopusSharedSearchCall(body);

            if (rawPublicationsResponse != null && !rawPublicationsResponse.isBlank()) {
                response = objectMapper.readValue(rawPublicationsResponse, new TypeReference<>() {
                });
            }
        } catch (Exception e) {
            log.error("Scopus Shared Search Publications response with body {} unexpected format {}", body, rawPublicationsResponse, e);
            throw new InternalException(
                    ErrorResponse.IdEnum.SCOPUSSHAREDSEARCHFAILURE, HttpStatus.INTERNAL_SERVER_ERROR, Map.of("body", body));
        }

        return response == null || response.getHits() == null ? Collections.emptyList() : response.getHits();
    }
}
