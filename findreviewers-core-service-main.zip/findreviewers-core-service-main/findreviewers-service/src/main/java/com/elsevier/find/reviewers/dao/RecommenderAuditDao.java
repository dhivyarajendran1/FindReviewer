package com.elsevier.find.reviewers.dao;

import software.amazon.awssdk.enhanced.dynamodb.AttributeConverter;
import software.amazon.awssdk.enhanced.dynamodb.AttributeValueType;
import software.amazon.awssdk.enhanced.dynamodb.EnhancedType;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbAttribute;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbConvertedBy;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbSortKey;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public interface RecommenderAuditDao {
    // The AWS Dynamo annotations do not work well with lombok
    // https://github.com/aws/aws-sdk-java-v2/issues/1932
    @DynamoDbBean
    class ManuscriptAudit {
        private String journalAcronym;
        private String sortKey;
        private Long eventTime;
        private Boolean forced;
        private List<String> missingAttributes;

        @DynamoDbPartitionKey
        @DynamoDbAttribute("JournalAcronym")
        public String getJournalAcronym() {
            return journalAcronym;
        }

        public void setJournalAcronym(String value) {
            journalAcronym = value;
        }

        @DynamoDbSortKey
        @DynamoDbAttribute("SortKey")
        public String getSortKey() {
            return sortKey;
        }

        public void setSortKey(String value) {
            sortKey = value;
        }

        @DynamoDbAttribute("EventTime")
        public Long getEventTime() {
            return eventTime;
        }

        public void setEventTime(Long value) {
            eventTime = value;
        }

        @DynamoDbAttribute("Forced")
        public Boolean getForced() {
            return forced;
        }

        public void setForced(Boolean value) {
            forced = value;
        }

        @DynamoDbAttribute("AdditionalInfo")
        @DynamoDbConvertedBy(AdditionalInfoToMissingAttributeConverter.class)
        public List<String> getMissingAttributes() {
            return missingAttributes;
        }

        public void setMissingAttributes(List<String> value) {
            missingAttributes = value;
        }
    }

    // The only value currently required from the Additional Information column is the
    // Missing Attributes, therefor we just extract that data from the document
    class AdditionalInfoToMissingAttributeConverter implements AttributeConverter<List<String>> {
        @Override
        public AttributeValue transformFrom(List<String> input) {
            // No support for writing to the audit required
            return null;
        }

        @Override
        public List<String> transformTo(AttributeValue input) {
            return input.m().getOrDefault("MissingAttributes",
                            AttributeValue.fromL(Collections.emptyList())).l()
                    .stream().map(AttributeValue::s).collect(Collectors.toList());
        }

        @Override
        public EnhancedType<List<String>> type() {
            return EnhancedType.listOf(String.class);
        }

        @Override
        public AttributeValueType attributeValueType() {
            return AttributeValueType.M;
        }
    }

    List<ManuscriptAudit> getManuscriptAudit(String journalAcronym, Long documentId);
}
