package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * Scopus Author details
 */
@Schema(description = "Scopus Author details")
@Validated



public class ScopusAuthor   {
  @JsonProperty("id")
  private String id = null;

  @JsonProperty("name")
  private String name = null;

  public ScopusAuthor id(String id) {
    this.id = id;
    return this;
  }

  /**
   * Scopus Id for the Author
   * @return id
   **/
  @Schema(example = "12345678a", description = "Scopus Id for the Author")
  
    public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public ScopusAuthor name(String name) {
    this.name = name;
    return this;
  }

  /**
   * The name of the Author
   * @return name
   **/
  @Schema(example = "J. Smith", description = "The name of the Author")
  
    public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ScopusAuthor scopusAuthor = (ScopusAuthor) o;
    return Objects.equals(this.id, scopusAuthor.id) &&
        Objects.equals(this.name, scopusAuthor.name);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, name);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ScopusAuthor {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
