package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.Editor;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * The response for a list of editors
 */
@Schema(description = "The response for a list of editors")
@Validated



public class EditorsResponse   {
  @JsonProperty("more")
  private Boolean more = null;

  @JsonProperty("editors")
  @Valid
  private List<Editor> editors = null;

  public EditorsResponse more(Boolean more) {
    this.more = more;
    return this;
  }

  /**
   * To support paging, specifies if there are more entries available after the last one returned
   * @return more
   **/
  @Schema(description = "To support paging, specifies if there are more entries available after the last one returned")
  
    public Boolean isMore() {
    return more;
  }

  public void setMore(Boolean more) {
    this.more = more;
  }

  public EditorsResponse editors(List<Editor> editors) {
    this.editors = editors;
    return this;
  }

  public EditorsResponse addEditorsItem(Editor editorsItem) {
    if (this.editors == null) {
      this.editors = new ArrayList<>();
    }
    this.editors.add(editorsItem);
    return this;
  }

  /**
   * Get editors
   * @return editors
   **/
  @Schema(description = "")
      @Valid
    public List<Editor> getEditors() {
    return editors;
  }

  public void setEditors(List<Editor> editors) {
    this.editors = editors;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    EditorsResponse editorsResponse = (EditorsResponse) o;
    return Objects.equals(this.more, editorsResponse.more) &&
        Objects.equals(this.editors, editorsResponse.editors);
  }

  @Override
  public int hashCode() {
    return Objects.hash(more, editors);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class EditorsResponse {\n");
    
    sb.append("    more: ").append(toIndentedString(more)).append("\n");
    sb.append("    editors: ").append(toIndentedString(editors)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
