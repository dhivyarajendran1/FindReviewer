package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.elsevier.find.reviewers.generated.model.ScopusSearchAuthor;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * Volunteer
 */
@Validated



public class Volunteer extends ScopusSearchAuthor  {
  @JsonProperty("webUserId")
  private Long webUserId = null;

  @JsonProperty("emJournalAcronym")
  private String emJournalAcronym = null;

  @JsonProperty("volunteerDate")
  private Long volunteerDate = null;

  /**
   * The reason the volunteer wants to review for the journal
   */
  public enum ReasonEnum {
    EXPERTORINTEREST("ExpertOrInterest"),
    
    PRESTIGEOFJOURNAL("PrestigeOfJournal"),
    
    PREVIOUSLYPUBLISHED("PreviouslyPublished"),
    
    LEARNANDSTAYUPTODATE("LearnAndStayUpToDate");

    private String value;

    ReasonEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static ReasonEnum fromValue(String text) {
      for (ReasonEnum b : ReasonEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("reason")
  private ReasonEnum reason = null;

  @JsonProperty("message")
  private String message = null;

  @JsonProperty("classificationCodes")
  @Valid
  private List<String> classificationCodes = null;

  @JsonProperty("campaign")
  private String campaign = null;

  public Volunteer webUserId(Long webUserId) {
    this.webUserId = webUserId;
    return this;
  }

  /**
   * Globally unique identifier for a user
   * @return webUserId
   **/
  @Schema(example = "32", required = true, description = "Globally unique identifier for a user")
      @NotNull

    public Long getWebUserId() {
    return webUserId;
  }

  public void setWebUserId(Long webUserId) {
    this.webUserId = webUserId;
  }

  public Volunteer emJournalAcronym(String emJournalAcronym) {
    this.emJournalAcronym = emJournalAcronym;
    return this;
  }

  /**
   * Journal volunteered for EM acronym
   * @return emJournalAcronym
   **/
  @Schema(example = "ACR", required = true, description = "Journal volunteered for EM acronym")
      @NotNull

    public String getEmJournalAcronym() {
    return emJournalAcronym;
  }

  public void setEmJournalAcronym(String emJournalAcronym) {
    this.emJournalAcronym = emJournalAcronym;
  }

  public Volunteer volunteerDate(Long volunteerDate) {
    this.volunteerDate = volunteerDate;
    return this;
  }

  /**
   * The date of the candidate volunteered (EPOCH - milliseconds)
   * minimum: 0
   * @return volunteerDate
   **/
  @Schema(example = "1579866980000", description = "The date of the candidate volunteered (EPOCH - milliseconds)")
  
  @Min(0L)  public Long getVolunteerDate() {
    return volunteerDate;
  }

  public void setVolunteerDate(Long volunteerDate) {
    this.volunteerDate = volunteerDate;
  }

  public Volunteer reason(ReasonEnum reason) {
    this.reason = reason;
    return this;
  }

  /**
   * The reason the volunteer wants to review for the journal
   * @return reason
   **/
  @Schema(example = "PrestigeOfJournal", description = "The reason the volunteer wants to review for the journal")
  
    public ReasonEnum getReason() {
    return reason;
  }

  public void setReason(ReasonEnum reason) {
    this.reason = reason;
  }

  public Volunteer message(String message) {
    this.message = message;
    return this;
  }

  /**
   * Additional information for why the user wants to volunteer for this journal
   * @return message
   **/
  @Schema(example = "Volunteer biography", description = "Additional information for why the user wants to volunteer for this journal")
  
    public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public Volunteer classificationCodes(List<String> classificationCodes) {
    this.classificationCodes = classificationCodes;
    return this;
  }

  public Volunteer addClassificationCodesItem(String classificationCodesItem) {
    if (this.classificationCodes == null) {
      this.classificationCodes = new ArrayList<>();
    }
    this.classificationCodes.add(classificationCodesItem);
    return this;
  }

  /**
   * Get classificationCodes
   * @return classificationCodes
   **/
  @Schema(description = "")
  
    public List<String> getClassificationCodes() {
    return classificationCodes;
  }

  public void setClassificationCodes(List<String> classificationCodes) {
    this.classificationCodes = classificationCodes;
  }

  public Volunteer campaign(String campaign) {
    this.campaign = campaign;
    return this;
  }

  /**
   * Optional identifier for the campaign used to recruit the reviewer
   * @return campaign
   **/
  @Schema(description = "Optional identifier for the campaign used to recruit the reviewer")
  
    public String getCampaign() {
    return campaign;
  }

  public void setCampaign(String campaign) {
    this.campaign = campaign;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Volunteer volunteer = (Volunteer) o;
    return Objects.equals(this.webUserId, volunteer.webUserId) &&
        Objects.equals(this.emJournalAcronym, volunteer.emJournalAcronym) &&
        Objects.equals(this.volunteerDate, volunteer.volunteerDate) &&
        Objects.equals(this.reason, volunteer.reason) &&
        Objects.equals(this.message, volunteer.message) &&
        Objects.equals(this.classificationCodes, volunteer.classificationCodes) &&
        Objects.equals(this.campaign, volunteer.campaign) &&
        super.equals(o);
  }

  @Override
  public int hashCode() {
    return Objects.hash(webUserId, emJournalAcronym, volunteerDate, reason, message, classificationCodes, campaign, super.hashCode());
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Volunteer {\n");
    sb.append("    ").append(toIndentedString(super.toString())).append("\n");
    sb.append("    webUserId: ").append(toIndentedString(webUserId)).append("\n");
    sb.append("    emJournalAcronym: ").append(toIndentedString(emJournalAcronym)).append("\n");
    sb.append("    volunteerDate: ").append(toIndentedString(volunteerDate)).append("\n");
    sb.append("    reason: ").append(toIndentedString(reason)).append("\n");
    sb.append("    message: ").append(toIndentedString(message)).append("\n");
    sb.append("    classificationCodes: ").append(toIndentedString(classificationCodes)).append("\n");
    sb.append("    campaign: ").append(toIndentedString(campaign)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
