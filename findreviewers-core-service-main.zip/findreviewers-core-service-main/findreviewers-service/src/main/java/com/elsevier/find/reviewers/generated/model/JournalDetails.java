package com.elsevier.find.reviewers.generated.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * Details about a journal
 */
@Schema(description = "Details about a journal")
@Validated



public class JournalDetails   {
  @JsonProperty("emJournalAcronym")
  private String emJournalAcronym = null;

  @JsonProperty("issnl")
  private String issnl = null;

  @JsonProperty("title")
  private String title = null;

  public JournalDetails emJournalAcronym(String emJournalAcronym) {
    this.emJournalAcronym = emJournalAcronym;
    return this;
  }

  /**
   * Journal EM acronym
   * @return emJournalAcronym
   **/
  @Schema(example = "ACR", required = true, description = "Journal EM acronym")
      @NotNull

    public String getEmJournalAcronym() {
    return emJournalAcronym;
  }

  public void setEmJournalAcronym(String emJournalAcronym) {
    this.emJournalAcronym = emJournalAcronym;
  }

  public JournalDetails issnl(String issnl) {
    this.issnl = issnl;
    return this;
  }

  /**
   * The ISSN-L of the Journal
   * @return issnl
   **/
  @Schema(example = "0736-5748", description = "The ISSN-L of the Journal")
  
    public String getIssnl() {
    return issnl;
  }

  public void setIssnl(String issnl) {
    this.issnl = issnl;
  }

  public JournalDetails title(String title) {
    this.title = title;
    return this;
  }

  /**
   * Title of the journal
   * @return title
   **/
  @Schema(example = "Journal Title", description = "Title of the journal")
  
    public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    JournalDetails journalDetails = (JournalDetails) o;
    return Objects.equals(this.emJournalAcronym, journalDetails.emJournalAcronym) &&
        Objects.equals(this.issnl, journalDetails.issnl) &&
        Objects.equals(this.title, journalDetails.title);
  }

  @Override
  public int hashCode() {
    return Objects.hash(emJournalAcronym, issnl, title);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class JournalDetails {\n");
    
    sb.append("    emJournalAcronym: ").append(toIndentedString(emJournalAcronym)).append("\n");
    sb.append("    issnl: ").append(toIndentedString(issnl)).append("\n");
    sb.append("    title: ").append(toIndentedString(title)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
