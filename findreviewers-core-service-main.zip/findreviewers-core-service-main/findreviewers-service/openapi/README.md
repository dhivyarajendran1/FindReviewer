# Open API Generation

This directory contains the specification of the Find Reviewers REST API.

## YAML Editing
The YAML file can be edited in IntelliJ with the assistance of the Swagger Plugin:
https://plugins.jetbrains.com/plugin/8347-swagger

To view the YAML in a more graphical editor it can be pasted into the following online tool:
https://editor.swagger.io/

## Code Generation
_IMPORTANT: Due to the default springfox not supporting spring-actuator at the same time we have to use springdoc
instead. This means that the parts of Swagger2SpringBoot and SwaggerDocumentationConfig that produce errors should be removed.
This is temporary while we give the team that own the generation tool to see what they want to do about this problem
(springfox causes other issues as well) as they may switch to springdoc permanently as part of the generation._

### Command Line
To generate the Jar Spring Boot code from the YAML, first download the latest version of the swagger-codegen-cli-3.X.X.jar from the following location:
https://search.maven.org/classic/#search%7Cga%7C1%7Cg%3A%22io.swagger.codegen.v3%22

(Note that you need to use a minimum of the 3.XX version to work with OpenAPI)

You can then user this Jar to generate the YAML and copy it to the project using the command run in the _findreviewers-core-service/openapi_ directory:

```
java -jar swagger-codegen-cli-3.0.33.jar generate \
        -i findreviewers.yaml \
        -l spring \
        -o springbootfiles \
        --api-package com.elsevier.find.reviewers.generated.api \
        --model-package com.elsevier.find.reviewers.generated.model \
        --invoker-package com.elsevier.find.reviewers.generated \
        --additional-properties configPackage=com.elsevier.find.reviewers.generated.config,delegatePattern=true,java8=true,defaultInterfaces=false,hideGenerationTimestamp=true,licenseUrl=https://www.elsevier.com/legal/elsevier-website-terms-and-conditions
```

Once the code is generated it can be copied into the "com.elsevier.find.reviewers.generated" package in the src directory.
(Making sure old files that are no longer required are removed)

### Gradle Task
There is a gradle task that can be run to generate and copy over the files to the correct generated directory.
This will not run as part of the build and is there to run manually to help generate the code from the YAML.

The task is under findreviewers-service -> openapi -> Tasks -> build and is called
```    generateSwaggerCode```

