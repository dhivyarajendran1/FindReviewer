def build(String version, String dockerFilePath, String nonprod_targetTag, String prod_targetTag) {
    def tags = "--tag '${nonprod_targetTag}'".toString()
    if (prod_targetTag.length() > 0) {
      tags += " --tag '${prod_targetTag}'".toString()
    }

    println "Switching docker builder"
    sh """
          docker buildx create --name pipelinebuilder --node pipelinebuilder0 --driver docker-container --bootstrap --use
      """

    println "Building Docker image"
    sh """
          docker buildx build \
              --pull \
              --platform linux/amd64,linux/arm64 \
              --push \
              --build-arg version=${version} \
              ${tags} \
              '${dockerFilePath}'
      """
  }

 def ecrLogin(String account_no) {
     println "Logging Docker into AWS ECR (region: us-east-1)"
     sh """
           aws ecr get-login-password | docker login --username AWS --password-stdin https://${account_no}.dkr.ecr.us-east-1.amazonaws.com
       """
   }

 return [
     build: this.&build,
     ecrLogin: this.&ecrLogin,
 ]
