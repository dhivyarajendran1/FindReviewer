REGION = "us-east-1"
TERRAFORM_VERSION = "tf_v1.2.2_amd"

static def getAccountNumber(String environment) {
    return environment == "rev-rec-prod" ? "338680281862" : "215048116110" as String
}

static def getBackendBucket(String environment) {
    return "elsevier-tio-aws-rap-tf-${environment}-${getAccountNumber(environment)}" as String
}

def init(String terraformScriptsDir, String environment, String backendKey) {

    println "Initializing terraform in '${environment}' for '${backendKey}'"

    def terrorPath = tool name: TERRAFORM_VERSION

    sh """
        export PATH=${terrorPath}:$PATH
        cd ${terraformScriptsDir}
        export TF_PLUGIN_CACHE_DIR=~/.terraform.d/plugin-cache
        terraform init \
            -reconfigure \
            -upgrade \
            -input=true \
            -get=true \
            -backend-config='bucket=${getBackendBucket(environment)}' \
            -backend-config='key=tfstate/${environment}-${backendKey}.json' \
            -backend-config='region=${REGION}'
    """
}

def validate(String environment, String backendKey) {

    init("./terraform", environment, backendKey)

    println "Validating terraform"
    def terrorPath = tool name: TERRAFORM_VERSION
    sh """
        export PATH=${terrorPath}:$PATH
        cd terraform
        TF_INPUT=0
        terraform validate 
    """
}

def plan(String environment, String backendKey) {

    init("./terraform", environment, backendKey)

    println "Planning terraform in ${environment}"

    def terrorPath = tool name: TERRAFORM_VERSION
    def vars = ['global_environment': environment].collect {entry -> "-var '${entry}'"}.join(" ")

    sh """
        export PATH=${terrorPath}:$PATH
        cd terraform
        TF_INPUT=0
        terraform plan -input=false ${vars}
    """
}

def apply(String environment, String backendKey) {

    init("./terraform", environment, backendKey)

    println "Applying terraform in ${environment}"

    def terrorPath = tool name: TERRAFORM_VERSION
    def vars = ['global_environment': environment].collect {entry -> "-var '${entry}'"}.join(" ")

    sh """
        export PATH=${terrorPath}:$PATH
        cd terraform
        TF_INPUT=0
        terraform apply -auto-approve -input=false ${vars}
    """
}

def getOutput(String environment, String backendKey, String outputName){

    init("./terraform", environment, backendKey)

    println "Getting terraform output '${outputName}'"

    def terrorPath = tool name: TERRAFORM_VERSION
    def outputValue = sh (
            script: """
                export PATH=${terrorPath}:$PATH
                cd terraform
                TF_INPUT=0
                terraform output -raw ${outputName}
            """,
            returnStdout: true
    ).trim()

    println "Terraform output '${outputName}' value is '${outputValue}'"

    return outputValue
}

def prepareECR(String environment,backendKey,deploymentVersion) {
     name    = environment
     region  = REGION

     apply(name, backendKey)
     def registryUrl = getOutput(name, backendKey, 'registry-url') + ":" + deploymentVersion

     return registryUrl
}

return [
    accountNumber: this.&getAccountNumber,
    validate: this.&validate,
    plan: this.&plan,
    apply: this.&apply,
    getOutput: this.&getOutput,
    prepareECR: this.&prepareECR
]
