

def manualApprovalToDeploy(String environmentType, String serviceName) {
    ansiColor('xterm') {
        timeout(time: 1, unit: 'HOURS') {
            script {
                if(environmentType.equals("nonprod")) {
                    def userInput
                    if (env.BRANCH_NAME.equalsIgnoreCase("main")) {
                        userInput = input(
                                id: 'approveDeploy', message: "Deploy ${serviceName} to Find Reviewers non-production environment?", Approve: environmentType, parameters: [
                                choice(name: 'Continue',
                                        choices: ["Yes", "No"].join("\n"),
                                        description: "Do you want to deploy ${serviceName} to nonprod?")
                        ])
                        TRIGGER_CHECK_MARX_SCAN = true
                        if ('Yes'.equals(userInput)) {
                            // OK to continue
                            return
                        }
                    } else {
                        userInput = input(
                                id: 'approveDeploy', message: "Deploy ${serviceName} to Find Reviewers non-production environment?", Approve: environmentType, parameters: [
                                choice(name: 'Continue',
                                        choices: ["Yes", "No"].join("\n"),
                                        description: "Do you want to deploy ${serviceName} to nonprod?"),
                                        
                                // If master, we don't want to ask the user twice if we want to trigger the scan
                                booleanParam(name: 'CheckMarx',
                                        defaultValue: false,
                                        description: "Do you want to proceed with a CheckMarx Scan?")
                        ])
                        // Configure a global variable based on input
                        TRIGGER_CHECK_MARX_SCAN = userInput["CheckMarx"]
                        if ('Yes'.equals(userInput["Continue"])) {
                            // OK to continue
                            return
                        }
                    }

                    // Bail out
                    currentBuild.result = 'ABORTED'
                    error("Stopping early, ${serviceName} deployment to Find Reviewers non-production environment was aborted")
                    return
                }

                if(environmentType.equals("prod")) {
                    def userInput = input(
                            id: 'approveDeploy', message: "Deploy ${serviceName} to Find Reviewers production environment?", Approve: environmentType, parameters: [
                            string(defaultValue: '',
                                    description: "Type 'prod' to approve ${serviceName} deployment to Find Reviewers production environment?",
                                    name: 'Answer'),
                            booleanParam(name: 'CheckMarx',
                                    defaultValue: true,
                                    description: "Do you want to proceed with a CheckMarx Scan?")
                    ])

                    // Configure a global variable based on input
                    TRIGGER_CHECK_MARX_SCAN = userInput["CheckMarx"]
                    if ('prod'.equals(userInput["Answer"])) {
                        // OK to continue
                        return
                    }

                    // Bail out
                    currentBuild.result = 'ABORTED'
                    error("Stopping early, ${serviceName} deployment to Find Reviewers production environment was aborted")
                    return
                }

                currentBuild.result = 'ABORTED'
                error("Deployment environment '${environmentType}' not recognised, ${serviceName} deployment was aborted")
            }
        }
    }
}

return [
    manualApprovalToDeploy: this.&manualApprovalToDeploy
]