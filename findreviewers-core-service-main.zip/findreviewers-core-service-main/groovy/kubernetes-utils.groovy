def getKubeConfigLocation(String environment) {
    return "/var/lib/jenkins/.kube/rev-rec-${environment}_config" as String
  }
  
def withKubeConfig(String environment, Closure body) {
    println("Setting 'KUBECONFIG' environment variable with '${environment}' kubeconfig location")
    env.KUBECONFIG = "/var/lib/jenkins/.kube/${environment}_config"
    body()
}

def replaceVarsInFile(String fileLocation, HashMap<String, String> vars, String newFileLocation) {
    println "Replacing vars in text from file ${fileLocation}"
    def text = readFile file: fileLocation
    vars.each {
        text = text.replaceAll("\\\$\\{${it.key}\\}", it.value)
    }
    println "Writing file ${newFileLocation} with content: ${text}"
    writeFile file: newFileLocation, text: text
}

def deploy(String environment, String imageTag, String feDomain) {
    sh """
           aws eks --region us-east-1 update-kubeconfig --name rev-rec-${environment}-eks-cluster --kubeconfig ${getKubeConfigLocation(environment)}
       """
    replaceVarsInFile(
            "./deployment.yml",
            [
                    "DOCKER_IMAGE": "${imageTag}",
                    "ENVIRONMENT" : "${environment}",
                    "FE_DOMAIN_NAME" : "${feDomain}",
                    "REPLICAS": "${environment == "prod" ? "2" : "1" }",
            ],
            "./${environment}_deployment.yml")

    println "Deploying service to ${environment} EKS"

    withKubeConfig("rev-rec-${environment}") {
        sh """
            kubectl apply -f './${environment}_deployment.yml'
        """
    }
}

return [
        withKubeConfig: this.&withKubeConfig,
        deploy: this.&deploy,
]
