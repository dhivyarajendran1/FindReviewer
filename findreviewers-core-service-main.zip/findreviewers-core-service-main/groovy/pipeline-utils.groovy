CHECKMARX_SAST_MEDIUM_THRESHOLD = 10
CHECKMARX_SAST_HIGH_THRESHOLD = 1

def triggerCheckMarxScan(projectName,
                        credentialsId,
                        teamPath = "CxServer\\SP\\Elsevier\\RAP\\SubmissionSystems",
                        serverUrl = "https://codescan.elsevier.com:443",
                        waitForResultsEnabled = true,
                        vulnerabilityThresholdEnabled = true,
                        isSastScan = true,
                        isOsaScan = false,
                        highThreshold = CHECKMARX_SAST_HIGH_THRESHOLD,
                        mediumThreshold = CHECKMARX_SAST_MEDIUM_THRESHOLD
                        ) {
    step([$class                       : 'CxScanBuilder', comment: '', excludeFolders: '', excludeOpenSourceFolders: '', exclusionsSetting: 'job',
          filterPattern                : '''!**/_cvs/**/*, !**/.svn/**/*,   !**/.hg/**/*,   !**/.git/**/*,  !**/.bzr/**/*, !**/bin/**/*,
        !**/obj/**/*,  !**/backup/**/*, !**/.idea/**/*, !**/*.DS_Store, !**/*.ipr,     !**/*.iws, !**/groovy/*.groovy,
        !**/*.bak,     !**/*.tmp,       !**/*.aac,      !**/*.aif,      !**/*.iff,     !**/*.m3u, !**/*.mid, !**/*.mp3,
        !**/*.mpa,     !**/*.ra,        !**/*.wav,      !**/*.wma,      !**/*.3g2,     !**/*.3gp, !**/*.asf, !**/*.asx,
        !**/*.avi,     !**/*.flv,       !**/*.mov,      !**/*.mp4,      !**/*.mpg,     !**/*.rm,  !**/*.swf, !**/*.vob,
        !**/*.wmv,     !**/*.bmp,       !**/*.gif,      !**/*.jpg,      !**/*.png,     !**/*.psd, !**/*.tif, !**/*.swf,
        !**/*.jar,     !**/*.zip,       !**/*.rar,      !**/*.exe,      !**/*.dll,     !**/*.pdb, !**/*.7z,  !**/*.gz,
        !**/*.tar.gz,  !**/*.tar,       !**/*.gz,       !**/*.ahtm,     !**/*.ahtml,   !**/*.fhtml, !**/*.hdm, !**/*.js,
        !**/node_modules/**, !**/*.iwl, !**/venv/**,    !../.terraform/**, !**/test/**/*, !**/generated/**/*, !**/*.gradle,
        !**/*.hdml,    !**/*.hsql,      !**/*.ht,       !**/*.hta,      !**/*.htc,     !**/*.htd, !**/*.war, !**/*.ear,
        !**/*.htmls,   !**/*.ihtml,     !**/*.mht,      !**/*.mhtm,     !**/*.mhtml,   !**/*.ssi, !**/*.stm, !**/*.html, !**/*.xml,
        !**/*.stml,    !**/*.ttml,      !**/*.txn,      !**/*.xhtm,   !**/*.class, !**/*.iml, !Checkmarx/Reports/*.*''',
    fullScanCycle: 10,
    avoidDuplicateProjectScans: true,
    fullScansScheduled: true,
    generatePdfReport: false,
    includeOpenSourceFolders: '',
    osaEnabled: isOsaScan,
    sastEnabled: isSastScan,
    preset: '36',
    credentialsId: "${credentialsId}",
    useOwnServerCredentials: true,
    projectName: "${projectName}",
    serverUrl: "${serverUrl}",
    teamPath: "${teamPath}",
    sourceEncoding: '1',
    vulnerabilityThresholdEnabled: vulnerabilityThresholdEnabled,
    // Mark build as UNSTABLE if vulnerabilities are found
    jobStatusOnError: 'UNSTABLE',
    vulnerabilityThresholdResult: "UNSTABLE",
    mediumThreshold: mediumThreshold,
    highThreshold: highThreshold,
    waitForResultsEnabled: waitForResultsEnabled])
}

def postDeploymentsToNewRelic(String newRelicApiKey, String applicationId, String serviceName, String deploymentVersion) {
    sh """
        curl -X POST "https://api.newrelic.com/v2/applications/${applicationId}/deployments.json" \\
              -H "X-Api-Key: $newRelicApiKey" \\
              -i \\
              -H "Content-Type: application/json" \\
              -d \\
        '{
            "deployment": {
                "revision": "${serviceName}-${deploymentVersion}"
            }
        }'
    """
}

return [
    triggerCheckMarxScan: this.&triggerCheckMarxScan,
    postDeploymentsToNewRelic: this.&postDeploymentsToNewRelic
]
