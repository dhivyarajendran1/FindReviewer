# Find Reviewers Core Service

Project holding the implementation of the Find Reviewers REST interface and associated service tests

##### Build
The project is built via the `findreviewer-service/bootJar` gradle build task and the output can be found in the `findreviewers-service/build/libs` directory

##### Run
The project can be run via the `bootRun` gradle application task or, if using IntelliJ, by creating a new `Jar Application` Run/Debug configuration providing the path to the built jar.  

## service-tests
The tests in `FindReviewers.feature` can be run directly on your machine by right clicking the feature file in your IDE and running the test.

You can also run these via gradle using the following command:

#### Build Latest Application
```shell script
gradle bootJar
```

#### Run Service Tests against Latest Application
```shell script
gradle cucumber
```

### Debugging Service Tests

The project uses [`testcontainers-java`](https://github.com/testcontainers/testcontainers-java) and as such, the service and dependencies all run within containers.

To debug the service while the service tests are running, you need to debug the Java service and its JVM that is running within the docker container *remotely*.

When the tests run, a random debugger port will be opened - you will see evidence of this with the following log line when tests run:

````shell script
[main] INFO com.elsevier.find.reviewers.bdd.containers.TestContainersContext - Service debugger port is: 33621
````

To capture this debugger port before the tests begin, you will need to set appropriate breakpoints (probably within the `TestContainersContext`).
Once the debugger port is captured, you can configure your remote debugging session appropriately, connect to the appropriate JVM and configure breakpoints in the service itself.

* [Configuring Remote Debugger Session in IntelliJ](https://elsevier.atlassian.net/wiki/spaces/ENGAGE/pages/51919595613/FAQ#FAQ-ConfiguringRemoteDebuggerSessioninIntelliJ)

#### Debugging Notes
You will have two debugger sessions open against two JVMs:

- a debugger session against service-tests
- a remote debugger session against the service

You will need to be mindful of these two sessions as you debug the application and the tests as this could cause confusion.


### Clean-up

[`testcontainers-java`](https://github.com/testcontainers/testcontainers-java) should handle the teardown of containers and any temporary images that were created.

Nevertheless, if anything has been left behind you can cleanup your environment with the below:

-  `docker system prune` - this will purge any containers that have stopped, dangling images and any dangling build cache.

## Authentication Testing
If you are testing EM authentication locally and you get the error:

`PKIX path building failed: sun.security.provider.certpath.SunCertPathBuilderException: unable to find valid certification path to requested target`

Then turn off ZScalar Internet Security.

